<?php
require_once('common.inc.php');
include("connection.php");


extract( $_GET );
extract( $_POST );

$year = date("Y");
$month = date("m");
$day = date("d");
$julian = "$year$month$day";
$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);
$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";
    
if(($_POST['username']==null) && ($_POST['password']==null))
{
include("companyquery.php");


    ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
      <div id="header" class="min_space"> <?php print($insertheader); ?>
        <div class="right_details"> <span class="need_help">Need Help? Call us at:</span> <span class="number"><?php print($companyphone); ?>
<br />
         <!-- <small>9:00 AM - 5:00 PM Mountain</small>--></span></div>
        <div class="menu"> &nbsp; </div>
        <img src="common/images/menu_bottom_shadow.gif" alt="" /> </div>
<?php
if($ls =="No"){
echo "<center><font size=3 color=red><B>Invalid Credentials</b></font></center><BR>";
}else if($ls =="None"){
echo "<center><font size=3 color=red><B>The username submitted is not recognized</b></font></center><BR>";
}

?>	
      <div id="body_container" > 
        <div id="left_container" >
          <div class="account_login_box" >
            <div class="top_curve">
              <div class="bottom_curve">
           
                  <fieldset > <FORM  action="login.php" method="POST">
                  <div class="left_details" >
                    <h2><img src="common/images/account_login_icon1.png" alt="" />Broker Login!</h2>
                    <label>Enter your username and password below.</label>
                    <div class="input_bg">
                      <input name="username" type="text" value="Username" onclick="if(this.value == 'Username') this.value='';" />
                    </div>
                    <div class="input_bg">
                      <input name="password" type="password" value="Password" onclick="if(this.value == 'Password') this.value='';" />
                    </div>
                    <br class="clear" />
                    <input type="submit" name="" value="" class="login_btn" onmouseover="this.className=('login_btn_over')" onmouseout="this.className=('login_btn')" />
                  </div>

<?php
if($ps =="Forgot"){
?>	

                  <div class="right_details">
                    <h2><img src="common/images/account_login_icon2.png" alt="" />Password Sent!</h2>
                    <label class="remember" ><p align="justify" >Thank you.  For security Reasons your password has been sent to the email address we have on file.  If for some reason you do not receive our email within a few moments, please check your spam filter or junk mail folder, it may be located there.  If you need further assistance you can call us at <?php print($companyphone); ?>.</p></label>
                   </div> 
	<?php
}else{
?>	

                  <div class="right_details">
                    <h2><img src="common/images/account_login_icon2.png" alt="" />Forgot Password?</h2>
                    <label class="remember">Can't Remember your password? <br />
                    Enter your user name and we will send it again.</label>
                    <div class="input_bg">
                      <input name="forgotusername" type="text" value="Username" onclick="if(this.value == 'Username') this.value='';"/>
                    </div>
                    <label>For security purposes your password will be <br />
                    sent to the email address we have on file.</label>
                    <br class="clear" />
                    <input type="submit" name="" value="" class="send_btn" onmouseover="this.className=('send_btn_over')" onmouseout="this.className=('send_btn')" />
                  </div> 
	<?php
				  }
				  ?>				  
				  
				  
				  
				  
				  
				  
				  </form>
                  </fieldset>
               
              </div>
            </div>
          </div>
        </div>
   <?php
if($companyname =="The Consumer Credit Repair Agency"){
?>
     <div id="right_container">
          <div class="safe_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h3>Safe &amp; Secure!</h3>
                <div class="row"> <a href="#"><img src="common/images/safe_image1.png" alt="" /></a> <a href="#"><img src="common/images/safe_image2.png" alt="" /></a> <a href="#"><img src="common/images/safe_image3.png" class="macfee" alt="" /></a> </div>
              </div>
            </div>
          </div>
        </div>
 </div> </div>
  <?php
}else{
  ?>

	
	<div id="right_container">
          <div class="safe_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h3>Log In Today!</h3>
                <div class="row"><img src="common/images/safe_image2.png" alt="" /></div>
              </div>
            </div>
          </div>
        </div>



      </div>
    </div>
  <?php
}
  ?>

	<div id="bottom_curve"><img src="common/images/login_bottom_curve.png" alt="" /></div>
    <div>
      <div id="footer">
        <div class="photo"><img src="common/images/footer_lock.png" alt="" /></div>
        <div class="details"> <img src="common/images/safe.png" alt="" />
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
<?php
  } 
  else
  {

 session_start();
    session_destroy();

$forgotusername = $_POST['forgotusername'];
if(($forgotusername =="") or ($forgotusername =="Username")){
///////START BROKER LOGIN
$query = "SELECT dealer_id, username, logins FROM dealers WHERE status !=9 and password='" . mysql_real_escape_string($_POST['password']) . "' and username='" . mysql_real_escape_string($_POST['username']) . "' LIMIT 1";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
if($row=mysql_fetch_assoc($result))
{
$brokerid   = $row['dealer_id'];
$brokerusername   = $row['username'];
        $logins = $row['logins'];

$is_broker = 1;

session_register('brokerid');  
session_register('brokerusername'); 
session_register('is_broker'); 

$morelogins = $logins+1;
$lastlogin = date("Y-m-d");

$query = "UPDATE dealers SET logins='$morelogins', lastlogin='$lastlogin' WHERE dealer_id=$brokerid";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());



mysql_close($conn);
header("Location: home.php");
exit();
}else{
$loginsuccess = "No";
header("Location: login.php?ls=$loginsuccess");   
exit();
}
///////END BROKER LOGIN
}else{

$query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, autoscheduler, reseller, htdiwebsite, adminsinglepayment1, adminsinglepayment2, admincouplepayment1, admincouplepayment2, single, couple, creditcard, paypal2, ach, singlefull, singledownpay1, singlepayment, couplefull, coupledownpay1, couplepayment, threeinone, paypal, months, perdelete, livehuman, dbname, dropdowncreditors, dropdownbegin, dropdowntails, autoresponder, bautoresponder, cautoresponder, helpdesk, companyheader, portals FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $autoscheduler = $row[12];          
        $reseller = $row[13];           
        $htdiwebsite = $row[14];           
        $adminsinglepayment1 = $row[15];
        $adminsinglepayment2 = $row[16];
        $admincouplepayment1 = $row[17];
        $admincouplepayment2 = $row[18];                                
        $single = $row[19];                                
        $couple = $row[20];                                
        $creditcard = $row[21];                 
        $paypal2 = $row[22];                 
        $ach = $row[23];                 
        $singlefull = $row[24];          
        $singledownpay1 = $row[25];          
        $singlepayment = $row[26];          
        $couplefull = $row[27];          
        $coupledownpay1 = $row[28];          
        $couplepayment = $row[29];          
        $threeinone = $row[30];          
        $paypal = $row[31];          
        $months = $row[32];          
        $perdelete = $row[33];          
        $livehuman = $row[34];          
        $dbname = $row[35];          
        $dropdowncreditors = $row[36];    
        $dropdownbegin = $row[37];    
        $dropdowntails = $row[38];                            
        $autoresponder = $row[39];                            
        $bautoresponder = $row[40];                            
        $cautoresponder = $row[41];                            
        $helpdesk = $row[42];                            
        $companyheader = $row[43];                            
        $portals = $row[44];                            
    }
$query = "SELECT email, username, password FROM dealers WHERE status !=9 and username='" . mysql_real_escape_string($_POST['forgotusername']) . "' LIMIT 1";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    if($row=mysql_fetch_assoc($result)){
        $clientemail   = $row['email'];
        $clientusername   = $row['username'];
        $clientpassword   = $row['password'];
	


$EMAIL_Message = "$companyskin Please find your login credentials below:<BR><BR>Password: $clientpassword<BR><BR><BR>Please login at <a href=$companywebsite/brokers>$companywebsite/brokers</a>";
$EMAIL_Subject = "Your login credentials";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From>\r\n";
                $formsent = mail($clientemail, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  

	

$loginsuccess = "Forgot";
header("Location: login.php?ps=$loginsuccess");   
exit();
}else{
$loginsuccess = "None";
header("Location: login.php?ls=$loginsuccess");   
exit();
	}


}//////END IF FORGOT
}
?>

