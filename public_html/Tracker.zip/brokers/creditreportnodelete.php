<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );


$thisbroker = $_SESSION['brokerid'];

if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
{
    include("connection.php");
   include('template.php');

             $query5 = "SELECT plan,reseller_id,prospectclient,status,broker_id FROM clients WHERE id='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "'";
              $result5 = mysql_query($query5, $conn) or die("error:" . mysql_error());
              while($row5=mysql_fetch_row($result5))
              {
                   $plan = $row5[0];
                   $reseller_id = $row5[1];                   
                   $prospectclient = $row5[2];                     
                   $status = $row5[3];     
                   $broker_id = $row5[4];     
                  }

                   if ($reseller_id != ""){
$reseller = "reseller";  
                   }
                   
                   if ($plan == "Budget"){
                   $plan2 = "Budget Account - Draft one bureau at a time!";
                   }
                 elseif ($plan == "Standard"){
                  $plan2 = "";
                  
}


if ($thisbroker != $broker_id){
?>
<font color="red"><B>You are not authorized to view this client. <?php print($thisbroker); ?></font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 }
if ($thisbroker == $broker_id){
?>

   <title><?php print($_SESSION['brokerclname']);?> Without Deleted Items</title>
<SCRIPT LANGUAGE="JavaScript">

function OpenWindow(url,winwidth,winheight) 
{
NewWindow=window.open(url,'descr','toolbar=no,location=0,directories=no,status=no,menubar=no,scrollbar=yes,scrollbars=yes,resizable=yes,copyhistory=no,width='+winwidth+',height='+winheight)
}
</script>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function ignoreQuote(string) {
var temp = "";
string = '' + string;
splitstring = string.split("'");
for(i = 0; i < splitstring.length; i++)
temp += splitstring[i];
return temp;

}
//  End -->
</script>


            <P align=center><FONT color=#000080 size=5>
Results
                  Tracker &#8482;</FONT></P>


            <P align=center> 
             

            <a href="creditreport.php">View with All accounts</a><br>
            &nbsp;</P>
            <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#000080
            cellSpacing=0 cellPadding=2 width="100%" bgColor=#c0c0c0 border=3>
              <TBODY>
              <TR>
                <TD width="50%">Client Name <font color="#000080"><?php print($_SESSION['brokerclname']);?></font></TD>
              </TR>
              </TBODY>
            </TABLE>

            <form action="creditreportnodelete.php" method="post" name=form>
            <?php
                 $i = 1;
                 $query = "SELECT id, type FROM accounttype";
                 $result = mysql_query($query, $conn) or die("error:" . mysql_error());
                 
                 while($row=mysql_fetch_row($result))
                 {
                     $actypeid = $row[0];
                     $actype = $row[1];
                     ?>
         <P align=left><FONT color=#000080><B><?php print($actype); ?> Credit
            Report</B></FONT></P>
         <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#000080
            cellSpacing=0 cellPadding=2 width="100%" border=3>
              <TBODY>
              <TR>
                <TD></TD>
                <TD>Account Name</TD>
                <TD>Account Number</TD>
                <TD>Beginning Status</TD>
                <TD>Action</TD>
                <TD>Step 1 Results</TD>
                <TD>Step 2 Results</TD>
                <TD>Step 3 Results</TD>
                <TD>Step 4 Results</TD>
                <TD>Step 5 Results</TD>
                <TD>Step 6 Results</TD>
                <TD>Step 7 Results</TD>
                <TD>Step 8 Results</TD>
                <TD>Step 9 Results</TD>
            </TR>
<?php

              $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, comments, dispute, s1dispute, deleted, s2dispute, s5result, s6result, s7result, s8result, s9result, frivolousnum, frivolousdate  FROM accounts WHERE (deleted='open' or deleted='Olddate') and clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "' and accounttype='$actypeid'";
              $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
              while($row2=mysql_fetch_row($result2))
              {
                   $accid = $row2[0];
                   $acname = $row2[1];
                   $acnumber = $row2[2];
                   $beginstatus = $row2[3];
                   $s1action = $row2[4];
                   $s1result = $row2[5];
                   $s2action = $row2[6];
                   $s2result = $row2[7];
                   $s3action = $row2[8];
                   $s3result = $row2[9];
                   $s4action = $row2[10];
                   $s4result = $row2[11];
                   $comments = $row2[12];
                   $dispute = $row2[13];
                   $s1dispute = $row2[14];
                   $deleted = $row2[15];
                   $s2dispute = $row2[16];
                   $s5result = $row2[17];
                   $s6result = $row2[18];
                   $s7result = $row2[19];
                   $s8result = $row2[20];
                   $s9result = $row2[21];    
				   $frivolousnum = $row2[22];                   
                   $frivolousdate = $row2[23];
                                                                                                              
                   $i = $i+1;
?>

             <TR>
                <TD>
                <input type="hidden" name="actypeid_<?php print($i);?>" value="<?php print($actypeid); ?>">
                 <input type="hidden" name="accid_<?php print($i);?>" value="<?php print($accid); ?>">
                 <select name="deleted_<?php print($i);?>" >
                 <option value selected="<?php print($deleted); ?>"><?php print($deleted); ?></option>
                <option value="Open">Open</option>
                <option value="Hold">Hold</option>                
                <option value="Inquiry">Inquiry</option>                      
                <option value="Fixed">Fixed</option>
                <option value="Deleted">Deleted</option>
                 </select>
                 
                </TD>
                <TD>
                <textarea name="acname_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($acname); ?></textarea></TD>
                <TD>
                <textarea name="acnumber_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($acnumber); ?></textarea></TD>
                <TD>
                <textarea name="bstatus_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($beginstatus); ?></textarea></TD>
                <TD>
                <textarea name="s1action_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($s1action); ?></textarea></TD>
                <TD>
                <textarea name="s1result_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($s1result); ?></textarea></TD>
                <TD>
                <textarea name="s2result_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($s2result); ?></textarea></TD>
                <TD>
                <textarea name="s3result_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($s3result); ?></textarea></TD>
                <TD>
                <textarea name="s4result_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($s4result); ?></textarea></TD>
                <TD>
                <textarea name="s5result_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($s5result); ?></textarea></TD>
                <TD>
                <textarea name="s6result_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($s6result); ?></textarea></TD>
                <TD>
                <textarea name="s7result_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($s7result); ?></textarea></TD>
                <TD>
                <textarea name="s8result_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($s8result); ?></textarea></TD>
                <TD>
                <textarea name="s9result_<?php print($i);?>" rows="2" cols="20" onChange="this.value=ignoreQuote(this.value)"><?php print($s9result); ?></textarea></TD>
             </TR>
<?php
    }
?>
                </TBODY>
              </TABLE>
<?php
  }
?>
 
             </form> 
              

             <p>&nbsp;</p>
             <P align=left><A href="clientstatus.php">See my Status Sheet</A></P>
              <p align="left"><a href="clientsearch.php?cname=&zip=&email=&f=1&Find=Find">Search Another Client</a></p>

             <P align=left>&nbsp;</P>
    <?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>