<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

$thisbroker = $_SESSION['brokerid'];

if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$myclients = "class='active'";

//-------client
    $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, comments, reseller_id, status, plan, DATE_FORMAT(dateresults, \"%m-%d-%Y\") as dateresults, singlecouple, showstatus, budgetday, avssnurl, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, altphone, dateresults, fonttype, jointwith, prospectclient FROM clients WHERE id='" . $_SESSION['brokerclientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $clientname = $row[0];
        $clientaddress = $row[1];
        $clientcity = $row[2];
        $clientstate = $row[3];
        $clientzip = $row[4];
        $clientemail = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $usernameu = $row[11];
        $pwdu = $row[12];
        $broker_id = $row[13];
	  $dealer_id = $row[14];
	  $affiliate_id = $row[15];
	  $comments = $row[16];
	  $reseller_id = $row[17];
	  $clientstatus = $row[18];
	  $plan = $row[19];
	  $dateresults = $row[20];
	  $singlecouple = $row[21];
	  $showstatus = $row[22];	  
	  $budgetday = $row[23];	  	  
	  $avssnurl = $row[24];	  	  	  
  	  $logins = $row[25];	  	 
	  $lastlogin = $row[26];	  	   	  
	  $altphone = $row[27];	  	   	  
	  $dateresults2 = $row[28];	  
	  $fonttype = $row[29];	  	  
	  $jointwith = $row[30];	  	 	  
	  $prospectclient = $row[31];		  

    }

	 ////////////////////CHECK FOR MASTER ACCOUNT
      $query = "SELECT account_exec FROM dealers WHERE dealer_id='$broker_id' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $masteraccount = $row[0];
    }

if ($thisbroker != $broker_id && $thisbroker != $masteraccount){
?>
<font color="red"><B>You are not authorized to view this client. <?php print($thisbroker); ?></font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 exit();
//mysql_close($conn);
}


$pageon = "My Results";

             if($country =="" or $country=="United States")   {
 $countryquery = "WHERE country = 'United States'";
 } else if($country=="Canada")   {
 $countryquery = "WHERE country = '$country'";
 } else{
 $countryquery = "WHERE country = '$country'";
 }


$query = "SELECT id, type FROM accounttype $countryquery "; 
      $result = mysql_query($query, $conn) or die("error:" . mysql_error());
      $col_count = mysql_num_fields($result);
      while($row=mysql_fetch_row($result))
      {
        $actypeid = $row[0];
        $actype = $row[1];

$query3 = "SELECT count(deleted) FROM accounts WHERE (deleted='Deleted' OR deleted='Fixed') and accounttype='$actypeid' and clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "' "; 
$result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
while($row3=mysql_fetch_row($result3))
{
$deleted2 = $row3[0];
$i = $i+1;
}

$query4 = "SELECT count(id) FROM accounts WHERE accounttype='$actypeid' and clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "' "; 
$result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
while($row3=mysql_fetch_row($result4))
{
$totalaccts = $row3[0];
$i = $i+1;
}

$totaldeletes = $totaldeletes + $deleted2;
$totalaccounts = $totalaccounts + $totalaccts;

if ($totalaccts !=0){
$percentagefixed = $deleted2/$totalaccts*100;
}
if ($actypeid == 1){
$equifaxvalue = $percentagefixed;
}if ($actypeid == 2){
$experianvalue = $percentagefixed;
}if ($actypeid == 3){
$transunionvalue = $percentagefixed;
}if ($actypeid == 8){
$equifaxcavalue = $percentagefixed;
}if ($actypeid == 9){
$transunioncavalue = $percentagefixed;
}



$datavalues .= "<set label='$actype' value='$percentagefixed' />";
}
    ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
<script type="text/javascript" src="common/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="common/js/main.js"></script>
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
     <?php

 include("header.php");
    ?>
      <div id="body_container">
        <div id="left_container">
           <div class="main_heading_box">
            <h2><img src="common/images/my_clients_icon.png" alt="" />Client Data</h2>
            <p>Please view details for <u><?php print($clientname); ?></u>.  Please use the submenu below to access Status, Notes and Results.  To expand bureaus, please click tab at the bottom of each table.</p>
          </div>
          <div class="my_results_details">
    
		  <table border="0" align="center" width="500" cellpadding="3" cellspacing="3">
	<tr>
		<td align="left"><a href="clientresults.php"><img src="common/images/client_results_btn.gif" border=0></a></td>
		<td align="center"><a href="clientnotes.php"><img src="common/images/client_notes_btn.gif" border=0></a></td>
		<td align="right"><a href="clientstatus.php"><img src="common/images/client_status_btn.gif" border=0></a></td>
	</tr>
</table>


  <?php
             if($country =="" or $country=="United States")   {
    ?>
            <div class="equifax_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>Equifax</h3>
  <?php
if($companyname =="The Consumer Credit Repair Agency"){
?><script language="JavaScript" src="../client/FusionCharts.js"></script>
<span class="miter"><div id="chartdiv2">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("../client/HLinearGauge.swf", "myChartId2", "365", "48", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='8' baseFontSize='9' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='8' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($equifaxvalue); ?></value></chart>");
                 myChart.setTransparent(true);
 myChart.render("chartdiv2");
      </script>
<?php
			}
	  ?>

				
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col2">Description</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <div class="main_table child_table"> <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
              <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "' and accounttype='1'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  $countacct = strlen($acnumber);

  if($countacct > 4){
$acnumber2 = str_repeat("x", (strlen($acnumber) - 4)) . substr($acnumber,-4,4); 
  }else{
$acnumber2 = $acnumber;
  }

  if($deleted =="Deleted" or $deleted =="Fixed"){
         $bgcolor="bgcolor=#00FF00";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
         $bgcolor="";
$derogstatus = "On Hold";
}else if($status =="scheduled"){
         $bgcolor="bgcolor=#FFCCCC";

                     $derogstatus = "Scheduled";

}else if($status =="pending"){
         $bgcolor="bgcolor=#FFFF99";

                     $derogstatus = "prepared/pending";

}else {


         $bgcolor="";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>
	
	<tr class="row" <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($acname); ?></td>
                      <td class="col5"><?php print($acnumber2); ?></td>
                      <td class="col5"><?php print($acbeginstatus); ?></td>
                      <td class="col6"><?php print($derogstatus); ?></td>
                    </tr>

 <?php
         }
     ?>
	 <tr class="row">
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                 
                  </table></div>
                  
                  
                  <span class="click"><a href="#"><img src="common/images/click.jpg" alt="" /></a></span> </div>
              </div>
            </div>
            
            <div class="equifax_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>Experian</h3>
               <?php
if($companyname =="The Consumer Credit Repair Agency"){
?>
<span class="miter"><div id="chartdiv3">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("../client/HLinearGauge.swf", "myChartId2", "365", "48", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='8' baseFontSize='9' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='8' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($experianvalue); ?></value></chart>");
                 myChart.setTransparent(true);
 myChart.render("chartdiv3");
      </script>
<?php
			}?>


                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col2">Description</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                   <div class="main_table child_table"> <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                 <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "' and accounttype='2'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     

  $countacct = strlen($acnumber);

  if($countacct > 4){
$acnumber2 = str_repeat("x", (strlen($acnumber) - 4)) . substr($acnumber,-4,4); 
  }else{
$acnumber2 = $acnumber;
  }

  if($deleted =="Deleted" or $deleted =="Fixed"){
         $bgcolor="bgcolor=#00FF00";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
         $bgcolor="";
$derogstatus = "On Hold";
}else if($status =="scheduled"){
         $bgcolor="bgcolor=#FFCCCC";

                     $derogstatus = "Scheduled";

}else if($status =="pending"){
         $bgcolor="bgcolor=#FFFF99";

                     $derogstatus = "prepared/pending";

}else {


         $bgcolor="";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>   	<tr class="row" <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($acname); ?></td>
                      <td class="col5"><?php print($acnumber2); ?></td>
                      <td class="col5"><?php print($acbeginstatus); ?></td>
                      <td class="col6"><?php print($derogstatus); ?></td>
                    </tr>

 <?php
         }
     ?>
     
                    <tr class="row">
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                  </table></div>
                  <span class="click"><a href="#"><img src="common/images/click.jpg" alt="" /></a></span> </div>
              </div>
            </div>
            
            <div class="equifax_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>TransUnion</h3>
  <?php
if($companyname =="The Consumer Credit Repair Agency"){
?>
<span class="miter"><div id="chartdiv4">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("../client/HLinearGauge.swf", "myChartId2", "365", "48", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='8' baseFontSize='9' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='8' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($transunionvalue); ?></value></chart>");
                 myChart.setTransparent(true);
 myChart.render("chartdiv4");
      </script>
<?php
			}?>


                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col2">Description</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <div class="main_table child_table">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                     <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "' and accounttype='3'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  $countacct = strlen($acnumber);

  if($countacct > 4){
$acnumber2 = str_repeat("x", (strlen($acnumber) - 4)) . substr($acnumber,-4,4); 
  }else{
$acnumber2 = $acnumber;
  }


  if($deleted =="Deleted" or $deleted =="Fixed"){
         $bgcolor="bgcolor=#00FF00";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
         $bgcolor="";
$derogstatus = "On Hold";
}else if($status =="scheduled"){
         $bgcolor="bgcolor=#FFCCCC";

                     $derogstatus = "Scheduled";

}else if($status =="pending"){
         $bgcolor="bgcolor=#FFFF99";

                     $derogstatus = "prepared/pending";

}else {


         $bgcolor="";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>
	
	<tr class="row" <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($acname); ?></td>
                      <td class="col5"><?php print($acnumber2); ?></td>
                      <td class="col5"><?php print($acbeginstatus); ?></td>
                      <td class="col6"><?php print($derogstatus); ?></td>
                    </tr>

 <?php
         }
     ?>
	 <tr class="row">
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                  </table>
                  </div>
                  <span class="click"><a href="#"><img src="common/images/click.jpg" alt="" /></a></span> </div>
              </div>
            </div>
               <?php
  }///////END IF UNITED STATES
	 /////////////////////////
	 	 /////////////////////////
		 	 /////////////////////////
  else if($country=="Canada")   {


	 ?>

	            <div class="equifax_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>Equifax</h3>
  <?php
if($companyname =="The Consumer Credit Repair Agency"){
?><script language="JavaScript" src="../client/FusionCharts.js"></script>
<span class="miter"><div id="chartdiv2">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("../client/HLinearGauge.swf", "myChartId2", "365", "48", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='8' baseFontSize='9' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='8' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($equifaxcavalue); ?></value></chart>");
                 myChart.setTransparent(true);
 myChart.render("chartdiv2");
      </script>
<?php
			}
	  ?>

				
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col2">Description</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <div class="main_table child_table"> <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
              <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "' and accounttype='1'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  $countacct = strlen($acnumber);

  if($countacct > 4){
$acnumber2 = str_repeat("x", (strlen($acnumber) - 4)) . substr($acnumber,-4,4); 
  }else{
$acnumber2 = $acnumber;
  }

  if($deleted =="Deleted" or $deleted =="Fixed"){
         $bgcolor="bgcolor=#00FF00";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
         $bgcolor="";
$derogstatus = "On Hold";
}else if($status =="scheduled"){
         $bgcolor="bgcolor=#FFCCCC";

                     $derogstatus = "Scheduled";

}else if($status =="pending"){
         $bgcolor="bgcolor=#FFFF99";

                     $derogstatus = "prepared/pending";

}else {


         $bgcolor="";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>
	
	<tr class="row" <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($acname); ?></td>
                      <td class="col5"><?php print($acnumber2); ?></td>
                      <td class="col5"><?php print($acbeginstatus); ?></td>
                      <td class="col6"><?php print($derogstatus); ?></td>
                    </tr>

 <?php
         }
     ?>
	 <tr class="row">
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                 
                  </table></div>
                  
                  
                  <span class="click"><a href="#"><img src="common/images/click.jpg" alt="" /></a></span> </div>
              </div>
            </div>
            

            
            <div class="equifax_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>TransUnion</h3>
  <?php
if($companyname =="The Consumer Credit Repair Agency"){
?>
<span class="miter"><div id="chartdiv4">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("../client/HLinearGauge.swf", "myChartId2", "365", "48", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='8' baseFontSize='9' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='8' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($transunioncavalue); ?></value></chart>");
                 myChart.setTransparent(true);
 myChart.render("chartdiv4");
      </script>
<?php
			}?>


                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col2">Description</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <div class="main_table child_table">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                     <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "' and accounttype='3'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  $countacct = strlen($acnumber);

  if($countacct > 4){
$acnumber2 = str_repeat("x", (strlen($acnumber) - 4)) . substr($acnumber,-4,4); 
  }else{
$acnumber2 = $acnumber;
  }


  if($deleted =="Deleted" or $deleted =="Fixed"){
         $bgcolor="bgcolor=#00FF00";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
         $bgcolor="";
$derogstatus = "On Hold";
}else if($status =="scheduled"){
         $bgcolor="bgcolor=#FFCCCC";

                     $derogstatus = "Scheduled";

}else if($status =="pending"){
         $bgcolor="bgcolor=#FFFF99";

                     $derogstatus = "prepared/pending";

}else {


         $bgcolor="";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>
	
	<tr class="row" <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($acname); ?></td>
                      <td class="col5"><?php print($acnumber2); ?></td>
                      <td class="col5"><?php print($acbeginstatus); ?></td>
                      <td class="col6"><?php print($derogstatus); ?></td>
                    </tr>

 <?php
         }
     ?>
	 <tr class="row">
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                  </table>
                  </div>
                  <span class="click"><a href="#"><img src="common/images/click.jpg" alt="" /></a></span> </div>
              </div>
            </div>
			

	<?php
  }
	 ?>

          </div>
        </div>
        <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
</body>
</html>
<?
}
else
{
    header("Location: login.php");
    exit();
}
?>