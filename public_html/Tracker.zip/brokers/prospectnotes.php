<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

$thisbroker = $_SESSION['brokerid'];

if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$myleads = "class='active'";

    $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, comments, reseller_id, status, plan, DATE_FORMAT(dateresults, \"%m-%d-%Y\") as dateresults, singlecouple, showstatus, budgetday, avssnurl, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, altphone, dateresults, fonttype, jointwith, prospectclient FROM clients WHERE id='" . $_SESSION['prospectclientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $clientname = $row[0];
        $clientaddress = $row[1];
        $clientcity = $row[2];
        $clientstate = $row[3];
        $clientzip = $row[4];
        $clientemail = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $usernameu = $row[11];
        $pwdu = $row[12];
        $broker_id = $row[13];
	  $dealer_id = $row[14];
	  $affiliate_id = $row[15];
	  $comments = $row[16];
	  $reseller_id = $row[17];
	  $clientstatus = $row[18];
	  $plan = $row[19];
	  $dateresults = $row[20];
	  $singlecouple = $row[21];
	  $showstatus = $row[22];	  
	  $budgetday = $row[23];	  	  
	  $avssnurl = $row[24];	  	  	  
  	  $logins = $row[25];	  	 
	  $lastlogin = $row[26];	  	   	  
	  $altphone = $row[27];	  	   	  
	  $dateresults2 = $row[28];	  
	  $fonttype = $row[29];	  	  
	  $jointwith = $row[30];	  	 	  
	  $prospectclient = $row[31];		  

    }
    
    
 ////////////////////CHECK FOR MASTER ACCOUNT
      $query = "SELECT account_exec FROM dealers WHERE dealer_id='$broker_id' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $masteraccount = $row[0];
    }

    
   if ($thisbroker != $broker_id && $thisbroker != $masteraccount){
?>
<font color="red"><B>You are not authorized to view this client. <?php print($thisbroker); ?></font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 exit();
//mysql_close($conn);
}



    $query = "SELECT DATE_FORMAT(dateenrol, \"%m-%d-%Y\") as dateenrol,  DATE_FORMAT(reportreceived, \"%m-%d-%Y\") as repdate, DATE_FORMAT(addressreceived, \"%m-%d-%Y\") as adddate, DATE_FORMAT(ssdate, \"%m-%d-%Y\") as ssdate, DATE_FORMAT(welcomepacket, \"%m-%d-%Y\") as welcomedate, DATE_FORMAT(returndoc, \"%m-%d-%Y\") as returndoc FROM enrolment WHERE clientid='" . $_SESSION['prospectclientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dateenrol = $row[0];
        $reportreceived = $row[1];
        $addressreceived = $row[2];
        $ssdate = $row[3];
        $welcomepacket = $row[4];
        $returndoc = $row[5];
   }


    $query = "SELECT auditfee, DATE_FORMAT(paid, \"%m-%d-%Y\") as paid, monthlyfee, monthlydue, payment, onlinepayment FROM billing WHERE clientid='" . $_SESSION['prospectclientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $auditfee = $row[0];
        $paid = $row[1];
        $monthlyfee = $row[2];
        $monthlydue = $row[3];
        $payment = $row[4];
        $onlinepayment = $row[5];
    }
    
    



    //mysql_close($conn);
	

    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">

      
<?php

 include("header.php");
    ?>




      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_home_icon.png" alt="" />Lead Data</h2>
            <p>Please view details for <u><?php print($clientname); ?></u>.</p>
          </div>
        

 <div class="overall_box">
            <div class="top_curve">
              <div class="bottom_curve">
		 <div class="left_details">
 <div class="my_account_datials">
                  <div class="user_details">
                    <ul>
                      <li>
                        <label>Name:</label>
                        <?php print($clientname); ?></li>
                      <li>
                        <label>Email:</label>
                        <?php print($clientemail); ?></li>
                      <li>
                        <label>Address</label>
                        <?php print($clientaddress); ?>, <?php print($clientcity); ?>, <?php print($clientstate); ?> <?php print($clientzip); ?></li>
                 <!--     <li>
                        <label>Email 2:</label>
                        ssmith@gmail.com</li>-->
                      <li>
                        <label>Phone:</label>
                        <?php print($phone); ?></li>
                      <li>
                        <label>Status:</label>
                        <?php print($clientstatus); ?></li>
                      <li>
                        <label>Enrolled:</label>
                        <?php print($dateenrol); ?></li>
                     
                    </ul>
                  </div></div>                   </div></div>                   </div></div> 




		   <div class="my_status_details">
            <div class="table_box">
              <div class="top_curve">
                <div class="bottom_curve">












                  <h3>Notes for <?php print($clientname); ?> </h3>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Date</td>
                      <td class="col2">Note</td>
                      <td class="col3">Sales Person</td>
                    </tr>
                  </table>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                  

    <?php
    $query = "SELECT DATE_FORMAT(repairdate, \"%m-%d-%Y\") as repdate,  received, action,  filelocation, counselor, id FROM  salesnotes WHERE clientid='" . $_SESSION['prospectclientid'] . "' ORDER BY repairdate DESC, id DESC";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $repairdate= $row[0];
        $received = $row[1];
        $action = $row[2];
        $filelocation = $row[3];
        $counselor= $row[4];
        $repairid= $row[5];
        

                    $bgcolor = "";

        


        ?>


                    <tr <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($repairdate); ?></td>
                      <td class="col5" ><?php print($action); ?></td>
                      <td class="col6" ><?php print($counselor); ?></td>
                    </tr>
                   <?php
    }
   // mysql_close($conn);
    ?>
                  
                  </table>
                </div>
              </div>
            </div>
          </div>




        </div>
      


<?php

 include("rightframe.php");
    ?>



        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
  </div>
</div>
</body>
</html>
    <?
}
else
{
    header("Location: login.php");
    exit();
}
?>