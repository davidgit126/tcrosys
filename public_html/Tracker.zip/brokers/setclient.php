<?php
session_start();

$_SESSION['brokerclientid']   = $_GET['cid'];
$_SESSION['brokerclname']     = $_GET['cname'];





header("Location: clientstatus.php");
exit();
?>
