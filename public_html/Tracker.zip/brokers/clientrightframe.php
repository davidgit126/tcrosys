    <?php
	

if($companyheader !=""){

    $mypicture = getimagesize("$companyheader"); 
   if($mypicture[0] > 179){
   $imagewidth = 179;
   }else{
   $imagewidth = $mypicture[0];
}
}
     ?>
	 
	 <div id="right_container">
          <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon1.png" alt="" class="icon" />Mailing Address </h4>
                <span class="credit"><img src="<?php print($companyheader); ?>" width="<?php print($imagewidth); ?>" alt="" /></span>
                <p class="gilbert"><?php print($companyaddress); ?><BR><?php print($companycity); ?>, <?php print($companystate); ?> <?php print($companyzip); ?></p>
              </div>
            </div>
          </div>




        

 <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon3.png" alt="" class="icon" />Client Results</h4>
                <p><strong><a href="clientresults.php">View Client Results</a></strong> You can view detailed deletion information for <?php print($clientname); ?> by clicking <a href="clientresults.php">here</a>.</p>
              </div>
            </div>
          </div>

   <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon2.png" alt="" class="icon" />Client Notes</h4>
                <p><strong><a href="clientnotes.php">View Notes On Account</a></strong> You can view detailed notes for <?php print($clientname); ?> by clicking <a href="clientnotes.php">here</a>.</p>
              </div>
            </div>
          </div>

		   <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon3.png" alt="" class="icon" />Client Status</h4>
                <p><strong><a href="clientstatus.php">View Client Status</a></strong> You can view overall status <?php print($clientname); ?> by clicking <a href="clientstatus.php">here</a>.</p>
              </div>
            </div>
          </div>