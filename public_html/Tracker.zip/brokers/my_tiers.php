<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

$thisbroker = $_SESSION['brokerid'];

if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$mytiers = "class='active'";

 
    

    //mysql_close($conn);
	

    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">

      
<?php

 include("header.php");
    ?>




      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_tiers_icon.png" alt="" />My Tiers</h2>
            <p>You can view all of the brokers you have referred on your tiers.  Thank you for your business.</p>
          </div>
        

          <div class="common_box">
            <div class=" top_curve">
              <div class="bottom_curve">
                <div class="my_account_datials">
                  <div class="user_details">




<font color="red">  <B> <?php print($message); ?></B></font>
<table align="center" border="0" width="600" cellspacing="5" style="border-collapse: collapse">
<td width="30%" align="center"><font size="5" color="#0066cc"><b>Tier 1</b><BR><BR></td>
<td width="5%" align="center"><font size="5" ><b></b></td>
<td width="30%" align="center"><font size="5" color="#0066cc"><b>Tier 2</b><BR><BR></td>
<td width="5%" align="center"><font size="5" ><b></b></td>
<td width="30%" align="center"><font size="5" color="#0066cc"><b>Tier 3</b><BR><BR></td>
</tr>

<tr>
<td align="center"></td>
<td align="center"></td>
<td align="center"><a href="brokerregister.php"><img src="common/images/partner_btn.png" alt="" /></a></td>
<td align="center"></td>
<td align="center"></td>
</tr>
<tr>
<td colspan=5><hr></td>

</tr>


<?php

$sql = "SELECT dealer_id, firstname, lastname, username FROM dealers WHERE tier2aff ='" . $_SESSION['brokerid'] . "' and status !=9 order by lastname";
$result = @mysql_query($sql,$conn) or die("Couldn't execute");
  while ($crow = mysql_fetch_array($result)) {	
		$tier2aff = $crow['dealer_id'];
		$tier2fname = $crow['firstname'];
		$tier2lname = $crow['lastname'];
		$tier2username = $crow['username'];
if ($tier2lname =="") {
$tier2listing = $tier2username;
}else{
$tier2listing = "$tier2lname, $tier2fname";
}
 $cnt++;

 if ($cnt == 1) {
$tier1name = "$lastname, $firstname";
}else{
$tier1name = "";
}

 ?>
<tr>
<td align="center">  <font size="3"><u><? echo "$tier1name"; ?></u></font></td>

<td align="center"></td>

<td align="center">
<div style="border-style: solid; border-width: 0; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">
  <font size="3"><u><? echo "$tier2listing"; ?></u></font></div>
</td>
<td ></td>
<td ></td>
<?php
$sql2 = "SELECT dealer_id, firstname, lastname, username FROM dealers WHERE tier2aff = '$tier2aff' and status !=9 order by lastname";
$result2 = @mysql_query($sql2,$conn) or die("Couldn't execute");
  while ($crow2 = mysql_fetch_array($result2)) {	
		$tier3aff = $crow2['dealer_id'];
		$tier3fname = $crow2['firstname'];
		$tier3lname = $crow2['lastname'];
		$tier3username = $crow2['username'];
		
	if ($tier3lname =="") {
$tier3listing = $tier3username;
}else{
$tier3listing = "$tier3lname, $tier3fname";
}	
		
?>
<tr>
<td ></td>
<td ></td>
<td ></td>
<td ></td>
<td align="center">
<div style="border-style: groove; border-width: 0; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">
  <font size="3"><u><? echo "$tier3listing"; ?></u></font>
</div>
</td>



<?php
}}
?>

       </table>







</div>


                
                </div>
              </div>
            </div>
          </div>




        </div>
      


<?php

 include("rightframe.php");
    ?>



        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
</body>
</html>
    <?
}
else
{
    header("Location: login.php");
    exit();
}
?>