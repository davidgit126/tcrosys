<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_broker']) && $_SESSION['is_broker'] == 1)
{
include('template.php');
    include("connection.php");
    
$query = "SELECT dealer_id FROM dealers where account_exec ='" . $_SESSION['brokerid'] . "'";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$brokercnt=0;
          while($row=mysql_fetch_row($result))
          {
              $masterbrokerid           = $row[0];
              $brokercnt++;
              
$masterbrokersearch .="broker_id='$masterbrokerid' or ";
}

if($brokercnt!=0)
          {
$masterprefix = "(";         
$masterbrokersearch .="broker_id='AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA') AND ";
$masterbrokersearch = "$masterprefix$masterbrokersearch";
}
    ?>
    
    

    <font color="red">  <B> <?php print($message); ?></B></font><BR>

    
    
    
    
    <p class="subtitle">Please search for the Client using one of the following criteria or click "Search" to list all</p><form action="" method="get">
        <table>
            <tr>
                <td>Client Name: </td>
                <td>
                    <input class="txtbox" type="text" name="cname" size="20">
                </td>
            </tr>
            <tr>
                <td colspan="2"><b>or</b></td>
            </tr>
            <tr>
                <td>ZIP: </td>
                <td>
                    <input class="txtbox" type="text" name="zip" size="20">
                </td>
            </tr>
            <tr>
                <td colspan="2"><b>or</b></td>
            </tr>
            <tr>
                <td>Client E-mail: </td>
                <td>
                    <input class="txtbox" type="text" name="email" size="20">
                </td>
            </tr>
        </table>
        <input type="hidden" name="f" value="1">
        <input type="submit" name="Find" value="Search">
    </form>
    
  <br>
    <br>
    
        <?php


    if($_GET['f']==1)
    {
        ?>
        List your Clients matching  search criteria </p>
        <table cellpadding="0" cellspacing="2" 
        class="outerTable">
        <tr class="formLabel" >
            <td>Name</td>
            <td>City</td>
            <td>State</td>
            <td>Enter Date</td>

        </tr>
        <?php
          if(($_GET['cname'] != null) && ($_GET['cname'] != ''))
          {
             $query = "SELECT id, name, city, state, phone, createdate, plan FROM clients WHERE broker_id ='" . $_SESSION['brokerid'] . "' AND prospectclient = 'Client' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND name LIKE('" . mysql_real_escape_string($_GET['cname']) . "%')";
          }
          else if($_GET['zip'] != '')
          {
              $query = "SELECT id, name, city, state, email, phone, createdate, plan FROM clients WHERE broker_id ='" . $_SESSION['brokerid'] . "' AND prospectclient = 'Client' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND zip='" . mysql_real_escape_string($_GET['zip']) . "'";
          }
          else if(($_GET['email'] != null) && ($_GET['email'] != ''))
          {
              $query = "SELECT id, name, city, state, email, phone, createdate, plan FROM clients WHERE broker_id ='" . $_SESSION['brokerid'] . "' AND prospectclient = 'Client' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND email LIKE('" . mysql_real_escape_string($_GET['email']) . "%')";
          }
          else
              $query = "SELECT id, name, city, state, phone, createdate, plan FROM clients WHERE broker_id ='" . $_SESSION['brokerid'] . "' AND prospectclient = 'Client' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled'";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $address      = $row[2];
              $cemail       = $row[3];
              $phone = $row[4];
              $createdate = $row[5];
              $plan  = $row[6];
              $cnt++;
              
        

$bgcolor = "FFFFFF";
              ?>
              <tr class="formField" >
              <td ><a href="setclient.php?cid=<?php print($id); ?>&cname=<?php print($clientname); ?>"><?php print($clientname); ?></a>&nbsp;</td>
              <td ><?php print($address); ?>&nbsp;</td>
              <td ><?php print($cemail); ?>&nbsp;</td>

              <td ><?php print($createdate); ?>&nbsp;</td>

              
             

              </tr>
              <?php
          }
     
          ?>
          </table>
          
           <?php

          if($brokercnt!=0)
          {
 ?>

          <BR><BR><BR>
           List of Clients you are Master Account on matching your search criteria </p>
          <table cellpadding="0" cellspacing="2" 
        class="outerTable">        <tr class="formLabel" >
            <td>Name</td>
            <td>City</td>
            <td>State</td>
            <td>Enter Date</td>
            <td>Broker</td>

        </tr>
        <?php
          if(($_GET['cname'] != null) && ($_GET['cname'] != ''))
          {
             $query = "SELECT id, name, city, state, phone, createdate, plan, broker_id FROM clients WHERE $masterbrokersearch  prospectclient = 'Client' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND name LIKE('" . mysql_real_escape_string($_GET['cname']) . "%') order by broker_id";
          }
          else if($_GET['zip'] != '')
          {
              $query = "SELECT id, name, city, state, email, phone, createdate, plan, broker_id FROM clients WHERE $masterbrokersearch  prospectclient = 'Client' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND zip='" . mysql_real_escape_string($_GET['zip']) . "' order by broker_id";
          }
          else if(($_GET['email'] != null) && ($_GET['email'] != ''))
          {
              $query = "SELECT id, name, city, state, email, phone, createdate, plan, broker_id FROM clients WHERE $masterbrokersearch  prospectclient = 'Client' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND email LIKE('" . mysql_real_escape_string($_GET['email']) . "%') order by broker_id";
          }
          else
              $query = "SELECT id, name, city, state, phone, createdate, plan, broker_id FROM clients WHERE $masterbrokersearch  prospectclient = 'Client' AND status !='expired' AND status !='canceled' AND clientdelete != 'Yes' order by broker_id";


          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $address      = $row[2];
              $cemail       = $row[3];
              $phone = $row[4];
              $createdate = $row[5];
              $plan  = $row[6];
              $broker_id  = $row[7];
              $cnt++;
              
           
$brokerlastname = "";   
$brokerfirstname = "";
            $query2 = "SELECT lastname, firstname FROM dealers WHERE dealer_id='$broker_id' ";
    $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
    while($row2=mysql_fetch_row($result2))
    {
        $brokerlastname = $row2[0];
        $brokerfirstname = $row2[1];
    }

$bgcolor = "FFFFFF";
              ?>
              <tr class="formField" >
              <td bgcolor=<?php print($bgcolor); ?>><a href="setclient.php?cid=<?php print($id); ?>&cname=<?php print($clientname); ?>"><?php print($clientname); ?></a>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($address); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($cemail); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($createdate); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?>&nbsp;</td>

              
             

              </tr>
              <?php
          }
          mysql_close($conn);
          ?>
          </table>

 <?php
}
 ?>

          <?php
         
    }
}
else
{
    header("Location: login.php");
    exit();
}

?>
