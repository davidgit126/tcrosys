<?php
require_once('common.inc.php');
session_start();


extract($_GET);
extract($_POST);


if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
{
 include("connection.php");
 include("companyquery.php");



//////START CUSTOM PAGES


  $query = "SELECT id, pagename, active, pageorder, onheader, onfooter, pagecontent, pagetitle, pagemetas, type FROM webcms WHERE pagename='$page' and type='broker'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $pagename  = $row[1];
              $active   = $row[2];
              $pageorder   = $row[3];
              $onheader = $row[4];
              $onfooter = $row[5];              
              $pagecontent = $row[6];                
              $pagetitle = $row[7];     
              $pagemetas = $row[8];                
              $pagetype = $row[9];                
$onpage = $pagename;
}






?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php print($pagetitle); ?></title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">

      
<?php

 include("header.php");

 $todaysdate =  date("F d, Y");
$year =   date("Y");

$pagecontent = str_replace("{THREEINONE}", "$threeinone", $pagecontent);
$pagecontent = str_replace("{COMPANY}", "$companyname", $pagecontent);
$pagecontent = str_replace("{COMPANYADDR}", "$companyaddress", $pagecontent);
$pagecontent = str_replace("{COMPANYCITY}", "$companycity", $pagecontent);
$pagecontent = str_replace("{COMPANYSTATE}", "$companystate", $pagecontent);
$pagecontent = str_replace("{COMPANYZIP}", "$companyzip", $pagecontent);
$pagecontent = str_replace("{COMPANYPHONE}", "$companyphone", $pagecontent);
$pagecontent = str_replace("{COMPANYFAX}", "$companyfax", $pagecontent);
$pagecontent = str_replace("{SITE}", "$companywebsite", $pagecontent);
$pagecontent = str_replace("{COMPANYEMAIL}", "$companyemail", $pagecontent);
$pagecontent = str_replace("{USERNAME}", "$username", $pagecontent);
$pagecontent = str_replace("{PASSWORD}", "$password", $pagecontent);
$pagecontent = str_replace("{F_NAME}", "$firstname", $pagecontent);
$pagecontent = str_replace("{L_NAME}", "$lastname", $pagecontent);
$pagecontent = str_replace("{BEMAIL}", "$email", $pagecontent);
$pagecontent = str_replace("{TODAYDATE}", "$todaysdate", $pagecontent);
$pagecontent = str_replace("{YEAR}", "$year", $pagecontent);


if($pagename == "Marketing"){
	$subimageheader = "my_marketing_icon.png";
}else if($pagename == "FAQ"){
	$subimageheader = "faq_icon.png";
}else {
	$subimageheader = "my_home_icon.png";
}
    ?>




      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/<?php print($subimageheader); ?>" alt="" /><?php print($pagename); ?></h2>
            <p><?php print($pagemetas); ?></p>
          </div>
          <div class="overall_box">
            <div class="top_curve">
              <div class="bottom_curve">

                <div class="cmscontent_details">
                  <h3><?php print($pagetitle); ?></h3>
                 

                  <p><?php echo $pagecontent; ?></p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      
<?php

 include("rightframe.php");
    ?>



        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
</body>
</html>
    <?
}
else
{
    header("Location: clientlogin.php");
    exit();
}
?>