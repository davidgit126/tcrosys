<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );


if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$myhome = "class='active'";

   
                	

   
    //mysql_close($conn);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<script type="text/javascript" src="common/js/dropdownmenu.js"></script>
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
<?php

 include("header.php");
    ?>
  <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_home_icon.png" alt="" />My Home</h2>
            <p class="my_accout">Welcome back, <?php print($firstname); ?>.  Use the navigation on the top or right to access different areas.  Below is a brief snapshot of what you can do.</p>
          </div>
          <div class="common_box">
            <div class=" top_curve">
              <div class="bottom_curve">
                <div class="my_account_datials">
                  <div class="user_details">

                  </div>
<table border="0" width="500" cellpadding="3" cellspacing="3">
<tr>
<td align="left" width=1><a href="my_clients.php"><img src="common/images/my_clients_icon1.png"></a></td>
<td align="left"><a style="font-size: large; color: #0066cc; font-weight: bold; text-decoration: none" href="my_clients.php"> Closely monitor your clients progress</a></td>
</tr>

<tr>
<td align="left" width=1><a href="my_leads.php"><img src="common/images/my_leads_icon1.png"></a></td>
<td align="left"><a style="font-size: large; color: #0066cc; font-weight: bold; text-decoration: none" href="my_leads.php"> View follow up details of hot new leads</a></td>
</tr>

<?php
 if($commission !=0){     
    ?>   
<tr>
<td align="left" width=1><a href="my_comms.php"><img src="common/images/common_box_icon4.png"></a></td>
<td align="left"><a style="font-size: large; color: #0066cc; font-weight: bold; text-decoration: none" href="my_comms.php"> Track all your commissions earned to date</a></td>
</tr>
<?php
}
    ?>   

<?php
 if($tier2comm !=0){     
    ?>   
<tr>
<td align="left" width=1><a href="my_comms.php"><img src="common/images/my_tiers_icon1.png"></a></td>
<td align="left"><a style="font-size: large; color: #0066cc; font-weight: bold; text-decoration: none" href="my_tiers.php"> View your tiers and submit a referral partner</a></td>
</tr>
<?php
}
    ?>   


<?php
if($htdiwebsite == "Yes"){
$query = "SELECT pagename FROM webcms WHERE active='Yes' and type='broker' and pagename='Marketing'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $marketingpageexists = $row[0];
	}

if($marketingpageexists != ""){

	    ?>   

<tr>
<td align="left" width=1><a href="cms.php?page=Marketing"><img src="common/images/my_marketing_icon2.png"></a></td>
<td align="left"><a style="font-size: large; color: #0066cc; font-weight: bold; text-decoration: none" href="cms.php?page=Marketing"> Grab banners, links and other materials</a></td>
</tr>
  <?php
}}
     
    ?>
	


	<?php
if($htdiwebsite == "Yes"){
$query = "SELECT pagename FROM webcms WHERE active='Yes' and type='broker' and pagename='FAQ'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $faqpageexists = $row[0];
	}

if($faqpageexists != ""){

	    ?>   

<tr>
<td align="left" width=1><a href="cms.php?page=FAQ"><img src="common/images/common_box_icon2.png"></a></td>
<td align="left"><a style="font-size: large; color: #0066cc; font-weight: bold; text-decoration: none" href="cms.php?page=FAQ"> Learn answers to frequently asked questions</a></td>
</tr>
  <?php
}}
     
    ?>   
</table>


                </div>
              </div>
            </div>
          </div>
        </div>
      <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
</body>
</html>
  <?
}
else
{
    header("Location: login.php");
    exit();
}
?>