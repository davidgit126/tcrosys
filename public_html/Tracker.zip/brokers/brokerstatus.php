<?php
require_once('common.inc.php');
session_start();


extract($_GET);
extract($_POST);



if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
  {
include('template.php');
      include("connection.php");

      if($_POST['updatecl'] == 1)
      {
        
        $query = "UPDATE dealers SET
                lastname='" . mysql_real_escape_string($_POST['lastname']) . "',
                firstname='" . mysql_real_escape_string($_POST['firstname']) . "',
                address='" . mysql_real_escape_string($_POST['address']) . "',
                dealership='" . mysql_real_escape_string($_POST['dealership']) . "',                
                city='" . mysql_real_escape_string($_POST['city']) . "',
                prov='" . mysql_real_escape_string($_POST['prov']) . "',
                zipcode='" . mysql_real_escape_string($_POST['zipcode']) . "',
                email='" . mysql_real_escape_string($_POST['email']) . "',
                fax='" . mysql_real_escape_string($_POST['fax']) . "',
                telephone='" . mysql_real_escape_string($_POST['telephone']) . "',
                emailnotify='" . mysql_real_escape_string($_POST['emailnotify']) . "',
                notification='" . mysql_real_escape_string($_POST['notification']) . "',
                
                password='" . mysql_real_escape_string($_POST['password']) . "'

                WHERE dealer_id='" . $_SESSION['brokerid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());


   }
  $query = "SELECT dbname FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dbname = $row[0];
    }
    
    
    if ($_POST['action'] == "addpic"){
$dbpart = explode('_', $dbname); 
$dbpart = $dbpart[0];
  $uploadbroker = "/home/$dbpart/public_html/brokers/pics/";

if ($HTTP_POST_VARS['submit']) {
  print_r($HTTP_POST_FILES);
  if (!is_uploaded_file($HTTP_POST_FILES['file']['tmp_name'])) {
    $error = "You did not upload a file!";
    unlink($HTTP_POST_FILES['file']['tmp_name']);
    // assign error message, remove uploaded file, redisplay form.
  } else {
    //a file was uploaded
    $maxfilesize=307200;


    if ($HTTP_POST_FILES['file']['size'] > $maxfilesize) {
      $error = "file is too large"; unlink($HTTP_POST_FILES['file']['tmp_name']);
      // assign error message, remove uploaded file, redisplay form.
    } else {
      if ($HTTP_POST_FILES['file']['type'] != "image/gif" AND $HTTP_POST_FILES['file']['type'] != "image/pjpeg") { 
        $error = "This file type is not allowed";
        unlink($HTTP_POST_FILES['file']['tmp_name']);
        // assign error message, remove uploaded file, redisplay form.
      } else {
      
      $jpg = ".jpg";
       //File has passed all validation, copy it to the final destination and remove the temporary file:
       copy($HTTP_POST_FILES['file']['tmp_name'],"$uploadbroker".$_POST['ssnforfile'].$jpg);
       unlink($HTTP_POST_FILES['file']['tmp_name']);
      $error = "Image successfully uploaded!";
       
       $file = $_POST['ssnforfile'].$jpg;
$newurl = $file;

$query = "UPDATE dealers SET
                url='$newurl'
                WHERE dealer_id='" . $_SESSION['brokerid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        
     }
    } 
  }
}}

if ($_POST['action'] == "removepic")
    {
        $query = "UPDATE dealers SET
                url=''
                WHERE dealer_id='" . $_SESSION['brokerid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
              $error = "Image successfully removed!";

    }

   
          
   
                	

    $query = "SELECT lastname, firstname, address, city, prov, zipcode, email, fax, telephone, dealership, username, password, comments, dealer_id, affiliate_id, emailnotify, notification, url   FROM dealers WHERE dealer_id='" . $_SESSION['brokerid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lastname = $row[0];
        $firstname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $prov = $row[4];
        $zipcode = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $telephone = $row[8];
        $dealership = $row[9];
        $username = $row[10];
        $password = $row[11];
	    $comments = $row[12];
		$dealer_id = $row[13];			
		$affiliate_id = $row[14];			
		$emailnotify = $row[15];			
		$notification = $row[16];			
		$url = $row[17];			

    }
   

    
    if ($emailnotify == 0) {
$emailnotifyname = "Notifications Off";
}else if  ($emailnotify == 1) {
$emailnotifyname = "Client Updates Only";
}else if  ($emailnotify == 2) {
$emailnotifyname = "Client Updates & New Lead Submissions";
}else if  ($emailnotify == 3) {
$emailnotifyname = "Client Updates, New Lead Submissions & Updates";
}

 if ($notification == 0) {
$notificationname = "No";
}else if  ($notification == 1) {
$notificationname = "Yes";
}

 

$bgcolor = "c0c0c0";


    //mysql_close($conn);
?>
 

                 <font color="red">  <B> <?php print($error); ?></B></font>
                      
                      
                    

                      
                  

                      
                     <table width="820" cellspacing="2" cellpadding="0" border="0" align="center">
	 <tr >
    <td class="subtitle" height="19">Your Account Information</td>
  </tr>
	<tr>
		<td>            
      <form name="broker" action="brokerstatus.php"    method="post" >
     <table width="100%" cellspacing="2" cellpadding="0" class="outerTable">
 
  <tr>
    <td class="formLabel" width="110" height="23">Username</td>
    <td class="formField" width="270" height="23" colspan="3">
      <?php print($username);?></td>
  </tr>
  
  <tr>
    <td class="formLabel" width="110" height="23">Password</td>
    <td class="formField" width="270" height="23" colspan="3">
                            <input type="text" class="inputMed" name="password" value="<?php print($password);?>" size="20"></td>
  </tr>
  
  <tr>
    <td class="formLabel" height="2" colspan="4"></td>
  </tr>
  
  <tr>
    <td class="formLabel" width="110" height="23">First Name</td>
    <td class="formField" width="270" height="23">
<input class="inputMed" name="firstname" value="<?php print($firstname); ?>" size="20"></td>
      
      
    <td class="formLabel" height="23">Company</td>
    <td class="formField" height="23">
<input class="inputLong" size="45" name="dealership" value="<?php print($dealership); ?>"></td>
  </tr>
  
  <tr>
    <td class="formLabel" height="23">Last Name</td>
    <td class="formField" height="23">
<input class="inputMed" name="lastname" value="<?php print($lastname); ?>" size="20"></td>
      
      
    <td class="formLabel" height="23">Address</td>
    <td class="formField" height="23">
                                        <input class="inputLong" size="45" name="address" value="<?php print($address); ?>"></td>
  </tr>
  <tr>
      
      
    <td class="formLabel" height="23">Email</td>
    <td class="formField" height="23">
<input class="inputLong" name="email" value="<?php print($email); ?>" size="36"></td>
    
    
    <td class="formLabel" height="23">City, State, Zip</td>
    <td class="formField" height="23">
                                        <input class="inputMed" size="17" name="city" value="<?php print($city); ?>">,<input class="inputSuperShort" name="prov" value="<?php print($prov); ?>" size="4"><input class="inputShort" size="10" name="zipcode" value="<?php print($zipcode); ?>"></td>
  </tr>
  <tr>
    
    
    <td class="formLabel" height="12">Phone</td>
    <td class="formField" height="12">
<input class="inputMed" name="telephone" value="<?php print($telephone); ?>" size="20"></td>
    
    
    <td class="formLabel" height="12"></td>
    <td class="formField" height="12">
                                        </td>
  </tr>
  <tr>
    
    
    <td class="formLabel" height="11">Email Settings</td>
    <td class="formField" height="11" colspan="3">
                                        <select class="txtbox"   name="emailnotify">
					    <option value="<?php print($emailnotify); ?>" selected><?php print($emailnotifyname); ?></option>                                        
					    <option value="0" >Notifications Off</option>
					    <option value="1" >Client Updates Only</option>
					    <option value="2" >Client Updates & New Leads</option>
					    <option value="3" >Client Updates, New Leads & Updates</option>
					    </select></td>
    
    
  </tr>
  <tr>
    
    
    <td class="formLabel" height="12" colspan="2">Show your info on your 
    clients' portals.</td>
    
    
    <td class="formField" height="12" colspan="2"> 
                                        <select class="txtbox"   name="notification">
					    <option value="<?php print($notification); ?>" selected><?php print($notificationname); ?></option>                                        
					    <option value="0" >No</option>
					    <option value="1" >Yes</option>
					    </select></td>
  </tr>
  </table>
              
         <BR>  
            <input type="hidden" name="updatecl" value="1">
                           
 <input type="submit" name="Update" value="Update">
 
</form>                            
                       
        
<?php
            if ($url == "NULL"  or $url ==""){
            ?>
             <p>

<BR>
<form action="" method="post" enctype="multipart/form-data">

Choose image upload to your file (this will be shown on your clients' accounts if set to YES above)<br>
<input class="txtbox" type="file" name="file" size="60"><br>
<input type="hidden" name="ssnforfile" value="<?php print($_SESSION['brokerid']); ?>">
<input type="hidden" name="action" value="addpic"><br>
<input type="submit" name="submit" value="Submit"> <br>
&nbsp;</form>

<?php
           
}else{
?>
  <img border="0" src="pics/<?php print($url); ?>"><BR>
  <form action="" method="post" enctype="multipart/form-data">


Remove this image from your record
<br>

<input type="hidden" name="action" value="removepic">
<input type="submit" name="submit" value="Remove"> <br>
&nbsp;</form>  <?php
 }
?>
               
                       
            </td>
  </tr>
</table>
  
                       
                      
                      
                 
                  
                   
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>