<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );


if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$myleads = "class='active'";

$query = "SELECT dealer_id FROM dealers where account_exec ='" . $_SESSION['brokerid'] . "'";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$brokercnt=0;
          while($row=mysql_fetch_row($result))
          {
              $masterbrokerid           = $row[0];
              $brokercnt++;
              
$masterbrokersearch .="broker_id='$masterbrokerid' or ";
}

if($brokercnt!=0)
          {
$masterprefix = "(";         
$masterbrokersearch .="broker_id='AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA') AND ";
$masterbrokersearch = "$masterprefix$masterbrokersearch";
}



?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<script type="text/javascript" src="common/js/dropdownmenu.js"></script>
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
<?php

 include("header.php");
    ?>
  <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_leads_icon.png" alt="" />My Leads</h2>
            <p class="my_accout">Please search for the Lead using one of the following criteria or click "Submit" to list all. </p>
          </div>


  <div class="common_box">
            <div class=" top_curve">
              <div class="bottom_curve">
                <div class="my_account_datials">
                  <div class="user_details">
 <form action="" method="get"><ul>
 <li>
                        <label>Name:</label>
<input class="txtbox" type="text" name="cname" size="20"></li>
                      <li>
                        <label>E-mail:</label>
<input class="txtbox" type="text" name="email" size="20"></li>
						
											  
											 
                    </ul> <input type="hidden" name="f" value="1">
        <input type="image" src="common/images/diputes_submit.gif" name="submit">
		
	
    </form>
                  </div>
                         

                 
                </div>
              </div>
            </div>
          </div>





 <?php
	    if($_GET['f']==1){
$titlemessage = "List of your prospects matching search criteria";
 }else{
$titlemessage = "Below is a list of the 5 most recent prospects.  Use search fields above to expand.";
 }
        ?>

		   <div class="my_status_details">
            <div class="table_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3><?php print($titlemessage); ?></h3>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Date</td>
                      <td class="col2">Name</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                   

    <?php
          if(($_GET['cname'] != null) && ($_GET['cname'] != ''))
          {
             $query = "SELECT id, name, city, state, phone, createdate, plan, status FROM clients WHERE broker_id ='" . $_SESSION['brokerid'] . "' AND prospectclient = 'Prospect' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND name LIKE('" . mysql_real_escape_string($_GET['cname']) . "%')";
          }
          else if($_GET['zip'] != '')
          {
              $query = "SELECT id, name, city, state, email, phone, createdate, plan, status FROM clients WHERE broker_id ='" . $_SESSION['brokerid'] . "' AND prospectclient = 'Prospect' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND zip='" . mysql_real_escape_string($_GET['zip']) . "'";
          }
          else if(($_GET['email'] != null) && ($_GET['email'] != ''))
          {
              $query = "SELECT id, name, city, state, email, phone, createdate, plan, status FROM clients WHERE broker_id ='" . $_SESSION['brokerid'] . "' AND prospectclient = 'Prospect' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND email LIKE('" . mysql_real_escape_string($_GET['email']) . "%')";
          }
          else

		  
		  
    if($_GET['f']==1){
		  $query = "SELECT id, name, city, state, phone, createdate, plan, status FROM clients WHERE broker_id ='" . $_SESSION['brokerid'] . "' AND prospectclient = 'Prospect' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled'";
	}else{
		  $query = "SELECT id, name, city, state, phone, createdate, plan, status FROM clients WHERE broker_id ='" . $_SESSION['brokerid'] . "' AND prospectclient = 'Prospect' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' order by createdate desc LIMIT 5";
	}
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $address      = $row[2];
              $cemail       = $row[3];
              $phone = $row[4];
              $createdate = $row[5];
              $plan  = $row[6];
              $status  = $row[7];
              $cnt++;
			  
			  
			  if($filelocation !=""){
         $bgcolor = "bgcolor=#FFCCCC";
}else {

                    $bgcolor = "";

                    }


        ?>


                    <tr <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($createdate); ?></td>
                      <td class="col5" ><a href="setprospect.php?cid=<?php print($id); ?>&cname=<?php print($clientname); ?>"><?php print($clientname); ?></a></td>
                      <td class="col6" ><?php print($status); ?></td>
                    </tr>
                   <?php
    }
   // mysql_close($conn);
    ?>
                    <tr>
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                   
                  </table>
                </div>
              </div>
            </div>
          </div>



 <?php

	  
	
	/////start master accounts
	?>



 <?php


          if($brokercnt!=0 && $_GET['f']==1)
    {
        ?>
		   <div class="my_status_details">
            <div class="table_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>List of clients you are Master Account on matching your search criteria</h3>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Date</td>
                      <td class="col2">Name</td>
                      <td class="col3">Broker</td>
					  </tr>
                  </table>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                   

    <?php
           if(($_GET['cname'] != null) && ($_GET['cname'] != ''))
          {
             $query = "SELECT id, name, city, state, phone, createdate, plan, broker_id, status FROM clients WHERE $masterbrokersearch  prospectclient = 'Prospect' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND name LIKE('" . mysql_real_escape_string($_GET['cname']) . "%') order by broker_id";
          }
          else if($_GET['zip'] != '')
          {
              $query = "SELECT id, name, city, state, email, phone, createdate, plan, broker_id, status FROM clients WHERE $masterbrokersearch  prospectclient = 'Prospect' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND zip='" . mysql_real_escape_string($_GET['zip']) . "' order by broker_id";
          }
          else if(($_GET['email'] != null) && ($_GET['email'] != ''))
          {
              $query = "SELECT id, name, city, state, email, phone, createdate, plan, broker_id, status FROM clients WHERE $masterbrokersearch  prospectclient = 'Prospect' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' AND email LIKE('" . mysql_real_escape_string($_GET['email']) . "%') order by broker_id";
          }
          else
              $query = "SELECT id, name, city, state, phone, createdate, plan, broker_id, status FROM clients WHERE $masterbrokersearch  prospectclient = 'Prospect' AND status !='expired' AND status !='canceled' AND clientdelete != 'Yes' order by broker_id";


          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $address      = $row[2];
              $cemail       = $row[3];
              $phone = $row[4];
              $createdate = $row[5];
              $plan  = $row[6];
              $broker_id  = $row[7];
              $status  = $row[8];

              $cnt++;
			  
$brokerlastname = "";   
$brokerfirstname = "";
            $query2 = "SELECT lastname, firstname FROM dealers WHERE dealer_id='$broker_id' ";
    $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
    while($row2=mysql_fetch_row($result2))
    {
        $brokerlastname = $row2[0];
        $brokerfirstname = $row2[1];
    }

			  
			  if($filelocation !=""){
         $bgcolor = "bgcolor=#FFCCCC";
}else {

                    $bgcolor = "";

                    }


        ?>


                    <tr <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($createdate); ?></td>
                      <td class="col5" ><a href="setprospect.php?cid=<?php print($id); ?>&cname=<?php print($clientname); ?>"><?php print($clientname); ?></a></td>
                      <td class="col6" ><?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?></td>
                    </tr>
                   <?php
    }
   // mysql_close($conn);
    ?>
                    <tr>
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                   
                  </table>
                </div>
              </div>
            </div>
          </div>



 <?php

	}        ?>




        
        </div>
      <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
</body>
</html>
  <?
}
else
{
    header("Location: login.php");
    exit();
}
?>