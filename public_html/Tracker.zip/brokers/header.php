<?php
 $query = "SELECT lastname, firstname, address, city, prov, zipcode, email, fax, telephone, dealership, username, password, comments, dealer_id, affiliate_id, emailnotify, notification, url, commission, tier2comm, tier3comm, bio, bioapproved, address2, checkssn   FROM dealers WHERE dealer_id='" . $_SESSION['brokerid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lastname = $row[0];
        $firstname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $prov = $row[4];
        $zipcode = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $telephone = $row[8];
        $dealership = $row[9];
        $username = $row[10];
        $password = $row[11];
	    $comments = $row[12];
		$dealer_id = $row[13];			
		$affiliate_id = $row[14];			
		$emailnotify = $row[15];			
		$notification = $row[16];			
		$url = $row[17];			
	    $commission = $row[18];			
	    $tier2comm = $row[19];			
	    $tier3comm = $row[20];			
	    $bio = $row[21];			
	    $bioapproved = $row[22];			
	    $address2 = $row[23];			
	    $checkssn = $row[24];			
		}
          $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_brokers WHERE broker_id='" . $_SESSION['brokerid'] . "' GROUP BY broker_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}


    
    if ($emailnotify == 0) {
$emailnotifyname = "Notifications Off";
}else if  ($emailnotify == 1) {
$emailnotifyname = "Client Updates Only";
}else if  ($emailnotify == 2) {
$emailnotifyname = "Client Updates & New Lead Submissions";
}else if  ($emailnotify == 3) {
$emailnotifyname = "Client Updates, New Lead Submissions & Updates";
}

 if ($notification == 0) {
$notificationname = "No";
}else if  ($notification == 1) {
$notificationname = "Yes";
}
 ?>

<div id="header"> <?php print($insertheader); ?>

		<div class="right_details"> <span class="logout"><a href="logout.php">Log Out</a></span> <span class="number"><?php print($companyphone); ?><br />
          <!--<small>M-F 9:00 AM - 5:00 PM MTN</small>--> </span> <span class="welcome">Welcome, <?php print($firstname); ?> <?php print($lastname); ?><BR>
		             <!-- <a href="#">You Have <font color="green">4</font> New Messages </a>--></span>
</div>  <div class="menu">
          <ul>

		

            <li <?php print($myhome); ?>><a href="home.php">My Home</a></li>
            <li <?php print($myaccount); ?>><a href="my_account.php">My Account</a></li>
            <li <?php print($myclients); ?>><a href="my_clients.php">My Clients</a></li>
            <li <?php print($myleads); ?>><a href="my_leads.php">My Leads</a></li>

      <?php
 if($commission !=0){     
    ?>                         <li <?php print($mycomms); ?>><a href="my_comms.php">My Commissions</a></li>

      <?php
	  }
 if($tier2comm !=0){     
    ?>                         <li <?php print($mytiers); ?>><a href="my_tiers.php">My Tiers</a></li>


<?php
	  }
      if($htdiwebsite == "Yes"){

$query = "SELECT pagename FROM webcms WHERE active='Yes' and onheader='Yes' and type='broker' and pageorder > 0 order by pageorder";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $pagenamelink = $row[0];

      if($onpage == $pagenamelink){
$mycms = "class='active'";
	  }else{
$mycms = "";
	  }
$headerlinks .="<li $mycms><a href=\"cms.php?page=$pagenamelink\">$pagenamelink</a></li>";
    }


echo $headerlinks;
}   
    ?>
</ul>
          <!-- <span class="new_message"><a href="#">You Have <small>4</small> New Messages </a></span>-->
           </div>
		           <img src="common/images/menu_bottom_shadow.gif" alt="" /> </div>