<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

$thisbroker = $_SESSION['brokerid'];
if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$myclients = "class='active'";

    $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, comments, reseller_id, status, plan, DATE_FORMAT(dateresults, \"%m-%d-%Y\") as dateresults, singlecouple, showstatus, budgetday, avssnurl, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, altphone, dateresults, fonttype, jointwith, prospectclient FROM clients WHERE id='" . $_SESSION['brokerclientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $clientname = $row[0];
        $clientaddress = $row[1];
        $clientcity = $row[2];
        $clientstate = $row[3];
        $clientzip = $row[4];
        $clientemail = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $usernameu = $row[11];
        $pwdu = $row[12];
        $broker_id = $row[13];
	  $dealer_id = $row[14];
	  $affiliate_id = $row[15];
	  $comments = $row[16];
	  $reseller_id = $row[17];
	  $clientstatus = $row[18];
	  $plan = $row[19];
	  $dateresults = $row[20];
	  $singlecouple = $row[21];
	  $showstatus = $row[22];	  
	  $budgetday = $row[23];	  	  
	  $avssnurl = $row[24];	  	  	  
  	  $logins = $row[25];	  	 
	  $lastlogin = $row[26];	  	   	  
	  $altphone = $row[27];	  	   	  
	  $dateresults2 = $row[28];	  
	  $fonttype = $row[29];	  	  
	  $jointwith = $row[30];	  	 	  
	  $prospectclient = $row[31];		  

    }
    
if($showstatus ==""){
$showstatus = "&nbsp;";
}
    
 ////////////////////CHECK FOR MASTER ACCOUNT
      $query = "SELECT account_exec FROM dealers WHERE dealer_id='$broker_id' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $masteraccount = $row[0];
    }

    
   


    $query = "SELECT DATE_FORMAT(dateenrol, \"%m-%d-%Y\") as dateenrol,  DATE_FORMAT(reportreceived, \"%m-%d-%Y\") as repdate, DATE_FORMAT(addressreceived, \"%m-%d-%Y\") as adddate, DATE_FORMAT(ssdate, \"%m-%d-%Y\") as ssdate, DATE_FORMAT(welcomepacket, \"%m-%d-%Y\") as welcomedate, DATE_FORMAT(returndoc, \"%m-%d-%Y\") as returndoc FROM enrolment WHERE clientid='" . $_SESSION['brokerclientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dateenrol = $row[0];
        $reportreceived = $row[1];
        $addressreceived = $row[2];
        $ssdate = $row[3];
        $welcomepacket = $row[4];
        $returndoc = $row[5];
   }


    $query = "SELECT auditfee, DATE_FORMAT(paid, \"%m-%d-%Y\") as paid, monthlyfee, monthlydue, payment, onlinepayment FROM billing WHERE clientid='" . $_SESSION['brokerclientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $auditfee = $row[0];
        $paid = $row[1];
        $monthlyfee = $row[2];
        $monthlydue = $row[3];
        $payment = $row[4];
        $onlinepayment = $row[5];
    }
    
    
if ($thisbroker != $broker_id && $thisbroker != $masteraccount){
?>
<font color="red"><B>You are not authorized to view this client. <?php print($thisbroker); ?></font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 exit();




    //mysql_close($conn);
	
}
    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">

      
<?php

 include("header.php");
    ?>




      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_clients_icon.png" alt="" />Client Data</h2>
            <p>Please view details for <u><?php print($clientname); ?></u>.  Please use the submenu below to access Status, Notes and Results.</p>
          </div>
          <div class="overall_box">
            <div class="top_curve">
              <div class="bottom_curve">

               <div class="left_details">
 <div class="my_account_datials">
                  <div class="user_details">
<table border="0" align="center" width="500" cellpadding="3" cellspacing="3">
	<tr>
		<td align="left"><a href="clientresults.php"><img src="common/images/client_results_btn.gif" border=0></a></td>
		<td align="center"><a href="clientnotes.php"><img src="common/images/client_notes_btn.gif" border=0></a></td>
		<td align="right"><a href="clientstatus.php"><img src="common/images/client_status_btn.gif" border=0></a></td>
	</tr>
</table>
<HR>


				  
				  <ul>
                      <li>
                        <label>Name:</label>
                        <?php print($clientname); ?></li>
                      <li>
                        <label>Email:</label>
                        <?php print($clientemail); ?></li>
                      <li>
                        <label>Address</label>
                        <?php print($clientaddress); ?>, <?php print($clientcity); ?>, <?php print($clientstate); ?> <?php print($clientzip); ?></li>
                 <!--     <li>
                        <label>Email 2:</label>
                        ssmith@gmail.com</li>-->
                      <li>
                        <label>Phone:</label>
                        <?php print($phone); ?></li>
                      <li>
                        <label>Status:</label>
                        <?php print($clientstatus); ?></li>
                      <li>
                        <label>Enrolled:</label>
                        <?php print($dateenrol); ?></li>
                     
                    </ul>
                  </div>
                       
 <?php
             if($country =="" or $country=="United States")   {
 $countryquery = "WHERE country = 'United States'";
 } else if($country=="Canada")   {
 $countryquery = "WHERE country = '$country'";
 } else{
 $countryquery = "WHERE country = '$country'";
 }

$query = "SELECT id, type FROM accounttype $countryquery "; 
      $result = mysql_query($query, $conn) or die("error:" . mysql_error());
      $col_count = mysql_num_fields($result);
      while($row=mysql_fetch_row($result))
      {
        $actypeid = $row[0];
        $actype = $row[1];

 $query3 = "SELECT count(deleted) FROM accounts WHERE (deleted='Deleted' OR deleted='Fixed') and accounttype='$actypeid' and clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "'";
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $deleted2 = $row3[0];
                   $i = $i+1;
}
 $query4 = "SELECT count(id) FROM accounts WHERE accounttype='$actypeid' AND clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "'";
              $result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result4))
              {
                   $totalaccts = $row3[0];
                   $i = $i+1;
}


$totaldeletes = $totaldeletes + $deleted2;
$totalaccounts = $totalaccounts + $totalaccts;

if ($totalaccts !=0){
$percentagefixed = $deleted2/$totalaccts*100;
}
if ($actypeid == 1){
$equifaxvalue = $percentagefixed;
}if ($actypeid == 2){
$experianvalue = $percentagefixed;
}if ($actypeid == 3){
$transunionvalue = $percentagefixed;
}if ($actypeid == 8){
$equifaxcavalue = $percentagefixed;
}if ($actypeid == 9){
$transunioncavalue = $percentagefixed;
}

	  }

?>


  <p align="center">
                            <?php

if($companyname !="The Consumer Credit Repair Agency"){
    if($totalaccts !="0")
    {
       function encodeDataURL($strDataURL, $addNoCacheStr=false) {
    if ($addNoCacheStr==true) {
		if (strpos($strDataURL,"?")<>0)
			$strDataURL .= "&FCCurrTime=" . Date("H_i_s");
		else
			$strDataURL .= "?FCCurrTime=" . Date("H_i_s");
    }
	return urlencode($strDataURL);
}


function datePart($mask, $dateTimeStr) {
    @list($datePt, $timePt) = explode(" ", $dateTimeStr);
    $arDatePt = explode("-", $datePt);
    $dataStr = "";
    if (count($arDatePt) == 3) {
        list($year, $month, $day) = $arDatePt;
        // determine the request
        switch ($mask) {
        case "m": return $month;
        case "d": return $day;
        case "y": return $year;
        }
        return (trim($month . "/" . $day . "/" . $year));
    }
    return $dataStr;
}


function renderChart($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false, $registerWithJS=false, $setTransparent="") {
	if ($strXML=="")
        $tempData = "//Set the dataURL of the chart\n\t\tchart_$chartId.setDataURL(\"$strURL\")";
    else
        $tempData = "//Provide entire XML data using dataXML method\n\t\tchart_$chartId.setDataXML(\"$strXML\")";

    $chartIdDiv = $chartId . "Div";
    $ndebugMode = boolToNum($debugMode);
    $nregisterWithJS = boolToNum($registerWithJS);
	$nsetTransparent=($setTransparent?"true":"false");
$render_chart = <<<RENDERCHART

	<!-- START Script Block for Chart $chartId -->
	<div id="$chartIdDiv" align="center">
		Chart.
	</div>
	<script type="text/javascript">	
		var chart_$chartId = new FusionCharts("$chartSWF", "$chartId", "$chartWidth", "$chartHeight", "$ndebugMode", "$nregisterWithJS");
      chart_$chartId.setTransparent("$nsetTransparent");
    
		$tempData
		chart_$chartId.render("$chartIdDiv");
	        </script>	
	<!-- END Script Block for Chart $chartId -->
RENDERCHART;

  return $render_chart;
}


function renderChartHTML($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false,$registerWithJS=false, $setTransparent="") {
    $strFlashVars = "&chartWidth=" . $chartWidth . "&chartHeight=" . $chartHeight . "&debugMode=" . boolToNum($debugMode);
    if ($strXML=="")
        $strFlashVars .= "&dataURL=" . $strURL;
    else
        $strFlashVars .= "&dataXML=" . $strXML;
    
    $nregisterWithJS = boolToNum($registerWithJS);
    if($setTransparent!=""){
      $nsetTransparent=($setTransparent==false?"opaque":"transparent");
    }else{
      $nsetTransparent="window";
    }
$HTML_chart = <<<HTMLCHART
	<!-- START Code Block for Chart $chartId -->
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="$chartWidth" height="$chartHeight" id="$chartId">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="$chartSWF"/>		
		<param name="FlashVars" value="$strFlashVars&registerWithJS=$nregisterWithJS" />
		<param name="quality" value="high" />
		<param name="wmode" value="$nsetTransparent" />
		<embed src="$chartSWF" FlashVars="$strFlashVars&registerWithJS=$nregisterWithJS" quality="high" width="$chartWidth" height="$chartHeight" name="$chartId" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="$nsetTransparent" /></object>
	<!-- END Code Block for Chart $chartId -->
HTMLCHART;

  return $HTML_chart;
}

function boolToNum($bVal) {
    return (($bVal==true) ? 1 : 0);
}





	$fixed = $totaldeletes/$totalaccounts*100;
	$open = ($totalaccounts-$totaldeletes)/($totalaccounts)*100;
		$strXML  = "<chart numberSuffix='%25' bgcolor='FFFFFF' caption='Items fixed/deleted: $totaldeletes out of $totalaccounts'  showZeroPies='0' chartTopMargin='0' chartBottomMargin='0' showPercentValues='1' showAboutMenuItem='0' showPrintMenuItem='0' showValues='1' showYAxisValues ='0' formatNumberScale='0' showShadow='1' startingAngle='90' use3DLighting ='1' showBorder='1'>";
	$strXML .= "<set label='Open' value='$open' color='1496c7' isSliced='1'  />";
	$strXML .= "<set label='Improved' value='$fixed' color='95c731'/>";
	$strXML .= "</chart>";
	
	echo renderChartHTML("http://www.tcrosystems.net/Pie2D.swf", "", $strXML, "myFirst", 500, 300, false, false);
 }
  }//////END IF NOT JOE





if($companyname =="The Consumer Credit Repair Agency"){
if($totalaccounts !=""){
	$fixed = $totaldeletes/$totalaccounts*100;
$fixedchart = number_format($fixed, 0, '.', '');
}
	 ?>     
	 <table><tr><td valign="top">
<div class="left_details">
<h3>Overall Improvement<BR><?php print($fixedchart); ?>%</h3>

<script language="JavaScript" src="../client/FusionCharts.js"></script>
 <div id="chartdiv" align="center">
         The chart will appear within this DIV. This text will be replaced by the chart.
      </div>
	   <script type="text/javascript">
	
var myChart = new FusionCharts("../client/AngularGauge.swf", "myChartId", "325", "175", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='0' chartRightMargin='0' chartTopMargin='0' showAboutMenuItem='0' bgAlpha='0,0' showBorder='0' gaugeFillMix='{light-10},{light-30},{light-20},{dark-5},{color},{light-30},{light-20},{dark-10}' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' gaugeStartAngle='180' gaugeEndAngle='0' palette='1' numberSuffix='%25' tickValueDistance='10' showValue='1'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><dials><dial value='<?php print($fixed); ?>' rearExtension='10'/></dials></chart>");
         myChart.setTransparent(true);
		 myChart.render("chartdiv");
      </script>
</div>
</td>


<?php

$eqxchart = number_format($equifaxvalue, 0, '.', '');
$expchart = number_format($experianvalue, 0, '.', '');
$tuchart = number_format($transunionvalue, 0, '.', '');
	  ?>

<td valign="top">
<div class="right_details">

<h3>Equifax - <?php print($eqxchart); ?>% Improvement</h3>
<span><div id="chartdiv2" align="center">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("../client/HLinearGauge.swf", "myChartId2", "300", "50", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='4' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='9' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($equifaxvalue); ?></value></chart>");
               myChart.setTransparent(true);
   myChart.render("chartdiv2");
      </script>
	  
	  <h3 class="space">Experian - <?php print($expchart); ?>% Improvement</h3>
<span><div id="chartdiv3" align="center">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("../client/HLinearGauge.swf", "myChartId2", "300", "50", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='4' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='9' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($expchart); ?></value></chart>");
               myChart.setTransparent(true);
   myChart.render("chartdiv3");
      </script>

                  <h3 class="space">TransUnion - <?php print($tuchart); ?>% Improvement</h3>
<span><div id="chartdiv4" align="center">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("../client/HLinearGauge.swf", "myChartId2", "300", "50", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='4' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='9' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($tuchart); ?></value></chart>");
               myChart.setTransparent(true);
   myChart.render("chartdiv4");
      </script>
  </div>
</td></tr></table>
















<?php
}
	  ?>



























</div>
 </div>                    

                <div class="content_details">
                  <h3>Current status of <?php print($clientname); ?> is:</h3>
                  <ul>
                    <li><?php print($showstatus); ?></li>
                  </ul>
                
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
    <p>&nbsp;</p>
	</div>
              </div>
            </div>
          </div>
		  




        </div>
      


<?php

 include("rightframe.php");
    ?>



        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
</body>
</html>
    <?
}
else
{
    header("Location: login.php");
    exit();
}
?>