<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

$thisbroker = $_SESSION['brokerid'];

if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
{
    include("connection.php");
include('template.php');
    
         $query5 = "SELECT plan,reseller_id,prospectclient,status,broker_id FROM clients WHERE id='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "'";
              $result5 = mysql_query($query5, $conn) or die("error:" . mysql_error());
              while($row5=mysql_fetch_row($result5))
              {
                   $plan = $row5[0];
                   $reseller_id = $row5[1];                   
                   $prospectclient = $row5[2];                     
                   $status = $row5[3];     
                   $broker_id = $row5[4];     
                  }

                    ////////////////////CHECK FOR MASTER ACCOUNT
      $query = "SELECT account_exec FROM dealers WHERE dealer_id='$broker_id' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $masteraccount = $row[0];
    }
    
                   if ($reseller_id != ""){
$reseller = "reseller";  
                   }
                   
                   if ($plan == "Budget"){
                   $plan2 = "Budget Account - Draft one bureau at a time!";
                   }
                 elseif ($plan == "Standard"){
                  $plan2 = "";
                  
}

if ($thisbroker != $broker_id && $thisbroker != $masteraccount){
?>
<font color="red"><B>You are not authorized to view this client. <?php print($thisbroker); ?></font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 }
if ($thisbroker == $broker_id or $thisbroker == $masteraccount){

$query = "SELECT status FROM clients WHERE id='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "'"; 
      $result = mysql_query($query, $conn) or die("error:" . mysql_error());
      $col_count = mysql_num_fields($result);
      while($row=mysql_fetch_row($result))
      {
        $status = $row[0];
}

?>



   <title><?php print($_SESSION['brokerclname']);?></title>

          
          <table cellpadding="0" cellspacing="2" 
        class="outerTable">
              <TBODY>
              <TR class="formLabel" >
                <TD ><?php print($_SESSION['brokerclname']);?>&nbsp;</TD>
              </TR>
              </TBODY>
            </TABLE>

            <form action="creditreport.php" method="post" name=form>
            <?php
                 $i = 1;
                 $query = "SELECT id, type FROM accounttype";
                 $result = mysql_query($query, $conn) or die("error:" . mysql_error());
                 
                 while($row=mysql_fetch_row($result))
                 {
                     $actypeid = $row[0];
                     $actype = $row[1];
                     ?>
         <P class="subtitle" align=left><?php print($actype); ?>
 <table width="100%" cellpadding="0" cellspacing="2" 
        class="outerTable">

              <TBODY>
                <TR class="formLabel" >
         <TD width="12%" ><b>Account Name</b></TD>
        <TD width="12%" ><b>Account#</b></TD>
        <TD width="12%" ><b>Type</b></TD>
        <TD width="12%" ><b>Action</b></TD>
        <TD width="13%" ><b>Status</b></TD>
    </TR>
          
<?php

              $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['brokerclientid']) . "' and accounttype='$actypeid'";
              $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
              while($row2=mysql_fetch_row($result2))
              {
                    $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  if($deleted =="Deleted" or $deleted =="Fixed"){
         $textcss = "00CC99";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
                    $textcss = "FFFFFF";
                     $derogstatus = "On Hold";
}else if($status =="scheduled"){

                    $textcss = "FFCCCC";
                     $derogstatus = "Scheduled";

}else if($status =="pending"){

                    $textcss = "FFFF99";
                     $derogstatus = "prepared/pending";

}else {


                    $textcss = "FFFFFF";
                     $derogstatus = "In Dispute";

                    }
?>

             <TR class="formField" >
        <TD width="12%" bgcolor="#<?php print($textcss);?>"><?php print($acname); ?>&nbsp;</TD>
        <TD width="12%" bgcolor="#<?php print($textcss);?>"><?php print($acnumber); ?>&nbsp;</TD>
        <TD width="12%" bgcolor="#<?php print($textcss);?>"><?php print($acbeginstatus); ?>&nbsp;</TD>
        <TD width="12%" bgcolor="#<?php print($textcss);?>"><?php print($s1action); ?>&nbsp;</TD>
        <TD width="13%" bgcolor="#<?php print($textcss);?>"><?php print($derogstatus); ?>&nbsp;</TD>
      </TR>
<?php
    }
?>
                </TBODY>
              </TABLE>
<?php
  }
?>

 
             </form>

 
             

             <p>&nbsp;</p>
             <P align=left><A href="clientstatus.php">See Status Sheet</A></P>
              <p align="left"><a href="clientsearch.php?cname=&zip=&email=&f=1&Find=Find">Search Another Client</a></p>

             <P align=left>&nbsp;</P>
    <?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>