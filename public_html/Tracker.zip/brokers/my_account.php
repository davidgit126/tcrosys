<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

if($_SESSION['is_broker'] == 1 AND $_SESSION['brokerid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$myaccount = "class='active'";

      if($_POST['updatecl'] == 1)
      {
        
        $query = "UPDATE dealers SET
                lastname='" . mysql_real_escape_string($_POST['lastname']) . "',
                firstname='" . mysql_real_escape_string($_POST['firstname']) . "',
                address='" . mysql_real_escape_string($_POST['address']) . "',
                address2='" . mysql_real_escape_string($_POST['address2']) . "',
				dealership='" . mysql_real_escape_string($_POST['dealership']) . "',                
                city='" . mysql_real_escape_string($_POST['city']) . "',
                prov='" . mysql_real_escape_string($_POST['prov']) . "',
                zipcode='" . mysql_real_escape_string($_POST['zipcode']) . "',
                email='" . mysql_real_escape_string($_POST['email']) . "',
                fax='" . mysql_real_escape_string($_POST['fax']) . "',
                telephone='" . mysql_real_escape_string($_POST['telephone']) . "',
                emailnotify='" . mysql_real_escape_string($_POST['emailnotify']) . "',
                notification='" . mysql_real_escape_string($_POST['notification']) . "',
                
                password='" . mysql_real_escape_string($_POST['password']) . "'

                WHERE dealer_id='" . $_SESSION['brokerid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());


   }

         if($_POST['updatebio'] == 1)
      {
        
        $query = "UPDATE dealers SET
                bio='" . mysql_real_escape_string($_POST['bio']) . "',
                bioapproved='No'
                WHERE dealer_id='" . $_SESSION['brokerid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
   }


  $query = "SELECT dbname FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dbname = $row[0];
    }
    
    
    if ($_POST['action'] == "addpic"){
$dbpart = explode('_', $dbname); 
$dbpart = $dbpart[0];
  $uploadbroker = "/home/$dbpart/public_html/brokers/pics/";

if ($HTTP_POST_VARS['submit']) {
  print_r($HTTP_POST_FILES);
  if (!is_uploaded_file($HTTP_POST_FILES['file']['tmp_name'])) {
    $error = "You did not upload a file!";
    unlink($HTTP_POST_FILES['file']['tmp_name']);
    // assign error message, remove uploaded file, redisplay form.
  } else {
    //a file was uploaded
    $maxfilesize=307200;


    if ($HTTP_POST_FILES['file']['size'] > $maxfilesize) {
      $error = "file is too large"; unlink($HTTP_POST_FILES['file']['tmp_name']);
      // assign error message, remove uploaded file, redisplay form.
    } else {
      if ($HTTP_POST_FILES['file']['type'] != "image/gif" AND $HTTP_POST_FILES['file']['type'] != "image/pjpeg") { 
        $error = "This file type is not allowed";
        unlink($HTTP_POST_FILES['file']['tmp_name']);
        // assign error message, remove uploaded file, redisplay form.
      } else {
      
      $jpg = ".jpg";
       //File has passed all validation, copy it to the final destination and remove the temporary file:
       copy($HTTP_POST_FILES['file']['tmp_name'],"$uploadbroker".$_POST['ssnforfile'].$jpg);
       unlink($HTTP_POST_FILES['file']['tmp_name']);
      $error = "Image successfully uploaded!";
       
       $file = $_POST['ssnforfile'].$jpg;
$newurl = $file;

$query = "UPDATE dealers SET
                url='$newurl'
                WHERE dealer_id='" . $_SESSION['brokerid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        
     }
    } 
  }
}}

if ($_POST['action'] == "removepic")
    {
        $query = "UPDATE dealers SET
                url=''
                WHERE dealer_id='" . $_SESSION['brokerid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
              $error = "Image successfully removed!";

    }

   
          
   
                	

   
    //mysql_close($conn);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<script type="text/javascript" src="common/js/dropdownmenu.js"></script>
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
<?php

 include("header.php");
    ?>
  <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_account_icon.png" alt="" />My Account</h2>
            <p class="my_accout">To change or update your personal information please use the form below.  If you need help please call us at <?php print($companyphone); ?>, during regular business hours. </p>
          </div>
          <div class="common_box">
            <div class=" top_curve">
              <div class="bottom_curve">
                <div class="my_account_datials">
                  <div class="user_details">
 <form name="broker" action=""    method="post" >                    <ul>
 <li>
                        <label>Username:</label>
<?php print($username); ?></li>
                      <li>
                        <label>Password:</label>
                        <input class="input_bg" type="password" name="password" value="<?php print($password);?>" size="21"></li>
						
											  
											  <li>
                        <label>First Name:</label>
                        <input class="input_bg" name="firstname" value="<?php print($firstname); ?>" size="30"></li>
                      <li>
                        <label>Last Name:</label>
                        <input name="lastname" value="<?php print($lastname); ?>" size="20"></li>
                      <li>
                        <label>Address</label>
                        <input name="address" value="<?php print($address); ?>" size="30"></li>
                      <li>
                        <label>City/St/Zip:</label>
<input size="12" name="city" value="<?php print($city); ?>">,<input name="prov" value="<?php print($prov); ?>" size="2"><input size="5" name="zipcode" value="<?php print($zipcode); ?>"></li>
 <li>
                        <label>Email:</label>
<input name="email" value="<?php print($email); ?>" size="30"></li>
                      <li>
                        <label>Phone:</label>
<input name="telephone" value="<?php print($telephone); ?>" size="20"></li>
                     
 <li>					  
 <label>Company:</label>
<input size="30" name="dealership" value="<?php print($dealership); ?>"></li>
 <li>					  
 <label>Website:</label>
<input size="30" name="address2" value="<?php print($address2); ?>"></li>
                   				  
         <ul>
 <li>
                        <label>Settings:</label>
 <select class="txtbox"   name="emailnotify">
					    <option value="<?php print($emailnotify); ?>" selected><?php print($emailnotifyname); ?></option>                                        
					    <option value="0" >Notifications Off</option>
					    <option value="1" >Client Updates Only</option>
					    <option value="2" >Client Updates & New Leads</option>
					    <option value="3" >Client Updates, New Leads & Updates</option>
					    </select></li>
                      
					
											  
											  <li>
                        <label>Show Info:</label>
                         <select class="txtbox"   name="notification">
					    <option value="<?php print($notification); ?>" selected><?php print($notificationname); ?></option>                                        
					    <option value="0" >No</option>
					    <option value="1" >Yes</option>
					    </select>
						
						</li>
                     
           
                    </ul>
                  </div>
				  <input type="hidden" name="updatecl" value="1">
                           
 <input type="image" src="common/images/diputes_submit.gif" name="submit">
 
</form>                            

<HR>
<!-- BIO AREA -->

 <style type="text/css"> 
/* <![CDATA[ */

textarea
{
	clear: both;
	display: block;
	padding: 4px 4px 4px 4px;
	border: 0px;
	font-family: Verdana, sans-serif; 
	font-size: 11px;

}
 
/* ]]> */
</style>

                    <?php
if ($bioapproved == "No"){
$biomessage ="Awaiting Approval";
					}
            ?>

 <div class="please_mail">
   <h4>Your Bio: <font color=green size=1><?php print($biomessage); ?></font></h4>        
<form action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="updatebio" value="1">
                           
<textarea  class="expand75-250 " style="font-size:8pt;" name="bio" size="20" rows="6" cols="105"><?php print($bio); ?></textarea>
    <BR><BR>

 
<input type="image" src="common/images/diputes_submit.gif" name="submit">


  </form>
                  </div>
<HR>
                  <div class="please_mail">
                    <h4>Your Picture:</h4>
                    <?php
            if ($url == "NULL"  or $url ==""){
            ?>
             <p>

<BR>
<form action="" method="post" enctype="multipart/form-data">

Choose image upload to your file (this will be shown on your clients' accounts if set to YES above)<br>
<input class="txtbox" type="file" name="file" size="60"><br>
<input type="hidden" name="ssnforfile" value="<?php print($_SESSION['brokerid']); ?>">
<input type="hidden" name="action" value="addpic"><br>
<input type="submit" name="submit" value="Submit">
<br>
&nbsp;</form>

<?php
           
}else{
?>
  <img border="0" src="pics/<?php print($url); ?>"><BR>
  <form action="" method="post" enctype="multipart/form-data">


Remove this image from your record
<br>

<input type="hidden" name="action" value="removepic">
 <input type="image" src="common/images/diputes_submit.gif" name="submit"> <br>
&nbsp;</form>  <?php
 }
?>



                  </div>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
<script type="text/javascript" src="../admin/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="../admin/jquery.textarea-expander.js"></script>

</body>
</html>
  <?
}
else
{
    header("Location: login.php");
    exit();
}
?>