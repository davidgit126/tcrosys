<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>


<h1>  Server Maintenance </h1>
<p>
HTDI Financial will be conducting a scheduled server maintenance on Friday evening, January 27, 2012 beginning at 11:59pm MNT.
<p>During this window your admin, customer, broker and affiliate portals will be offline and unavailable.
<p>This maintenance is necessary to ensure continued service levels and HTDI will work hard to minimize overall system downtime as much as possible.
<p>Service Affected: Admin, Customer, Broker, Affiliate Portals
<p>Start Date: Friday, January 27, 2012 ( 11:59 pm MTN*)
<p>End: Saturday, January 28 2012 ( 11:59 pm MTN*)
<p>Duration: 24 hours*
<p>Reason: Hardware Server Upgrade
<p>* All times approximated.
<p>We appreciate your patience during this maintenance and welcome any feedback. For support or additional information please contact our team at 877.877.4834.
</body>
</html>
