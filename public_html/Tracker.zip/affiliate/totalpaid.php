<?php
extract( $_GET );
extract( $_POST );
?>
<?php
require_once('common.inc.php');
ob_start();
session_start();

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_affiliate']) && $_SESSION['is_affiliate'] == 1)
  {
 include("connection.php");
include("template.php");

     

$bgcolor = "c0c0c0";


    
?>
 

                 <font color="red">  <B> <?php print($error); ?></B></font>
                        <p align="center">
                        <font size="5" color="#000080">Total Paid</font></p>



     
  
  
       
 



                      

                       

                        
                      
                     
                        <div align="center">
                          <center>
                         <b><font color="#FF0000" face="Verdana" size="2"><?php print($message); ?>
                          </font></b>
                         
                            
                            <BR>
                            
                           

                             <table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="75%" id="AutoNumber3" cellpadding="3">
 										
 <tr>
                              <td width="100%" valign="top">
                              <p align="center"><b>
                              <font face="Verdana" size="4"><?php print($_SESSION['clname']); ?></font></b></td>
                            </tr>
                            <tr>
                              <td width="100%" valign="top">
                              <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5">
                                <tr>
                                  <td width="12%"><b>Pay Date</b></td>
                                  <td width="11%"><b>Check #</b></td>
                                  <td width="62%"> 
                                        <b>Notes</b></td>
                                  <td width="15%"> 
                                        <b>Pay Amount</b></td>
                                </tr>
                                
                                 <?php
    $query = "SELECT payment_date, ck_number, notes, payment_amount FROM commission_affiliate WHERE affiliate_id='" . $_SESSION['affiliateid'] . "' and payment_amount != '' ORDER BY payment_date DESC";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $check_date= $row[0];
        $check_num = $row[1];
        $notes = $row[2];
        $amount_paid = $row[3];

?>
                                <tr>
                                
                                  <td width="12%"><?php print($check_date); ?></td>
                                  <td width="11%"><?php print($check_num); ?></td>
                                  <td width="62%"><?php print($notes); ?></td>
                                  <td width="15%">$<?php print($amount_paid); ?></td>
                              
 </tr>
               <?php
       }
      
?>                   
                                <tr>
                                  <td width="100%" colspan="4">
                                  <p align="center">&nbsp;</td>
                                </tr>
                              </table>
                              </td>
                            </tr>
                            </table>

                          </center>
</div>
                        <p align="left">
                        <a href="affiliatestatus.php">Back</a>
                        &nbsp;
                        </p>
                        
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>