<?php
extract( $_GET );
extract( $_POST );
?>
<?php
require_once('common.inc.php');
session_start();

if($_SESSION['is_affiliate'] == 1 AND $_SESSION['affiliateid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$myleads = "class='active'";


?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<script type="text/javascript" src="common/js/dropdownmenu.js"></script>
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
<?php

 include("header.php");
    ?>
  <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_leads_icon.png" alt="" />My Leads</h2>
            <p class="my_accout">Please search for the Lead using one of the following criteria or click "Submit" to list all. </p>
          </div>


  <div class="common_box">
            <div class=" top_curve">
              <div class="bottom_curve">
                <div class="my_account_datials">
                  <div class="user_details">
 <form action="" method="get"><ul>
<li><label>Name:</label><input class="txtbox" type="text" name="cname" size="20"></li>
<li><label>Status:</label><input class="txtbox" type="text" name="status" size="20"></li>
						
											  
											 
                    </ul> <input type="hidden" name="f" value="1">
        <input type="image" src="common/images/diputes_submit.gif" name="submit">
		
	
    </form>
                  </div>
                         

                 
                </div>
              </div>
            </div>
          </div>





 <?php
	    if($_GET['f']==1){
$titlemessage = "List of leads submissions matching search criteria";
 }else{
$titlemessage = "Below is a list of the 5 most recent lead submissions.  Use search fields above to expand.";
 }

  if (! $cname) {
$cnamequery = "";
}else{
$cnamequery = " AND name LIKE('%" . mysql_real_escape_string($_GET['cname']) . "%')";
}
  if (! $status) {
$statusquery = "";
}else{
$statusquery = " AND status LIKE('%" . mysql_real_escape_string($_GET['status']) . "%')";
}


        ?>

		   <div class="my_status_details">
            <div class="table_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3><?php print($titlemessage); ?></h3>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Date</td>
                      <td class="col2">Name</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                   

    <?php
    if($_GET['f']==1){
		  $query = "SELECT id, name, city, state, phone, DATE_FORMAT(createdate, \"%m-%d-%Y\") as createdate, plan, status FROM clients WHERE affiliate_id ='" . $_SESSION['affiliateid'] . "' $cnamequery $statusquery AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled'";
	}else{
		  $query = "SELECT id, name, city, state, phone, DATE_FORMAT(createdate, \"%m-%d-%Y\") as createdate, plan, status FROM clients WHERE affiliate_id ='" . $_SESSION['affiliateid'] . "' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' order by createdate desc LIMIT 5";
	}
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $address      = $row[2];
              $cemail       = $row[3];
              $phone = $row[4];
              $createdate = $row[5];
              $plan  = $row[6];
              $status  = $row[7];
              $cnt++;
			  
			  
			  if($filelocation !=""){
         $bgcolor = "bgcolor=#FFCCCC";
}else {

                    $bgcolor = "";

                    }


        ?>


                    <tr <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($createdate); ?></td>
                      <td class="col5" ><a href="setprospect.php?cid=<?php print($id); ?>&cname=<?php print($clientname); ?>"><?php print($clientname); ?></a></td>
                      <td class="col6" ><?php print($status); ?></td>
                    </tr>
                   <?php
    }
   // mysql_close($conn);
    ?>
                    <tr>
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                   
                  </table>
                </div>
              </div>
            </div>
          </div>






        
        </div>
      <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
</body>
</html>
  <?
}
else
{
    header("Location: login.php");
    exit();
}
?>