    <?php
	

if($companyheader !=""){

    $mypicture = getimagesize("$companyheader"); 
   if($mypicture[0] > 179){
   $imagewidth = 179;
   }else{
   $imagewidth = $mypicture[0];
}
}
     ?>
	 
	 <div id="right_container">
          <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon1.png" alt="" class="icon" />Mailing Address </h4>
                <span class="credit"><img src="<?php print($companyheader); ?>" width="<?php print($imagewidth); ?>" alt="" /></span>
                <p class="gilbert"><?php print($companyaddress); ?><BR><?php print($companycity); ?>, <?php print($companystate); ?> <?php print($companyzip); ?></p>
              </div>
            </div>
          </div>



<!--
	 <?php
	

if($url ==""){
$picturebox = "<BR>You have no picture uploaded.  To upload a picture please <a href=\"my_account.php\">click here</a><BR><BR>";
}else{
    $brokerpicture = getimagesize("pics/$url"); 
   if($brokerpicture[0] > 185){
   $brokerimagewidth = 185;
   }else{
   $brokerimagewidth = $brokerpicture[0];
}
$picturebox = "<img border=\"0\" src=\"pics/$url\" width=\"$brokerimagewidth\">";
}
     ?>
          <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4>My Picture</h4>
                <p align="center"><BR><?php print($picturebox); ?>
				</p>
              </div>
            </div>
          </div>

 <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/my_account_icon3.png" alt="" class="icon" />My Account</h4>
                <p><strong><?php print($firstname); ?> <?php print($lastname); ?> <a href="my_account.php"><font size="1" face="Verdana">(update)</font></a></strong><BR>
				<?php print($dealership); ?><BR><?php print($address); ?><BR><?php print($city); ?>, <?php print($prov); ?> <?php print($zipcode); ?></p>
              </div>
            </div>
          </div>
-->
<?php
if($htdiwebsite == "Yes"){
$query = "SELECT pagename FROM webcms WHERE active='Yes' and type='affiliate' and pagename='FAQ'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $faqpageexists = $row[0];
	}

if($faqpageexists != ""){

	    ?>   

          <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon2.png" alt="" class="icon" />Frequently Asked </h4>
                <p><strong><a href="cms.php?page=FAQ">Can I Track My Commissions?</a></strong> Yes, you can view the total commissions earned to date and what is scheduled to be paid by clicking <a href="my_comms.php">here</a>.</p>
              </div>
            </div>
          </div>

			  <?php
}}
     
    ?>   
		  <?php
if($htdiwebsite == "Yes"){
$query = "SELECT pagename FROM webcms WHERE active='Yes' and type='affiliate' and pagename='Marketing'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $marketingpageexists = $row[0];
	}

if($marketingpageexists != ""){

	    ?>   

          <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/my_marketing_icon1.png" alt="" class="icon" />Marketing Materials</h4>
                <p><strong><a href="cms.php?page=Marketing">Committed To Your Success</a></strong> Find the banners, links and other creative materials that will help you maximize your referral experience.</p>
              </div>
            </div>
          </div>

			  <?php
}}
     
    ?>   