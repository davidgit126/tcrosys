<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_affiliate']) && $_SESSION['is_affiliate'] == 1)
  {
 include("connection.php");
include("template.php");

      if($_POST['updatecl'] == 1)
      {
        
        $query = "UPDATE sales_affiliates SET
                lname='" . mysql_real_escape_string($_POST['lname']) . "',
                fname='" . mysql_real_escape_string($_POST['fname']) . "',
                address='" . mysql_real_escape_string($_POST['address']) . "',
                city='" . mysql_real_escape_string($_POST['city']) . "',
                state='" . mysql_real_escape_string($_POST['state']) . "',
                zip='" . mysql_real_escape_string($_POST['zip']) . "',
                email='" . mysql_real_escape_string($_POST['email']) . "',
                fax='" . mysql_real_escape_string($_POST['fax']) . "',
                phone='" . mysql_real_escape_string($_POST['phone']) . "',
                alt_phone='" . mysql_real_escape_string($_POST['altphone']) . "',
                password='" . mysql_real_escape_string($_POST['pwdu']) . "'
                WHERE id='" . $_SESSION['affiliateid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

                	}

    $query = "SELECT lname, fname, address, city, state, zip, email, fax, phone, ssn, user, password, comments, alt_phone, commission_rate, id FROM sales_affiliates WHERE id='" . $_SESSION['affiliateid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lname = $row[0];
        $fname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $state = $row[4];
        $zip = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $phone = $row[8];
        $ssnum = $row[9];
        $usernameu = $row[10];
        $pwdu = $row[11];
	    $comments = $row[12];
	    $altphone = $row[13];	  	   	  
		$commission_rate = $row[14];	 
		$affiliate_id = $row[15];			

    }
    
  

  $query3 = "SELECT count(id) FROM clients WHERE prospectclient = 'Client' AND affiliate_id = '$affiliate_id'";
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $totalcredit = $row3[0];
                   $affiliateearn = $totalcredit * $commission_rate;
}

 $query = "SELECT sum(amount_paid) as total_paid FROM commission_affiliate WHERE affiliate_id = '$affiliate_id'";

              $result = mysql_query($query, $conn) or die("error:" . mysql_error());
              while($row=mysql_fetch_array($result))
              {
                   $total_paid = $row[total_paid];
                    $total_due = $affiliateearn - $total_paid;
}


    
    

$bgcolor = "c0c0c0";


    //mysql_close($conn);
?>

                 <font color="red">  <B> <?php print($error); ?></B></font>
                        <p align="center">
                        <font color="#000080" size="5"><?php print($prospectclient); ?> Status Sheet</font>
                        </p>
                        <p align="left">
                        <b><font color="#000080">Personal Information</font></b>
                        </p>

</B></font></p>
     
  
  
       
 



                        <form  action="affiliatestatus.php"    method="post" >
                                        <input type="hidden" name="budgetday" value="<?php print($budgetday); ?>"
                                        <font size="1" color="#008000" face="Arial">
                            <input type="hidden" name="enrol" value="1">
                            Username: <b><?php print($usernameu);?></b>
                            <br>
                            Password: 
                            <input type="text" name="pwdu" value="<?php print($pwdu);?>" size="20">
                            </p>
                            
                            <table style="BORDER-COLLAPSE: collapse" bordercolor="#000080"
                            cellspacing="0" cellpadding="3" width="98%" bgcolor="#<?php print($bgcolor);?>" border="3">
                                <tbody>
                                <tr>
                                    <td width="25%">First Name 
                                        <input name="fname" value="<?php print($fname); ?>" size="20">
                                    </td>
                                    <td width="25%">Last Name 
                                        <input name="lname" value="<?php print($lname); ?>" size="20"> </td>
                                    <td width="50%">E-mail 
                                        <input name="email" value="<?php print($email); ?>" size="20">
                                    </td>
                                </tr>
                                <tr>
                                    <td width="50%" colspan="2">Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                        <input size="45" name="address" value="<?php print($address); ?>">
                                    <br>
                                    City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                        <input size="22" name="city" value="<?php print($city); ?>">
                                    </td>
                                    <td width="50%">
                                        
 
 
 
 
 
                                        State/Province&nbsp;&nbsp;&nbsp; 
                                        <input
                                                         size="4" name="state" value="<?php print($state); ?>">
                                    <br>
                                        Zip/Postal Code 
                                        <input size="10" name="zip" value="<?php print($zip); ?>">
                                        
 
 
 
 
 
                                         </td>
                                </tr>
                                <tr>
                                    <td width="25%">Daytime Phone# 
                                        <input name="phone" value="<?php print($phone); ?>" size="20">
                                    </td>
                                    <td width="25%">Alt Phone# 
                                        <input name="altphone" value="<?php print($altphone); ?>" size="20">
                                    </td>
                                    <td width="50%">Fax# 
                                        <input name="fax" value="<?php print($fax); ?>" size="20">
                                    </td>
                                </tr>
    </tbody>
                            </table>
                            <br>
                            <input type="hidden" name="info" value="1">

                            <p>

                            <br>
                            <input type="hidden" name="updatecl" value="1">
                           

 
            
 <input type="submit" name="Update" value="Update">
 
  
            

                            </p>

                        </form>

                       

                        
                      
                     
                        <div align="center">
                          <center>
                         <b><font color="#FF0000" face="Verdana" size="2"><?php print($message); ?>
                          </font></b>
                               <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber3">
                            <tr>
                              <td width="10%" valign="top" rowspan="3"><b>Payee:</b></td>
                              <td width="40%" rowspan="3">
                              <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber4">
                                <tr>
                                  <td width="100%"><?php print($fname); ?>&nbsp;<?php print($lname); ?><BR>
                                  					<?php print($address); ?><BR>
                                  					<?php print($city); ?>, <?php print($state); ?>&nbsp;<?php print($zip); ?></td>
                                </tr>
                              </table>
                              </td>
                              <td width="2%" rowspan="3">&nbsp;</td>
                              <td width="24%" rowspan="3"><b>Total Commissions<br>
                              Total Paid<br>
                              Total Owed</b></td>
                              <td width="6%" rowspan="3">$<?php print($affiliateearn); ?> <BR>
                                                    $<?php print($total_paid); ?> <BR>  

                                                    $<?php print($total_due); ?>  
                              </td>
                              <td width="18%"><font size="1" face="Verdana">
                              <a href="totalearned.php">Details</a> </font></td>
                            </tr>
                            <tr>
                              <td width="18%"><font size="1" face="Verdana">
                              <a href="totalpaid.php">Details</a></font></td>
                            </tr>
                            <tr>
                              <td width="18%">&nbsp;</td>
                            </tr>
                            </table>
                       
                            <BR>
                            
                           

                             

                          </center>
</div>
                        <p align="left">
                        <a href="home.php">Main Menu</a>
                        </p>
                        <p align="left">

                        </p>
                        <p align="left">&nbsp;
                        
                        </p>
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>