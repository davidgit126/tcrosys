<?php
extract( $_GET );
extract( $_POST );
?>
<?php
require_once('common.inc.php');
ob_start();
session_start();

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_affiliate']) && $_SESSION['is_affiliate'] == 1)
  {
 include("connection.php");
include("template.php");

      

    $query = "SELECT lname, fname, address, city, state, zip, email, fax, phone, ssn, user, password, comments, alt_phone, commission_rate, id FROM sales_affiliates WHERE id='" . $_SESSION['affiliateid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lname = $row[0];
        $fname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $state = $row[4];
        $zip = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $phone = $row[8];
        $ssnum = $row[9];
        $usernameu = $row[10];
        $pwdu = $row[11];
	    $comments = $row[12];
	    $altphone = $row[13];	  	   	  
		$commission_rate = $row[14];	 
		$affiliate_id = $row[15];			

    }
    
  

  $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_affiliate WHERE affiliate_id = '$affiliate_id' GROUP BY affiliate_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}
    
    


    
    

$bgcolor = "c0c0c0";


    //mysql_close($conn);
?>

                 <font color="red">  <B> <?php print($error); ?></B></font>
                        <p align="center">
                        <font size="5" color="#000080">Commissions</font></p>
                        <p align="left">&nbsp;
                        </p>

</B></font></p>
     
  
  
       
 



                      

                       

                        
                      
                     
                        <div align="center">
                          <center>
                         <b><font color="#FF0000" face="Verdana" size="2"><?php print($message); ?>
                          </font></b>
                               <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber3">
                            <tr>
                              <td width="10%" valign="top" rowspan="3"><b>Payee:</b></td>
                              <td width="40%" rowspan="3">
                              <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber4">
                                <tr>
                                  <td width="100%"><?php print($fname); ?>&nbsp;<?php print($lname); ?><BR>
                                  					<?php print($address); ?><BR>
                                  					<?php print($city); ?>, <?php print($state); ?>&nbsp;<?php print($zip); ?></td>
                                </tr>
                              </table>
                              </td>
                              <td width="2%" rowspan="3">&nbsp;</td>
                              <td width="24%" rowspan="3"><b>Total Commissions<br>
                              Total Paid<br>
                              Total Owed</b></td>
                              <td width="6%" rowspan="3">$<?php print($COM_total_comish); ?> <BR>
                                                    $<?php print($COM_total_pd); ?> <BR>  

                                                    $<?php print($COM_total_comish - $COM_total_pd); ?>  
                              </td>
                              <td width="18%"><font size="1" face="Verdana">
                              <a href="totalearned.php">Details</a> </font></td>
                            </tr>
                            <tr>
                              <td width="18%"><font size="1" face="Verdana">
                              <a href="totalpaid.php">Details</a></font></td>
                            </tr>
                            <tr>
                              <td width="18%">&nbsp;</td>
                            </tr>
                            </table>
                       
                            <BR>
                            
                           

                             

                          </center>
</div>
                        <p align="left">
                        <a href="home.php">Main Menu</a>
                        </p>
                        <p align="left">

                        </p>
                        <p align="left">&nbsp;
                        
                        </p>
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>