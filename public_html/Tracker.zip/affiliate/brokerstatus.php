<?php
extract( $_GET );
extract( $_POST );
?>
<?php
require_once('common.inc.php');
session_start();
$thisaffiliate = $_SESSION['affiliateid'];

if($_SESSION['is_affiliate'] == 1 AND $_SESSION['affiliateid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$mypartners = "class='active'";

    $query = "SELECT lastname, firstname, address, city, prov, zipcode, email, fax, telephone, dealership, username, password, comments, dealer_id, affiliate_id, commission, account_exec, emailnotify, notification, url, tier2comm, tier3comm, tier2aff, tier3aff, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, bio, bioapproved, address2, checkssn, DATE_FORMAT(createdate, \"%m-%d-%Y\") as createdate  FROM dealers WHERE status !=9 and dealer_id='" . $_SESSION['dealer_id'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lastname = $row[0];
        $firstname = $row[1];
        $address = $row[2];
        $brokercity = $row[3];
        $prov = $row[4];
        $zipcode = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $telephone = $row[8];
        $dealership = $row[9];
        $username = $row[10];
        $password = $row[11];
	    $comments = $row[12];
		$dealer_id = $row[13];			
		$affiliate_id = $row[14];			
		$commission = $row[15];			
		$masterbroker = $row[16];			
		$emailnotify = $row[17];			
		$notification = $row[18];			
		$url = $row[19];			
		$newtier2comm = $row[20];			
		$newtier3comm = $row[21];			
		$tier2affiliate = $row[22];			
		$tier3affiliate = $row[23];			
		$logins = $row[24];			
		$lastlogin= $row[25];			
		$bio= $row[26];			
		$bioapproved = $row[27];			
		$address2 = $row[28];			
		$checkssn = $row[29];			
		$createdate = $row[30];			
		}
    
    

    
   if ($thisaffiliate != $affiliate_id ){
?>
<font color="red"><B>You are not authorized to view this client. <?php print($thisaffiliate); ?></font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 exit();
//mysql_close($conn);
}




    
    



    //mysql_close($conn);
	

    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">

      
<?php

 include("header.php");
    ?>




      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_partners_icon.png" alt="" />Partner Data</h2>
            <p>Please view details for <u><?php print($firstname); ?> <?php print($lastname); ?></u>.</p>
          </div>
        

 <div class="overall_box">
            <div class="top_curve">
              <div class="bottom_curve">
		 <div class="left_details">
 <div class="my_account_datials">
                  <div class="user_details">
                    <ul>
                      <li>
                        <label>Name:</label>
                        <?php print($firstname); ?> <?php print($lastname); ?></li>
                      <li>
                        <label>City</label>
                        <?php print($brokercity); ?></li>
                   <!--   <li>
                        <label>Status:</label>
                        <?php print($clientstatus); ?></li>-->
                      <li>
                        <label>Enrolled:</label>
                        <?php print($createdate); ?></li>
                     
                    </ul>
                  </div></div>                   </div></div>                   </div></div> 




		   <div class="my_status_details">
            <div class="table_box">
              <div class="top_curve">
                <div class="bottom_curve">












                  <h3>List of leads/clients <?php print($firstname); ?> has entered</h3>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Date</td>
                      <td class="col2">Name</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                  

    <?php
    $query = "SELECT id, name, city, state, phone, createdate, plan, status FROM clients WHERE affiliate_id ='" . $_SESSION['affiliateid'] . "' AND broker_id ='" . $_SESSION['dealer_id'] . "' AND clientdelete != 'Yes' AND status !='expired' AND status !='canceled' order by createdate ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
              $id           = $row[0];
              $clientname   = $row[1];
              $address      = $row[2];
              $cemail       = $row[3];
              $phone = $row[4];
              $createdate = $row[5];
              $plan  = $row[6];
              $status  = $row[7];
              $cnt++;
        

                    $bgcolor = "";

        


        ?>


                    <tr <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($createdate); ?></td>
                      <td class="col5" ><a href="setprospect.php?cid=<?php print($id); ?>&cname=<?php print($clientname); ?>"><?php print($clientname); ?></a></td>
                      <td class="col6" ><?php print($status); ?></td>
                    </tr>
                   <?php
    }
   // mysql_close($conn);
    ?>
                  
                  </table>
                </div>
              </div>
            </div>
          </div>




        </div>
      


<?php

 include("rightframe.php");
    ?>



        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
</body>
</html>
    <?
}
else
{
    header("Location: login.php");
    exit();
}
?>