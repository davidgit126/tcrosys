<?php
extract( $_GET );
extract( $_POST );
?>
<?php
require_once('common.inc.php');
session_start();
$thisaffiliate = $_SESSION['affiliateid'];

if($_SESSION['is_affiliate'] == 1 AND $_SESSION['affiliateid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$mycomms = "class='active'";

 
    

    //mysql_close($conn);
	

    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">

      
<?php

 include("header.php");
    ?>




      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_commissions_icon.png" alt="" />My Payments</h2>
            <p>You can view all of the payments made to you.  Thank you for your business.</p>
          </div>
        			<table border="0" align="center" width="500" cellpadding="3" cellspacing="3">
	<tr>
		<td align="center"><a href="my_comms.php"><img src="common/images/viewcomms_btn.png" border=0></a></td>
		<td align="center"><a href="my_payments.php"><img src="common/images/viewpaid_btn.png" border=0></a></td>
	</tr>
</table>



 <div class="overall_box">
            <div class="top_curve">
              <div class="bottom_curve">
		 <div class="left_details">
 <div class="my_account_datials">
                  <div class="user_details">
                    <ul>
                      <li>
                        <label>Earned:</label>
                        $<?php print($COM_total_comish); ?></li>
                      <li>
                        <label>Paid:</label>
                        $<?php print($COM_total_pd); ?></li>
                      <li>
                        <label>Owed</label>
                        $<?php print($COM_total_comish - $COM_total_pd); ?></li>
               
                     
                    </ul>
                  </div></div>                   </div></div>                   </div></div> 




		   <div class="my_status_details">
            <div class="table_box">
              <div class="top_curve">
                <div class="bottom_curve">












                  <h3>Detailed Payments</h3>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Date</td>
                      <td class="col2">Notes</td>
                      <td class="col3">Check Number/Amount</td>
                    </tr>
                  </table>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                  

    <?php
    $query = "SELECT payment_date, ck_number, notes, payment_amount FROM commission_affiliate WHERE affiliate_id='" . $_SESSION['affiliateid'] . "' and payment_amount != '' ORDER BY payment_date DESC";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $check_date= $row[0];
        $check_num = $row[1];
        $notes = $row[2];
        $amount_paid = $row[3];
                    $bgcolor = "";

        


        ?>


                    <tr <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($check_date); ?></td>
                      <td class="col5" ><?php print($notes); ?></td>
                      <td class="col6" >#<?php print($check_num); ?> - $<?php print($amount_paid); ?></td>
                    </tr>
                   <?php
    }
   // mysql_close($conn);
    ?>
                  
                  </table>
                </div>
              </div>
            </div>
          </div>




        </div>
      


<?php

 include("rightframe.php");
    ?>



        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
</body>
</html>
    <?
}
else
{
    header("Location: login.php");
    exit();
}
?>