<?php
extract( $_GET );
extract( $_POST );
?>
<?php
require_once('common.inc.php');
ob_start();
session_start();

if(isset($_SESSION['is_affiliate']) && $_SESSION['is_affiliate'] == 1)
{
 include("connection.php");
include("template.php");

    ?>
    
    

    <font color="red">  <B> <?php print($message); ?></B></font><BR>

    
    
    
    
    Please search for the Prospect  using one of the following criteria or Add a new 
Prospect to the database
    <form action="" method="get">
        <table>
            <tr>
                <td>Prospect Name: </td>
                <td>
                    <input type="text" name="cname" size="20">
                </td>
            </tr>
            <tr>
                <td colspan="2"><b>or</b></td>
            </tr>
            <tr>
                <td>ZIP: </td>
                <td>
                    <input type="text" name="zip" size="20">
                </td>
            </tr>
            <tr>
                <td colspan="2"><b>or</b></td>
            </tr>
            <tr>
                <td>Prospect E-mail: </td>
                <td>
                    <input type="text" name="email" size="20">
                </td>
            </tr>
        </table>
        <input type="hidden" name="f" value="1">
        <input type="submit" name="Find" value="Find">
    </form>
   
    
        <?php
    

    include("connection.php");
    if($_GET['f']==1)
    {
        ?>
        List of Prospects matching your search criteria </p>
        <table border="1">
        <tr>
            <td>Name</td>
            <td>City</td>
            <td>State</td>
            <td>Enter Date</td>

        </tr>
        <?php
          if(($_GET['cname'] != null) && ($_GET['cname'] != ''))
          {
             $query = "SELECT id, name, city, state, phone, createdate, plan FROM clients WHERE affiliate_id ='" . $_SESSION['affiliateid'] . "' AND prospectclient = 'Prospect' AND name LIKE('" . mysql_real_escape_string($_GET['cname']) . "%')";
          }
          else if($_GET['zip'] != '')
          {
              $query = "SELECT id, name, city, state, email, phone, createdate, plan FROM clients WHERE affiliate_id ='" . $_SESSION['affiliateid'] . "' AND prospectclient = 'Prospect' AND zip='" . mysql_real_escape_string($_GET['zip']) . "'";
          }
          else if(($_GET['email'] != null) && ($_GET['email'] != ''))
          {
              $query = "SELECT id, name, city, state, email, phone, createdate, plan FROM clients WHERE affiliate_id ='" . $_SESSION['affiliateid'] . "' AND prospectclient = 'Prospect' AND email LIKE('" . mysql_real_escape_string($_GET['email']) . "%')";
          }
          else
              $query = "SELECT id, name, city, state, phone, createdate, plan FROM clients WHERE affiliate_id ='" . $_SESSION['affiliateid'] . "' AND prospectclient = 'Prospect'";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $address      = $row[2];
              $cemail       = $row[3];
              $phone = $row[4];
              $createdate = $row[5];
              $plan  = $row[6];
              $cnt++;
              
        

$bgcolor = "FFFFFF";
              ?>
              <tr>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($clientname); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($address); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($cemail); ?>&nbsp;</td>

              <td bgcolor=<?php print($bgcolor); ?>><?php print($createdate); ?>&nbsp;</td>

              
          

              </tr>
              <?php
          }
          mysql_close($conn);
          ?>
          </table>
          <?php
          if($cnt==0)
          {
              print("There are no matching records to your search criteria. Please try again.");
          }
    }
}
else
{
    header("Location: login.php");
    exit();
}
?>