<?php
session_start();

$_SESSION['prospectclientid']   = $_GET['cid'];
$_SESSION['prospectclname']     = $_GET['cname'];



header("Location: prospectstatus.php");
exit();
?>
