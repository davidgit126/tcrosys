<?php
    session_start();
    session_destroy();
    header("Location: /affiliate");
    exit();
?>