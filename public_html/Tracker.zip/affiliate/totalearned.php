<?php
extract( $_GET );
extract( $_POST );
?>
<?php
require_once('common.inc.php');
ob_start();
session_start();

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_affiliate']) && $_SESSION['is_affiliate'] == 1)
  {
 include("connection.php");
include("template.php");

      
    $query = "SELECT commission_rate FROM sales_affiliates WHERE id='" . $_SESSION['affiliateid'] . "'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $commission= $row[0];


$bgcolor = "c0c0c0";

}
     $query3 = "SELECT count(id) FROM clients WHERE prospectclient = 'Client' AND affiliate_id ='" . $_SESSION['affiliateid'] . "'";

              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $totalcredit = $row3[0];
                   $affiliateearn = $totalcredit * $commission;
}

?>

                 <font color="red">  <B> <?php print($error); ?></B></font>
                        <p align="center">
                        <font size="5" color="#000080">Total Commissions Earned</font></p>



     
  
  
       
 



                      

                       

                        
                      
                     
                        <div align="center">
                          <center>
                         <b><font color="#FF0000" face="Verdana" size="2"><?php print($message); ?>
                          </font></b>
                         
                            
                            <BR>
                            
                           

                             <table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber3" cellpadding="3">
 										
 <tr>
                              <td width="100%" valign="top">
                              <p align="center"><b>
                              <font face="Verdana" size="4"><?php print($_SESSION['clname']); ?></font></b></td>
                            </tr>
                            <tr>
                              <td width="100%" valign="top">
                              <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5">
                                <tr>
                                  <td width="12%"><b>Earn Date</b></td>
                                  <td width="25%"><b>Name</b></td>
                                  
                                  <td width="15%"> 
                                        <b>Earn Amount</b></td>
                                </tr>
                                
                                 <?php
    $query = "SELECT DATE_FORMAT(clients.createdate, \"%m-%d-%Y\") as createdate, clients.name, commission_affiliate.amount_paid FROM clients,commission_affiliate WHERE clients.prospectclient = 'Client' AND clients.affiliate_id='" . $_SESSION['affiliateid'] . "' AND clients.id = commission_affiliate.contact_id ORDER BY createdate DESC";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $createdate= $row[0];
        $name = $row[1];
$amount_paid = $row[2];

?>
                                <tr>
                                
                                  <td width="12%"><?php print($createdate); ?></td>
                                  <td width="25%"><?php print($name); ?></td>

                                  <td width="15%">$<?php print($commission); ?></td>
                              
 </tr>
                              <?php
       }
        $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_affiliate WHERE affiliate_id='" . $_SESSION['affiliateid'] . "' GROUP BY affiliate_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}

?>                

  <tr>
                                
                                  <td width="12%">&nbsp;</td>
                                  <td width="25%">&nbsp;</td>

                                  <td width="15%"><b>Total -
                                  <font color="#008000">$<?php print($COM_total_comish); ?></font></b></td>
                              
 </tr>
                  
                                </table>
                              </td>
                            </tr>
                            </table>

                          </center>
</div>
                        <p align="left">
                        <a href="affiliatestatus.php">Back</a>
                        &nbsp;
                        </p>
                        
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>