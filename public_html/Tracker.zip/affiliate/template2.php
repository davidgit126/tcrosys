<html>
<head>
<title></title>
</head>
<body>

<!-- Page Content Begin -->
<div id="content">
<?=$page['content']?>
</div>
<!-- Page Content End -->

</body>
</html>
