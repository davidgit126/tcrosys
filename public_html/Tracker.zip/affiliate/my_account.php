<?php
extract( $_GET );
extract( $_POST );
?>
<?php
require_once('common.inc.php');
session_start();

if($_SESSION['is_affiliate'] == 1 AND $_SESSION['affiliateid'] != "")
{
 include("connection.php");
 include("companyquery.php");

$myaccount = "class='active'";

      if($_POST['updatecl'] == 1)
      {
        
        $query = "UPDATE sales_affiliates SET
                lname='" . mysql_real_escape_string($_POST['lname']) . "',
                fname='" . mysql_real_escape_string($_POST['fname']) . "',
                address='" . mysql_real_escape_string($_POST['address']) . "',
                address2='" . mysql_real_escape_string($_POST['address2']) . "',
				company='" . mysql_real_escape_string($_POST['company']) . "',                
                city='" . mysql_real_escape_string($_POST['city']) . "',
                state='" . mysql_real_escape_string($_POST['state']) . "',
                zip='" . mysql_real_escape_string($_POST['zip']) . "',
                email='" . mysql_real_escape_string($_POST['email']) . "',
                fax='" . mysql_real_escape_string($_POST['fax']) . "',
                phone='" . mysql_real_escape_string($_POST['phone']) . "',
                
                password='" . mysql_real_escape_string($_POST['password']) . "'

                WHERE id='" . $_SESSION['affiliateid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());


   }

    
    

                	

   
    //mysql_close($conn);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<script type="text/javascript" src="common/js/dropdownmenu.js"></script>
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
<?php

 include("header.php");
    ?>
  <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_account_icon.png" alt="" />My Account</h2>
            <p class="my_accout">To change or update your personal information please use the form below.  If you need help please call us at <?php print($companyphone); ?>, during regular business hours. </p>
          </div>
          <div class="common_box">
            <div class=" top_curve">
              <div class="bottom_curve">
                <div class="my_account_datials">
                  <div class="user_details">
 <form name="broker" action=""    method="post" >                    <ul>
 <li>
                        <label>Username:</label>
<?php print($user); ?></li>
                      <li>
                        <label>Password:</label>
                        <input class="input_bg" type="password" name="password" value="<?php print($password);?>" size="21"></li>
						
											  
											  <li>
                        <label>First Name:</label>
                        <input class="input_bg" name="fname" value="<?php print($fname); ?>" size="30"></li>
                      <li>
                        <label>Last Name:</label>
                        <input name="lname" value="<?php print($lname); ?>" size="20"></li>
                      <li>
                        <label>Address</label>
                        <input name="address" value="<?php print($address); ?>" size="30"></li>
                      <li>
                        <label>City/St/Zip:</label>
<input size="12" name="city" value="<?php print($city); ?>">,<input name="state" value="<?php print($state); ?>" size="2"><input size="5" name="zip" value="<?php print($zip); ?>"></li>
 <li>
                        <label>Email:</label>
<input name="email" value="<?php print($email); ?>" size="30"></li>
                      <li>
                        <label>Phone:</label>
<input name="phone" value="<?php print($phone); ?>" size="20"></li>
                     
 <li>					  
 <label>Company:</label>
<input size="30" name="company" value="<?php print($company); ?>"></li>
 <li>					  
 <label>Website:</label>
<input size="30" name="address2" value="<?php print($address2); ?>"></li>
                   				  
 <!--        <ul>
 <li>
                        <label>Settings:</label>
 <select class="txtbox"   name="emailnotify">
					    <option value="<?php print($emailnotify); ?>" selected><?php print($emailnotifyname); ?></option>                                        
					    <option value="0" >Notifications Off</option>
					    <option value="1" >Client Updates Only</option>
					    <option value="2" >Client Updates & New Leads</option>
					    <option value="3" >Client Updates, New Leads & Updates</option>
					    </select></li>
                      
					
											  
											  <li>
                        <label>Show Info:</label>
                         <select class="txtbox"   name="notification">
					    <option value="<?php print($notification); ?>" selected><?php print($notificationname); ?></option>                                        
					    <option value="0" >No</option>
					    <option value="1" >Yes</option>
					    </select>
						
						</li>
                     
           
                    </ul>-->
                  </div>
				  <input type="hidden" name="updatecl" value="1">
                           
 <input type="image" src="common/images/diputes_submit.gif" name="submit">
 
</form>                            



                  <p>&nbsp;</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
<script type="text/javascript" src="../admin/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="../admin/jquery.textarea-expander.js"></script>

</body>
</html>
  <?
}
else
{
    header("Location: login.php");
    exit();
}
?>