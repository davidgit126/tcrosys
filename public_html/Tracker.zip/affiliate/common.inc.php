<?php
extract( $_GET );
extract( $_POST );
?>
<?php

include_once('../include/common.inc.php');

?>
