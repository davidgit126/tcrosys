<?php
 $query = "SELECT lname, fname, address, city, state, zip, email, fax, phone, company, user, password, comments, id, commission_rate, address2, ssn   FROM sales_affiliates WHERE id='" . $_SESSION['affiliateid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lname = $row[0];
        $fname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $state = $row[4];
        $zip = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $phone = $row[8];
        $company = $row[9];
        $user = $row[10];
        $password = $row[11];
	    $comments = $row[12];
		$id = $row[13];			
	    $commission = $row[14];			
	    $address2 = $row[15];			
	    $ssn = $row[16];			
		}
          $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_affiliate WHERE affiliate_id='" . $_SESSION['affiliateid'] . "' GROUP BY affiliate_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}


 /*   
    if ($emailnotify == 0) {
$emailnotifyname = "Notifications Off";
}else if  ($emailnotify == 1) {
$emailnotifyname = "Client Updates Only";
}else if  ($emailnotify == 2) {
$emailnotifyname = "Client Updates & New Lead Submissions";
}else if  ($emailnotify == 3) {
$emailnotifyname = "Client Updates, New Lead Submissions & Updates";
}

 if ($notification == 0) {
$notificationname = "No";
}else if  ($notification == 1) {
$notificationname = "Yes";
}
*/
 ?>

<div id="header"> <?php print($insertheader); ?>

		<div class="right_details"> <span class="logout"><a href="logout.php">Log Out</a></span> <span class="number"><?php print($companyphone); ?><br />
          <!--<small>M-F 9:00 AM - 5:00 PM MTN</small>--> </span> <span class="welcome">Welcome, <?php print($fname); ?> <?php print($lname); ?><BR>
		             <!-- <a href="#">You Have <font color="green">4</font> New Messages </a>--></span>
</div>  <div class="menu">
          <ul>

		

            <li <?php print($myhome); ?>><a href="home.php">My Home</a></li>
            <li <?php print($myaccount); ?>><a href="my_account.php">My Account</a></li>
<!--            <li <?php print($myclients); ?>><a href="my_clients.php">My Clients</a></li>-->
            <li <?php print($myleads); ?>><a href="my_leads.php">My Leads</a></li>
      <?php
 if($commission !=0){     
    ?>                         <li <?php print($mycomms); ?>><a href="my_comms.php">My Commissions</a></li>

      <?php
	  }
    ?>                     

            <li <?php print($mypartners); ?>><a href="my_partners.php">My Partners</a></li>

<?php

      if($htdiwebsite == "Yes"){

$query = "SELECT pagename FROM webcms WHERE active='Yes' and onheader='Yes' and type='affiliate' and pageorder > 0 order by pageorder";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $pagenamelink = $row[0];

      if($onpage == $pagenamelink){
$mycms = "class='active'";
	  }else{
$mycms = "";
	  }
$headerlinks .="<li $mycms><a href=\"cms.php?page=$pagenamelink\">$pagenamelink</a></li>";
    }


echo $headerlinks;
}   
    ?>
</ul>
          <!-- <span class="new_message"><a href="#">You Have <small>4</small> New Messages </a></span>-->
           </div>
		           <img src="common/images/menu_bottom_shadow.gif" alt="" /> </div>