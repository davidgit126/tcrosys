<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

if($_SESSION['is_affiliate'] == 1 AND $_SESSION['affiliateid'] != "")
{
 include("connection.php");

$mypartners = "class='active'";

  $query = "SELECT dbname, tier1aff, tier2aff, tier3aff FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dbname = $row[0];
        $commission = $row[1];
        $tier2comm = $row[2];
        $tier3comm = $row[3];
    }

   
$tier_id=$_SESSION['affiliateid'];
	
      if($_POST['addbroker'] == 1)
      {


////////////    
$query = "SELECT dealer_id FROM dealers WHERE username='" . mysql_real_escape_string($_POST['username']) . "'"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
   // print($col_count);
   $reccount=0;
    while($row=mysql_fetch_row($result))
    {
         $reccount++;
    } 

    if($reccount>0)
    {

        print("<html><body>");
        print("The username <b>$username</b> already exist. Please <a href=brokerregister.php?susername=$susername&spassword=$spassword&sfirstname=$sfirstname&slastname=$slastname&semail=$semail&sphone=$sphone&saddress=$saddress&szip=$szip&sstate=$sstate&scity=$scity&sdealership=$sdealership>CLICK HERE</a> to choose another name. ");
		exit();
    }  
    else
    {
//////////////

$createdate = date("Y-m-d");
        $query = "INSERT INTO dealers(firstname, lastname, dealership, address, city, prov, zipcode, email, fax, telephone, createdate, username, password, affiliate_id, reseller_id, commission, tier2comm, tier3comm, tier2aff, tier3aff)
                VALUES(
                '" . mysql_real_escape_string($_POST['sfirstname']) . "', 
                '" . mysql_real_escape_string($_POST['slastname']) . "',
                '" . mysql_real_escape_string($_POST['sdealership']) . "',
                '" . mysql_real_escape_string($_POST['saddress']) . "', 
                '" . mysql_real_escape_string($_POST['scity']) . "', 
                '" . mysql_real_escape_string($_POST['sstate']) . "',
                '" . mysql_real_escape_string($_POST['szip']) . "',
                '" . mysql_real_escape_string($_POST['semail']) . "',
                '" . mysql_real_escape_string($_POST['sfax']) . "',
                '" . mysql_real_escape_string($_POST['sphone']) . "',
                '$createdate',
                '" . mysql_real_escape_string($_POST['username']) . "',
                '" . mysql_real_escape_string($_POST['password']) . "',
                '" . mysql_real_escape_string($_SESSION['affiliateid']) . "',
                '" . mysql_real_escape_string($_POST['reseller_id']) . "',
                '$commission',
                '$tier2comm',
                '$tier3comm',
                '$tier2aff',
                '$tier3aff'
				)";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());




  $query = "SELECT id, name, subject, message, type, activated, description FROM systememails WHERE name='Broker_Welcome'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailid           = $row[0];
              $emailname   = $row[1];
              $subject   = $row[2];
              $message   = $row[3];
              $type = $row[4];
              $activated = $row[5];              
              $description = $row[6];    
}
 if($activated =="Yes"){

 $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 

    }
    $query = "SELECT lastname, firstname, address, city, prov, zipcode, email, fax, telephone, dealership, username, password, comments, dealer_id, affiliate_id FROM dealers WHERE username='" . mysql_real_escape_string($_POST['username']) . "'"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lastname = $row[0];
        $firstname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $prov = $row[4];
        $zipcode = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $telephone = $row[8];
        $dealership = $row[9];
        $username = $row[10];
        $password = $row[11];
	    $comments = $row[12];
		$dealer_id = $row[13];			
		$affiliate_id = $row[14];			

    }
    include_once("../companystrip.php");
    include_once("../brokerstrip.php");

$EMAIL_Message = "$companyskin$message2";
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From>\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
}



        header("Location: my_partners.php?message=Broker Record Created!");
        exit();





	}/////END IF ALREADY EXISTS
	}  //////END IF ADD BROKER
   	
    include("companyquery.php");

    //mysql_close($conn);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<script type="text/javascript" src="common/js/dropdownmenu.js"></script>
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
<?php

 include("header.php");
    ?>
  <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_partners_icon.png" alt="" />Registration</h2>
            <p class="my_accout">Please enter the Referral Partner information to be entered under your Affiliate ID.  Any client submissions by this Referral Partner will result in a commission for you. </p>
          </div>
          <div class="common_box">
            <div class=" top_curve">
              <div class="bottom_curve">
                <div class="my_account_datials">
                  <div class="user_details">
 <form name="broker" action=""  method="post" > 
 <ul>
 <li>
                        <label>Username:</label>
<input class="input_bg" type="text" name="username" value="<? echo "$susername"; ?>" size="21"></li>
                      <li>
                        <label>Password:</label>
                        <input class="input_bg" type="password" name="password" value="<? echo "$spassword"; ?>" size="21"></li>
						
											  
											  <li>
                        <label>First Name:</label>
                        <input class="input_bg" name="sfirstname" value="<? echo "$sfirstname"; ?>" size="30"></li>
                      <li>
                        <label>Last Name:</label>
                        <input name="slastname" value="<? echo "$slastname"; ?>" size="20"></li>
                      <li>
                        <label>Address</label>
                        <input name="saddress" value="<? echo "$saddress"; ?>" size="30"></li>
                      <li>
                        <label>City/St/Zip:</label>
<input size="12" name="scity" value="<? echo "$scity"; ?>">,<input name="sstate" value="<? echo "$sstate"; ?>" size="2"><input size="5" name="szip" value="<? echo "$szip"; ?>"></li>
 <li>
                        <label>Email:</label>
<input name="semail" value="<? echo "$semail"; ?>" size="30"></li>
                      <li>
                        <label>Phone:</label>
<input name="sphone" value="<? echo "$sphone"; ?>" size="20"></li>
                     
 <li>					  
 <label>Company:</label>
<input size="30" name="sdealership" value="<? echo "$sdealership"; ?>"></li>
                     
                   				  
                   
                    </ul>
                  </div>

<input type="hidden" name="addbroker" value="1">
<input type="hidden" name="tier_id" value="<? echo "$tier_id"; ?>">            
 <input type="image" src="common/images/diputes_submit.gif" name="submit">
 
</form>                            
<HR>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>  </div>
</div>
</body>
</html>
  <?
}
else
{
    header("Location: login.php");
    exit();
}
?>