<?php
session_start();

$dealer_id   = $_GET['brokercid'];
$_SESSION['clname']     = $_GET['cname'];

session_register('dealer_id');  

header("Location: brokerstatus.php");
exit();
?>
