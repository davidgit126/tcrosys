<?php


extract( $_GET );
extract( $_POST );

require "aes-lib.php";
require_once('common.inc.php');
include("connection.php");

$username= $_GET['HTDILogin'];
$password = $_GET['HTDIPassword'];
$HTDIURL = $_GET['URL'];
$today = date("Y-m-d");

$year = date("Y");
$month = date("m");
$day = date("d");
$julian = "$year$month$day";
$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);
$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";

$ip=$_SERVER["REMOTE_ADDR"];
$site=$_SERVER["HTTP_REFERER"];


$calsearch = $julian;
$calsearchword = "today";





$ipquery = "SELECT dbname FROM companyinfo WHERE companyid='1'";
    $ipresult = mysql_query($ipquery, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($ipresult))
    {
        $dbname = $row[0];          
    }

/*include "700score_connection2.php"; 
 $query = "SELECT mainstatus, dealer_id, fileloc FROM dealers WHERE dbname='$dbname' limit 1";
    $result = mysql_query($query, $conn2);
    while($row=mysql_fetch_row($result))
    {
        $mainstatus = $row[0];
          $dealer_id = $row[1];
          $isptcso = $row[2];
$csotracker_id=$dealer_id;
        session_register('csotracker_id'); 
        session_register('isptcso'); 

        }

 
*/


    $query = "SELECT id, username, access, fname, extension, affiliate, brokers, modleads, modemails FROM users WHERE password='$password' and username='$username' LIMIT 1";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        if($row=mysql_fetch_assoc($result))
    {
        $usid   = $row['id'];
        $usname = $row['username'];
        $usaccess = $row['access'];
        $usfname = $row['fname'];
        $usext = $row['extension'];
        $affiliate = $row['affiliate'];
        $brokers = $row['brokers'];
        $restrict = $row['modleads'];
        $editleads = $row['modemails'];
        $is_admin = 1;
        $action = "Successful Login";

        session_register('usid');  
        session_register('usname'); 
        session_register('usaccess'); 
        session_register('usfname'); 
        session_register('usext'); 
        session_register('affiliate'); 
        session_register('brokers'); 
        session_register('restrict'); 
        session_register('editleads'); 
        session_register('is_admin'); 
 



$query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, autoscheduler, reseller, htdiwebsite, adminsinglepayment1, adminsinglepayment2, admincouplepayment1, admincouplepayment2, single, couple, creditcard, paypal2, ach, singlefull, singledownpay1, singlepayment, couplefull, coupledownpay1, couplepayment, threeinone, paypal, months, perdelete, livehuman, dbname, dropdowncreditors, dropdownbegin, dropdowntails, autoresponder, bautoresponder, cautoresponder, helpdesk, companyheader, timezone FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $autoscheduler = $row[12];          
        $reseller = $row[13];           
        $htdiwebsite = $row[14];           
        $adminsinglepayment1 = $row[15];
        $adminsinglepayment2 = $row[16];
        $admincouplepayment1 = $row[17];
        $admincouplepayment2 = $row[18];                                
        $single = $row[19];                                
        $couple = $row[20];                                
        $creditcard = $row[21];                 
        $paypal2 = $row[22];                 
        $ach = $row[23];                 
        $singlefull = $row[24];          
        $singledownpay1 = $row[25];          
        $singlepayment = $row[26];          
        $couplefull = $row[27];          
        $coupledownpay1 = $row[28];          
        $couplepayment = $row[29];          
        $threeinone = $row[30];          
        $paypal = $row[31];          
        $months = $row[32];          
        $perdelete = $row[33];          
        $livehuman = $row[34];          
        $dbname = $row[35];          
        $dropdowncreditors = $row[36];    
        $dropdownbegin = $row[37];    
        $dropdowntails = $row[38];                            
        $autoresponder = $row[39];                            
        $bautoresponder = $row[40];                            
        $cautoresponder = $row[41];                            
        $helpdesk = $row[42];                            
        $companyheader = $row[43];                            
        $timezone = $row[44];                            
    }

if ($companywebsite =="http://www.creditrepairtracking.com"){
$toolbarsite = "$companywebsite/demo";
}else{
$toolbarsite = "$companywebsite/admin";
}
/////////////APPOINTMENTS
$calendaruser =$_SESSION['usname'];
		$calsql = "SELECT * FROM calendar where cal_date='$calsearch' and cal_create_by ='$calendaruser' ORDER BY cal_time";
		$calresult = @mysql_query($calsql,$conn) or die("Couldn't execute");
		$number_appts = @mysql_num_rows($calresult);
 while ($calrow = mysql_fetch_array($calresult)) {	
		    $cal_id = $calrow['cal_id'];
		    $cal_contactid = $calrow['cal_contactid'];
		    $cal_create_by = $calrow['cal_create_by'];
		    $cal_description = $calrow['cal_description'];
		    $cal_link = $calrow['cal_link'];
		    $cal_name = $calrow['cal_name'];
		    $cal_date = $calrow['cal_date'];
		    $cal_time = $calrow['cal_time'];
		    $active = $calrow['cal_mod_time'];

$cal_year = substr("$cal_date", 0, 4);
$cal_month = substr("$cal_date", 4, 2);
$cal_day = substr("$cal_date", 6, 2);
$cal_time = substr("$cal_time", 0, -2);
if (strlen($cal_time) == 3){
$cal_time = "0$cal_time";
}
		    
if ($active != 0){
$apptitems .= '<item id="item12" href="' .$toolbarsite. '/menu.php"><![CDATA[' .$cal_month. '/' .$cal_day. '/' .$cal_year. ' at ' .$cal_time. ' :: ' .$cal_name. ']]></item>';
}else{
$apptitems .= '<item id="item11" href="' .$toolbarsite. '/menu.php"><![CDATA[<strike>' .$cal_month. '/' .$cal_day. '/' .$cal_year. ' at ' .$cal_time. ' :: ' .$cal_name. '</strike>]]></item>';
}

}


//////////PROSPECTS

if ($_SESSION['restrict'] == "Yes"){
$restrictleads = "and id < 0";
	 
 $sqlrestrict = "SELECT id FROM sales_affiliates where user ='" . $_SESSION['usname'] . "' ";
  $resultrestrict = @mysql_query($sqlrestrict,$conn);
  while ($rowrestrict = mysql_fetch_array($resultrestrict)) {
  $affid = $rowrestrict['id'];
$restrictleads = "and affiliate_id='$affid'";

}


}//END RESTRICT

	 $query5 = "SELECT count(id) FROM clients WHERE clientdelete !='yes' and prospectclient = 'Prospect' and scheduleddate < '$today' $restrictleads";
          $result5 = mysql_query($query5, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row5=mysql_fetch_row($result5))
          {
              $newconsumerleads           = $row5[0];
}
if ($newconsumerleads != 0){
$leadstitle = '<button id="but2"><![CDATA[Prospects <font color =#FF0000><B>( ' .$newconsumerleads. ' )</b></font>]]>';
}else{
$leadstitle = '<button id="but2"><![CDATA[Prospects]]>';
}




    if($helpdesk=="Yes" && ($_SESSION['usaccess']=="support" or $_SESSION['usaccess']=="full")){
  $query3 = "SELECT id, clientid, subject, description FROM helpdesk WHERE status='OPEN'";
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $hdid = $row3[0];
                   $hdclientid = $row3[1];
                   $hdsub = $row3[2];
                   $hddescription = $row3[3];
                   $opentickets = $opentickets+1;

 $query4 = "SELECT name FROM clients WHERE id='$hdclientid'";
              $result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
              while($row4=mysql_fetch_row($result4))
              {
                   $hduser= $row4[0];
}


$hd_select .= '<item id="item11" href="' .$toolbarsite. '/viewticket.php?helpdeskid=' .$hdid. '"><![CDATA[(Logged By - ' .$hduser. ') <B>' .$hdsub. '</b>   <font color=#008080>' .$hdcat. '</font>]]></item>';
}
if($hdid !=""){
$helpdesktitle = '<button id="but5"><![CDATA[Helpdesk <font color =#FF0000><B>( ' .$opentickets. ' )</b></font>]]>';
}else{
$helpdesktitle = '<button id="but5"><![CDATA[Helpdesk]]>';
}

}
// XML Definition start
		$pt = '<toolbar>';

			$pt .= '<button id="but3" href="' .$toolbarsite. '/menu.php"><![CDATA[<B><font color="#003399">Welcome, ' .$usfname. '!</font></b>&nbsp;&nbsp;&nbsp;&nbsp;]]></button>';

    if($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="support" or $_SESSION['usaccess']=="processing")
    {
	

			$pt .= '<button id="but1"><![CDATA[Clients]]>';
				$pt .= '<menu>';
					$pt .= '<item id="item01" href="' .$toolbarsite. '/search.php?status=pending&amp;f=1&amp;Find=Find"><![CDATA[Pending Clients]]></item>';
					$pt .= '<item id="item02" text="Client Search" href="' .$toolbarsite. '/search.php"/>';
					$pt .= '<separator />';
					$pt .= '<item id="item04" text="Add Client" href="' .$toolbarsite. '/register.php"/>';
					$pt .= '<item id="item05" text="Add Joint Client" href="' .$toolbarsite. '/registerjoint.php"/>';
				$pt .= '</menu>';
			$pt .= '</button>';
}
    if($_SESSION['usaccess']!="processing" && $_SESSION['usaccess']!="WebCMS")
    {
			
	$pt .= $leadstitle;
				$pt .= '<menu>';
					$pt .= '<item id="item06" text="List All Prospects" href="' .$toolbarsite. '/prospectsearch.php"/>';
					$pt .= '<item id="item07" text="Prospect Search" href="' .$toolbarsite. '/prospectsearch.php?search=on"/>';
					$pt .= '<separator />';
					$pt .= '<item id="item08" text="Add Prospect" href="' .$toolbarsite. '/prospectregister.php"/>';
				$pt .= '</menu>';
			$pt .= '</button>';
			
}			
    if($helpdesk=="Yes" && ($_SESSION['usaccess']=="support" or $_SESSION['usaccess']=="full")){
	$pt .= $helpdesktitle;
				$pt .= '<menu>';
					$pt .= $hd_select;
				$pt .= '</menu>';
			$pt .= '</button>';
}			

			$pt .= '<button id="but10"><![CDATA[Appointments]]>';
				$pt .= '<menu>';
					$pt .= $apptitems;
				$pt .= '</menu>';
			$pt .= '</button>';
			
			
		//	$pt .= '<button id="but30"><![CDATA[&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;]]></button>';

		$pt .= '</toolbar>';
// XML Definition end

		$pw = "123";
		$encr = AESEncryptCtr($pt, $pw, 256);
		echo $encr;
	}
?>
