<?
/* make the database connection */
$conn2  = mysql_connect("localhost", "score700_dealer", "c@mpasano");

/* connect to a particular database */
mysql_select_db("score700_dealer", $conn2) or die ("could not connect");


?>