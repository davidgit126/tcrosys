<?php

  if (isset($_COOKIE['HTDILogin']) && isset($_COOKIE['HTDIPassword']))
  {
	setcookie('HTDILogin', '');
	setcookie('HTDIPassword', '');
  }

?>