<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
 include("companyquery.php");

$myhelp = "class='active'";
//-------client
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, showstatus FROM clients WHERE id='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password2 = $row[12];
        $showstatus = $row[13];


    } 

    ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<script type="text/javascript" src="common/js/dropdownmenu.js"></script>
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
  <?php

 include("header.php");
    ?>      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
           <?php
if($added=="yes"){
	echo "<h2><img src=common/images/help_icon.png>Received!</h2><p>We have received your Helpdesk ticket and will respond shortly.  You will receive an email once an answer has been submitted.</p>";
}else{
echo "<h2><img src=common/images/help_icon.png>Help Desk</h2> <p>Don't want to call customer support?  Easily submit a new Helpdesk ticket below.  One of our staff members will get back to you as soon as possible.</p>";
}
    ?> 
          </div>
          <div class="common_box">
            <div class=" top_curve">
              <div class="bottom_curve">
                <div class="start_ticket_details">
                  <div class="top_section"> <span class="open_btn"><a href="my_help.php?status=OPEN"></a></span>
                    <h2>Existing Helpdesk Tickets</h2>
                    <span class="close_btn"><a href="my_help.php?status=CLOSED"></a></span> </div>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="top_table">
                    <tr>
                      <td class="col1">Ticket ID</td>
                      <td class="col2">Status</td>
                      <td class="col3">Subject</td>
                      <td class="col4">Logged</td>
                    </tr>
                  </table>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="detail_table">
          <?php
                   if($status =="OPEN"){
                   $statusq = " and status!='CLOSED'";
                   }
                   if($status =="CLOSED"){
                   $statusq = " and status='CLOSED'";
                   }

    $query = "SELECT id, status, subject, description, DATE_FORMAT(date, \"%m-%d-%Y\") as hdlogdate,  tstamp, ip FROM helpdesk WHERE deleted !='Yes'$statusq and clientid='" . $_SESSION['clientusid'] . "' ORDER BY id DESC"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $hdid= $row[0];
        $hdstatus = $row[1];
        $hdsubject = $row[2];
        $hddescription = $row[3];
        $hdlogdate= $row[4];
        $hdtstamp= $row[5];
        $hdip= $row[6];


        ?>
		<tr>
                      <td class="col1"><a href="viewticket.php?hdid=<?php print($hdid); ?>"><?php print($hdid); ?></a></td>
                      <td class="col2"><?php print($hdstatus); ?></td>
                      <td class="col3"><a href="viewticket.php?hdid=<?php print($hdid); ?>"><?php print($hdsubject); ?></a></td>
                      <td class="col4"><?php print($hdlogdate); ?></td>
                    </tr>
                   
  <?php
    }
    //mysql_close($conn);
    ?>

                  </table>
                  <div class="row"> <a href="logticket.php"><img src="common/images/start_new_ticket_btn.gif" alt="" class="start_new_btn" /></a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>
  </div>
</div>
</body>
</html>
<?
}
else
{
    header("Location: clientlogin.php");
    exit();
}
?>