<?php
require_once('common.inc.php');
ob_start();


extract( $_GET );
extract( $_POST );

include("connection.php");
 include("companyquery.php");

if(($_POST['username']==null) && ($_POST['password']==null))
{
$def = "yes";

$query = "SELECT cbackgroundimage, cmaintextsize, cmaintextfont, cbackgroundcolor FROM companycss WHERE id='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $cbackgroundimage= $row[0];
        $cmaintextsize= $row[1];
        $cmaintextfont = $row[2];
        $cbackgroundcolor= $row[3];
    }
if ($cbackgroundcolor == ""){
$backgroundsettings = "background-image:   url('$cbackgroundimage')";
}else{
$backgroundsettings = "background-color:'$cbackgroundcolor'";
}

    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
      <div id="header" class="min_space"> <?php print($insertheader); ?>
        <div class="right_details"> <span class="need_help">Need Help? Call us at:</span> <span class="number"><?php print($companyphone); ?>
<br />
         <!-- <small>9:00 AM - 5:00 PM Mountain</small>--></span></div>
        <div class="menu"> &nbsp; </div>
        <img src="common/images/menu_bottom_shadow.gif" alt="" /> </div>
<?php
if($ls =="No"){
echo "<center><font size=3 color=red><B>Invalid Credentials</b></font></center><BR>";
}else if($ls =="None"){
echo "<center><font size=3 color=red><B>The username submitted is not recognized</b></font></center><BR>";
}

?>	
      <div id="body_container" > 
        <div id="left_container" >
          <div class="account_login_box" >
            <div class="top_curve">
              <div class="bottom_curve">
           
                  <fieldset > <FORM  action="clientlogin.php" method="POST">
                  <div class="left_details" >
                    <h2><img src="common/images/account_login_icon1.png" alt="" />Account Login!</h2>
                    <label>Enter your username and password below.</label>
                    <div class="input_bg">
                      <input name="username" type="text" value="Username" onclick="if(this.value == 'Username') this.value='';" />
                    </div>
                    <div class="input_bg">
                      <input name="password" type="password" value="" onclick="if(this.value == 'Password') this.value='';" />
                    </div>
                    <br class="clear" />
                    <input type="submit" name="" value="" class="login_btn" onmouseover="this.className=('login_btn_over')" onmouseout="this.className=('login_btn')" />
                  </div>

<?php
if($ps =="Forgot"){
?>	

                  <div class="right_details">
                    <h2><img src="common/images/account_login_icon2.png" alt="" />Password Sent!</h2>
                    <label class="remember">Thank you.  For security Reasons your password has been sent to the email address we have on file.  If for some reason you do not receive our email within a few moments, please check your spam filter or junk mail folder, it may be located there.  If you need further assistance you can call us at <?php print($companyphone); ?>.</label>
                   </div> 
	<?php
}else{
?>	

                  <div class="right_details">
                    <h2><img src="common/images/account_login_icon2.png" alt="" />Forgot Password?</h2>
                    <label class="remember">Can’t Remember your password? <br />
                    Enter your user name and we will send it again.</label>
                    <div class="input_bg">
                      <input name="forgotusername" type="text" value="Username" onclick="if(this.value == 'Username') this.value='';"/>
                    </div>
                    <label>For security purposes your password will be <br />
                    sent to the email address we have on file.</label>
                    <br class="clear" />
                    <input type="submit" name="" value="" class="send_btn" onmouseover="this.className=('send_btn_over')" onmouseout="this.className=('send_btn')" />
                  </div> 
	<?php
				  }
				  ?>				  
				  
				  
				  
				  
				  
				  
				  </form>
                  </fieldset>
               
              </div>
            </div>
          </div>
        </div>
  <?php
if($companyname =="The Consumer Credit Repair Agency"){
?>
     <div id="right_container">
          <div class="safe_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h3>Safe &amp; Secure!</h3>
                <div class="row"> <a href="#"><img src="common/images/safe_image1.png" alt="" /></a> <a href="#"><img src="common/images/safe_image2.png" alt="" /></a> <a href="#"><img src="common/images/safe_image3.png" class="macfee" alt="" /></a> </div>
              </div>
            </div>
          </div>
        </div>

  <?php
}
  ?>


      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/login_bottom_curve.png" alt="" /></div>
    <div>
      <div id="footer">
        <div class="photo"><img src="common/images/footer_lock.png" alt="" /></div>
        <div class="details"> <img src="common/images/safe.png" alt="" />
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
 <?php
  } 
  else
  {



 session_start();
    session_destroy();

$forgotusername = $_POST['forgotusername'];
if(($forgotusername =="") or ($forgotusername =="Username")){
///////START CLIENT LOGIN
$query = "SELECT id, name, logins FROM clients WHERE clientdelete !='yes' and password='" . mysql_real_escape_string($_POST['password']) . "' and username='" . mysql_real_escape_string($_POST['username']) . "' and status != 'inactive' and status != 'canceled' and status != 'expired' and username !='' LIMIT 1";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    if($row=mysql_fetch_assoc($result))
    {
        $clientusid   = $row['id'];
        $clientname = $row['name'];
        $logins = $row['logins'];
        $is_client = 1;
        session_register('clientusid');  
        session_register('clientname'); 
        session_register('is_client'); 

$morelogins = $logins+1;
$lastlogin = date("Y-m-d");

$query = "UPDATE clients SET logins='$morelogins', lastlogin='$lastlogin' WHERE id=$clientusid";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
mysql_close($conn);
header("Location: main.php");   
exit();
}else{
$loginsuccess = "No";
header("Location: clientlogin.php?ls=$loginsuccess");   
exit();
}
///////END CLIENT LOGIN
}else{
$query = "SELECT email, username, password FROM clients WHERE clientdelete !='yes' and username='" . mysql_real_escape_string($_POST['forgotusername']) . "' and status != 'inactive' and status != 'canceled' and status != 'expired' and username !='' LIMIT 1";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    if($row=mysql_fetch_assoc($result)){
        $clientemail   = $row['email'];
        $clientusername   = $row['username'];
        $clientpassword   = $row['password'];
	


$EMAIL_Message = "$companyskin Please find your login credentials below:<BR><BR>Password: $clientpassword<BR><BR><BR>Please login at <a href=$companywebsite>$companywebsite</a>";
$EMAIL_Subject = "Your login credentials";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From>\r\n";
                $formsent = mail($clientemail, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  




$loginsuccess = "Forgot";
header("Location: clientlogin.php?ps=$loginsuccess");   
exit();
	}else{
$loginsuccess = "None";
header("Location: clientlogin.php?ls=$loginsuccess");   
exit();
	}


}//////END IF FORGOT
}
?>



