<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
 include("companyquery.php");

$myhome = "class='active'";

    $query = "SELECT showstatus, plan, broker_id, name, country FROM clients WHERE id='" . $_SESSION['clientusid'] . "'"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $showstatus = $row[0];
        $plan = $row[1];        
        $broker_id = $row[2];        
        $name = $row[3];        
        $country = $row[4];        
 }
if($showstatus ==""){
	$showstatus = "&nbsp;";
}


$clientfirstname = explode(' ', $name); 
$clientfirstname = $clientfirstname[0];

function encodeDataURL($strDataURL, $addNoCacheStr=false) {
    if ($addNoCacheStr==true) {
		if (strpos($strDataURL,"?")<>0)
			$strDataURL .= "&FCCurrTime=" . Date("H_i_s");
		else
			$strDataURL .= "?FCCurrTime=" . Date("H_i_s");
    }
	return urlencode($strDataURL);
}


function datePart($mask, $dateTimeStr) {
    @list($datePt, $timePt) = explode(" ", $dateTimeStr);
    $arDatePt = explode("-", $datePt);
    $dataStr = "";
    if (count($arDatePt) == 3) {
        list($year, $month, $day) = $arDatePt;
        // determine the request
        switch ($mask) {
        case "m": return $month;
        case "d": return $day;
        case "y": return $year;
        }
        return (trim($month . "/" . $day . "/" . $year));
    }
    return $dataStr;
}


function renderChart($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false, $registerWithJS=false, $setTransparent="true") {
	if ($strXML=="")
        $tempData = "//Set the dataURL of the chart\n\t\tchart_$chartId.setDataURL(\"$strURL\")";
    else
        $tempData = "//Provide entire XML data using dataXML method\n\t\tchart_$chartId.setDataXML(\"$strXML\")";

    $chartIdDiv = $chartId . "Div";
    $ndebugMode = boolToNum($debugMode);
    $nregisterWithJS = boolToNum($registerWithJS);
	$nsetTransparent=($setTransparent?"true":"false");
$render_chart = <<<RENDERCHART

	<!-- START Script Block for Chart $chartId -->
	<div id="$chartIdDiv" align="center">
		Chart.
	</div>
	<script type="text/javascript">	
		var chart_$chartId = new FusionCharts("$chartSWF", "$chartId", "$chartWidth", "$chartHeight", "$ndebugMode", "$nregisterWithJS");
      chart_$chartId.setTransparent("$nsetTransparent");
    
		$tempData
		chart_$chartId.render("$chartIdDiv");
	                         </script>	
	<!-- END Script Block for Chart $chartId -->
RENDERCHART;

  return $render_chart;
}


function renderChartHTML($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false,$registerWithJS=false, $setTransparent="true") {
    $strFlashVars = "&chartWidth=" . $chartWidth . "&chartHeight=" . $chartHeight . "&debugMode=" . boolToNum($debugMode);
    if ($strXML=="")
        $strFlashVars .= "&dataURL=" . $strURL;
    else
        $strFlashVars .= "&dataXML=" . $strXML;
    
    $nregisterWithJS = boolToNum($registerWithJS);
    if($setTransparent!=""){
      $nsetTransparent=($setTransparent==false?"opaque":"transparent");
    }else{
      $nsetTransparent="window";
    }
$HTML_chart = <<<HTMLCHART
	<!-- START Code Block for Chart $chartId -->
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="$chartWidth" height="$chartHeight" id="$chartId">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="$chartSWF"/>		
		<param name="FlashVars" value="$strFlashVars&registerWithJS=$nregisterWithJS" />
		<param name="quality" value="high" />
		<param name="wmode" value="$nsetTransparent" />
		<embed src="$chartSWF" FlashVars="$strFlashVars&registerWithJS=$nregisterWithJS" quality="high" width="$chartWidth" height="$chartHeight" name="$chartId" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="$nsetTransparent" /></object>
	<!-- END Code Block for Chart $chartId -->
HTMLCHART;

  return $HTML_chart;
}

function boolToNum($bVal) {
    return (($bVal==true) ? 1 : 0);
}



             if($country =="" or $country=="United States")   {
 $countryquery = "WHERE country = 'United States'";
 } else if($country=="Canada")   {
 $countryquery = "WHERE country = '$country'";
 } else{
 $countryquery = "WHERE country = '$country'";
 }



$query = "SELECT id, type FROM accounttype $countryquery "; 
      $result = mysql_query($query, $conn) or die("error:" . mysql_error());
      $col_count = mysql_num_fields($result);
      while($row=mysql_fetch_row($result))
      {
        $actypeid = $row[0];
        $actype = $row[1];

$query3 = "SELECT count(deleted) FROM accounts WHERE (deleted='Deleted' OR deleted='Fixed') and accounttype='$actypeid' and clientid='" . $_SESSION['clientusid'] . "' "; 
$result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
while($row3=mysql_fetch_row($result3))
{
$deleted2 = $row3[0];
$i = $i+1;
}

$query4 = "SELECT count(id) FROM accounts WHERE accounttype='$actypeid' and clientid='" . $_SESSION['clientusid'] . "' "; 
$result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
while($row3=mysql_fetch_row($result4))
{
$totalaccts = $row3[0];
$i = $i+1;
}

$totaldeletes = $totaldeletes + $deleted2;
$totalaccounts = $totalaccounts + $totalaccts;

if ($totalaccts !=0){
$percentagefixed = $deleted2/$totalaccts*100;
}
if ($actypeid == 1){
$equifaxvalue = $percentagefixed;
}if ($actypeid == 2){
$experianvalue = $percentagefixed;
}if ($actypeid == 3){
$transunionvalue = $percentagefixed;
}if ($actypeid == 8){
$equifaxcavalue = $percentagefixed;
}if ($actypeid == 9){
$transunioncavalue = $percentagefixed;
}



$datavalues .= "<set label='$actype' value='$percentagefixed' />";
}

 $strXML  = "<chart numberSuffix='%25' chartLeftMargin='0' decimals='2' chartRightMargin='0' palette='2' labelDisplay='Rotate' slantLabels='1' numDivLines ='3' YAxisMaxValue ='100' showPrintMenuItem='0' showValues='1' use3DLighting ='1' showAboutMenuItem='0' showBorder='0' bgAlpha='0,0' >";
	$strXML .= "$datavalues";
	
	$strXML .= "<styles>";
$strXML .= "<definition>";

$strXML .= "<style name='myFont' type='font' isHTML='1' bold='1' size='11' color='FFFFFF' />";
$strXML .= "<style name='myShadow' type='shadow' color='333333' angle='45' strength='3'/>";
$strXML .= "<style name='myShadow2' type='shadow' angle='45' distance='1' color='FFFFFF'/>";
$strXML .= "<style name='myAnim3' type='animation' param='_xScale' start='0' duration='1'/>";
$strXML .= "<style name='myAnim4' type='animation' param='_alpha' start='0' duration='1'/>";
$strXML .= "<style name='myAnim5' type='animation' param='_xScale' start='0' duration='1'/>";
$strXML .= "<style name='myAnim6' type='animation' param='_y' start='$canvasStartY' duration='1'/>";
$strXML .= "</definition>";

$strXML .= "<application>";
$strXML .= "<apply toObject='DataValues' styles='myFont,myShadow,myAnim' />";
//$strXML .= "<apply toObject='DataLabels' styles='myFont,myShadow,myAnim' />";
$strXML .= "<apply toObject='DIVLINES' styles='myShadow2' />";
$strXML .= "<apply toObject='ANCHORS' styles='myAnim2' />";
$strXML .= "<apply toObject='ANCHORS' styles='myBevel' />";
$strXML .= "<apply toObject='HGRID' styles='myAnim3, myAnim4' />";
$strXML .= "<apply toObject='DIVLINES' styles='myAnim5' />";
$strXML .= "<apply toObject='YAXISVALUES' styles='myAnim6' />";
$strXML .= "</application>";

$strXML .= "</styles>";

	$strXML .= "</chart>";
	

    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">

      
<?php

 include("header.php");
    ?>




      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_home_icon.png" alt="" />My Home</h2>
            <p>Welcome back, below is a snapshot of our progress to date, more detailed information can be found on your My Results page.</p>
          </div>
          <div class="overall_box">
            <div class="top_curve">
              <div class="bottom_curve">


                <div class="left_details">


<?php
if($totalaccounts !=""){
$fixed = $totaldeletes/$totalaccounts*100;
$fixedchart = number_format($fixed, 0, '.', '');
}

if($companyname =="The Consumer Credit Repair Agency"){
?>
                  <h3>Overall Improvement<BR><?php print($fixedchart); ?>%</h3>

<script language="JavaScript" src="FusionCharts.js"></script>
 <div id="chartdiv" align="center">
         The chart will appear within this DIV. This text will be replaced by the chart.
      </div>
	   <script type="text/javascript">
	
var myChart = new FusionCharts("AngularGauge.swf", "myChartId", "325", "175", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='0' chartRightMargin='0' chartTopMargin='0' showAboutMenuItem='0' bgAlpha='0,0' showBorder='0' gaugeFillMix='{light-10},{light-30},{light-20},{dark-5},{color},{light-30},{light-20},{dark-10}' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' gaugeStartAngle='180' gaugeEndAngle='0' palette='1' numberSuffix='%25' tickValueDistance='10' showValue='1'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><dials><dial value='<?php print($fixed); ?>' rearExtension='10'/></dials></chart>");
         myChart.setTransparent(true);
		 myChart.render("chartdiv");
      </script>
<?php
}else{
echo renderChartHTML("http://www.tcrosystems.net/Column3D.swf", "", $strXML, "bargraph", 325, 250, false, false);
}
?>

</div>
                
				
<div class="right_details">
<?php
if($companyname =="The Consumer Credit Repair Agency"){
$eqxchart = number_format($equifaxvalue, 0, '.', '');
$expchart = number_format($experianvalue, 0, '.', '');
$tuchart = number_format($transunionvalue, 0, '.', '');

?>

<h3>Equifax - <?php print($eqxchart); ?>% Improvement</h3>
<span><div id="chartdiv2" align="center">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("HLinearGauge.swf", "myChartId2", "350", "50", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='4' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='9' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($equifaxvalue); ?></value></chart>");
               myChart.setTransparent(true);
   myChart.render("chartdiv2");
      </script>
	  
	  <h3 class="space">Experian - <?php print($expchart); ?>% Improvement</h3>
<span><div id="chartdiv3" align="center">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("HLinearGauge.swf", "myChartId2", "350", "50", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='4' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='9' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($expchart); ?></value></chart>");
               myChart.setTransparent(true);
   myChart.render("chartdiv3");
      </script>

                  <h3 class="space">TransUnion - <?php print($tuchart); ?>% Improvement</h3>
<span><div id="chartdiv4" align="center">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("HLinearGauge.swf", "myChartId2", "350", "50", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='4' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='9' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($tuchart); ?></value></chart>");
               myChart.setTransparent(true);
   myChart.render("chartdiv4");
      </script>

<?php
}else{

if($totalaccounts !=""){
$fixed = $totaldeletes/$totalaccounts*100;
$open = ($totalaccounts-$totaldeletes)/($totalaccounts)*100;
$delpercentage = $totaldeletes/$totalaccounts*100;
$delpercentage = number_format($delpercentage, 2, '.', '');

}
$strXML2  = "<chart numberSuffix='%25' caption='Items fixed/deleted: $totaldeletes out of $totalaccounts ($delpercentage%25)' showZeroPies='0' chartTopMargin='0' chartBottomMargin='0' chartLeftMargin='0' showPercentValues='1' showAboutMenuItem='0' showPrintMenuItem='0' showValues='0' showLabels='1' showYAxisValues ='0' formatNumberScale='0' showShadow='1' startingAngle='90' use3DLighting ='1' showBorder='0' bgAlpha='0,0'>";
$strXML2 .= "<set label='Open' value='$open'  isSliced='1'  />";
$strXML2 .= "<set label='Fixed' value='$fixed' color='008000'/>";
$strXML2 .= "</chart>";
echo renderChartHTML("http://www.tcrosystems.net/Pie2D.swf", "", $strXML2, "myFirst", 420, 270, false, false);
}
?>

               
				  
				  </div>
                <div class="content_details">
                  <h3>My current status is:</h3>
                  <ul>
                    <li><?php print($showstatus); ?></li>
                  </ul>
                  <p>&nbsp;</p>
 <p>&nbsp;</p>
                           
		
		    <?php

				   if($broker_id !=""){
   $query3 = "SELECT firstname, lastname, email, telephone, url, notification, bio, bioapproved, address2 FROM dealers WHERE dealer_id='$broker_id' and status !=9"; 
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $brokerfirstname = $row3[0];
                   $brokerlastname = $row3[1];
                   $brokeremail = $row3[2];
                   $brokerphone = $row3[3];
                   $brokerurl = $row3[4];
                   $brokernotification= $row3[5];
                   $brokerbio= $row3[6];
                   $brokerbioapproved= $row3[7];
                   $brokerwebsite = $row3[8];
				   $brokerbio = nl2br($brokerbio);         

				   }
}

if($brokernotification ==1){
?>
<hr> <p>&nbsp;</p>

   <table border="0" width="100%" id="AutoNumber2">
       <tr>
            <td width="50%" valign="top">
                 <h3>You were referred by:</h3>
 <p><strong><?php print($brokerfirstname); ?> <?php print($brokerlastname); ?></strong></p> <p>&nbsp;</p>
<?php if($brokerphone !=""){ ?>
<p>Phone: <?php print($brokerphone); ?></p> <p>&nbsp;</p>
<?php }?>
<?php if($brokeremail !=""){ ?>
<p>Email: <a href="mailto:<?php print($brokeremail); ?>"><?php print($brokeremail); ?></a></p><p>&nbsp;</p>
<?php }?>                  
<?php if($brokerwebsite !=""){
    $brokerwebsiteLink=$brokerwebsite;
    if (!strpos("-".$brokerwebsite, "http://")) {
        $brokerwebsiteLink="http://".$brokerwebsite;
    } ?>
<p>Website: <a href="<?php print($brokerwebsiteLink); ?>"><?php print($brokerwebsite); ?></a></p>
<?php }?> 
				  <p>&nbsp;</p>
                  <p>&nbsp;</p>
				  </td>
            <td width="50%">
  <?php
	

    if($brokerurl !=""){
    $mypicture = getimagesize("../brokers/pics/$brokerurl"); 
   if($mypicture[0] >200){
   $imagewidth = 200;
   }else{
   $imagewidth = $mypicture[0];
}

     ?>
      
 <p align="center">           
 <img border="0" src="../brokers/pics/<?php print($brokerurl); ?>" width="<?php print($imagewidth); ?>">           
            
            
     <?php
}
     ?>
   
        
            
            
            
            
            </td>
          </tr>
<!--- BIO -->
    
<?php
if($brokerbioapproved =="Yes"){
?>

<tr>
            <td colspan=2 width="100%" valign="top">
                 <h3>Bio of <?php print($brokerfirstname); ?> <?php print($brokerlastname); ?></h3>
                  <p><?php print($brokerbio); ?></p><BR><BR>
				  </td>
            </td>
          </tr>
		  <?php
}}
?>

<!--END BIO --> 

        </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      
<?php

 include("rightframe.php");
    ?>



        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>
 </div>
</div>
</body>
</html>
    <?
}
else
{
    header("Location: clientlogin.php");
    exit();
}
?>