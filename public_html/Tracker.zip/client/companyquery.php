<?php
$query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, autoscheduler, reseller, htdiwebsite, adminsinglepayment1, adminsinglepayment2, admincouplepayment1, admincouplepayment2, single, couple, creditcard, paypal2, ach, singlefull, singledownpay1, singlepayment, couplefull, coupledownpay1, couplepayment, threeinone, paypal, months, perdelete, livehuman, dbname, dropdowncreditors, dropdownbegin, dropdowntails, autoresponder, bautoresponder, cautoresponder, helpdesk, companyheader, portals, privatelabel FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $autoscheduler = $row[12];          
        $reseller = $row[13];           
        $htdiwebsite = $row[14];           
        $adminsinglepayment1 = $row[15];
        $adminsinglepayment2 = $row[16];
        $admincouplepayment1 = $row[17];
        $admincouplepayment2 = $row[18];                                
        $single = $row[19];                                
        $couple = $row[20];                                
        $creditcard = $row[21];                 
        $paypal2 = $row[22];                 
        $ach = $row[23];                 
        $singlefull = $row[24];          
        $singledownpay1 = $row[25];          
        $singlepayment = $row[26];          
        $couplefull = $row[27];          
        $coupledownpay1 = $row[28];          
        $couplepayment = $row[29];          
        $threeinone = $row[30];          
        $paypal = $row[31];          
        $months = $row[32];          
        $perdelete = $row[33];          
        $livehuman = $row[34];          
        $dbname = $row[35];          
        $dropdowncreditors = $row[36];    
        $dropdownbegin = $row[37];    
        $dropdowntails = $row[38];                            
        $autoresponder = $row[39];                            
        $bautoresponder = $row[40];                            
        $cautoresponder = $row[41];                            
        $helpdesk = $row[42];                            
        $companyheader = $row[43];                            
        $portals = $row[44];                            
        $privatelabel = $row[45];                            
    }
if($companyheader !=""){
	    $mylogo = getimagesize("$companyheader"); 
   if($mylogo[0] >525){
   $logoimagewidth = 525;
   }else{
   $logoimagewidth = $mylogo[0];
}


$insertheader = "<a href=\"main.php\"><img src=\"$companyheader\" border=0 class=\"logo\" width=\"$logoimagewidth\"/></a>";
}else{
$insertheader = "";
}

if($privatelabel =="No"){
$poweredbymessage="<p align=center><a target=\"_blank\" href=\"http://www.creditrepairtracking.com\"><img border=0 src=../admin/trackstarlogoforemail.png></a></p>";
}



$query = "SELECT cbackgroundimage, cmaintextsize, cmaintextfont, cbackgroundcolor FROM companycss WHERE id='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $cbackgroundimage= $row[0];
        $cmaintextsize= $row[1];
        $cmaintextfont = $row[2];
        $cbackgroundcolor= $row[3];
    }
if ($cbackgroundcolor == ""){
$backgroundsettings = "background-image:   url('$cbackgroundimage')";
}else{
$backgroundsettings = "background-color:'$cbackgroundcolor'";
}


    $today = date("Y-m-d");
if($portals !="Yes"){
exit();
}

?>