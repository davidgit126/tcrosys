<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );


if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
 include("companyquery.php");

//-------client
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password FROM clients WHERE id='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password2 = $row[12];


    } 
//----------enrolment
    $query = "SELECT DATE_FORMAT(dateenrol, \"%m-%d-%Y\") as dateenrol,  DATE_FORMAT(reportreceived, \"%m-%d-%Y\") as repdate, DATE_FORMAT(addressreceived, \"%m-%d-%Y\") as adddate, DATE_FORMAT(ssdate, \"%m-%d-%Y\") as ssdate, DATE_FORMAT(welcomepacket, \"%m-%d-%Y\") as welcomedate, DATE_FORMAT(returndoc, \"%m-%d-%Y\") as returndoc FROM enrolment WHERE clientid='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dateenrol = $row[0];
        $reportreceived = $row[1];
        $addressreceived = $row[2];
        $ssdate = $row[3];
        $welcomepacket = $row[4];
        $returndoc = $row[5];
    } 
//---------billing
    $query = "SELECT auditfee, DATE_FORMAT(paid, \"%m-%d-%Y\") as paid, monthlyfee, monthlydue, payment FROM billing WHERE clientid='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $auditfee = $row[0];
        $paid = $row[1];
        $monthlyfee = $row[2];
        $monthlydue = $row[3];
        $payment = $row[4];
    } 

//////START CUSTOM PAGES


  $query = "SELECT id, pagename, active, pageorder, onheader, onfooter, pagecontent, pagetitle, pagemetas, type FROM webcms WHERE pagename='$page' and type='client'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $pagename  = $row[1];
              $active   = $row[2];
              $pageorder   = $row[3];
              $onheader = $row[4];
              $onfooter = $row[5];              
              $pagecontent = $row[6];                
              $pagetitle = $row[7];     
              $pagemetas = $row[8];                
              $pagetype = $row[9];                
$onpage = $pagename;
}

$todaysdate =  date("F d, Y");
$year =   date("Y");

 $clientfirstname = explode(' ', $name); 
$clientfirstname = $clientfirstname[0];

$pagecontent = str_replace("{PASSWORD}", "$password2", $pagecontent);

$pagecontent = str_replace("{THREEINONE}", "$threeinone", $pagecontent);
$pagecontent = str_replace("{COMPANY}", "$companyname", $pagecontent);
$pagecontent = str_replace("{COMPANYADDR}", "$companyaddress", $pagecontent);
$pagecontent = str_replace("{COMPANYCITY}", "$companycity", $pagecontent);
$pagecontent = str_replace("{COMPANYSTATE}", "$companystate", $pagecontent);
$pagecontent = str_replace("{COMPANYZIP}", "$companyzip", $pagecontent);
$pagecontent = str_replace("{COMPANYPHONE}", "$companyphone", $pagecontent);
$pagecontent = str_replace("{COMPANYFAX}", "$companyfax", $pagecontent);
$pagecontent = str_replace("{SITE}", "$companywebsite", $pagecontent);
$pagecontent = str_replace("{COMPANYEMAIL}", "$companyemail", $pagecontent);
$pagecontent = str_replace("{USERNAME}", "$username", $pagecontent);
$pagecontent = str_replace("{NAME}", "$name", $pagecontent);
$pagecontent = str_replace("{ADDRESS}", "$address", $pagecontent);
$pagecontent = str_replace("{CITY}", "$city", $pagecontent);
$pagecontent = str_replace("{STATE}", "$state", $pagecontent);
$pagecontent = str_replace("{ZIP}", "$zip", $pagecontent);
$pagecontent = str_replace("{EMAIL}", "$email", $pagecontent);
$pagecontent = str_replace("{PHONE}", "$phone", $pagecontent);
$pagecontent = str_replace("{SSN}", "$ssnum", $pagecontent);
$pagecontent = str_replace("{DOB}", "$birthdate", $pagecontent);
$pagecontent = str_replace("{FNAME}", "$clientfirstname", $pagecontent);
$pagecontent = str_replace("{TODAYDATE}", "$todaysdate", $pagecontent);
$pagecontent = str_replace("{YEAR}", "$year", $pagecontent);

if($pagename == "Marketing"){
	$subimageheader = "my_marketing_icon.png";
}else if($pagename == "FAQ"){
	$subimageheader = "faq_icon.png";
}else if($pagename == "Refer"){
	$subimageheader = "referral_icon.png";
}else {
	$subimageheader = "my_home_icon.png";
}


$freeconsultform = "<form action=\"prospect_signup.php\" method=\"post\" target=\"_top\"><table cellspacing=\"5\" cellpadding=\"5\"><tr><td><p align=\"left\">First Name</p></td>";
$freeconsultform .= "<td ><input size=\"15\" name=\"fname\"></td></tr><tr><td ><p align=\"left\">Last Name </p></td><td ><input size=\"15\" name=\"lname\"></td></tr><tr><td ><p align=\"left\">Phone</p></td>";
$freeconsultform .= "<td ><input size=\"15\" name=\"phone\"></td></tr><tr><td ><p align=\"left\">Email</p></td><td ><input size=\"15\" name=\"email\"></td></tr>";
if ($action == "added"){
$freeconsultform .= "<tr><td colspan=\"2\"><p align=\"center\">Your referral has been submitted.  Thank you.</p></td></tr></table></form>";
}else{
$freeconsultform .= "<tr><td colspan=\"2\"><p align=\"center\"><input type=\"submit\" value=\"Submit\" name=\"submit\"></p></td></tr></table></form>";
	}
$pagecontent = str_replace("{FREECONSULT}", "$freeconsultform", $pagecontent);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php print($pagetitle); ?></title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
    <script language="javascript" type="text/javascript">
        <!--
        function popitup(url) {
            newwindow = window.open(url, 'blank', 'scrollbars=yes,toolbar=no,width=700,height=620');
            if (window.focus) {
                newwindow.focus()
            }
            return false;
        }
        var gHref = 'drive.php';
        // -->
    </script>
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">

      
<?php

 include("header.php");
    ?>




      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/<?php print($subimageheader); ?>" alt="" /><?php print($pagename); ?></h2>
            <p><?php print($pagemetas); ?></p>
          </div>
          <div class="overall_box">
            <div class="top_curve">
              <div class="bottom_curve">

                <div class="cmscontent_details">
                  <h3><?php print($pagetitle); ?></h3>
                 

                  <p><?php echo $pagecontent; ?></p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      
<?php

 include("rightframe.php");
    ?>



        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>
  </div>
</div>
</body>
</html>
    <?
}
else
{
    header("Location: clientlogin.php");
    exit();
}
?>