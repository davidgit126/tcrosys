<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
 include("companyquery.php");

$mystatus = "class='active'";

//-------client
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, showstatus FROM clients WHERE id='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password2 = $row[12];
        $showstatus = $row[13];


    } 

    ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
   <?php

 include("header.php");
    ?>

      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_status_icon.png" alt="" />My Status</h2>
            <p>View the current status of your account, follow each round of correspondence, all communication and other documented work during the on-going credit repair process.</p>
          </div>
          <div class="my_status_details">
            <div class="table_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>My Status: <?php print($showstatus); ?></h3>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Date</td>
                      <td class="col2">Received</td>
                      <td class="col3">Response</td>
                    </tr>
                  </table>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                  

    <?php
    $query = "SELECT DATE_FORMAT(repairdate, \"%m-%d-%Y\") as repdate,  received, action,  filelocation, counselor FROM  repair WHERE clientid='" . $_SESSION['clientusid'] . "' ORDER BY repairdate DESC"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $repairdate= $row[0];
        $received = $row[1];
        $action = $row[2];
        $filelocation = $row[3];
        $counselor= $row[4];
          if($filelocation !=""){
         $bgcolor = "bgcolor=#FFCCCC";
}else {

                    $bgcolor = "";

                    }


        ?>


                    <tr <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($repairdate); ?></td>
                      <td class="col5" ><?php print($received); ?></td>
                      <td class="col6" ><?php print($action); ?></td>
                    </tr>
                   <?php
    }
   // mysql_close($conn);
    ?>
                    <tr>
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                    <tr>
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>
  </div>
</div>
</body>
</html>
<?
}
else
{
    header("Location: clientlogin.php");
    exit();
}
?>