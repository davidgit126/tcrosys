<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
 include("companyquery.php");

$myresults = "class='active'";

//-------client
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, showstatus, status, country FROM clients WHERE id='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password2 = $row[12];
        $showstatus = $row[13];
        $status = $row[14];
        $country = $row[15];

    } 
$pageon = "My Results";

             if($country =="" or $country=="United States")   {
 $countryquery = "WHERE country = 'United States'";
 } else if($country=="Canada")   {
 $countryquery = "WHERE country = '$country'";
 } else{
 $countryquery = "WHERE country = '$country'";
 }


$query = "SELECT id, type FROM accounttype $countryquery "; 
      $result = mysql_query($query, $conn) or die("error:" . mysql_error());
      $col_count = mysql_num_fields($result);
      while($row=mysql_fetch_row($result))
      {
        $actypeid = $row[0];
        $actype = $row[1];

$query3 = "SELECT count(deleted) FROM accounts WHERE (deleted='Deleted' OR deleted='Fixed') and accounttype='$actypeid' and clientid='" . $_SESSION['clientusid'] . "' "; 
$result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
while($row3=mysql_fetch_row($result3))
{
$deleted2 = $row3[0];
$i = $i+1;
}

$query4 = "SELECT count(id) FROM accounts WHERE accounttype='$actypeid' and clientid='" . $_SESSION['clientusid'] . "' "; 
$result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
while($row3=mysql_fetch_row($result4))
{
$totalaccts = $row3[0];
$i = $i+1;
}

$totaldeletes = $totaldeletes + $deleted2;
$totalaccounts = $totalaccounts + $totalaccts;

if ($totalaccts !=0){
$percentagefixed = $deleted2/$totalaccts*100;
}
if ($actypeid == 1){
$equifaxvalue = $percentagefixed;
}if ($actypeid == 2){
$experianvalue = $percentagefixed;
}if ($actypeid == 3){
$transunionvalue = $percentagefixed;
}if ($actypeid == 8){
$equifaxcavalue = $percentagefixed;
}if ($actypeid == 9){
$transunioncavalue = $percentagefixed;
}



$datavalues .= "<set label='$actype' value='$percentagefixed' />";
}
    ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
<script type="text/javascript" src="common/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="common/js/main.js"></script>
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
     <?php

 include("header.php");
 $eqxchart = number_format($equifaxvalue, 0, '.', '');
$expchart = number_format($experianvalue, 0, '.', '');
$tuchart = number_format($transunionvalue, 0, '.', '');
 $eqxcachart = number_format($equifaxcavalue, 0, '.', '');
$tucachart = number_format($transunioncavalue, 0, '.', '');

    ?>
      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/result_icon.png" alt="" />My Results</h2>
            <p>Track your monthly progress across all three bureaus, view the total number of items corrected, updated or deleted.</p>
          </div>
          <div class="my_results_details">
    
		  
  <?php
             if($country =="" or $country=="United States")   {
    ?>

            <div class="equifax_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>Equifax - <?php print($eqxchart); ?>% Improvement</h3>
  <?php
if($companyname =="The Consumer Credit Repair Agency"){
?><script language="JavaScript" src="FusionCharts.js"></script>
<span class="miter"><div id="chartdiv2">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("HLinearGauge.swf", "myChartId2", "365", "48", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='8' baseFontSize='9' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='8' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($equifaxvalue); ?></value></chart>");
                 myChart.setTransparent(true);
 myChart.render("chartdiv2");
      </script>
<?php
			}
	  ?>

				
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col2">Description</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <div class="main_table child_table"> <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
              <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientusid']) . "' and accounttype='1'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  if($deleted =="Deleted" or $deleted =="Fixed"){
         $bgcolor="bgcolor=#00FF00";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
         $bgcolor="";
$derogstatus = "On Hold";
}else if($status =="scheduled"){
         $bgcolor="bgcolor=#FFCCCC";

                     $derogstatus = "Scheduled";

}else if($status =="pending"){
         $bgcolor="bgcolor=#FFFF99";

                     $derogstatus = "prepared/pending";

}else {


         $bgcolor="";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>
	
	<tr class="row" <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($acname); ?></td>
                      <td class="col5"><?php print($acnumber); ?></td>
                      <td class="col5"><?php print($acbeginstatus); ?></td>
                      <td class="col6"><?php print($derogstatus); ?></td>
                    </tr>

 <?php
         }
     ?>
	 <tr class="row">
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                 
                  </table></div>
                  
                  
                  <span class="click"><a href="#"><img src="common/images/click.jpg" alt="" /></a></span> </div>
              </div>
            </div>
            
            <div class="equifax_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>Experian - <?php print($expchart); ?>% Improvement</h3>
               <?php
if($companyname =="The Consumer Credit Repair Agency"){
?>
<span class="miter"><div id="chartdiv3">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("HLinearGauge.swf", "myChartId2", "365", "48", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='8' baseFontSize='9' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='8' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($experianvalue); ?></value></chart>");
                 myChart.setTransparent(true);
 myChart.render("chartdiv3");
      </script>
<?php
			}?>


                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col2">Description</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                   <div class="main_table child_table"> <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                 <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientusid']) . "' and accounttype='2'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  if($deleted =="Deleted" or $deleted =="Fixed"){
         $bgcolor="bgcolor=#00FF00";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
         $bgcolor="";
$derogstatus = "On Hold";
}else if($status =="scheduled"){
         $bgcolor="bgcolor=#FFCCCC";

                     $derogstatus = "Scheduled";

}else if($status =="pending"){
         $bgcolor="bgcolor=#FFFF99";

                     $derogstatus = "prepared/pending";

}else {


         $bgcolor="";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>   	<tr class="row" <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($acname); ?></td>
                      <td class="col5"><?php print($acnumber); ?></td>
                      <td class="col5"><?php print($acbeginstatus); ?></td>
                      <td class="col6"><?php print($derogstatus); ?></td>
                    </tr>

 <?php
         }
     ?>
     
                    <tr class="row">
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                  </table></div>
                  <span class="click"><a href="#"><img src="common/images/click.jpg" alt="" /></a></span> </div>
              </div>
            </div>
            
            <div class="equifax_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>TransUnion - <?php print($tuchart); ?>% Improvement</h3>
  <?php
if($companyname =="The Consumer Credit Repair Agency"){
?>
<span class="miter"><div id="chartdiv4">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("HLinearGauge.swf", "myChartId2", "365", "48", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='8' baseFontSize='9' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='8' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($transunionvalue); ?></value></chart>");
                 myChart.setTransparent(true);
 myChart.render("chartdiv4");
      </script>
<?php
			}?>


                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col2">Description</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <div class="main_table child_table">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                     <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientusid']) . "' and accounttype='3'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  if($deleted =="Deleted" or $deleted =="Fixed"){
         $bgcolor="bgcolor=#00FF00";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
         $bgcolor="";
$derogstatus = "On Hold";
}else if($status =="scheduled"){
         $bgcolor="bgcolor=#FFCCCC";

                     $derogstatus = "Scheduled";

}else if($status =="pending"){
         $bgcolor="bgcolor=#FFFF99";

                     $derogstatus = "prepared/pending";

}else {


         $bgcolor="";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>
	
	<tr class="row" <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($acname); ?></td>
                      <td class="col5"><?php print($acnumber); ?></td>
                      <td class="col5"><?php print($acbeginstatus); ?></td>
                      <td class="col6"><?php print($derogstatus); ?></td>
                    </tr>

 <?php
         }
     ?>
	 <tr class="row">
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                  </table>
                  </div>
                  <span class="click"><a href="#"><img src="common/images/click.jpg" alt="" /></a></span> </div>
              </div>
            </div>
               <?php
  }///////END IF UNITED STATES
	 /////////////////////////
	 	 /////////////////////////
		 	 /////////////////////////
  else if($country=="Canada")   {


	 ?>
           
	
			            <div class="equifax_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>Equifax - <?php print($eqxcachart); ?>% Improvement</h3>
  <?php
if($companyname =="The Consumer Credit Repair Agency"){
?><script language="JavaScript" src="FusionCharts.js"></script>
<span class="miter"><div id="chartdiv2">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("HLinearGauge.swf", "myChartId2", "365", "48", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='8' baseFontSize='9' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='8' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($equifaxcavalue); ?></value></chart>");
                 myChart.setTransparent(true);
 myChart.render("chartdiv2");
      </script>
<?php
			}
	  ?>

				
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col2">Description</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <div class="main_table child_table"> <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
              <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientusid']) . "' and accounttype='8'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  if($deleted =="Deleted" or $deleted =="Fixed"){
         $bgcolor="bgcolor=#00FF00";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
         $bgcolor="";
$derogstatus = "On Hold";
}else if($status =="scheduled"){
         $bgcolor="bgcolor=#FFCCCC";

                     $derogstatus = "Scheduled";

}else if($status =="pending"){
         $bgcolor="bgcolor=#FFFF99";

                     $derogstatus = "prepared/pending";

}else {


         $bgcolor="";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>
	
	<tr class="row" <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($acname); ?></td>
                      <td class="col5"><?php print($acnumber); ?></td>
                      <td class="col5"><?php print($acbeginstatus); ?></td>
                      <td class="col6"><?php print($derogstatus); ?></td>
                    </tr>

 <?php
         }
     ?>
	 <tr class="row">
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                 
                  </table></div>
                  
                  
                  <span class="click"><a href="#"><img src="common/images/click.jpg" alt="" /></a></span> </div>
              </div>
            </div>
            
          
            
            <div class="equifax_box">
              <div class="top_curve">
                <div class="bottom_curve">
                  <h3>TransUnion - <?php print($tucachart); ?>% Improvement</h3>
  <?php
if($companyname =="The Consumer Credit Repair Agency"){
?>
<span class="miter"><div id="chartdiv4">The chart will appear within this DIV. This text will be replaced by the chart.</div></span>
<script type="text/javascript">
var myChart = new FusionCharts("HLinearGauge.swf", "myChartId2", "365", "48", "0", "0");
      myChart.setDataXML("<chart chartLeftMargin='8' baseFontSize='9' chartTopMargin='0' chartBottomMargin='0' bgAlpha='0,0' showBorder='0' pointerOnTop='1' pointerRadius='8' gaugeRoundRadius='5' gaugeFillMix='{light-10},{light-70},{dark-10}' gaugeFillRatio='60,20,20' gaugeFillRatio='' lowerLimit='0' upperLimit='100' lowerLimitDisplay='0' upperLimitDisplay='Clean' numberSuffix='%25' tickValueDistance='-3' showValue='0'><colorRange><color minValue='0' maxValue='25' code='0360BE'/><color minValue='25' maxValue='50' code='0191C8'/><color minValue='50' maxValue='75' code='74C2E1'/><color minValue='75' maxValue='100' code='FFFFFF'/></colorRange><value><?php print($transunioncavalue); ?></value></chart>");
                 myChart.setTransparent(true);
 myChart.render("chartdiv4");
      </script>
<?php
			}?>


                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col2">Description</td>
                      <td class="col3">Status</td>
                    </tr>
                  </table>
                  <div class="main_table child_table">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_table">
                     <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientusid']) . "' and accounttype='9'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  if($deleted =="Deleted" or $deleted =="Fixed"){
         $bgcolor="bgcolor=#00FF00";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
         $bgcolor="";
$derogstatus = "On Hold";
}else if($status =="scheduled"){
         $bgcolor="bgcolor=#FFCCCC";

                     $derogstatus = "Scheduled";

}else if($status =="pending"){
         $bgcolor="bgcolor=#FFFF99";

                     $derogstatus = "prepared/pending";

}else {


         $bgcolor="";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>
	
	<tr class="row" <?php print($bgcolor);?>>
                      <td class="col4" ><?php print($acname); ?></td>
                      <td class="col5"><?php print($acnumber); ?></td>
                      <td class="col5"><?php print($acbeginstatus); ?></td>
                      <td class="col6"><?php print($derogstatus); ?></td>
                    </tr>

 <?php
         }
     ?>
	 <tr class="row">
                      <td class="col4">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col5">&nbsp;</td>
                      <td class="col6">&nbsp;</td>
                    </tr>
                  </table>
                  </div>
                  <span class="click"><a href="#"><img src="common/images/click.jpg" alt="" /></a></span> </div>
              </div>
            </div>







			               <?php
  }///////END IF CANADA


	 ?>

          </div>
        </div>
        <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>
  </div>
</div>
</body>
</html>
<?
}
else
{
    header("Location: clientlogin.php");
    exit();
}
?>