<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
 include("companyquery.php");

$myhelp = "class='active'";
//-------client
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, showstatus FROM clients WHERE id='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password2 = $row[12];
        $showstatus = $row[13];


  if($_POST['logticket'] == 1){
      
 $query = "SELECT id FROM helpdesk WHERE clientid='" . $_SESSION['clientusid'] . "' and description='" . mysql_real_escape_string($_POST['response']) . "' LIMIT 1"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $checkid = $row[0];
 
    } 

      if($checkid == ""){

      $hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";
$ip=$_SERVER["REMOTE_ADDR"];

      $query = "INSERT INTO helpdesk(clientid, subject, description, date, tstamp, ip)
                    VALUES(
                    '" . $_SESSION['clientusid'] . "',
                    '$subject',
					'" . mysql_real_escape_string($_POST['response']) . "',
                    '$today',
                    '$tstamp',
                    '$ip')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());




$response = nl2br($response);         
$response = stripslashes($response);
	$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $companyname <$companyreply>\r\n";
            

                $subject2 = "Helpdesk Submission by $name";
                $message = "$companyskin<B>Date:</B>  $today<BR><BR><B>Subject:</B>  $subject<BR><B>Message:</B>  $response<BR><BR><HR>Please log into your system to respond to this client at <a href=$companywebsite>$companywebsite</a> and click on Helpdesk on the main menu";
                $formsent = mail($companyemail, $subject2, $message, $HEADERS, "-f $companyreply");  
    

 if($email != "" AND $email != "none@none.com"){
	$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $companyname <$companyreply>\r\n";
            

                $subject2 = "Your Helpdesk Submission has been logged";
                $message = "$companyskin<B>Date:</B>  $today<BR><BR><B>Subject:</B>  $subject<BR><B>Message:</B>  $response<BR><BR><HR>Please log into your account to monitor or respond to this ticket";
                $formsent = mail($email, $subject2, $message, $HEADERS, "-f $companyreply");  

}

echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=my_help.php?added=yes\">"; 

      }
}

    
   
     


    //mysql_close($conn);
    } 

    ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
  <?php

 include("header.php");
    ?>      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/help_icon.png" alt="" />Help Desk</h2>
            <p>Don't want to call customer support?  Easily submit a new Helpdesk ticket below.  One of our staff members will get back to you as soon as possible.</p>
          </div>
          <div class="help_details">
            <div class="message_box">
              <div class=" top_curve">
                <div class="bottom_curve">
                 <form action="" method="post">
                    <fieldset>
                    <h4>Log a New Helpdesk Ticket</h4>
                    <label class="subject">Subject</label>
                    <div class="input_bg">
                      <input name="subject" type="text" value="" />
                    </div>
                    <label>Message</label>
                    <div class="textarea_bg">
                      <textarea name="response" cols="" rows=""></textarea>
                    </div> <input class="txtbox" type="hidden" name="logticket" value="1">
                    <input type="submit" value="" class="start_ticket_btn" />
                    </fieldset>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
         <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>
  </div>
</div>
</body>
</html>
<?
}
else
{
    header("Location: clientlogin.php");
    exit();
}
?>