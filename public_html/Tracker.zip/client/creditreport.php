<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
    include("connection.php");
include("template.php");


 $query = "SELECT status FROM clients WHERE id='" . mysql_real_escape_string($_SESSION['clientusid']) . "'"; 
      $result = mysql_query($query, $conn) or die("error:" . mysql_error());
      $col_count = mysql_num_fields($result);
      while($row=mysql_fetch_row($result))
      {
        $status = $row[0];
}





    

              $query3 = "SELECT count(deleted) FROM accounts WHERE (deleted='Deleted' OR deleted='Fixed') and clientid='" . $_SESSION['clientusid'] . "' "; 
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $deleted2 = $row3[0];
                   $i = $i+1;
}
 $query4 = "SELECT count(id) FROM accounts WHERE clientid='" . $_SESSION['clientusid'] . "' "; 
              $result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result4))
              {
                   $totalaccounts = $row3[0];
                   $i = $i+1;
}

?>

                             <p align="center">
                             <?php

    if($totalaccounts !="0")
    {
       function encodeDataURL($strDataURL, $addNoCacheStr=false) {
    if ($addNoCacheStr==true) {
		if (strpos($strDataURL,"?")<>0)
			$strDataURL .= "&FCCurrTime=" . Date("H_i_s");
		else
			$strDataURL .= "?FCCurrTime=" . Date("H_i_s");
    }
	return urlencode($strDataURL);
}


function datePart($mask, $dateTimeStr) {
    @list($datePt, $timePt) = explode(" ", $dateTimeStr);
    $arDatePt = explode("-", $datePt);
    $dataStr = "";
    if (count($arDatePt) == 3) {
        list($year, $month, $day) = $arDatePt;
        // determine the request
        switch ($mask) {
        case "m": return $month;
        case "d": return $day;
        case "y": return $year;
        }
        return (trim($month . "/" . $day . "/" . $year));
    }
    return $dataStr;
}


function renderChart($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false, $registerWithJS=false, $setTransparent="true") {
	if ($strXML=="")
        $tempData = "//Set the dataURL of the chart\n\t\tchart_$chartId.setDataURL(\"$strURL\")";
    else
        $tempData = "//Provide entire XML data using dataXML method\n\t\tchart_$chartId.setDataXML(\"$strXML\")";

    $chartIdDiv = $chartId . "Div";
    $ndebugMode = boolToNum($debugMode);
    $nregisterWithJS = boolToNum($registerWithJS);
	$nsetTransparent=($setTransparent?"true":"false");
$render_chart = <<<RENDERCHART

	<!-- START Script Block for Chart $chartId -->
	<div id="$chartIdDiv" align="center">
		Chart.
	</div>
	<script type="text/javascript">	
		var chart_$chartId = new FusionCharts("$chartSWF", "$chartId", "$chartWidth", "$chartHeight", "$ndebugMode", "$nregisterWithJS");
      chart_$chartId.setTransparent("$nsetTransparent");
    
		$tempData
		chart_$chartId.render("$chartIdDiv");
	                         </script>	
	<!-- END Script Block for Chart $chartId -->
RENDERCHART;

  return $render_chart;
}


function renderChartHTML($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false,$registerWithJS=false, $setTransparent="true") {
    $strFlashVars = "&chartWidth=" . $chartWidth . "&chartHeight=" . $chartHeight . "&debugMode=" . boolToNum($debugMode);
    if ($strXML=="")
        $strFlashVars .= "&dataURL=" . $strURL;
    else
        $strFlashVars .= "&dataXML=" . $strXML;
    
    $nregisterWithJS = boolToNum($registerWithJS);
    if($setTransparent!=""){
      $nsetTransparent=($setTransparent==false?"opaque":"transparent");
    }else{
      $nsetTransparent="window";
    }
$HTML_chart = <<<HTMLCHART
	<!-- START Code Block for Chart $chartId -->
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="$chartWidth" height="$chartHeight" id="$chartId">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="$chartSWF"/>		
		<param name="FlashVars" value="$strFlashVars&registerWithJS=$nregisterWithJS" />
		<param name="quality" value="high" />
		<param name="wmode" value="$nsetTransparent" />
		<embed src="$chartSWF" FlashVars="$strFlashVars&registerWithJS=$nregisterWithJS" quality="high" width="$chartWidth" height="$chartHeight" name="$chartId" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="$nsetTransparent" /></object>
	<!-- END Code Block for Chart $chartId -->
HTMLCHART;

  return $HTML_chart;
}

function boolToNum($bVal) {
    return (($bVal==true) ? 1 : 0);
}





	$fixed = $deleted2/$totalaccounts*100;
	$open = ($totalaccounts-$deleted2)/($totalaccounts)*100;
		$strXML  = "<chart numberSuffix='%25' bgAlpha='0,0' caption='Items fixed/deleted: $deleted2 out of $totalaccounts'  showZeroPies='0' chartTopMargin='0' chartBottomMargin='0' showPercentValues='1' showAboutMenuItem='0' showPrintMenuItem='0' showValues='1' showYAxisValues ='0' formatNumberScale='0' showShadow='1' startingAngle='90' use3DLighting ='1' showBorder='0'>";
	$strXML .= "<set label='Open' value='$open'  isSliced='1'  />";
	$strXML .= "<set label='Improved' value='$fixed' color='008000'/>";
	$strXML .= "</chart>";
	
	echo renderChartHTML("http://www.tcrosystems.net/Pie2D.swf", "", $strXML, "myFirst", 500, 300, false, false);
 }

        ?>






<?php


      $query = "SELECT id, type FROM accounttype"; 
      $result = mysql_query($query, $conn) or die("error:" . mysql_error());
      $col_count = mysql_num_fields($result);
      while($row=mysql_fetch_row($result))
      {
        $actypeid = $row[0];
        $actype = $row[1];
    ?>

       <P align=left><FONT color=#000080><B><?php print($actype); ?> Credit 
    Report</B></FONT></P>
         <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#000080 
    cellSpacing=0 cellPadding=2 width="90%" border=3>
      <TBODY>
      <TR>
         <TD width="12%" bgcolor="#FFFFFF"><b>Account Name</b></TD>
        <TD width="12%" bgcolor="#FFFFFF"><b>Account#</b></TD>
        <TD width="12%" bgcolor="#FFFFFF"><b>Type</b></TD>
        <TD width="12%" bgcolor="#FFFFFF"><b>Action</b></TD>
        <TD width="13%" bgcolor="#FFFFFF"><b>Status</b></TD>
    </TR>
    <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, deleted  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientusid']) . "' and accounttype='" . mysql_real_escape_string($actypeid) . "'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1action = $row2[4];                
           $s1result = $row2[5];
           $s2action = $row2[6];                
           $s2result = $row2[7];
           $s3action = $row2[8];                
           $s3result = $row2[9];
           $s4action = $row2[10];               
           $s4result = $row2[11];               
              $deleted = $row2[12];  
     
  if($deleted =="Deleted" or $deleted =="Fixed"){
         $textcss = "00CC99";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
                    $textcss = "FFFFFF";
                     $derogstatus = "On Hold";
}else if($status =="scheduled"){

                    $textcss = "FFCCCC";
                     $derogstatus = "Scheduled";

}else if($status =="pending"){

                    $textcss = "FFFF99";
                     $derogstatus = "prepared/pending";

}else {


                    $textcss = "FFFFFF";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>

      <TR>
        <TD width="12%" bgcolor="#<?php print($textcss);?>"><?php print($acname); ?>&nbsp;</TD>
        <TD width="12%" bgcolor="#<?php print($textcss);?>"><?php print($acnumber); ?>&nbsp;</TD>
        <TD width="12%" bgcolor="#<?php print($textcss);?>"><?php print($acbeginstatus); ?>&nbsp;</TD>
        <TD width="12%" bgcolor="#<?php print($textcss);?>"><?php print($s1action); ?>&nbsp;</TD>
        <TD width="13%" bgcolor="#<?php print($textcss);?>"><?php print($derogstatus); ?>&nbsp;</TD>
      </TR>
     <?php
         }
     ?>
        </TBODY>
      </TABLE>
     <?php
       }
       mysql_close($conn);
    ?>

    <?php
}
else
{
    header("Location: clientlogin.php");
    exit();
}

?>
