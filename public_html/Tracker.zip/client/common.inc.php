<?php

include_once('../include/common.inc.php');



extract( $_GET );
extract( $_POST );

?>
