      <div id="header"> <?php print($insertheader); ?>

		<div class="right_details"> <span class="logout"><a href="logout.php">Log Out</a></span> <span class="number"><?php print($companyphone); ?><br />
          <!--<small>M-F 9:00 AM - 5:00 PM MTN</small>--> </span> <span class="welcome">Welcome: <?php print($name); ?><BR>
		             <!-- <a href="#">You Have <font color="green">4</font> New Messages </a>--></span>
</div>  <div class="menu">
          <ul>

		

            <li <?php print($myhome); ?>><a href="main.php">My Home</a></li>
            <li <?php print($myaccount); ?>><a href="my_account.php">My Account</a></li>
            <li <?php print($mystatus); ?>><a href="my_status.php">My Status</a></li>
            <li <?php print($myresults); ?>><a href="my_results.php">My Results</a></li>
            <li <?php print($mydisputes); ?>><a href="my_disputes.php">My Disputes</a></li>
<?php
      if($helpdesk == "Yes"){
    ?>            <li <?php print($myhelp); ?>><a href="my_help.php">My Help</a></li>
<?php
}      if($htdiwebsite == "Yes"){

$query = "SELECT pagename FROM webcms WHERE active='Yes' and onheader='Yes' and type='client' and pageorder > 0 order by pageorder";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $pagenamelink = $row[0];

      if($onpage == $pagenamelink){
$mycms = "class='active'";
	  }else{
$mycms = "";
	  }
$headerlinks .="<li $mycms><a href=\"cms.php?page=$pagenamelink\">$pagenamelink</a></li>";
    }


echo $headerlinks;
}   
    ?>
</ul>
          <!-- <span class="new_message"><a href="#">You Have <small>4</small> New Messages </a></span>-->
           </div>
		           <img src="common/images/menu_bottom_shadow.gif" alt="" /> </div>