<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
 include("companyquery.php");

$myaccount = "class='active'";

//-------client
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password FROM clients WHERE id='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password2 = $row[12];


    } 

    ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<script type="text/javascript" src="common/js/dropdownmenu.js"></script>
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
<?php

 include("header.php");
    ?>
  <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_account_icon.png" alt="" />My Account</h2>
            <p class="my_accout">To change or update your personal information please call us at <?php print($companyphone); ?>, during regular business hours. A live representative will be happy to assist you.</p>
          </div>
          <div class="common_box">
            <div class=" top_curve">
              <div class="bottom_curve">
                <div class="my_account_datials">
                  <div class="user_details">
                    <ul>
                      <li>
                        <label>Name:</label>
                        <?php print($name); ?></li>
                      <li>
                        <label>Email:</label>
                        <?php print($email); ?></li>
                      <li>
                        <label>Address</label>
                        <?php print($address); ?>, <?php print($city); ?>, <?php print($state); ?> <?php print($zip); ?></li>
                 <!--     <li>
                        <label>Email 2:</label>
                        ssmith@gmail.com</li>-->
                      <li>
                        <label>Phone:</label>
                        <?php print($phone); ?></li>
                      <li>
                        <label>Username:</label>
                        <?php print($username); ?></li>
                      <li>
                        <label>Fax:</label>
                        <?php print($fax); ?></li>
                      <li>
                        <label>Password:</label>
                        *********</li>
                    </ul>
                  </div>
             <!--     <ul class="payment">
                    <li>
                      <label>Payment Method 1:</label>
                      Visa ****-8709    expiration: 08/2012</li>
                    <li>
                      <label>Payment Method 2:</label>
                    </li>
                  </ul>-->
                  <div class="keep_me">
                  <!--  <form action="">
                      <fieldset>
                      <input name="" type="checkbox" value="" class="checkbox" />
                      <label>Keep me up to date with valuable news, information and special offers from
                      <?php print($companyname); ?> and our affiliated business partners.</label>
                      </fieldset>
                    </form>-->
                  </div>
                  <div class="please_mail">
                    <h4>Please mail updated credit reports and credit bureau correspondence to:</h4>
                    <div class="row"> <span class="icon"><img src="common/images/my_account_icon1.png" alt="" /></span>
                      <div class="details">
                        <h5>Mail To:</h5>
                        <p><strong><?php print($companyname); ?></strong><br />
                          <?php print($companyaddress); ?> - <?php print($companycity); ?>, <?php print($companystate); ?> <?php print($companyzip); ?> <small>*For your safety and security, please DO NOT email sensitive personal information.</small> </p>
                      </div>
                    </div>
                    <div class="row"> <span class="icon"><img src="common/images/my_account_icon2.png" alt="" /></span>
                      <div class="details">
                        <h5 class="space">Please <a href="#">Do Not</a> Fax Monthly Updates</h5>
                      </div>
                    </div>
                  </div>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>
  </div>
</div>
</body>
</html>
  <?
}
else
{
    header("Location: clientlogin.php");
    exit();
}
?>
