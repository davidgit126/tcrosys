<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
 include("companyquery.php");

$myhelp = "class='active'";

      if($helpdesk == "Yes"){

//-------client
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country FROM clients WHERE id='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $active = $row[11];
    } 

      if($_POST['addhdresponse'] == 1){
      
 $query = "SELECT id FROM helpdeskresponses WHERE ticketid='$hdid' and response='" . mysql_real_escape_string($_POST['response']) . "' LIMIT 1"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $checkid = $row[0];
 
    } 

      if($checkid == ""){

      $hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";
$ip=$_SERVER["REMOTE_ADDR"];

      $query = "INSERT INTO helpdeskresponses(ticketid, byuser, response, date, tstamp, ip)
                    VALUES(
                    '$hdid',
                    '$name',
					'" . mysql_real_escape_string($_POST['response']) . "',
                    '$today',
                    '$tstamp',
                    '$ip')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());



        $query = "UPDATE helpdesk SET status='OPEN' WHERE id='$hdid'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());











      }
}

    
       $query = "SELECT id, status, subject, description, DATE_FORMAT(date, \"%m-%d-%Y\") as hdlogdate,  tstamp, ip FROM helpdesk WHERE deleted !='Yes' and clientid='" . $_SESSION['clientusid'] . "' and id=$hdid"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $hdid= $row[0];
        $hdstatus = $row[1];
        $hdsubject = $row[2];
        $hddescription = $row[3];
        $hdlogdate= $row[4];
        $hdtstamp= $row[5];
        $hdip= $row[6];
$hddescription = nl2br($hddescription);         

}
      if($hdstatus !=""){

    ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
  <?php

 include("header.php");
    ?>      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/help_icon.png" alt="" />Help Desk</h2>
            <p>View the extended list of frequently asked questions below, get closer in-depth look at the entire dispute process.</p>
          </div>
          <div class="help_details">
            <div class="ticket_details">
              <div class=" top_curve">
                <div class="bottom_curve">
                  <h4>Ticket Details</h4>
                  <ul class="ticket_id">
                  <li><strong>Ticket ID:</strong><?php print($hdid); ?></li>
                  <li><strong>Status:</strong><?php print($hdstatus); ?></li>
                  <li><strong>Logged:</strong><?php print($hdlogdate); ?></li>
                  <li><strong>IP Address:</strong><?php print($hdip); ?></li>
                  </ul>
                  <h5><?php print($hdsubject); ?></h5>
                  <ul class="just_testing">
                  <li><?php print($hddescription); ?></li>
                 
                  </ul>
                  <h5>User / Staff Follow Ups</h5>
                  <ul class="staff_follow">
               <?php

           $query = "SELECT id, byuser, response, DATE_FORMAT(date, \"%m-%d-%Y\") as hdresponsedate,  tstamp, ip FROM helpdeskresponses WHERE ticketid='$hdid' order by id"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $rsid= $row[0];
        $byuser = $row[1];
        $response = $row[2];
        $hdresponsedate= $row[3];
        $rststamp= $row[4];
        $rsiptstamp= $row[5];

$response = nl2br($response);         

        ?>
  
<li><span><?php print($byuser); ?><br /><?php print($hdresponsedate); ?> at <?php print($rststamp); ?></span><span class="response"><?php print($response); ?></span></li>

<?php
 }
 ?>

                  </ul>
                  <h5>Add A Response?</h5>
                   <form action="" method="post">

                   <fieldset>
                   <div class="textarea_bg">
                   <textarea name="response" cols="" rows=""></textarea>
                   </div>
				    <input class="txtbox" type="hidden" name="addhdresponse" value="1">
                   <input type="submit" value="" class="add_response_btn" />
                   </fieldset>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
         <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>
  </div>
</div>
</body>
</html>
<?
}}}
else
{
    header("Location: clientlogin.php");
    exit();
}
?>