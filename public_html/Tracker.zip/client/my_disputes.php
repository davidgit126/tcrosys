<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
 include("companyquery.php");

$mydisputes = "class='active'";

//-------client
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, showstatus, country FROM clients WHERE id='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password2 = $row[12];
        $showstatus = $row[13];
        $country = $row[14];
    } 


if($_REQUEST['update']==1)
    { 
        $cnt= sizeof($_REQUEST['updateid']);
        for($i=0; $i<$cnt; $i++)
        {
           $query = "UPDATE accounts SET
                    comments='" . mysql_real_escape_string($comments[$i]) . "',
                    dispute='" . mysql_real_escape_string($disputes[$i]) . "'
                    WHERE id='" . mysql_real_escape_string($updateid[$i]) . "'"; 
           $result = mysql_query($query, $conn) or die("error:" . mysql_error());       
        }
        $clname = str_replace(" ", "%20", $_SESSION['clientname']);
        $clname = str_replace("(", "%20", $clname); 
        $clname = str_replace(")", "%20", $clname); 
        $formsent = mail($site_email_address,
                         "Client Comments",
                         "The following Client has passed the interviewer:\r\nClient name: " . $_SESSION['clientname'] . "\r\n View: http://{$_SERVER['SERVER_NAME']}/admin/intervieweradmin.php?clientid=" . $_SESSION['clientusid'] . "&clname={$clname}",
                         "From: $site_email_address");  
     }

    ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Credit Repair</title>
<link rel="stylesheet" type="text/css" href="common/css/style.css" />
<!--[if IE 6]>
<script  type="text/javascript" src="common/js/jq-png-min.js"></script>
<link rel="stylesheet" type="text/css" href="common/css/ie6.css" /> 
<![endif]-->
</head>
<body>
<div id="wrapper">
  <div id="layout">
    <div id="top_curve"><img src="common/images/layout_top_curve.png" alt="" /></div>
    <div id="middle_bg">
 <?php

 include("header.php");
    ?>
      <div id="body_container">
        <div id="left_container">
          <div class="main_heading_box">
            <h2><img src="common/images/my_disputes_icon.png" alt="" />My Disputes</h2>
            <p class="disputes">Tell us which items you would like to dispute and why. Provide any additional information that may help us, if you have it. It’s fast, easy and only needs to be done once.</p>
          </div>
          <div class="common_box">
            <div class="top_curve disputes_top">
              <div class="bottom_curve disputes_bottom">
                <div class="diputes_details">
                <form action="my_disputes.php" method="post">

                <fieldset>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="top_table">
                    <tr>
                      <td class="col1">Account Name</td>
                      <td class="col2">Account Number</td>
                      <td class="col3 letter_spacing">Provide Additional Information That May Help Us Here</td>
                    </tr>
                  </table>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="detail_table">
               <?php

					
	              if($country =="" or $country=="United States")   {
 $countryquery = "WHERE country = 'United States'";
 } else if($country=="Canada")   {
 $countryquery = "WHERE country = '$country'";
 } else{
 $countryquery = "WHERE country = '$country'";
 }



$query = "SELECT id, name, number, comments, dispute FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientusid']) . "'  GROUP BY name, number"; 
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$col_count = mysql_num_fields($result);
$count=0;   
while($row=mysql_fetch_row($result))
{
    $accid= $row[0];
    $accname= $row[1];
    $accnumber = $row[2];
    $comments = $row[3];
    $dispute = $row[4];
    $count= $count+1;
    ?>
	<tr>
                      <td class="col1"><?php print($accname); ?></td>
                      <td class="col2"><?php print($accnumber); ?></td>
                      <td class="col3"><div class="input_bg"><input name="comments[]" type="text" value="<?php print($comments); ?>" />
					   <input type="hidden" name ="updateid[]" value="<?php print($accid); ?>">
                <input type="hidden" name ="accname[]" value="<?php print($accname); ?>">
                <input type="hidden" name ="accnumber[]" value="<?php print($accnumber); ?>">
				</div></td>
                    </tr>
                       <?php
    }
    //mysql_close($conn);
    if($count==0) 
    {
        ?>
        <tr><td>You don't have any accounts with us yet.</td></tr>
        <?php
    }
    ?>

                  </table>
				      <?
      if($count!=0)
      {
          ?>
        <input type="hidden" name ="update" value="1">
        <br>
       <span class="row"><input type="submit" value="" class="submit_btn" /></span>
        <?          
      }
    ?>
                   
                  </fieldset>
                  </form>
                  </div>
              </div>
            </div>
          </div>
        </div>
         <?php

 include("rightframe.php");
    ?>
        </div>
      </div>
    </div>
    <div id="bottom_curve"><img src="common/images/layout_bottom_curve.png" alt="" /></div>
<?php print($poweredbymessage); ?>
  </div>
</div>
</body>
</html>
<?
}
else
{
    header("Location: clientlogin.php");
    exit();
}
?>