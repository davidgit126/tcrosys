    <?php
	


extract( $_GET );
extract( $_POST );

if($companyheader !=""){

    $mypicture = getimagesize("$companyheader"); 
   if($mypicture[0] > 179){
   $imagewidth = 179;
   }else{
   $imagewidth = $mypicture[0];
}
}
     ?>
	 
	 <div id="right_container">
          <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon1.png" alt="" class="icon" />Mailing Address </h4>
                <span class="credit"><img src="<?php print($companyheader); ?>" width="<?php print($imagewidth); ?>" alt="" /></span>
                <p class="gilbert"><?php print($companyaddress); ?><BR><?php print($companycity); ?>, <?php print($companystate); ?> <?php print($companyzip); ?></p>
              </div>
            </div>
          </div>

<?php
if($htdiwebsite == "Yes"){
$query = "SELECT pagename FROM webcms WHERE active='Yes' and type='client' and pagename='FAQ'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $faqpageexists = $row[0];
	}

if($faqpageexists != ""){

	    ?>   

          <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon2.png" alt="" class="icon" />Frequently Asked </h4>
                <p><strong><a href="cms.php?page=FAQ">Can I Track My Results?</a></strong> Yes, you can see what has been removed or improved by clicking <a href="my_results.php">here</a>.</p>
              </div>
            </div>
          </div>

			  <?php
}}
      if($helpdesk == "Yes"){
    ?>   
          <div class="common_box">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon3.png" alt="" class="icon" />Customer Support </h4>
                <p><strong><a href="my_help.php">Have Questions Need Help</a></strong> Submitting questions and providing feedback has never been easier using our online Helpdesk.</p>
              </div>
            </div>
          </div>

		  	  <?php
		  }

if($htdiwebsite == "Yes"){

	    $query = "SELECT showstatus, plan, broker_id, name FROM clients WHERE id='" . $_SESSION['clientusid'] . "'"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $showstatus = $row[0];
        $plan = $row[1];        
        $broker_id = $row[2];        
        $name = $row[3];        
 }


$query = "SELECT pagename, pagename, pagemetas, pagetitle FROM webcms WHERE active='Yes' and type='client' and pagename='Refer'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $referpageexists = $row[0];
        $referpagename = $row[1];
        $referpagemetas = $row[2];
        $referpagetitle = $row[3];
	}

if($referpageexists != ""){

	    ?>   

          <div class="common_box space_min">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon4.png" alt="" class="icon" /><?php print($referpagetitle); ?></h4>
                <p><strong><a href="cms.php?page=Refer">Refer Friends and Family</a></strong><?php print($referpagemetas); ?></p>
              </div>
            </div>
          </div>
		  <?php
		  }
		  
		  
		  
		  $query = "SELECT pagename, pagename, pagemetas, pagetitle FROM webcms WHERE active='Yes' and type='client' and pagename='Partner'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $partnerpageexists = $row[0];
        $partnerpagename = $row[1];
        $partnerpagemetas = $row[2];
        $partnerpagetitle = $row[3];
	}

		  if($partnerpageexists != "" && $broker_id !=""){
			     $query3 = "SELECT firstname, lastname, email, telephone, url, notification FROM dealers WHERE dealer_id='$broker_id' and status !=9"; 
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $brokerfirstname = $row3[0];
                   $brokerlastname = $row3[1];
                   $brokeremail = $row3[2];
                   $brokerphone = $row3[3];
                   $brokerurl = $row3[4];
                   $brokernotification= $row3[5];
}


	    ?>   

          <div class="common_box space_min">
            <div class="top_curve">
              <div class="bottom_curve">
                <h4><img src="common/images/common_box_icon3.png" alt="" class="icon" /><?php print($partnerpagetitle); ?></h4>
                <p><strong><?php print($brokerfirstname); ?> <?php print($brokerlastname); ?></strong>Phone: <?php print($brokerphone); ?><BR>E-Mail: <?php print($brokeremail); ?></p>
              </div>
            </div>
          </div>

			<?php
	

    if($brokerurl !=""){
    $mypicture = getimagesize("../brokers/pics/$brokerurl"); 
   if($mypicture[0] >200){
   $imagewidth = 200;
   }else{
   $imagewidth = $mypicture[0];
}

     ?>
      
 <p align="center">           
 <img border="0" src="../brokers/pics/<?php print($brokerurl); ?>" width="<?php print($imagewidth); ?>">           
              <?php
	}
 ?>
            

		  <?php
		  }
		  
		  
		  
		  
		  
		  
		  }
		     ?>