<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
     include("connection.php");
include("template.php");

     if($_REQUEST['update']==1)
    { 
        $cnt= sizeof($_REQUEST['updateid']);
        for($i=0; $i<$cnt; $i++)
        {
           $query = "UPDATE accounts SET
                    comments='" . mysql_real_escape_string($comments[$i]) . "',
                    dispute='" . mysql_real_escape_string($disputes[$i]) . "'
                    WHERE id='" . mysql_real_escape_string($updateid[$i]) . "'"; 
           $result = mysql_query($query, $conn) or die("error:" . mysql_error());       
        }
        $clname = str_replace(" ", "%20", $_SESSION['clientname']);
        $clname = str_replace("(", "%20", $clname); 
        $clname = str_replace(")", "%20", $clname); 
        $formsent = mail($site_email_address,
                         "Client Comments",
                         "The following Client has passed the interviewer:\r\nClient name: " . $_SESSION['clientname'] . "\r\n View: http://{$_SERVER['SERVER_NAME']}/admin/intervieweradmin.php?clientid=" . $_SESSION['clientusid'] . "&clname={$clname}",
                         "From: $site_email_address");  
     }
?>
<h1><?php print($clientname);?>'s The Interviewer&trade;</h1>
<p>
<strong>The Interviewer&trade;</strong> is your chance to let us know of any discrepancies that 
might appear on your credit reports, from your personal information to 
your account information and details.&nbsp; With more information we can 
work rapidly and more effectively in the repair of your credit reports.
</p>

<p align="left">
Below you will find a list of account names and numbers for each derogatory 
account listed on your credit reports.&nbsp; Please tell us if any of 
the information listed on your credit reports is incorrect, for example: 
the dates the accounts were opened or closed; the current balance; and 
whether the account is open or closed now.&nbsp; Also, if the account is 
paid, when was it paid.&nbsp; If the account is a charge off or 
collections account, how long ago did it become delinquent.&nbsp; Any 
additional information you can provide about each account is also very 
helpful.&nbsp; <b>Do not worry if you do not know the exact dates for 
when these things occurred, or if you do not know the current status of 
an account.&nbsp; If you are unable or unwilling to fill out this form 
we will assume that you are in dispute about all of the negative account 
information reported&nbsp; on your credit reports and process 
accordingly.</b>&nbsp; Otherwise fill out this form to the best of your 
knowledge and click submit.  If we have any questions regarding your answers we will contact you.
</p>

<form action="interviewer.php" method="post">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="106">
 <tr> 
  <td width="33%" valign="top" height="26"><b>Account Names</b></td>
  <td width="33%" valign="top" height="26"><b>Account Number</b></td>
  
<td width="34%" valign="top" height="26"> <div align="left"><strong>Comments </strong></div></td>
</tr>                
<?php
$query = "SELECT id, name, number, comments, dispute
          FROM  accounts
          WHERE clientid='" . mysql_real_escape_string($_SESSION['clientusid']) . "'  GROUP BY name, number"; 
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$col_count = mysql_num_fields($result);
$count=0;   
while($row=mysql_fetch_row($result))
{
    $accid= $row[0];
    $accname= $row[1];
    $accnumber = $row[2];
    $comments = $row[3];
    $dispute = $row[4];
    $count= $count+1;
    ?>
    <tr>
          <td valign="top" height="52"><?php print($count); ?>. <b><?php print($accname); ?></b></td>
          <td valign="top" height="52"><b><?php print($accnumber); ?></b>
          </td>
          <td valign="top" height="52">
         <select class="txtbox" size="1" name="disputes[]">
              <option>N/A</option>
              <option <?php if($dispute=="To the best of my knowledge this account is not mine.") {print("selected");} ?> >To the best of my knowledge this account is not mine.</option>
              <option <?php if($dispute=="To the best of my knowledge I was never late.") {print("selected");} ?> >To the best of my knowledge I was never late.</option>
              <option <?php if($dispute=="This account is more than seven years old.") {print("selected");} ?>>This account is more than seven years old.</option>
         </select> 
          <br>
               <textarea class="txtbox" rows="2" name="comments[]" cols="60"><?php print($comments); ?></textarea>
                <input type="hidden" name ="updateid[]" value="<?php print($accid); ?>">
                <input type="hidden" name ="accname[]" value="<?php print($accname); ?>">
                <input type="hidden" name ="accnumber[]" value="<?php print($accnumber); ?>">

            </td>
        </tr>
    <?php
    }
    mysql_close($conn);
    if($count==0) 
    {
        ?>
        <tr><td>You don't have any accounts with us yet.</td></tr>
        <?php
    }
    ?>
    </table>
    <?
      if($count!=0)
      {
          ?>
        <input type="hidden" name ="update" value="1">
        <br>
        <div align=center><input type="submit" value="Submit" name="Submit"></div>
        <?          
      }
    ?>
    </form>
    <p align="center">&nbsp; </p>
    <p align="center">Thank you!</p>
    <?php
}
else
{
    header("Location: clientlogin.php");
    exit();
}

?>