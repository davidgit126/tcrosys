<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
include("template.php");





//-------client
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password FROM clients WHERE id='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password2 = $row[12];


    } 
//----------enrolment
    $query = "SELECT DATE_FORMAT(dateenrol, \"%m-%d-%Y\") as dateenrol,  DATE_FORMAT(reportreceived, \"%m-%d-%Y\") as repdate, DATE_FORMAT(addressreceived, \"%m-%d-%Y\") as adddate, DATE_FORMAT(ssdate, \"%m-%d-%Y\") as ssdate, DATE_FORMAT(welcomepacket, \"%m-%d-%Y\") as welcomedate, DATE_FORMAT(returndoc, \"%m-%d-%Y\") as returndoc FROM enrolment WHERE clientid='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dateenrol = $row[0];
        $reportreceived = $row[1];
        $addressreceived = $row[2];
        $ssdate = $row[3];
        $welcomepacket = $row[4];
        $returndoc = $row[5];
    } 
//---------billing
    $query = "SELECT auditfee, DATE_FORMAT(paid, \"%m-%d-%Y\") as paid, monthlyfee, monthlydue, payment FROM billing WHERE clientid='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $auditfee = $row[0];
        $paid = $row[1];
        $monthlyfee = $row[2];
        $monthlydue = $row[3];
        $payment = $row[4];
    } 
    //mysql_close($conn);



if ($page ==""){



              $query3 = "SELECT count(deleted) FROM accounts WHERE (deleted='Deleted' OR deleted='Fixed') and clientid='" . $_SESSION['clientusid'] . "' "; 
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $deleted2 = $row3[0];
                   $i = $i+1;
}
 $query4 = "SELECT count(id) FROM accounts WHERE clientid='" . $_SESSION['clientusid'] . "' "; 
              $result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result4))
              {
                   $totalaccounts = $row3[0];
                   $i = $i+1;
}

?>

                             <p align="center">
                            
                             <?php

    if($totalaccounts !="0")
    {
       function encodeDataURL($strDataURL, $addNoCacheStr=false) {
    if ($addNoCacheStr==true) {
		if (strpos($strDataURL,"?")<>0)
			$strDataURL .= "&FCCurrTime=" . Date("H_i_s");
		else
			$strDataURL .= "?FCCurrTime=" . Date("H_i_s");
    }
	return urlencode($strDataURL);
}


function datePart($mask, $dateTimeStr) {
    @list($datePt, $timePt) = explode(" ", $dateTimeStr);
    $arDatePt = explode("-", $datePt);
    $dataStr = "";
    if (count($arDatePt) == 3) {
        list($year, $month, $day) = $arDatePt;
        // determine the request
        switch ($mask) {
        case "m": return $month;
        case "d": return $day;
        case "y": return $year;
        }
        return (trim($month . "/" . $day . "/" . $year));
    }
    return $dataStr;
}


function renderChart($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false, $registerWithJS=false, $setTransparent="true") {
	if ($strXML=="")
        $tempData = "//Set the dataURL of the chart\n\t\tchart_$chartId.setDataURL(\"$strURL\")";
    else
        $tempData = "//Provide entire XML data using dataXML method\n\t\tchart_$chartId.setDataXML(\"$strXML\")";

    $chartIdDiv = $chartId . "Div";
    $ndebugMode = boolToNum($debugMode);
    $nregisterWithJS = boolToNum($registerWithJS);
	$nsetTransparent=($setTransparent?"true":"false");
$render_chart = <<<RENDERCHART

	<!-- START Script Block for Chart $chartId -->
	<div id="$chartIdDiv" align="center">
		Chart.
	</div>
	<script type="text/javascript">	
		var chart_$chartId = new FusionCharts("$chartSWF", "$chartId", "$chartWidth", "$chartHeight", "$ndebugMode", "$nregisterWithJS");
      chart_$chartId.setTransparent("$nsetTransparent");
    
		$tempData
		chart_$chartId.render("$chartIdDiv");
	                         </script>	
	<!-- END Script Block for Chart $chartId -->
RENDERCHART;

  return $render_chart;
}


function renderChartHTML($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false,$registerWithJS=false, $setTransparent="true") {
    $strFlashVars = "&chartWidth=" . $chartWidth . "&chartHeight=" . $chartHeight . "&debugMode=" . boolToNum($debugMode);
    if ($strXML=="")
        $strFlashVars .= "&dataURL=" . $strURL;
    else
        $strFlashVars .= "&dataXML=" . $strXML;
    
    $nregisterWithJS = boolToNum($registerWithJS);
    if($setTransparent!=""){
      $nsetTransparent=($setTransparent==false?"opaque":"transparent");
    }else{
      $nsetTransparent="window";
    }
$HTML_chart = <<<HTMLCHART
	<!-- START Code Block for Chart $chartId -->
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="$chartWidth" height="$chartHeight" id="$chartId">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="$chartSWF"/>		
		<param name="FlashVars" value="$strFlashVars&registerWithJS=$nregisterWithJS" />
		<param name="quality" value="high" />
		<param name="wmode" value="$nsetTransparent" />
		<embed src="$chartSWF" FlashVars="$strFlashVars&registerWithJS=$nregisterWithJS" quality="high" width="$chartWidth" height="$chartHeight" name="$chartId" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="$nsetTransparent" /></object>
	<!-- END Code Block for Chart $chartId -->
HTMLCHART;

  return $HTML_chart;
}

function boolToNum($bVal) {
    return (($bVal==true) ? 1 : 0);
}





	$fixed = $deleted2/$totalaccounts*100;
	$open = ($totalaccounts-$deleted2)/($totalaccounts)*100;
		$strXML  = "<chart numberSuffix='%25' bgAlpha='0,0' caption='Items fixed/deleted: $deleted2 out of $totalaccounts'  showZeroPies='0' chartTopMargin='0' chartBottomMargin='0' showPercentValues='1' showAboutMenuItem='0' showPrintMenuItem='0' showValues='1' showYAxisValues ='0' formatNumberScale='0' showShadow='1' startingAngle='90' use3DLighting ='1' showBorder='0'>";
	$strXML .= "<set label='Open' value='$open'  isSliced='1'  />";
	$strXML .= "<set label='Improved' value='$fixed' color='008000'/>";
	$strXML .= "</chart>";
	
	echo renderChartHTML("http://www.tcrosystems.net/Pie2D.swf", "", $strXML, "myFirst", 500, 300, false, false);
 }

        ?>
                            
                            
                            

    <h2>Personal Information</h2>
    <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#C0C0C0 cellSpacing=0 cellPadding=3 width="98%" bgColor=#c0c0c0 border=2>
    <TBODY>
    <TR>
    <TD width="50%" bgcolor="#FFFFCC"><b>Name</b> - <?php print($name); ?>
    <BR><b>Address</b><BR><?php print($address); ?><BR>
    <?php print($city); ?>, <?php print($state); ?> <?php print($zip); ?>
    
    
    
    </TD>
    <TD width="50%" bgcolor="#FFFFCC"><b>E-mail</b> - <?php print($email); ?><BR><b>Phone</b> - <?php print($phone); ?><BR><b>DOB</b> - <?php print($birthdate); ?></TD></TR>
    </TBODY>
    <TBODY>
    <TR>
    <TD width="50%" bgcolor="#FFFFCC"><b>Date Of Enrollment</b> - <?php print($dateenrol); ?>    <b>Welcome Packet Mailed</b> - <?php print($welcomepacket); ?></TD>
    <TD width="50%" bgcolor="#FFFFCC"><b>Returned Documents Received</b> - <?php print($returndoc); ?></TD>
    </TR>
    </TBODY>
    </TABLE>

    <h2>Credit Repair Process</h2>

    <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#C0C0C0 cellSpacing=0 cellPadding=2 width="98%" border=3>
    <TBODY>
    <TR>
    <TD width="9%"><B>Date</B></TD>
    <TD width="42%"><B>Received</B> (e-mail, phone call, reports, letter, fax, etc.)</TD>
    <TD width="47%"><B>Action Taken</B></TD>
    </TR>
    <?php
    $query = "SELECT DATE_FORMAT(repairdate, \"%m-%d-%Y\") as repdate,  received, action,  filelocation, counselor FROM  repair WHERE clientid='" . $_SESSION['clientusid'] . "' ORDER BY repairdate DESC"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $repairdate= $row[0];
        $received = $row[1];
        $action = $row[2];
        $filelocation = $row[3];
        $counselor= $row[4];
          if($filelocation !=""){
         $textcss = "FFCCCC";
}else {

                    $textcss = "FFFFFF";

                    }


        ?>
        <TR>
        <TD width="9%" bgcolor="#<?php print($textcss);?>"><?php print($repairdate); ?>&nbsp;</TD>
        <TD width="42%" bgcolor="#<?php print($textcss);?>"><?php print($received); ?>&nbsp;</TD>
        <TD width="47%" bgcolor="#<?php print($textcss);?>"><?php print($action); ?>&nbsp;</TD>        </TR>
        <?php
    }
    mysql_close($conn);
    ?>
    </TBODY>
    </TABLE>
    
    </FORM>
    <?php
}else{
//////START CUSTOM PAGES


  $query = "SELECT id, pagename, active, pageorder, onheader, onfooter, pagecontent, pagetitle, pagemetas, type FROM webcms WHERE pagename='$page' and type='client'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $pagename  = $row[1];
              $active   = $row[2];
              $pageorder   = $row[3];
              $onheader = $row[4];
              $onfooter = $row[5];              
              $pagecontent = $row[6];                
              $pagetitle = $row[7];     
              $pagemetas = $row[8];                
              $pagetype = $row[9];                
           
}

$todaysdate =  date("F d, Y");
$year =   date("Y");

 $clientfirstname = explode(' ', $name); 
$clientfirstname = $clientfirstname[0];

$pagecontent = str_replace("{PASSWORD}", "$password2", $pagecontent);

$pagecontent = str_replace("{THREEINONE}", "$threeinone", $pagecontent);
$pagecontent = str_replace("{COMPANY}", "$companyname", $pagecontent);
$pagecontent = str_replace("{COMPANYADDR}", "$companyaddress", $pagecontent);
$pagecontent = str_replace("{COMPANYCITY}", "$companycity", $pagecontent);
$pagecontent = str_replace("{COMPANYSTATE}", "$companystate", $pagecontent);
$pagecontent = str_replace("{COMPANYZIP}", "$companyzip", $pagecontent);
$pagecontent = str_replace("{COMPANYPHONE}", "$companyphone", $pagecontent);
$pagecontent = str_replace("{COMPANYFAX}", "$companyfax", $pagecontent);
$pagecontent = str_replace("{SITE}", "$companywebsite", $pagecontent);
$pagecontent = str_replace("{COMPANYEMAIL}", "$companyemail", $pagecontent);
$pagecontent = str_replace("{USERNAME}", "$username", $pagecontent);
$pagecontent = str_replace("{NAME}", "$name", $pagecontent);
$pagecontent = str_replace("{ADDRESS}", "$address", $pagecontent);
$pagecontent = str_replace("{CITY}", "$city", $pagecontent);
$pagecontent = str_replace("{STATE}", "$state", $pagecontent);
$pagecontent = str_replace("{ZIP}", "$zip", $pagecontent);
$pagecontent = str_replace("{EMAIL}", "$email", $pagecontent);
$pagecontent = str_replace("{PHONE}", "$phone", $pagecontent);
$pagecontent = str_replace("{SSN}", "$ssnum", $pagecontent);
$pagecontent = str_replace("{DOB}", "$birthdate", $pagecontent);
$pagecontent = str_replace("{FNAME}", "$clientfirstname", $pagecontent);
$pagecontent = str_replace("{TODAYDATE}", "$todaysdate", $pagecontent);
$pagecontent = str_replace("{YEAR}", "$year", $pagecontent);


$freeconsultform = "<form action=\"prospect_signup.php\" method=\"post\" target=\"_top\"><table cellspacing=\"5\" cellpadding=\"5\"><tr><td><p align=\"left\">First Name</p></td>";
$freeconsultform .= "<td ><input size=\"15\" name=\"fname\"></td></tr><tr><td ><p align=\"left\">Last Name </p></td><td ><input size=\"15\" name=\"lname\"></td></tr><tr><td ><p align=\"left\">Phone</p></td>";
$freeconsultform .= "<td ><input size=\"15\" name=\"phone\"></td></tr><tr><td ><p align=\"left\">Email</p></td><td ><input size=\"15\" name=\"email\"></td></tr>";
if ($action == "added"){
$freeconsultform .= "<tr><td colspan=\"2\"><p align=\"center\">Your referral has been submitted.  Thank you.</p></td></tr></table></form>";
}else{
$freeconsultform .= "<tr><td colspan=\"2\"><p align=\"center\"><input type=\"submit\" value=\"Submit\" name=\"submit\"></p></td></tr></table></form>";
	}
$pagecontent = str_replace("{FREECONSULT}", "$freeconsultform", $pagecontent);

?>

<title><?php echo $pagetitle; ?></title>
<?php echo $pagecontent; ?>




  <?php
}
?>

    <?php

}
else
{
    header("Location: clientlogin.php");
    exit();
}

?>