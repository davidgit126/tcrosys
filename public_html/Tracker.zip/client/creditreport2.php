<?php
require_once('common.inc.php');
ob_start();
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
    include("connection.php");
    ?>
    <h1><?php print($clientname);?>'s Results Tracker&trade;</h1>
                  
    <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#000080 
    cellSpacing=0 cellPadding=2 width="98%" bgColor=#c0c0c0 border=3>
      <TBODY>
      <TR>
        <TD width="50%">Client Name <font color="#000080"><?php print($clientname);?></font></TD>
      </TR>
      </TBODY>
    </TABLE>
    <?php
      $query = "SELECT id, type FROM accounttype"; 
      $result = mysql_query($query, $conn) or die("error:" . mysql_error());
      $col_count = mysql_num_fields($result);
      while($row=mysql_fetch_row($result))
      {
        $actypeid = $row[0];
        $actype = $row[1];
    ?>
       <P align=left><FONT color=#000080><B><?php print($actype); ?> Credit 
    Report</B></FONT></P>
         <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#000080 
    cellSpacing=0 cellPadding=2 width="98%" border=3>
      <TBODY>
      <TR>
        <TD width="12%">Account Name</TD>
        <TD width="12%">Account Number</TD>
        <TD width="12%">Beginning Status</TD>
        <TD width="13%">Step 5 Results</TD>
        <TD width="13%">Step 6 Results</TD>
        <TD width="13%">Step 7 Results</TD>
        <TD width="13%">Step 8 Results</TD>
        <TD width="13%">Step 9 Results</TD>
    </TR>
    <?php 
         $query2 = "SELECT id, name, number, beginstatus, s5result, s6result, s7result, s8result, s9result FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['usid']) . "' and accounttype='" . mysql_real_escape_string($actypeid) . "'";
         $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s5result = $row2[4];                
           $s6result = $row2[5];
           $s7result = $row2[6];                
           $s8result = $row2[7];
           $s9result = $row2[8];                
           
    ?>

      <TR>
        <TD width="12%"><?php print($acname); ?>&nbsp;</TD>
        <TD width="12%"><?php print($acnumber); ?>&nbsp;</TD>
        <TD width="12%"><?php print($acbeginstatus); ?>&nbsp;</TD>
        <TD width="13%"><?php print($s5result); ?>&nbsp;</TD>
        <TD width="13%"><?php print($s6result); ?>&nbsp;</TD>
        <TD width="13%"><?php print($s7result); ?>&nbsp;</TD>
        <TD width="13%"><?php print($s8result); ?>&nbsp;</TD>
        <TD width="13%"><?php print($s9result); ?>&nbsp;</TD>
      </TR>
     <?php
         }
     ?>
        </TBODY>
      </TABLE>
     <?php
       }
       mysql_close($conn);
    ?>
    <b><a href="creditreport.php">< Steps 1-4</a></b>
    <P align=left><br>
    <br>
    <A href="clientstatus.php">See my Status Sheet</A></P>
    <P align=left><A href="interviewer.php">Interviewer</A></P>
    <P align=left><a href="main.php">Main Menu</a></P>
    <?php
}
else
{
    header("Location: clientlogin.php");
    exit();
}

$page['content'] = ob_get_contents();
ob_end_clean();
include('template.php');
?>