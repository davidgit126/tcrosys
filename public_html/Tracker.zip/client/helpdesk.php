<?php
require_once('common.inc.php');
session_start();


extract( $_GET );
extract( $_POST );

if(isset($_SESSION['is_client']) && $_SESSION['is_client'] == 1)
{
 include("connection.php");
include("template.php");

      if($helpdesk == "Yes"){

//-------client
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country FROM clients WHERE id='" . $_SESSION['clientusid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $active = $row[11];
    } 

    //mysql_close($conn);
    ?>
<STYLE type=text/css>
A:active  {	COLOR: #006699; TEXT-DECORATION: none      }
A:visited { COLOR: #334A9B; TEXT-DECORATION: none      }
A:hover   { COLOR: #334A9B; TEXT-DECORATION: underline }
A:link    { COLOR: #334A9B; TEXT-DECORATION: none      }
td { font-family:Tahoma;font-size:11px;color:#000000 }

 .title, h1	{ font-size: 23px; font-weight: bold; font-family: Trebuchet MS,Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000066; }
 .forminput     { font-size: 8pt; background-color: #CCCCCC; font-family: verdana, helvetica, sans-serif; vertical-align:middle }
 .tbox          { FONT-SIZE: 11px; FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif; COLOR: #000000; BACKGROUND-COLOR: #ffffff }
 .gbox          { FONT-SIZE: 11px; FONT-FAMILY: Verdana; COLOR: #000000; BACKGROUND-COLOR: #F7F7F7 }

</STYLE>

<style type="text/css">
 .tbox {
	FONT-SIZE: 11px;
	FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif;
	COLOR: #000000;
	BACKGROUND-COLOR: #ffffff
}
      </style> 
          <div align="center">
            <center><BR>
  <table width="60%" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
    <tr>
      <td height="22">( <a href="helpdesk.php?status=OPEN">open requests</a> / <a href="helpdesk.php?status=CLOSED">resolved requests</a> 
        ) </td>
    </tr>
    <tr> 
      <td height="22"> 
      <?php
if($added=="yes"){
echo "<p align=center><font color=#008000 size=3><b>Ticket Logged!</b></font>";
}
    ?>

</td>    </tr>
    <tr> 
      <td> <table width="100%" border="0" cellspacing="1" align="center" height="19">
          <tr bgcolor="#DEDEEB"> 
            <td width="12%"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Call ID</font></td>
                </tr>
                <tr> 
                  <td height="5"> </td>
                </tr>
              </table></td>
            <td width="10%"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Status</font></td>
                </tr>
                <tr> 
                  <td height="5"> </td>
                </tr>
              </table></td>
            <td width="45%" class="usertab"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Subject</font></td>
                </tr>
                <tr> 
                  <td height="5"> </td>
                </tr>
              </table></td>
            <td width="24%"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">When Logged</font></td>
                </tr>
                <tr> 
                  <td height="5"> </td>
                </tr>
              </table></td>
          </tr>
        </table>
        <div align="center">
        <!-- list of calls -->
        
        
          <table width="100%" border="0" cellspacing="1" cellpadding="4" align="center">
          
              <?php
                   if($status =="OPEN"){
                   $statusq = " and status!='CLOSED'";
                   }
                   if($status =="CLOSED"){
                   $statusq = " and status='CLOSED'";
                   }

    $query = "SELECT id, status, subject, description, DATE_FORMAT(date, \"%m-%d-%Y\") as hdlogdate,  tstamp, ip FROM helpdesk WHERE deleted !='Yes'$statusq and clientid='" . $_SESSION['clientusid'] . "' ORDER BY id DESC"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $hdid= $row[0];
        $hdstatus = $row[1];
        $hdsubject = $row[2];
        $hddescription = $row[3];
        $hdlogdate= $row[4];
        $hdtstamp= $row[5];
        $hdip= $row[6];


        ?>

              <tr bgcolor="#f1f1f1">
            
          
              <td height="11" width="5%"><center>
              <img src="mail.gif" width="11" height="9"></center></td>
              <td height="11" width="7%"><a href="viewticket.php?hdid=<?php print($hdid); ?>"><?php print($hdid); ?></a>
              </td>
              <td height="11" width="10%"><?php print($hdstatus); ?></td>
              <td height="11" width="45%">
               <a href="viewticket.php?hdid=<?php print($hdid); ?>"><?php print($hdsubject); ?></a>
              </td>
              <td height="11" width="24%"><?php print($hdlogdate); ?></td>
            </tr>
              <?php
    }
    //mysql_close($conn);
    ?>

          </table>
          
        
        
        <!-- list of calls -->
        </div>
        
        </td>
    </tr>
    <tr> 
      <td>&nbsp; </td>
    </tr>
    </table>
            </center>
          </div>










    <p align="center"><input type="button" value="Log a New Ticket" onClick="javascript:window.location.href='logticket.php'">
</p>











    <?php
}}
else
{
    header("Location: clientlogin.php");
    exit();
}

?>