<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();

extract ($_SESSION );

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   
    ?>
   
  <?php
    if($_SESSION['usname']=="admin")
    {
    
    
    
     include('template.php');
include("connection.php");

    

        ?>
  
    
   
<form method="POST" action="addcredlettersuccess.php">
                            



<div align="center">
  <center>
<font color="#FF0000"><b><?php print($success); ?></b></font>


<table width="70%"><tr><td width="95%" align=center valign="top">


<table border=1 width="919" cellspacing="1" cellpadding="6">


<tr>
  <td BGCOLOR="#CCCCCC" align="right" width="229">
<b><font face="Verdana" size="2">Creditor Letter Name:</font></b> </td>
  <td BGCOLOR="#CCCCCC" colspan="3" width="672"> 
<input class="txtbox" type=text name=lettername size=85 value="">
</TD>
</tr>


<tr>
  <td BGCOLOR="#CCCCCC" align="right" width="229">
<p align="left">
&nbsp;</td>
  <td BGCOLOR="#CCCCCC" width="229"> 
                                        &nbsp;<b><font face="Verdana" size="2">Display AV/SSN Proof?</font></b> 
                                        <br> 
                                        <select name="showproof" class="txtbox"  >
                
                 <option value="Yes">Yes</option>
 <option value="No">No</option>

              </select></TD>
  <td BGCOLOR="#CCCCCC" align="right" width="229">
<b><font face="Verdana" size="2">Order on letter menu&nbsp;&nbsp; </font></b><br>
<input class="txtbox" type=text name=letterorder size=6 value=""></td>
  <td BGCOLOR="#CCCCCC" width="229">&nbsp; 
                                        </TD>
</tr>

<tr>
  <td colspan="4" BGCOLOR="#CCCCCC" align="center" width="901">
<textarea rows="15" name="abovedisputes"  id="abovedisputes" cols="110"></textarea>
<script language=JavaScript src='../include/gui/scripts/innovaeditor.js'></script>
   <script language=JavaScript src='http://www.tcrosystems.net/scripts/addcreditor.js'></script>


</TD>
</tr>

</table><br>
<input type="submit" value="Add Letter"> 




</td></tr></table>
</center>
</div>


</center>


  
</form>
<p>
<BR><BR><a href="letters.php">Letter Menu</a>
</p>



  
<?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>