<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    include('template.php');
if($_SESSION['isptcso']!="PTCSO")
{
   ?>
<font color="red"><B>You do not have access to this area </font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 }else{
  include("connection.php");

?>
    
 
    <font color="red">  <B> <?php print($message); ?></B></font>
  <?php
    include('main.php');
   ?> 
        

              <BR><BR><BR>
          <?php
    
    if($_GET['f']==1)
    {

        ?>
        <table width="50%" background="bluestrip.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
        <tr>

            <td colspan="6" background="titlebackground.gif">
            <img border="0" src="leftupcorner.gif" width="32" height="29"><img border="0" src="listofclients.gif" width="250" height="29"><img border="0" src="filler.gif" width="63" height="29"></td>

            <td width="1" background="titlebackground.gif">
            <img border="0" src="rightupcorner.gif" width="10" height="29"></td>


        </tr>
        <tr>
<td><font color="#FFFFFF"></font></td>
<td ><font color="#FFFFFF"><b>Company Name</b></font></td>
<td><font color="#FFFFFF"><b>Last Name</b></font></td>
<td><font color="#FFFFFF"><b>First Name</b></font></td>
<td><font color="#FFFFFF"><b>Setup Date</b></font></td>
<td><font color="#FFFFFF"><b>Status</b></font></td>
</tr>
        <?php

include "700score_connection2.php"; 
 $query = "SELECT dealer_id, firstname, lastname, createdate, mainstatus, dealership FROM dealers WHERE contract='licensee' and dedemail='" . $_SESSION['csotracker_id'] . "' ";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $licensee_id = $row[0];
          $licensee_fname = $row[1];
        $licensee_lname = $row[2];
        $licensee_createdate = $row[3];
        $licensee_status = $row[4];
        $licensee= $row[5];

          

             $cnt++;
                  
$bgcolor = "FFFFFF";

              ?>
<tr>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($cnt); ?>&nbsp;&nbsp;</td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><a href="setlicensee.php?licid=<?php print($licensee_id); ?>"><?php print($licensee); ?></a></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($licensee_lname); ?></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($licensee_fname); ?></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($licensee_createdate); ?></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($licensee_status); ?></td>
</tr>
              <?php
          }
          mysql_close($conn);
          ?>
          
          
          
          
          
          
          



          
          
          </table>
          <?php
          if($cnt==0)
          {
              print("There are no matching records to your search criteria. Please try again.");
          }
    }
}

}
else
{
    header("Location: login.php");
    exit();
}

?>