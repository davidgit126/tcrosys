<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();
extract ($_SESSION );


$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";
$today = date("Y-m-d");

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);

$nowday = date("d");
$nowmonthword = date("M");
$nowmonthword2 = date("F");
$nowmonthword3 = date("F", strtotime("-1 month"));
//$nowmonthword3 = strtotime('-1 second' '$nowmonthword3');
$nowmonthword4 = date("F", strtotime("-2 month"));

$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

$thismonth = date("Y-m");
$thismonth2 = date("Y-m", strtotime("-1 month"));
$thismonth3 = date("Y-m", strtotime("-2 month"));


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
include("connection.php");
include('template.php');
include('main.php');
include('rolloverhelp.php');

/////////////////////////////////////////////////////////////////////////
$brokeronform = $_POST['brokeronform'];
$sessionedbroker = $_SESSION['dealer_id'];

if($updatebroker == 1)
    {


        $query = "UPDATE dealers SET
                account_exec=$masteraccount
                WHERE dealer_id='" . $_SESSION['dealer_id'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Master Account',
                    '" . mysql_real_escape_string($_SESSION['dealer_id']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());


    }

      if($_POST['updatecl'] == 1)
      {
 if ($brokeronform == $sessionedbroker){
       
        $query = "UPDATE dealers SET
                lastname='" . mysql_real_escape_string($_POST['lastname']) . "',
                firstname='" . mysql_real_escape_string($_POST['firstname']) . "',
                address='" . mysql_real_escape_string($_POST['address']) . "',
                address2='" . mysql_real_escape_string($_POST['address2']) . "',
                checkssn='" . mysql_real_escape_string($_POST['checkssn']) . "',
				dealership='" . mysql_real_escape_string($_POST['dealership']) . "',                
                city='" . mysql_real_escape_string($_POST['city']) . "',
                prov='" . mysql_real_escape_string($_POST['prov']) . "',
                zipcode='" . mysql_real_escape_string($_POST['zipcode']) . "',
                email='" . mysql_real_escape_string($_POST['email']) . "',
                fax='" . mysql_real_escape_string($_POST['fax']) . "',
                telephone='" . mysql_real_escape_string($_POST['telephone']) . "',
                username='" . mysql_real_escape_string($_POST['username']) . "',
                password='" . mysql_real_escape_string($_POST['password']) . "',
                affiliate_id='" . mysql_real_escape_string($_POST['affiliate_id']) . "',
                commission='" . mysql_real_escape_string($_POST['commission']) . "',
                tier2comm='" . mysql_real_escape_string($_POST['newtier2comm']) . "',
                tier3comm='" . mysql_real_escape_string($_POST['newtier3comm']) . "',
				emailnotify='" . mysql_real_escape_string($_POST['emailnotify']) . "',
                notification='" . mysql_real_escape_string($_POST['notification']) . "',
                comments='" . mysql_real_escape_string($_POST['comments']) . "'
                WHERE dealer_id='" . $_SESSION['dealer_id'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Affiliate',
                    '" . mysql_real_escape_string($_SESSION['dealer_id']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}else{
print("<font color=red><b>Your Broker Session Has Expired.  You can prevent this from happening by not keeping old broker windows open after opening new broker records. </b></font>");
exit(); 
}

   }
        
          
   if ($calhour !="") {
     $dealer_id=$_SESSION['dealer_id'];
  $loggedinuser = $_SESSION['usname'];
  $client_nameforlink=str_replace(" ", "%20", "$clientname");     

$webpage = "setbroker.php?cid=$dealer_id&cname=$client_nameforlink";
$typeofreminder = "(Broker)";


 if (($calampm == "pm") && ($calhour < 12)){
$calhour += 12;
}
 if (($calampm == 'am') && ($calhour == 12)){
$calhour = 0;
}
 if ($priority == ""){
$priority = "";
}else  if ($priority == "Medium"){
$priority = "(Medium Priority)";
}else if ($priority == "High"){
$priority = "(HIGH Priority)";
}

$date = mktime ( 3, 0, 0, $calmonth, $calday, $calyear );
  $str_cal_date = date ( "Ymd", $date );
  $changefollowup = date ( "Y-m-d", $date );
  $str_cal_time = sprintf ( "%d%02d00", $calhour, $calminute );
  $modtime = date ( "Gis" );
  
$sqlcal1 = "INSERT INTO calendar (cal_contactid, cal_create_by, cal_date, cal_time, cal_mod_date, cal_mod_time, cal_name, cal_link, cal_description)
			VALUES(
	\"$dealer_id\",
	\"$loggedinuser\",
	\"$str_cal_date\",
	\"$str_cal_time\",
	\"$julian\",
	\"$modtime\",
	\"Call $clientname $typeofreminder $priority\",
	\"$webpage\",
	\"$note\")";
                $result = mysql_query($sqlcal1, $conn) or die("error:" . mysql_error());

$query = "UPDATE clients SET
                scheduleddate='$changefollowup'
                WHERE id='$id'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}


if ($_POST['action'] == "addpic"){
$dbpart = explode('_', $dbname); 
$dbpart = $dbpart[0];
  $uploadbroker = "/home/$dbpart/public_html/brokers/pics/";

if ($HTTP_POST_VARS['submit']) {
  print_r($HTTP_POST_FILES);
  if (!is_uploaded_file($HTTP_POST_FILES['file']['tmp_name'])) {
    $error = "You did not upload a file!";
    unlink($HTTP_POST_FILES['file']['tmp_name']);
    // assign error message, remove uploaded file, redisplay form.
  } else {
    //a file was uploaded
    $maxfilesize=307200;


    if ($HTTP_POST_FILES['file']['size'] > $maxfilesize) {
      $error = "file is too large"; unlink($HTTP_POST_FILES['file']['tmp_name']);
      // assign error message, remove uploaded file, redisplay form.
    } else {
if (substr($HTTP_POST_FILES['file']['type'], 0, 5) != 'image') { 
        $error = "This file type is not allowed";
        unlink($HTTP_POST_FILES['file']['tmp_name']);
        // assign error message, remove uploaded file, redisplay form.
      } else {
      
      $jpg = ".jpg";
       //File has passed all validation, copy it to the final destination and remove the temporary file:
       copy($HTTP_POST_FILES['file']['tmp_name'],"$uploadbroker".$_POST['ssnforfile'].$jpg);
       unlink($HTTP_POST_FILES['file']['tmp_name']);
      $error = "Image successfully uploaded!";
       
       $file = $_POST['ssnforfile'].$jpg;
$newurl = $file;

$query = "UPDATE dealers SET
                url='$newurl'
                WHERE dealer_id='" . $_SESSION['dealer_id'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
     }
    } 
  }
}}
if ($_POST['action'] == "removepic")
    {
        $query = "UPDATE dealers SET
                url=''
                WHERE dealer_id='" . $_SESSION['dealer_id'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    }

if ($delmaster ==1)
    {
        $query = "UPDATE dealers SET
                account_exec=''
                WHERE dealer_id='" . $_SESSION['dealer_id'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    }

    $query = "SELECT lastname, firstname, address, city, prov, zipcode, email, fax, telephone, dealership, username, password, comments, dealer_id, affiliate_id, commission, account_exec, emailnotify, notification, url, tier2comm, tier3comm, tier2aff, tier3aff, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, bio, bioapproved, address2, checkssn   FROM dealers WHERE status !=9 and dealer_id='" . $_SESSION['dealer_id'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lastname = $row[0];
        $firstname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $prov = $row[4];
        $zipcode = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $telephone = $row[8];
        $dealership = $row[9];
        $username = $row[10];
        $password = $row[11];
	    $comments = $row[12];
		$dealer_id = $row[13];			
		$affiliate_id = $row[14];			
		$commission = $row[15];			
		$masterbroker = $row[16];			
		$emailnotify = $row[17];			
		$notification = $row[18];			
		$url = $row[19];			
		$newtier2comm = $row[20];			
		$newtier3comm = $row[21];			
		$tier2affiliate = $row[22];			
		$tier3affiliate = $row[23];			
		$logins = $row[24];			
		$lastlogin= $row[25];			
		$bio= $row[26];			
		$bioapproved = $row[27];			
		$address2 = $row[28];			
		$checkssn = $row[29];			
		}

		  $bio = nl2br($bio);               


	       if ($tier2affiliate != "") {
    $query = "SELECT username, firstname, lastname FROM dealers WHERE dealer_id=$tier2affiliate";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $tier2username = $row[0];
        $tier2firstname = $row[1];
        $tier2lastname = $row[2];
		}
		   }

		     if ($tier3affiliate != "") {
    $query = "SELECT username, firstname, lastname FROM dealers WHERE dealer_id=$tier3affiliate";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $tier3username = $row[0];
        $tier3firstname = $row[1];
        $tier3lastname = $row[2];
		}
		   }


       if ($emailnotify == 0) {
$emailnotifyname = "Notifications Off";
}else if  ($emailnotify == 1) {
$emailnotifyname = "Client Updates Only";
}else if  ($emailnotify == 2) {
$emailnotifyname = "Client Updates & New Lead Submissions";
}else if  ($emailnotify == 3) {
$emailnotifyname = "Client Updates, New Lead Submissions & Updates";
}
 if ($notification == 0) {
$notificationname = "No";
}else if  ($notification == 1) {
$notificationname = "Yes";
}
//////////////////////////////BROKER REFERRALS

$leadquery = "((leadentered like '$thismonth%') or (createdate like '$thismonth%')) AND clientdelete != 'yes' and status != 'inactive' ";
$leadquery2 = "((leadentered like '$thismonth2%') or (createdate like '$thismonth2%')) AND clientdelete != 'yes' and status != 'inactive' ";
$leadquery3 = "((leadentered like '$thismonth3%') or (createdate like '$thismonth3%')) AND clientdelete != 'yes' and status != 'inactive' ";

$query2 = "SELECT id, name, address, email, singlecouple FROM clients WHERE broker_id ='" . $_SESSION['dealer_id'] . "' and $leadquery ";
$result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
$numberprospects = 0;
while($row2=mysql_fetch_row($result2))
{
              $id           = $row2[0];
              $clientname   = $row2[1];
              $clientaddress      = $row2[2];
              $cemail       = $row2[3];
              $singlecouple = $row2[4];

if ($singlecouple ==""){
	$prospectvalue = 1;
} elseif ($singlecouple =="Single"){
	$prospectvalue = 1;
} elseif ($singlecouple =="Joint"){
	$prospectvalue = .5;
}

$numberprospects = $numberprospects + $prospectvalue;
}

$query2 = "SELECT id, name, address, email, singlecouple FROM clients WHERE broker_id ='" . $_SESSION['dealer_id'] . "' and $leadquery2 ";
$result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
$numberprospects2 = 0;
while($row2=mysql_fetch_row($result2))
{
              $id           = $row2[0];
              $clientname   = $row2[1];
              $clientaddress      = $row2[2];
              $cemail       = $row2[3];
              $singlecouple = $row2[4];

if ($singlecouple ==""){
	$prospectvalue = 1;
} elseif ($singlecouple =="Single"){
	$prospectvalue = 1;
} elseif ($singlecouple =="Joint"){
	$prospectvalue = .5;
}

$numberprospects2 = $numberprospects2 + $prospectvalue;
}

$query2 = "SELECT id, name, address, email, singlecouple FROM clients WHERE broker_id ='" . $_SESSION['dealer_id'] . "' and $leadquery3 ";
$result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
$numberprospects3 = 0;
while($row2=mysql_fetch_row($result2))
{
              $id           = $row2[0];
              $clientname   = $row2[1];
              $clientaddress      = $row2[2];
              $cemail       = $row2[3];
              $singlecouple = $row2[4];

if ($singlecouple ==""){
	$prospectvalue = 1;
} elseif ($singlecouple =="Single"){
	$prospectvalue = 1;
} elseif ($singlecouple =="Joint"){
	$prospectvalue = .5;
}

$numberprospects3 = $numberprospects3 + $prospectvalue;
}




//////////////////////////////BROKER NOTES
if ($note) {


$sql_note = "INSERT INTO salesnotes

(clientid,received,action,counselor,repairdate,filelocation)
               VALUES
('" . mysql_real_escape_string($_SESSION['dealer_id']) . "',
\"broker\",
\"$note\",
'" . mysql_real_escape_string($_SESSION['usfname']) . "',
\"$today\",
\"$tstamp\")";
$result_note = @mysql_query($sql_note,$conn);
}

    
  $SA_sql = "SELECT dealership,firstname,lastname FROM dealers where dealer_id='$masterbroker'";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $brokerdealership = $srow['dealership'];
		    $brokerfirstname = $srow['firstname'];
		    $brokerlastname = $srow['lastname'];
		  	    
		}


  $query3 = "SELECT count(id) FROM clients WHERE prospectclient = 'Client' AND affiliate_id = '$affiliate_id'";
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $totalcredit = $row3[0];
                   $affiliateearn = $totalcredit * $commission_rate;
}

 $query = "SELECT sum(amount_paid) as total_paid FROM commission_affiliate WHERE affiliate_id = '$affiliate_id'";

              $result = mysql_query($query, $conn) or die("error:" . mysql_error());
              while($row=mysql_fetch_array($result))
              {
                   $total_paid = $row[total_paid];
                    $total_due = $affiliateearn - $total_paid;
}


    
    
/* Connection to Affiliates People */

		$SA_sql = "SELECT * FROM sales_affiliates WHERE type='Affiliate' AND status !='del' ORDER BY lname";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $affiliateid = $srow['id'];
		    $fname = $srow['fname'];
		    $lname = $srow['lname'];


                if ($username == "$user") {
		$user_select6 .= "<option value=\"$affiliateid\">$lname, $fname</option>";
		}else{
		$user_select6 .= "<option value=\"$affiliateid\">$lname, $fname</option>";
		}

		$ARUSERS{"$affiliateid"} = "$affiliateid";
		
		}

$SA_sql = "SELECT fname,lname FROM sales_affiliates where id='$affiliate_id'";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $affiliatefirstname = $srow['fname'];
		    $affiliatelastname = $srow['lname'];
		}

$bgcolor = "c0c0c0";


    //mysql_close($conn);
?>
<?php
/////////////////////////////////////////// REGULAR MODE
if($_SESSION['brokers']=="Yes" && $mode !="email"){

    $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_brokers WHERE broker_id = '" . $_SESSION['dealer_id'] . "' GROUP BY broker_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];
}
?>

<body onLoad="Tooltip.init()">
<script type="text/javascript" src="jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery.textarea-expander.js"></script>
   <style type="text/css"> 
/* <![CDATA[ */

textarea
{
	clear: both;
	display: block;
	font-family: Verdana, sans-serif; 
	font-size: 11px;
	padding: 4px 4px 4px 4px;
	margin: 6px auto;

}
 
/* ]]> */
</style>
<font color="red">  <B> <?php print($error); ?></B></font>
<h3 class="elegantLG" align="center"><?php print($firstname); ?> <?php print($lastname); ?>'s Broker Record<BR>
<a href="search.php?searchbroker=<?php print($_SESSION['dealer_id']); ?>&f=1"><img border=0 src="viewclients_btn.png" alt="" /></a>
&nbsp;&nbsp;&nbsp;
<a href="prospectsearch.php?searchbroker=<?php print($_SESSION['dealer_id']); ?>&f=1"><img border=0 src="viewprospects_btn.png" alt="" /></a>
</h3>
<SCRIPT LANGUAGE="JavaScript">
    function validate2(formCheck)
{
   if (formCheck.affiliate_id.value =="")
    {
        return confirm("By removing this affiliate from this account, this affiliate will no longer earn commission for any clients this broker brings.  Are you sure you want to do this?"); 
   
    }  
    
    if (formCheck.affiliate_id.value !="")
    {
        return confirm("You are about tie an affiliate to this broker.  By doing this, any future lead submitted by this broker that turns into a client this affiliate will earn a commission on.  Are you sure you want to do this?"); 
   
    }  

    
    
    }
    
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript" SRC="CalendarPopup.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript">document.write(getCalendarStyles());</SCRIPT>
<SCRIPT LANGUAGE="JavaScript">
var cal = new CalendarPopup("testdiv1");
cal.setReturnFunction("setMultipleValues3"); 
function setMultipleValues3(y,m,d) { 
     document.forms[1].calyear.value=y; 
     document.forms[1].calmonth.selectedIndex=m; 
     document.forms[1].calday.selectedIndex=d; 
     }
     


function finalCheck(form) {
if(! document.Subscribe.note.value){
alert("You must enter a \"Note\"")
document.Subscribe.note.focus();return false}



	}

</SCRIPT>
 <script type="text/javascript">

	subject_id = '';
	function handleHttpResponse() {
		if (http.readyState == 4) {
			if (subject_id != '') {
				document.getElementById(subject_id).innerHTML = http.responseText;
			}
		}
	}
	function getHTTPObject() {
		var xmlhttp;
		/*@cc_on
		@if (@_jscript_version >= 5)
			try {
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (E) {
					xmlhttp = false;
				}
			}
		@else
		xmlhttp = false;
		@end @*/
		if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
			try {
				xmlhttp = new XMLHttpRequest();
			} catch (e) {
				xmlhttp = false;
			}
		}
		return xmlhttp;
	}
	var http = getHTTPObject(); // We create the HTTP Object

	function getScriptPage(div_id,content_id)
	{
		subject_id = div_id;
		content = document.getElementById(content_id).value;
http.open("GET", "template.php?searchpage=masterbroker&content=" + escape(content), true);
http.onreadystatechange = handleHttpResponse;
		http.send(null);
		if(content.length>0)
			box('1');
		else
			box('0');

	}	

	function highlight(action,id)
	{
	  if(action)	
		document.getElementById('word'+id).bgColor = "#1550b4";
	  else
		document.getElementById('word'+id).bgColor = "#2E2E2E";
	}
	function display(word)
	{
		document.getElementById('text_content').value = word;
		document.getElementById('box').style.display = 'none';
		document.getElementById('text_content').focus();
	}
	function box(act)
	{
	  if(act=='0')	
	  {
		document.getElementById('box').style.display = 'none';

	  }
	  else
		document.getElementById('box').style.display = 'block';
		document.getElementById('topbox').style.display = 'block';
	}
</script> 
  <script>
function confirmDelete(delUrl) {
  if (confirm("Assign Master Account to see all this broker's accounts?")) {
    document.location = delUrl;
  }
}
</script>
<style type="text/css">
table.bordered {border-left: 1px solid black;border-top: 1px solid black; }
table.bordered tr td, table.bordered tbody tr td {border-right: 1px solid black;border-bottom:1px solid black}
button, input[type="submit"] {font-weight:bold;border:1px solid black;cursor:hand;}
tr.odd td{background-color:lightyellow}
tr.even td{background-color:lightgrey}
tr.white td{background-color:EAEAEB}
tr.space td{background-color:B3C1E1}

</style>
<div align="center">
  <center>
<TABLE width="1050" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111">
<TR>
<td valign="top">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="500">
<tr><td width="1"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Last Login - <?php print($lastlogin); ?>  (Total Logins - <?php print($logins); ?>)</td>
<td width="1"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
<table class="blrtb" width="500" border="0" cellpadding="0" cellspacing="0">
<form method="POST" action="" name="Subscribe" >
<input type="hidden" name="brokeronform" value="<?php print($dealer_id); ?>">

<tr class="white">
<td> &nbsp; Company</font></td>
<td class='ss-round-inputs' >&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="dealership" value="<?php print($dealership); ?>" size="25"><img border="0" src="input-right.gif" width="7" >
</td></tr>
<tr class="white">
<td> &nbsp; First Name</font></td>
<td class='ss-round-inputs' >&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="firstname" value="<?php print($firstname); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
</td></tr>
<tr class="white">
<td> &nbsp; Last Name</font></td>
<td class='ss-round-inputs' >&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="lastname" value="<?php print($lastname); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
</td>
</tr>
<tr class="white">
<td> &nbsp; Username</font></td>
<td class='ss-round-inputs' >&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="username" value="<?php print($username);?>" size="20"><img border="0" src="input-right.gif" width="7" >
</td>
</tr>
<tr class="white">
<td> &nbsp; Password</font></td>
<td class='ss-round-inputs' >&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="password" value="<?php print($password);?>" size="20"><img border="0" src="input-right.gif" width="7" >
</td>
</tr>
<tr class="white">
<td> &nbsp; SSN/EIN</font></td>
<td class='ss-round-inputs' >&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="checkssn" value="<?php print($checkssn);?>" size="20"><img border="0" src="input-right.gif" width="7" >
</td>
</tr>
<tr >
<td>&nbsp; </td>
<td>&nbsp;</td></tr>
<tr class="white">
<td> &nbsp; Address</font></td>
<td class='ss-round-inputs' >&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="address" value="<?php print($address); ?>" size="28" ><img border="0" src="input-right.gif" width="7" >
</td></tr>

<tr class="white">
  <td > &nbsp; City, St Zip</font>   </td>
  <td class='ss-round-inputs' >
&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  size="16" name="city" value="<?php print($city); ?>"><img border="0" src="input-right.gif" width="7" >
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  size="2" name="prov" value="<?php print($prov); ?>"><img border="0" src="input-right.gif" width="7" >
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  size="5" name="zipcode" value="<?php print($zipcode); ?>"><img border="0" src="input-right.gif" width="7" ></td>
</tr>

<tr class="white">
  <td > &nbsp; Phone</font></td><td class='ss-round-inputs' >
&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="telephone" value="<?php print($telephone); ?>" size="20"><img border="0" src="input-right.gif" width="7" ></td>
</tr>
<tr class="white">
  <td > &nbsp; Alt Phone</font></td><td class='ss-round-inputs' >
&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="fax" value="<?php print($fax); ?>" size="20"><img border="0" src="input-right.gif" width="7" ></td>
</tr>
<tr class="white">
  <td > &nbsp; Website</font></td><td class='ss-round-inputs' >
&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="address2" value="<?php print($address2); ?>" size="40"><img border="0" src="input-right.gif" width="7" ></td>
</tr><tr >
  <td >&nbsp; </td><td >&nbsp;
</td>
</tr>

<tr class="white">
  <td > &nbsp; Email</font></td><td class='ss-round-inputs' >
&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="email" value="<?php print($email); ?>" size="30"><img border="0" src="input-right.gif" width="7" >

</td>
</tr>
<tr class="white">
  <td colspan="2" style="padding:10px;">&nbsp;
  <?php

$query = "SELECT id, name FROM systememails WHERE type ='broker' and name not like '%_Welcome' order by name";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
           
        $emailid = $row[0]; 
        $emailname = $row[1]; 

  
    ?>
<a href="brokerstatus.php?id=<? echo "$id"; ?>&mode=email&emailid=<? echo "$emailid"; ?>"><? echo $emailname; ?></a>&nbsp;<B>|</B>
<?php
}

  
    ?>
</font>
  </td></tr>


<tr >
  <td >&nbsp; </td><td >&nbsp;
</td>
</tr>
<tr class="white">
  <td > &nbsp; Show Info</font></td><td >
&nbsp; 
                                        <select class="txtbox"   name="notification">
					    <option value="<?php print($notification); ?>" selected><?php print($notificationname); ?></option>                                        
					    <option value="0" >No</option>
					    <option value="1" >Yes</option>
					    </select>
					

</td>
</tr>

<tr class="white">
  <td > &nbsp; Settings</font></td><td >
&nbsp; 
                                        <select class="txtbox"   name="emailnotify">
					    <option value="<?php print($emailnotify); ?>" selected><?php print($emailnotifyname); ?></option>                                        
					    <option value="0" >Notifications Off</option>
					    <option value="1" >Client Updates Only</option>
					    <option value="2" >Client Updates & New Lead Submissions</option>
					    <option value="3" >Client Updates, New Lead Submissions & Updates</option>
					    </select>

</td>
</tr>
<tr class="white">
  <td > &nbsp;  </font></td><td >
&nbsp; 
<?php
  if($welcomeresend == "Yes"){
        ?>
                                      Welcome Email Sent!
                                <?php
  }else if($welcomeresend == "No"){
        ?>
                                      Email not activated
                                <?php
 }else{
        ?>
       <input type="button" value="Resend Welcome Email" onClick="javascript:window.location.href='welcomeresend.php?t=Broker'">
                                <?php
 }

        ?>

</td>
</tr>


<tr class="white">
<td > &nbsp; &nbsp;</font></td><td class='ss-round-inputs' > &nbsp; 
&nbsp; Master Account -      
<?php print($brokerdealership); ?> ---- (<?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?>)
<?php
  if($brokerdealership != ""){
        ?>

<a href="brokerstatus.php?delmaster=1"><img border="0" src="deletebutton.png"></a>
<?php
}
?>
<img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Master Account</B><BR>You can assign another broker as a Master Account over <?php print($brokerfirstname); ?> <?php print($brokerlastname); ?>.  A Master can see all leads and clients for <?php print($brokerfirstname); ?> <?php print($brokerlastname); ?> as well as any other account this broker is Master over.<font color=#0364C4 style=font-size:9px;><br><br>Master Accounts can see this when they log in.</font>')" 
    onmouseout="hideTip()" width="19" height="19">

<font color="#FF0000"><B><?php print($brokertracking2); ?></B></font>
					    
<BR> &nbsp; 
              <div class="ajax-div">
	<div class="input-div">

<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" size="20" onKeyUp="getScriptPage('box','text_content')" id="text_content" ><img border="0" src="input-right.gif" width="7" >
				</div>
</div>
</td>
</tr>

<tr >
<td ></td><td >
<div id="box"></div>&nbsp</td>
</tr>
<!-- COMMISSION SECTION -->
<tr class="white">
<td > &nbsp; Tier 1 Comm</font></td><td class='ss-round-inputs' >
&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10" name="commission" value="<?php print($commission); ?>"><img border="0" src="input-right.gif" width="7" ></td>
</tr>
<tr class="white">
<td > &nbsp; Tier 2 Comm</font></td><td class='ss-round-inputs' >
&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10" name="newtier2comm" value="<?php print($newtier2comm); ?>"><img border="0" src="input-right.gif" width="7" ></td>
</tr>
<tr class="white">
<td > &nbsp; Tier 3 Comm</font></td><td class='ss-round-inputs' >
&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10" name="newtier3comm" value="<?php print($newtier3comm); ?>"><img border="0" src="input-right.gif" width="7" ></td>
</tr>
<!-- END COMMISSION SECTION -->

<tr class="white"><td > &nbsp; Affiliate</font></td><td >
&nbsp; <select class="txtbox"   name="affiliate_id" onChange = "return validate2(broker)"; >
					    <option value="<?php print($affiliate_id); ?>" selected><?php print($affiliatelastname); ?>, <?php print($affiliatefirstname); ?></option>
					    <? echo "$user_select6"; ?>
						<option value="">--Remove Affiliate from this broker--</option>
					    </select></td></tr>

<tr class="white">
<td > &nbsp; Tier 2/3</font></td><td class='ss-round-inputs' >
&nbsp; <a href="setbroker.php?cid=<?php print($tier2affiliate); ?>&cname=<?php print($tier2firstname); ?> <?php print($tier2lastname); ?>"><?php print($tier2firstname); ?> <?php print($tier2lastname); ?></a>/<a href="setbroker.php?cid=<?php print($tier3affiliate); ?>&cname=<?php print($tier3firstname); ?> <?php print($tier3lastname); ?>"><?php print($tier3firstname); ?> <?php print($tier3lastname); ?></a>
</td>
</tr>
<tr >

  <td>&nbsp; </td><td >&nbsp;
</td>
</tr>

<tr class="white">
  <td width="100%" colspan="2" align="center">Internal Comments <BR><textarea class="expand25-250 txtbox"  name="comments" rows="3" cols="65"><?php print($comments); ?></textarea></font>
</td>
</tr>

<tr class="white"><td colspan="2"> 
<p align="center">
     <input type="hidden" name="info" value="1">

                            <input type="hidden" name="updatecl" value="1">
                           

 
              <?php
    if($_SESSION['usaccess']=="full")
    {
        ?>
 <input type="submit" name="Update" value="Update">
 
  
              <?php
 }
        ?>
  </td></tr>
</form>


<form method="POST" action="" name="" >

<tr class="white"><td width="100%" colspan="2" align="center"> 
<center>
<hr>
<p>
<b>ADD A NOTE</font></b><br>
<textarea name="note" class="expand50-250" rows="5" cols="65">
</textarea><br>
&nbsp;</font></p>
</center>
</td></tr>

<tr class="white"><td width="100%" colspan="2" align="center"> 
<center><b>SET FOLLOWUP</b><br>
			<select class="txtbox" name="calday">
<option value="<? echo "$nowday"; ?>" selected="selected"><? echo "$nowday"; ?></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22"">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<select class="txtbox" name="calmonth">
<option value="<? echo "$nowmonth"; ?>" selected="selected"><? echo "$nowmonthword"; ?></option>
<option value="1">Jan</option>
<option value="2">Feb</option>
<option value="3">Mar</option>
<option value="4">Apr</option>
<option value="5">May</option>
<option value="6">Jun</option>
<option value="7">Jul</option>
<option value="8">Aug</option>
<option value="9">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
<input maxlength="4" class="txtbox" type="text" name="calyear" size="4" value=<? echo "$nowyear"; ?> >

<A HREF="#" onClick="cal.showCalendar('anchor1'); return false;" NAME="anchor1" ID="anchor1">
<img border="0" src="calendar.gif"></A>




&nbsp;&nbsp;
			<input class="txtbox" type="text" name="calhour" size="2" value="" maxlength="2" />:<input class="txtbox" type="text" name="calminute" size="2" value="" maxlength="2" />
<label><input type="radio" name="calampm" value="am" checked="" />AM</label>
<label><input type="radio" name="calampm" value="pm"  />PM</label><BR>
<strong>Priority</strong>     
<label><input type="radio" name="priority" value=""  checked="" />Low</label>
<label><input type="radio" name="priority" value="Medium"  />Medium</label>
<label><input type="radio" name="priority" value="High"  />High</label>
<br>
<input type="hidden" name="clientname" value="<? echo "$firstname"; ?> <? echo "$lastname"; ?>">

</td></tr>
 
<tr class="white"><td colspan="2" height="10"></td></tr>

<tr class="white"><td align="center" colspan="2" width="100%">
<center><input type="submit" name="submit" value="Update">
</td></tr>

<tr class="white"><td colspan="2" height="15"></td></tr>



</table>
</form>
<DIV ID="testdiv1" STYLE="position:absolute;visibility:hidden;background-color:white;layer-background-color:white;"></DIV>
</TD><TD VALIGN="TOP">

</TD>

<TD>&nbsp;
</TD>






<td valign="top">

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="519">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Notes</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
<div style="border:1px  solid; width:519; height:525px; overflow:auto;">
<table class="blrtb" width="500" border="0" cellpadding="0" cellspacing="0">
<?



$sql = "SELECT * FROM salesnotes WHERE clientid = '" . $_SESSION['dealer_id'] . "' AND received ='broker' ORDER BY repairdate DESC, id";
$result = @mysql_query($sql,$conn) or die("Couldn't execute");

$num_results = mysql_num_rows($result);

if (! $num_results || $num_results == "0") {
echo "<font color=red><b>$accesscomment</font></b><BR>";
echo "<b><font face=\"Verdana\" size=\"2\" color=\"#FF0000\">No notes added.</font></b>";
echo "</TABLE></div>";
}else{

  $change_color = "1";
  
echo "<TABLE width=\"500\" BORDER=\"0\" bordercolor=\"#000000\" class=\"blrtb\" cellpadding=\"0\" cellspacing=\"0\">";



  while ($row = mysql_fetch_array($result)) {	
    $NOTE_id = $row['id'];
    $NOTE_contact_id = $row['clientid'];
    $NOTE_view = $row['action'];
    $NOTE_user = $row['counselor'];
    $NOTE_julian = $row['repairdate'];
    $NOTE_tstamp = $row['filelocation'];

$NOTE_year = substr("$NOTE_julian", 0, 4);
$NOTE_month = substr("$NOTE_julian", 5, 2);
$NOTE_day = substr("$NOTE_julian", 8, 2);

if ($change_color == "2") {
$bgcolor = "class=\"even\"";
$change_color = "1";
}else{
$bgcolor = "class=\"odd\"";
$change_color = "2";
}

echo "<TR $bgcolor>";
echo "<TD align=\"center\"><font size=\"1\">$NOTE_month/$NOTE_day/$NOTE_year</font></TD>";
echo "<TD align=\"center\"><font face=\"Verdana\" ><font size=\"1\">$NOTE_view</font></TD>";
echo "<TD align=\"center\"><font face=\"Verdana\" ><font size=\"1\">$NOTE_user</font></TD>";
echo "</TR>";


} // end while loop //
echo "</TABLE></div>
<p>";
	} // end if results //

//echo "<br><br>";


?>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="519">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Referral Statistics</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="519">
<tr><td width="100%">


 <script type="text/javascript" src="FusionCharts.js"></script>

 <div id="chartContainer">FusionCharts will load here!</div>
 
                        <script type="text/javascript"><!--
                            var strXML = "<chart bgAlpha='0,0' showPrintMenuItem='0' showValues='1' showAboutMenuItem='0' showBorder='0'  >\n\
                                            <set label='<?php print($nowmonthword4); ?>' value='<?php print($numberprospects3); ?>' />\n\
                                            <set label='<?php print($nowmonthword3); ?>' value='<?php print($numberprospects2); ?>' />\n\
                                            <set label='<?php print($nowmonthword2); ?>' value='<?php print($numberprospects); ?>' />\n\
<styles>\n\
<definition>\n\
<style name='myFont' type='font' isHTML='1' bold='1' size='11' color='FFFFFF' />\n\
<style name='myShadow' type='shadow' color='333333' angle='45' strength='3'/>\n\
<style name='myShadow2' type='shadow' angle='45' distance='1' color='FFFFFF'/>\n\
<style name='myAnim3' type='animation' param='_xScale' start='0' duration='1'/>\n\
<style name='myAnim4' type='animation' param='_alpha' start='0' duration='1'/>\n\
<style name='myAnim5' type='animation' param='_xScale' start='0' duration='1'/>\n\
</definition>\n\
<application>\n\
<apply toObject='DataValues' styles='myFont,myShadow,myAnim' />\n\
<apply toObject='DIVLINES' styles='myShadow2' />\n\
<apply toObject='ANCHORS' styles='myAnim2' />\n\
<apply toObject='ANCHORS' styles='myBevel' />\n\
<apply toObject='HGRID' styles='myAnim3, myAnim4' />\n\
<apply toObject='DIVLINES' styles='myAnim5' />\n\
<apply toObject='YAXISVALUES' styles='myAnim6' />\n\
</application>\n\
</styles>\n\
</chart>";
 
                            var myChart = new FusionCharts( "Column3D.swf", "myChartId", "519", "300", "0", "0" );
                            myChart.setXMLData(strXML);
                            myChart.render("chartContainer");
                            
                            // -->
                        </script>
						
						
						</td></tr>
</table>


</table>




<p></p>
</div>
</td>
</tr>

</table>




<?php
if ($bio != "") {

	if ($bioapproved == "No"){
$biomessage ="<a href=approvebrokerbio.php><font color=green size=1>Awaiting Approval</font></a>";
					}
?>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="1050">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Bio of <?php print($firstname); ?> <?php print($lastname); ?> <?php print($biomessage); ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table border="0" cellpadding="5" style="border-collapse: collapse" bordercolor="#111111" width="1050" id="AutoNumber3" cellpadding="0">

                            <tr class="white">
                              <td width="100%" valign="top">
<?php print($bio); ?>
                             

                              </td>
                            </tr>
                            </table>
<?php
}?>

















                     

 <?php
            if ($url == "NULL"  or $url ==""){
            ?>


             <p>

<BR>
<form action="" method="post" enctype="multipart/form-data">

Choose image upload to <?php print($firstname); ?> <?php print($lastname); ?>'s account:<br>
<input class="txtbox" type="file" name="file" size="60"><br>
<input type="hidden" name="ssnforfile" value="<?php print($_SESSION['dealer_id']); ?>">
<input type="hidden" name="action" value="addpic"><br>
<input type="submit" name="submit" value="Submit"> <br>
&nbsp;</form>

<?php
           
}else{
?>
<p></p>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="1050">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Picture of <?php print($firstname); ?> <?php print($lastname); ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table border="0" cellpadding="5" style="border-collapse: collapse" bordercolor="#111111" width="1050" id="AutoNumber3" cellpadding="0">

                            <tr class="white">
                              <td width="100%" valign="top" align="center">

  <img border="0" src="../brokers/pics/<?php print($url); ?>"><BR>
  <form action="" method="post" enctype="multipart/form-data">


Remove this image from record
<br>

<input type="hidden" name="action" value="removepic">
<input type="submit" name="submit" value="Remove"> <br>
&nbsp;</form>
</td>
                            </tr>
                            </table>
							<?php
 }
?>

                                      <hr>

                            </p>

                       
  
                       

                        
                       <div align="center">
                          <center>
                         <b><font color="#FF0000" face="Verdana" size="2"><?php print($message); ?>
                          </font></b>
                          <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber3" height="1">
                            <tr>
                              <td width="10%" valign="top" rowspan="3" height="1"><b>Payee:</b></td>
                              <td width="40%" rowspan="3" height="1">
                            <?php print($firstname); ?>&nbsp;<?php print($lastname); ?><BR>
                                  					<?php print($address); ?><BR>
                                  					<?php print($city); ?>, <?php print($prov); ?>&nbsp;<?php print($zipcode); ?>                              </td>
                              <td width="2%" rowspan="3" height="1"></td>
                              <td width="19%" rowspan="3" height="1"><b>
                              <a href="brokertotalearned.php?brokercheck=yes">Total Comms</a><br>
                              <a href="totalpaid.php?brokercheck=yes">Total Paid</a><br>
                              Total Owed</b></td>
                              <td width="11%" rowspan="3" height="1">$<?php print($COM_total_comish); ?> <BR>
                                                    $<?php print($COM_total_pd); ?> <BR>  

                                                    $<?php print($COM_total_comish - $COM_total_pd); ?>  
                              </td>
                              <td width="18%" height="16"></td>
                            </tr>
                            <tr>
                              <td width="18%" height="15"></td>
                            </tr>
                            <tr>
                              <td width="18%" height="1"></td>
                            </tr>
                            </table>
                            
                            <BR>
                            
                           
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="50%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Make Payment</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

                             <table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber3" cellpadding="0" background="bluestripshort.gif">
 										<form  action="addcommission.php"    method="post" >
                                        <input type="hidden" name="brokercommission" value="Yes">                           
                                        <input type="hidden" name="broker_id" value="<?php print($_SESSION['dealer_id']); ?>">                           
										<input type="hidden" name="adminuser" value="<?php print($_SESSION['usname']); ?>">                           
                            <tr>
                              <td width="100%" valign="top" colspan="2">
                              <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5" cellpadding="3">
                                <tr>
                                  <td width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style: none; border-right-width: medium">
                                  <font color="#FFFFFF"><b>Pay Date</b></font>
                                  <font size="1" color="#FF9900" face="Verdana">(I.E. 
                                  03-01-2006)</font></td>
                                  <td width="50%" style="border-left-style: none; border-left-width: medium; border-right-style: solid; border-right-width: 1"> 
                                        <input class="txtbox"  name="check_date" value="" size="20"></td>
                                </tr>
                                <tr>
                                  <td width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style: none; border-right-width: medium">
                                  <font color="#FFFFFF"><b>Pay Amount</b></font></td>
                                  <td width="50%" style="border-left-style: none; border-left-width: medium; border-right-style: solid; border-right-width: 1"> 
                                        <input class="txtbox"  name="amount_paid" value="" size="13">
                                  <font size="1" color="#FF9900" face="Verdana">
                                        (I.E. 1000.00 - no commas)</font></td>
                                </tr>
                                <tr>
                                  <td width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style: none; border-right-width: medium">
                                  <font color="#FFFFFF"><b>Check #</b></font></td>
                                  <td width="50%" style="border-left-style: none; border-left-width: medium; border-right-style: solid; border-right-width: 1"> 
                                        <input class="txtbox"  name="ck_number" value="" size="20"></td>
                                </tr>
                                <tr>
                                  <td width="100%" colspan="2" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1">
                                  <p align="center"><b>NOTES<br>
                                  </b> 
                                        <textarea class="txtbox"  name="notes" size="60" rows="6" cols="70"></textarea></td>
                                </tr>
                                <tr>
                                  <td width="100%" colspan="2" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                                  <p align="center"><input type="submit" value="Submit"></td>
                                </tr>
                              </table>
                              </td>
                            </tr>
                            </table>
  </center>
</div>
 
                     
                  
                        <p align="left">
                        <a href="menu.php">Main Menu</a>
                        </p>
                        <p align="left">
                        <a href="brokersearch.php?cname=&zip=&email=&f=1&Find=Find">Search Another 
                        Broker</a>
                        </p>
                        <p align="left">&nbsp;
                        
                        </p>
                      

                    
<?php
}
/////////////////////////////////////////// EMAIL MODE
///////////////////////////////////////// SEND PREFORMATTED EMAIL MODE
if ($mode=="email") {

$query = "SELECT id, subject, message, name FROM systememails WHERE id='$emailid'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
           
        $emailid = $row[0]; 
        $subject = $row[1]; 
        $message = $row[2]; 
        $emailname = $row[3]; 

    }
    $query = "SELECT fname, email, extension, lname FROM users WHERE id='" . $_SESSION['usid'] . "'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
           
        $salesfname = $row[0]; 
        $salesemail = $row[1]; 
        $salesextension = $row[2]; 
        $saleslname = $row[3]; 

    }

$firstname = ucwords(strtolower($firstname)); 
$lastname = ucwords(strtolower($lastname)); 
$email=$email;
$address=$address;
$city=$city;
$prov=$prov;
$zipcode=$zipcode;
$telephone=$telephone;


    include_once("companystrip.php");
    include_once("brokerstrip.php");

$message2 = str_replace("{SALESFNAME}", "$salesfname", $message2);
$subject2 = str_replace("{SALESFNAME}", "$salesfname", $subject2);

$message2 = str_replace("{SALESLNAME}", "$saleslname", $message2);
$subject2 = str_replace("{SALESLNAME}", "$saleslname", $subject2);

$message2 = str_replace("{SALESEMAIL}", "$salesemail", $message2);
$subject2 = str_replace("{SALESEMAIL}", "$salesemail", $subject2);

$message2 = str_replace("{SALESEXTENSION}", "$salesextension", $message2);
$subject2 = str_replace("{SALESEXTENSION}", "$salesextension", $subject2);

if($_POST['sendsalesmail'] == 'yes'){
$emailthatwassent = $_POST['email'];
$salesfname = $_POST['salesfname'];
$salesemail = $_POST['salesemail'];
$EMAIL_Message = "$message2";
$EMAIL_Subject = "$subject2";
$EMAIL_Reply = "$salesemail";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $salesfname ($companyname) <$salesemail>\r\n";
                  $formsent = mail($emailthatwassent, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $salesemail");  

    $note = "Sent $emailname email to $emailthatwassent";


$sql_note = "INSERT INTO salesnotes

(clientid,received,action,counselor,repairdate,filelocation)
               VALUES
('" . mysql_real_escape_string($_SESSION['dealer_id']) . "',
\"broker\",
\"$note\",
\"$salesfname\",
\"$today\",
\"$tstamp\")";
$result_note = @mysql_query($sql_note,$conn);



echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=brokerstatus.php?action=update\">"; 


}

?>      

          
     <BR><BR>
<TABLE align="center" width="60%" border="0" cellpadding="0" cellspacing="0">
<TR>
<td valign="top">
<form method="POST" action="" name="EMAIL" >
<input type="hidden" name="id" value="<? echo "$line[id]"; ?>">
<input type="hidden" name="salesfname" value="<? echo $salesfname; ?>">
<input type="hidden" name="salesemail" value="<? echo $salesemail; ?>">

<input type="hidden" name="sendsalesmail" value="yes">

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">
Send <input class="txtbox" name="fname" size="15" value="<? echo $firstname; ?>"> <? echo "$emailname"; ?>  email to <input class="txtbox" name="email" size="35" value="<? echo $email; ?>">
</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
<table width="100%" border="0" cellpadding="3" cellspacing="3" style="border-width:0; border-collapse: collapse" bordercolor="#111111">



<TR class="white" ><TD class="white" align="center"><h1>From <i><font color="#800000"><? echo $salesfname; ?> (<? echo $companyname; ?>) <? echo $salesemail; ?></font></i></h1></TD></tr>





<tr width="60%" bgcolor="#FFFFF"><td width="80%">
<p><b>Subject:</b> <? echo "$subject2"; ?>
<p><? echo "$message2"; ?></p>


</td></tr>




<tr ><td align="center" width="100%">&nbsp;
</td></tr>



<tr ><td align="center" width="100%">
<center>
<?php
if ($salesemail ==""){
echo "This feature not available because your profile does not contain a valid email address";
}else{
?>
<input type="submit" name="submit" value="SEND EMAIL"><input type="hidden" name="action" value="update">
<?php
}
?>

</td></tr>
<tr ><td height="15"></td></tr></table></form></TD></table>







<?php

}
}
else
{
    header("Location: login.php");
    exit();
}

?>