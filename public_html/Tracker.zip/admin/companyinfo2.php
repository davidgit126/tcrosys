<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
  include("connection.php");


if($addpage=="yes"){
$query = "INSERT INTO webcms(pagename, type)
VALUES('" . mysql_real_escape_string($_POST['pagename']) . "', 'website')";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$pageid = mysql_insert_id($conn);

$query = "INSERT INTO actionlog(username, action, clientid, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Add New WebCMS Page',
                    '$pageid',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());


echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=companyinfo.php?page=webcms&pageid=$pageid\">"; 
      exit();
}
if($stylesheetmod=="yes"){
$sql = "UPDATE webcms SET
pagecontent = \"$stylesheet\" WHERE type = \"webcss\"";
$result = mysql_query($sql,$conn);

$query = "INSERT INTO actionlog(username, action, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Modify CSS',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

}

if($updateweb=="yes" && $newpagename ==""){
$pagecontent =preg_replace("/(<style>)(.*)(<\/style>)/eis", '', $message); 
$sql = "UPDATE webcms SET
pagetitle = \"$pagetitle\",
pagecontent = \"$pagecontent\",
pagename = \"$pagename\",
onheader = \"$onheader\",
onfooter = \"$onfooter\",
pageorder = \"$pageorder\",
pagemetas= \"$pagemetas\",
active = \"$active\"
WHERE id = \"$pageid\"";
$result = mysql_query($sql,$conn);

$query = "INSERT INTO actionlog(username, action, clientid, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update $pagename WebCMS Page',
                    '$pageid',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

header("Location: companyinfo.php?page=webcms&pageid=$pageid&success=$pagename page updated!");  
}if($updateweb=="yes" && $newpagename !=""){
$query = "INSERT INTO webcms(pagetitle, pagecontent, pagename, onheader, onfooter, pageorder, pagemetas, active, type)
VALUES('" . mysql_real_escape_string($_POST['pagetitle']) . "',
'" . mysql_real_escape_string($_POST['message']) . "',
'" . mysql_real_escape_string($_POST['newpagename']) . "',
'" . mysql_real_escape_string($_POST['onheader']) . "',
'" . mysql_real_escape_string($_POST['onfooter']) . "',
'" . mysql_real_escape_string($_POST['pageorder']) . "',
'" . mysql_real_escape_string($_POST['pagemetas']) . "',
'" . mysql_real_escape_string($_POST['active']) . "',
'" . mysql_real_escape_string($_POST['pagetype']) . "'
)";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$pageid = mysql_insert_id($conn);

$query = "INSERT INTO actionlog(username, action, clientid, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Save $pagename as $newpagename WebCMS',
                    '$pageid',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=companyinfo.php?page=webcms&pageid=$pageid\">"; 
      exit();
}






      if($_POST['updatecompany'] == 1)
      {
        
        $query = "UPDATE companyinfo SET
                companyaddress='" . mysql_real_escape_string($_POST['companyaddress']) . "',
                companycity='" . mysql_real_escape_string($_POST['companycity']) . "',
                companystate='" . mysql_real_escape_string($_POST['companystate']) . "',
                companyzip='" . mysql_real_escape_string($_POST['companyzip']) . "',
                companyemail='" . mysql_real_escape_string($_POST['companyemail']) . "',
                companyfax='" . mysql_real_escape_string($_POST['companyfax']) . "',
                companyphone='" . mysql_real_escape_string($_POST['companyphone']) . "',
                companyreply='" . mysql_real_escape_string($_POST['companyreply']) . "',
                companywebsite='" . mysql_real_escape_string($_POST['companywebsite']) . "',
                timezone='" . mysql_real_escape_string($_POST['timezone']) . "'

                                WHERE companyid='1'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Company Info',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

 if($_POST['updatecustomize'] == 1)
      {
        
        $query = "UPDATE companycss SET
                backgroundimage='" . mysql_real_escape_string($_POST['backgroundimage']) . "',                
                maintextsize='" . mysql_real_escape_string($_POST['maintextsize']) . "',     
                maintextfont='" . mysql_real_escape_string($_POST['maintextfont']) . "',     
                backgroundcolor='" . mysql_real_escape_string($_POST['backgroundcolor']) . "',   
                showbargraph='" . mysql_real_escape_string($_POST['showbargraph']) . "',                                                                 
                cbackgroundimage='" . mysql_real_escape_string($_POST['cbackgroundimage']) . "',                                                                 
                cmaintextsize='" . mysql_real_escape_string($_POST['cmaintextsize']) . "',                                                                 
                cmaintextfont='" . mysql_real_escape_string($_POST['cmaintextfont']) . "',                                                                 
                cbackgroundcolor='" . mysql_real_escape_string($_POST['cbackgroundcolor']) . "',                                                                
                bbackgroundimage='" . mysql_real_escape_string($_POST['bbackgroundimage']) . "',                                                                 
                bmaintextsize='" . mysql_real_escape_string($_POST['bmaintextsize']) . "',                                                                 
                bmaintextfont='" . mysql_real_escape_string($_POST['bmaintextfont']) . "',                                                                 
                bbackgroundcolor='" . mysql_real_escape_string($_POST['bbackgroundcolor']) . "'                                                                 
                WHERE id='1'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        
                $query = "UPDATE companyinfo SET
                autoscheduler='" . mysql_real_escape_string($_POST['autoscheduler']) . "',                
                dropdowncreditors='" . mysql_real_escape_string($_POST['dropdowncreditors']) . "',     
                dropdownbegin='" . mysql_real_escape_string($_POST['dropdownbegin']) . "',     
                dropdowntails='" . mysql_real_escape_string($_POST['dropdowntails']) . "',   
                passisssn='" . mysql_real_escape_string($_POST['passisssn']) . "',                                                                 
                companyheader='" . mysql_real_escape_string($_POST['companyheader']) . "'

                                WHERE companyid='1'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());


$query = "INSERT INTO actionlog(username, action, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Customization',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}



 if($_POST['updatewebsite'] == 1)
      {
        
        $query = "UPDATE companyinfo SET
                paypal='" . mysql_real_escape_string($_POST['paypal']) . "',                
                paypal2='" . mysql_real_escape_string($_POST['paypal2']) . "',                
                ach='" . mysql_real_escape_string($_POST['ach']) . "',                
                creditcard='" . mysql_real_escape_string($_POST['creditcard']) . "',                
                singlefull='" . mysql_real_escape_string($_POST['singlefull']) . "',                
                singledownpay1='" . mysql_real_escape_string($_POST['singledownpay1']) . "',                
                singlepayment='" . mysql_real_escape_string($_POST['singlepayment']) . "',                
                coupledownpay1='" . mysql_real_escape_string($_POST['coupledownpay1']) . "',                
                couplefull='" . mysql_real_escape_string($_POST['couplefull']) . "',                
                couplepayment='" . mysql_real_escape_string($_POST['couplepayment']) . "',                
                threeinone='" . mysql_real_escape_string($_POST['threeinone']) . "',                
                months='" . mysql_real_escape_string($_POST['months']) . "',                
                perdelete='" . mysql_real_escape_string($_POST['perdelete']) . "',                
                livehuman='" . mysql_real_escape_string($_POST['livehuman']) . "'               
                WHERE companyid='1'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Website Settings',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}


 if($_POST['updateskin'] == 1)
      {
        
        $query = "UPDATE companyinfo SET
                companyskin='" . mysql_real_escape_string($_POST['companyskin']) . "'                
                   
                WHERE companyid='1'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Company Skin',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}




 
     $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, autoscheduler, reseller, htdiwebsite, adminsinglepayment1, adminsinglepayment2, admincouplepayment1, admincouplepayment2, single, couple, creditcard, paypal2, ach, singlefull, singledownpay1, singlepayment, couplefull, coupledownpay1, couplepayment, threeinone, paypal, months, perdelete, livehuman, dbname, dropdowncreditors, dropdownbegin, dropdowntails, passisssn, autoresponder, bautoresponder, cautoresponder, demanddraft, helpdesk, companyskin, timezone, companyheader FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $autoscheduler = $row[12];          
        $reseller = $row[13];           
        $htdiwebsite = $row[14];           
        $adminsinglepayment1 = $row[15];
        $adminsinglepayment2 = $row[16];
        $admincouplepayment1 = $row[17];
        $admincouplepayment2 = $row[18];                                
        $single = $row[19];                                
        $couple = $row[20];                                
        $creditcard = $row[21];                 
        $paypal2 = $row[22];                 
        $ach = $row[23];                 
        $singlefull = $row[24];          
        $singledownpay1 = $row[25];          
        $singlepayment = $row[26];          
        $couplefull = $row[27];          
        $coupledownpay1 = $row[28];          
        $couplepayment = $row[29];          
        $threeinone = $row[30];          
        $paypal = $row[31];          
        $months = $row[32];          
        $perdelete = $row[33];          
        $livehuman = $row[34];          
        $dbname = $row[35];          
        $dropdowncreditors = $row[36];    
        $dropdownbegin = $row[37];    
        $dropdowntails = $row[38];                            
        $passisssn = $row[39];                            
        $autoresponder = $row[40];                            
        $bautoresponder = $row[41];                            
        $cautoresponder = $row[42];                            
        $demanddraft = $row[43];                            
        $helpdesk = $row[44];                            
        $companyskin = $row[45];                            
        $timezone = $row[46];                            
        $companyheader = $row[47];                            
    }
    
       $query = "SELECT backgroundimage, maintextsize, maintextfont, backgroundcolor,showbargraph, cbackgroundimage,cmaintextsize,cmaintextfont, cbackgroundcolor, bbackgroundimage,bmaintextsize,bmaintextfont, bbackgroundcolor FROM companycss WHERE id='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $backgroundimage= $row[0];
        $maintextsize= $row[1];
        $maintextfont = $row[2];
        $backgroundcolor= $row[3];
        $showbargraph = $row[4];
        $cbackgroundimage= $row[5];
        $cmaintextsize= $row[6];
        $cmaintextfont= $row[7];
        $cbackgroundcolor = $row[8];
        $bbackgroundimage= $row[9];
        $bmaintextsize= $row[10];
        $bmaintextfont= $row[11];
        $bbackgroundcolor = $row[12];
    }
    
    $bgcolor = "c0c0c0";
$bgcolor = "FFFFFF";

      if($reseller == "Yes"){      
$resellerlabel = "CSO";
}else{
$resellerlabel = "Tracker";
}


$query = "SELECT message FROM systememails WHERE name='Client_Welcome'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $welcomeemail = $row[0];
    }

    //mysql_close($conn);

if ($preview=="yes"){
echo $companyskin;
$message=$welcomeemail;
include('companystrip.php');

echo $message2;
}else{

?>
         <title>System Settings</title>
                 <font color="red">  <B> <?php print($error); ?></B></font>
                        <?php
    include('main.php');
    include('template.php');

   ?>     
  
 <script type="text/javascript">
function doTooltip(e, msg) {
  if ( typeof Tooltip == "undefined" || !Tooltip.ready ) return;
  Tooltip.show(e, msg);
}

function hideTip() {
  if ( typeof Tooltip == "undefined" || !Tooltip.ready ) return;
  Tooltip.hide();
}

var dw_event = {
  
  add: function(obj, etype, fp, cap) {
    cap = cap || false;
    if (obj.addEventListener) obj.addEventListener(etype, fp, cap);
    else if (obj.attachEvent) obj.attachEvent("on" + etype, fp);
  }, 

  remove: function(obj, etype, fp, cap) {
    cap = cap || false;
    if (obj.removeEventListener) obj.removeEventListener(etype, fp, cap);
    else if (obj.detachEvent) obj.detachEvent("on" + etype, fp);
  }, 

  DOMit: function(e) { 
    e = e? e: window.event;
    e.tgt = e.srcElement? e.srcElement: e.target;
    
    if (!e.preventDefault) e.preventDefault = function () { return false; }
    if (!e.stopPropagation) e.stopPropagation = function () { if (window.event) window.event.cancelBubble = true; }
        
    return e;
  }
  
}

 
var viewport = {
  getWinWidth: function () {
    this.width = 0;
    if (window.innerWidth) this.width = window.innerWidth - 18;
    else if (document.documentElement && document.documentElement.clientWidth) 
  		this.width = document.documentElement.clientWidth;
    else if (document.body && document.body.clientWidth) 
  		this.width = document.body.clientWidth;
  },
  
  getWinHeight: function () {
    this.height = 0;
    if (window.innerHeight) this.height = window.innerHeight - 18;
  	else if (document.documentElement && document.documentElement.clientHeight) 
  		this.height = document.documentElement.clientHeight;
  	else if (document.body && document.body.clientHeight) 
  		this.height = document.body.clientHeight;
  },
  
  getScrollX: function () {
    this.scrollX = 0;
  	if (typeof window.pageXOffset == "number") this.scrollX = window.pageXOffset;
  	else if (document.documentElement && document.documentElement.scrollLeft)
  		this.scrollX = document.documentElement.scrollLeft;
  	else if (document.body && document.body.scrollLeft) 
  		this.scrollX = document.body.scrollLeft; 
  	else if (window.scrollX) this.scrollX = window.scrollX;
  },
  
  getScrollY: function () {
    this.scrollY = 0;    
    if (typeof window.pageYOffset == "number") this.scrollY = window.pageYOffset;
    else if (document.documentElement && document.documentElement.scrollTop)
  		this.scrollY = document.documentElement.scrollTop;
  	else if (document.body && document.body.scrollTop) 
  		this.scrollY = document.body.scrollTop; 
  	else if (window.scrollY) this.scrollY = window.scrollY;
  },
  
  getAll: function () {
    this.getWinWidth(); this.getWinHeight();
    this.getScrollX();  this.getScrollY();
  }
  
}


var Tooltip = {
    followMouse: true,
    overlaySelects: true,  // iframe shim for select lists (ie win)
    offX: 8,
    offY: 12,
    tipID: "tipDiv",
    showDelay: 100,
    hideDelay: 200,
    
    ovTimer: 0, // for overlaySelects
    ready:false, timer:null, tip:null, shim:null, supportsOverlay:false,
  
    init: function() {
        if ( document.createElement && document.body && typeof document.body.appendChild != "undefined" ) {
            var el = document.createElement("DIV");
            el.id = this.tipID;
            document.body.appendChild(el);
            this.supportsOverlay = this.checkOverlaySupport();
            this.ready = true;
        }
    },
    
    show: function(e, msg) {
        if (this.timer) { clearTimeout(this.timer);	this.timer = 0; }
        this.tip = document.getElementById( this.tipID );
        if (this.followMouse) // set up mousemove 
            dw_event.add( document, "mousemove", this.trackMouse, true );
        this.writeTip("");  // for mac ie
        this.writeTip(msg);
        viewport.getAll();
        this.handleOverlay(1, this.showDelay);
        this.positionTip(e);
        this.timer = setTimeout("Tooltip.toggleVis('" + this.tipID + "', 'visible')", this.showDelay);
    },
    
    writeTip: function(msg) {
        if ( this.tip && typeof this.tip.innerHTML != "undefined" ) this.tip.innerHTML = msg;
    },
    
    positionTip: function(e) {
        if ( this.tip && this.tip.style ) {    
            // put e.pageX/Y first! (for Safari)
            var x = e.pageX? e.pageX: e.clientX + viewport.scrollX;
            var y = e.pageY? e.pageY: e.clientY + viewport.scrollY;
    
            if ( x + this.tip.offsetWidth + this.offX > viewport.width + viewport.scrollX ) {
                x = x - this.tip.offsetWidth - this.offX;
                if ( x < 0 ) x = 0;
            } else x = x + this.offX;
        
            if ( y + this.tip.offsetHeight + this.offY > viewport.height + viewport.scrollY ) {
                y = y - this.tip.offsetHeight - this.offY;
                if ( y < viewport.scrollY ) y = viewport.height + viewport.scrollY - this.tip.offsetHeight;
            } else y = y + this.offY;
            
            this.tip.style.left = x + "px"; this.tip.style.top = y + "px";
        }
            
        this.positionOverlay();
    },
    
    hide: function() {
        if (this.timer) { clearTimeout(this.timer);	this.timer = 0; }
        this.handleOverlay(0, this.hideDelay);
        this.timer = setTimeout("Tooltip.toggleVis('" + this.tipID + "', 'hidden')", this.hideDelay);
        if (this.followMouse) // release mousemove
            dw_event.remove( document, "mousemove", this.trackMouse, true );
        this.tip = null; 
    },
    
    toggleVis: function(id, vis) { // to check for el, prevent (rare) errors
        var el = document.getElementById(id);
        if (el) el.style.visibility = vis;
    },

    trackMouse: function(e) {
    	e = dw_event.DOMit(e);
     	Tooltip.positionTip(e);
    },
    
    // check need for and support of iframe shim
    checkOverlaySupport: function() {
        if ( navigator.userAgent.indexOf("Windows") != -1 && 
            typeof document.body != "undefined" && 
            typeof document.body.insertAdjacentHTML != "undefined" && 
            !window.opera && navigator.appVersion.indexOf("MSIE 5.0") == -1 
            ) return true;
        else return false;
    }, 
    
    handleOverlay: function(bVis, d) {
        if ( this.overlaySelects && this.supportsOverlay ) {
            if (this.ovTimer) { clearTimeout(this.ovTimer); this.ovTimer = 0; }
            switch (bVis) {
                case 1 :
                    if ( !document.getElementById('tipShim') ) 
                        document.body.insertAdjacentHTML("beforeEnd", '<iframe id="tipShim" src="menu.php" style="position:absolute; left:0; top:0; z-index:500; visibility:hidden" scrolling="no" frameborder="0"></iframe>');
                    this.shim = document.getElementById('tipShim'); 
                    if (this.shim && this.tip) {
                        this.shim.style.width = this.tip.offsetWidth + "px";
                        this.shim.style.height = this.tip.offsetHeight + "px";
                    }
                    this.ovTimer = setTimeout("Tooltip.toggleVis('tipShim', 'visible')", d);
                break;
                case 0 :
                    this.ovTimer = setTimeout("Tooltip.toggleVis('tipShim', 'hidden')", d);
                    if (this.shim) this.shim = null;
                break;
             }
        }
    },    
    
    positionOverlay: function() {
        if ( this.overlaySelects && this.supportsOverlay && this.shim ) {
            this.shim.style.left = this.tip.style.left;
            this.shim.style.top = this.tip.style.top;
        }
    }
}


	

</script>
<body onLoad="Tooltip.init()">

<style>
/* This is where you can customize the appearance of the tooltip */
div#tipDiv {
  position:absolute; visibility:hidden; left:0; top:0; z-index:10000;
  background-color:#dee7f7; border:1px solid #336; 
  width:250px; padding:4px;
  color:#000; font-size:11px; line-height:1.2;
}
/* These are optional. They demonstrate how you can individually format tooltip content  */
div.tp1 { font-size:12px; color:#336; font-style:italic }
div.tp2 { font-weight:bolder; color:#337; padding-top:4px }
h3.elegant { letter-spacing: -2px; font-family:Georgia, "Times New Roman", Times, serif; font-weight: 100; font-size: 200%; text-shadow: #666666 0.2em 0.2em; }
h3.elegantLG { letter-spacing: -2px; font-family:Georgia, "Times New Roman", Times, serif; font-weight: 100; font-size: 300%; text-shadow: #666666 0.2em 0.2em; }

</style>

 <?php
 
if($page!="webcms" && $_SESSION['usname']=="admin"){

        ?>

<center>
&nbsp;<table border="0" cellspacing="0" width="100%" id="AutoNumber2" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
  <tr>
    <td>
<p align="center">
<a href="companyinfo.php"><font color="#008000">Company Settings</font></a> ::
<a href="companyinfo.php?page=3"><font color="#008000">Account Specs</font></a> ::
<a href="companyinfo.php?page=4"><font color="#008000">Customize</font></a> ::
<a href="companyinfo.php?page=5"><font color="#008000">Company Skin</font></a>
</td>
  </tr>
 
 </table>
 <?php
 
}

        ?>




<div>
  <center>


 <?php
if($page=="" && $_SESSION['usname']=="admin"){
        ?>
     <form  action=""    method="post" >
     
     <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="800">
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Company Information</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table bgcolor="#<?php print($bgcolor);?>" border="0" cellspacing="3" cellpadding="5" width="800" id="AutoNumber1" style="border-collapse: collapse" bordercolor="#111111">
<tr>
<td class='ss-round-inputs' width="50%">Company Name<br>
<B><?php print($companyname); ?></B>
<input type="hidden"  name="companyname" value="<?php print($companyname); ?>"></td>
<td class='ss-round-inputs' width="50%">Contact<br>
 
<B><?php print($companycontact); ?></B>
<input type="hidden"  name="companycontact" value="<?php print($companycontact); ?>">
</td>
</tr>
    
    
<tr>
<td class='ss-round-inputs' width="50%">&nbsp;</td>
<td class='ss-round-inputs' width="50%">&nbsp;</td>
</tr>
    
<tr>
<td class='ss-round-inputs' width="50%">Address<br>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  size="53" name="companyaddress" value="<?php print($companyaddress); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
<br>City, State Zip<br>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox" size="22" name="companycity" value="<?php print($companycity); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >,&nbsp; 
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox" size="4" name="companystate" value="<?php print($companystate); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >&nbsp;&nbsp;&nbsp; 
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  size="10" name="companyzip" value="<?php print($companyzip); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
<td class='ss-round-inputs' width="50%">E-mail<br>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="companyemail" value="<?php print($companyemail); ?>" size="40"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
<br>Reply E-mail<br>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="companyreply" value="<?php print($companyreply); ?>" size="40"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">Phone<br>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="companyphone" value="<?php print($companyphone); ?>" size="29"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">Fax<br>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="companyfax" value="<?php print($companyfax); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
                                    </td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">Tracker URL <BR>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="companywebsite" value="<?php print($companywebsite); ?>" size="54"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
                                    </td>
      <td width="50%">Time Zone 
                                        <select name="timezone" class="txtbox"  >
                <option value="<?php print($timezone); ?>" selected><?php print($timezone); ?></option>
               
<option value="Hawaii">Hawaii</option>
<option value="Alaska">Alaska</option>
<option value="Pacific">Pacific</option>
<option value="Mountain">Mountain</option>
<option value="Arizona">Arizona</option>
<option value="Central">Central</option>
<option value="Eastern">Eastern</option>
</select>&nbsp;&nbsp;
              
              
              
              </td>
    </tr>
    
    </table> 
<BR>
<table bgcolor="#<?php print($bgcolor);?>" border="0" cellspacing="3" cellpadding="5" width="800" id="AutoNumber1" style="border-collapse: collapse" bordercolor="#111111">
    <tr>
      <td class='ss-round-inputs' width="50%">Do You Accept PayPal? 
    
   

                                        <select  name="paypal2" >
                <option value="<?php echo $paypal2; ?>" selected><?php echo $paypal2; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>
      <td class='ss-round-inputs' width="50%">PayPal Email Address 
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="paypal" value="<?php print($paypal); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ><br>
 </td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">Do You Accept ACH?
    
    

   

                                          <select name="ach" >
                <option value="<?php echo $ach; ?>" selected><?php echo $ach; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>
      <td class='ss-round-inputs' width="50%">Do You Accept Credit Card?
    
   
   

                                          <select name="creditcard" >
                <option value="<?php echo $creditcard; ?>" selected><?php echo $creditcard; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>
    </tr>
    
       <tr><td></td></tr> 

    <tr>
      <td class='ss-round-inputs' width="50%">How much is an <b>Individual</b> Full Pay <font face="Arial,Helvetica,Geneva,Sans-serif,sans-serif" size=1>(if CROA exempt)</font><br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="singlefull" value="<?php print($singlefull); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">How much is an <b>Couple</b> Full Pay <font face="Arial,Helvetica,Geneva,Sans-serif,sans-serif" size=1>(if CROA exempt)</font><br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="couplefull" value="<?php print($couplefull); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
                                    </td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">How much is <b>Individual</b> setup<br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="singledownpay1" value="<?php print($singledownpay1); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">How much is <b>Couple</b> setup<br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="coupledownpay1" value="<?php print($coupledownpay1); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">How much are the <b>Individual</b> monthly payments<br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="singlepayment" value="<?php print($singlepayment); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">How much are <b>Couple</b> monthly payments<br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="couplepayment" value="<?php print($couplepayment); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">How much do you want to 
                                    charge per delete:<br>
    
   
    
   

   

                                      <font face="Arial,Helvetica,Geneva,Sans-serif,sans-serif" size="1">
                                      (Shown on warranty page)</font><br>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="perdelete" value="<?php print($perdelete); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">How long will your monthly 
                                    payments last:<hl><font face="Arial,Helvetica,Geneva,Sans-serif,sans-serif" size="1"><br>
                                      (&quot;0&quot; means ongoing)</font><br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="months" value="<?php print($months); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
                                    </td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="100%" colspan="2"> 

                                       
                                        Website for 3in1 reports
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="threeinone" value="<?php print($threeinone); ?>" size="38"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" > </td>
    </tr>
    
    
    
    
    
    
    </table>

    <p align="center">
    <input type="hidden" name="updatecompany" value="1">
    <input type="hidden" name="updatewebsite" value="1">
                            <input type="submit" name="Update" value="Update">
    </p>
    </form>
    
    </td>
    
  </tr>
</table>





 <?php
 }
if($page==2 && $_SESSION['usname']=="admin"){

if($htdiwebsite =="Yes"){
        ?>



       <form  action=""    method="post" >
         <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="800">
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Integrated Website</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

  <table bgcolor="#<?php print($bgcolor);?>" border="0" cellspacing="3" cellpadding="5" width="800" id="AutoNumber1" style="border-collapse: collapse" bordercolor="#111111">
    <tr>
      <td class='ss-round-inputs' width="50%">Accept PayPal? 
    
   

                                        <select  name="paypal2" >
                <option value="<?php echo $paypal2; ?>" selected><?php echo $paypal2; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>
      <td class='ss-round-inputs' width="50%">PayPal email address 
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="paypal" value="<?php print($paypal); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ><br>
 </td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">Accept ACH?
    
    

   

                                          <select name="ach" >
                <option value="<?php echo $ach; ?>" selected><?php echo $ach; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>
      <td class='ss-round-inputs' width="50%">Accept Credit Card?
    
   
   

                                          <select name="creditcard" >
                <option value="<?php echo $creditcard; ?>" selected><?php echo $creditcard; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">How much is an <b>Individual</b> Full Pay<br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="singlefull" value="<?php print($singlefull); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">How much is an <b>Couple</b> Full Pay<br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="couplefull" value="<?php print($couplefull); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
                                    </td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">How much is <b>Individual</b> setup<br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="singledownpay1" value="<?php print($singledownpay1); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">How much is <b>Couple</b> setup<br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="coupledownpay1" value="<?php print($coupledownpay1); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">How much are the <b>Individual</b> monthly payments<br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="singlepayment" value="<?php print($singlepayment); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">How much are <b>Couple</b> monthly payments<br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="couplepayment" value="<?php print($couplepayment); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">How much do you want to 
                                    charge per delete:<br>
    
   
    
   

   

                                      <font face="Arial,Helvetica,Geneva,Sans-serif,sans-serif" size="1">
                                      (Shown on warranty page)</font><br>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="perdelete" value="<?php print($perdelete); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">How long will your monthly 
                                    payments last:<hl><font face="Arial,Helvetica,Geneva,Sans-serif,sans-serif" size="1"><br>
                                      (&quot;0&quot; means ongoing)</font><br>
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="months" value="<?php print($months); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
                                    </td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="100%" colspan="2"> 

                                       
                                        Website for 3in1 reports
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="threeinone" value="<?php print($threeinone); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" > </td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="100%" colspan="2">LiveHuman Link:<font face="Arial,Helvetica,Geneva,Sans-serif,sans-serif" size="1"><a target="_blank" href="http://www.livehuman.com"><font color="#008000">What is this?</font></a></font><FONT SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif"><br>
    
    

   

                                          <textarea rows="5" name="livehuman" cols="79"><?php echo $livehuman; ?></textarea></FONT> </td>
    </tr>
    
    
    
    </table>
   <input type="hidden" name="updatewebsite" value="1">
                            <p align="center">
                            <input type="submit" name="Update" value="Update">
  </p>
    </form>  
 

     <BR>
   
     <?php
     
     
  }else{
  echo "You do not have an integrated website";
  }
  
  
  }
      if($page==3 && $_SESSION['usname']=="admin")
                                 {

        ?>
 <form  action=""    method="post" >

  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="400">
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Account Specifications</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

				<table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="400" id="AutoNumber4">
                  <tr>
                    <td width="33%">	<b>Account Type</b><BR><?php print($resellerlabel); ?>
<BR><BR>
<b>Web CMS</b><BR><?php print($htdiwebsite); ?>
<BR><BR>
<b>Demand Draft</b><BR><?php print($demanddraft); ?>
<BR><BR>
<b>Helpdesk</b><BR><?php print($helpdesk); ?>
<BR><BR>
<b>Prospect Autoresponder</b><br>
<?php print($autoresponder); ?>
<BR><BR>
<b>Broker Autoresponder</b><br>
<?php print($bautoresponder); ?>
<BR><BR>
<b>Client Autoresponder</b><br>
<?php print($cautoresponder); ?></td>
                  </tr>
          </table>

			</form>

     <?php
   }
   
   if($page==4 && $_SESSION['usname']=="admin"){

        ?>

   <form  action=""    method="post" >
         <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="800">
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Customize 
System</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

  <table bgcolor="#<?php print($bgcolor);?>" border="0" cellspacing="3" cellpadding="5" width="800" id="AutoNumber1" style="border-collapse: collapse" bordercolor="#111111">
    <tr>
      <td class='ss-round-inputs' width="100%" colspan="2" align="center">
      <p align="left"><u><b>ADMIN SECTION</b></u></td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">Show Bar Graph on Client Status 
      Sheet? 
    
   

                                        <select  name="showbargraph" >
                <option value="<?php echo $showbargraph; ?>" selected><?php echo $showbargraph; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>
      <td class='ss-round-inputs' width="50%">Main Text Size
    
   
   

                                          <select name="maintextsize" >
                <option value="<?php echo $maintextsize; ?>" selected><?php echo $maintextsize; ?></option>
                <option value="8px">8px</option>
                <option value="9px">9px</option>
                <option value="10px">10px</option>
                <option value="11px">11px</option>
                <option value="12px">12px</option>
                <option value="13px">13px</option>
                <option value="14px">14px</option>
                <option value="15px">15px</option>
                <option value="16px">16px</option>
                <option value="17px">17px</option>
                <option value="18px">18px</option>
                
              </select><br>
 </td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">&nbsp;</td>
      <td class='ss-round-inputs' width="50%">&nbsp;</td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">Main Text Font
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="maintextfont" value="<?php print($maintextfont); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">Background Color
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="backgroundcolor" value="<?php print($backgroundcolor); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
<img border="0" src="http://www.tcrosystems.net/questionmark.png"
    onmouseover="doTooltip(event,'<B>Background Color</B><BR>Format should be in hexadecimal format, I.E. <I>#FFFFFF</>.  If this has a value in it, it overrides the <b>Background Image</b> value below.')" 
    onmouseout="hideTip()" width="19" height="19">
    </td>
    </tr>
    
    
    
    <tr>
      <td width="100%" colspan="2">&nbsp; </td>
    </tr>
    <tr>
      <td class='ss-round-inputs' width="100%" colspan="2">

                                        <p align="left">Background Image
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="backgroundimage" value="<?php print($backgroundimage); ?>" size="60"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
    </tr>
    
    
    
    <tr>
      <td width="100%" colspan="2">&nbsp; </td>
    </tr>
    
    <?php
         if($reseller !="Yes")
                                 {
        ?>
    <tr>
      <td width="100%" colspan="2"> 
                           

                                        <p align="center">

                                        <b>Result Tracker Drop Down Lists</b><br>
                                        Creditors 
    
   

                                        <select  class="txtbox"  name="dropdowncreditors" >
                <option value="<?php echo $dropdowncreditors; ?>" selected><?php echo $dropdowncreditors; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select>&nbsp;&nbsp;Beginning Status 
    
   

                                        <select  class="txtbox"  name="dropdownbegin" >
                <option value="<?php echo $dropdownbegin; ?>" selected><?php echo $dropdownbegin; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select>&nbsp;&nbsp;Tail Ends 
    
   

                                        <select  class="txtbox"  name="dropdowntails" >
                <option value="<?php echo $dropdowntails; ?>" selected><?php echo $dropdowntails; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select>
              <BR><BR>
 <?php
                           }
        ?>
AutoScheduler 
                                        <select name="autoscheduler" class="txtbox"  >
                <option value="<?php print($autoscheduler); ?>" selected><?php print($autoscheduler); ?></option>
                <?php
                                if($reseller !="Yes")
                                 {
        ?>
 <option value="OFF">OFF</option>
  <?php
                             }
        ?>

                <option value="ON">ON</option>
              </select>&nbsp;&nbsp;
              
              
              
              Hide Password in Emails? 
    
   

                                        <select  name="passisssn" class="txtbox"  >
                <option value="<?php echo $passisssn; ?>" selected><?php echo $passisssn; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select>
            
</td>
    </tr>
    
    
    
    <tr>
      <td width="100%" colspan="2">&nbsp; </td>
    </tr>
   
    
    
    <tr>
      <td class='ss-round-inputs' width="100%" colspan="2">

                                        <p align="left">Main Header Image
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="companyheader" value="<?php print($companyheader); ?>" size="60"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="100%" colspan="2">

                                        <hr>
                                        <p align="left"><u><b>CLIENT SECTION</b></u></td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="50%">Main Text Font
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="cmaintextfont" value="<?php print($cmaintextfont); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">Main Text Size
    
   
   

                                          <select name="cmaintextsize" >
                <option value="<?php echo $cmaintextsize; ?>" selected><?php echo $cmaintextsize; ?></option>
                <option value="8px">8px</option>
                <option value="9px">9px</option>
                <option value="10px">10px</option>
                <option value="11px">11px</option>
                <option value="12px">12px</option>
                <option value="13px">13px</option>
                <option value="14px">14px</option>
                <option value="15px">15px</option>
                <option value="16px">16px</option>
                <option value="17px">17px</option>
                <option value="18px">18px</option>
                
              </select><br>
 </td>
    </tr>
    <tr>
      <td class='ss-round-inputs' width="50%">&nbsp;</td>
      <td class='ss-round-inputs' width="50%">&nbsp;</td>
    </tr>
    <tr>
      <td class='ss-round-inputs' width="50%">Background Image
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="cbackgroundimage" value="<?php print($cbackgroundimage); ?>" size="30"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">Background Color
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="cbackgroundcolor" value="<?php print($cbackgroundcolor); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
<img border="0" src="http://www.tcrosystems.net/questionmark.png"
    onmouseover="doTooltip(event,'<B>Background Color</B><BR>Format should be in hexadecimal format, I.E. <I>#FFFFFF</>.  If this has a value in it, it overrides the <b>Background Image</b> to the left.')" 
    onmouseout="hideTip()" width="19" height="19">
    </td>
    </tr>
    <tr>
      <td class='ss-round-inputs' width="100%" colspan="2">

                                        <hr>
                                        <p align="left"><u><b>BROKER SECTION</b></u></td>
    </tr>
    <tr>
      <td class='ss-round-inputs' width="50%">Main Text Font
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="bmaintextfont" value="<?php print($bmaintextfont); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">Main Text Size
    
   
   

                                          <select name="bmaintextsize" >
                <option value="<?php echo $bmaintextsize; ?>" selected><?php echo $bmaintextsize; ?></option>
                <option value="8px">8px</option>
                <option value="9px">9px</option>
                <option value="10px">10px</option>
                <option value="11px">11px</option>
                <option value="12px">12px</option>
                <option value="13px">13px</option>
                <option value="14px">14px</option>
                <option value="15px">15px</option>
                <option value="16px">16px</option>
                <option value="17px">17px</option>
                <option value="18px">18px</option>
                
              </select><br>
 </td>
    </tr>
    <tr>
      <td class='ss-round-inputs' width="50%">&nbsp;</td>
      <td class='ss-round-inputs' width="50%">&nbsp;</td>
    </tr>
    <tr>
      <td class='ss-round-inputs' width="50%">Background Image
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="bbackgroundimage" value="<?php print($bbackgroundimage); ?>" size="30"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
      <td class='ss-round-inputs' width="50%">Background Color
    
   

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="bbackgroundcolor" value="<?php print($bbackgroundcolor); ?>" size="28"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
<img border="0" src="http://www.tcrosystems.net/questionmark.png"
    onmouseover="doTooltip(event,'<B>Background Color</B><BR>Format should be in hexadecimal format, I.E. <I>#FFFFFF</>.  If this has a value in it, it overrides the <b>Background Image</b> to the left.')" 
    onmouseout="hideTip()" width="19" height="19">
    </td>
    </tr>
    <tr>
      <td width="100%" colspan="2">&nbsp; </td>
    </tr>
    <tr>
      <td class='ss-round-inputs' width="100%" colspan="2">

                                        <p align="left">&nbsp;</td>
    </tr>
    
    
    
    <tr>
      <td class='ss-round-inputs' width="100%" colspan="2">&nbsp;

                                        </td>
    </tr>
    
    
    
    </table>
   <input type="hidden" name="updatecustomize" value="1">
                            <p align="center">
                            <input type="submit" name="Update" value="Update">
  </p>
    </form>  

     
<?php 
}if($page=="webcms"){
if($pageid==""){

?>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="80%" id="AutoNumber1">
  <tr>
    <td width="50%"><form method="POST" action="">

<p align="center"><b>Add new page</b><BR>
Name (I.E. "services" or "contact")
<input class="txtbox" type=text name=pagename size=24>
<input type="hidden" name="addpage" value="yes">
<input type="submit" value="Add"></p>
</form>
</td>
 </tr>
</table>

<?php 
   $query = "SELECT pagecontent FROM webcms WHERE type='webcss'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $stylesheet           = $row[0];
}

?>

<form method="POST" action="">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="900" >
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Modify Style Sheet (CSS)</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="900" >
<tr><td>
<p align="center">
<textarea style="font-size:8pt;line-height: 1;" rows="40" cols="125" name="stylesheet"><? echo $stylesheet; ?></textarea>
</td></tr>
</table>
<BR>
<input type="hidden" name="stylesheetmod" value="yes">
<input type="submit" value="Update CSS"></p>
</form>

<?php 
}
?>


<?php 
if($pageid!=""){

    $query = "SELECT id, pagename, active, pageorder, onheader, onfooter, pagecontent, pagetitle, pagemetas, type FROM webcms WHERE id='$pageid'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $pagename  = $row[1];
              $active   = $row[2];
              $pageorder   = $row[3];
              $onheader = $row[4];
              $onfooter = $row[5];              
              $pagecontent = $row[6];                
              $pagetitle = $row[7];     
              $pagemetas = $row[8];                
              $pagetype = $row[9];                
           
}
if($pagetype=="website"){
  $query = "SELECT pagecontent FROM webcms WHERE type='webcss'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $stylesheet           = $row[0];
 $stylesheet = "<style>$stylesheet</style>";       
}}
if($pagetype=="PTCSO"){
  $query = "SELECT pagecontent FROM webcms WHERE type='PTCSOcss'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $stylesheet           = $row[0];
 $stylesheet = "<style>$stylesheet</style>";       
}}

?>
<BR>

<form method="POST" action="">
<input type="hidden" name="id" value="<?php print($pageid); ?>">
<input type="hidden" name="updateweb" value="yes">

Save page as: <input class="txtbox" type=text name="newpagename" size=24 value="">
Page Type=<select name="pagetype">
<option value="website">website</option>
<option value="affiliate">affiliate</option>
<option value="broker">broker</option>
<option value="client">client</option>
<option value="PTCSO">PTCSO</option>
</select>

<div align="center">
  <center>
<font color="#FF0000"><b><?php print($success); ?></b></font>


<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" >
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%"><?php print($pagename); ?> page &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Page Type = <?php print($pagetype); ?></td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table width="100%">







<tr>
<td BGCOLOR="#CCCCCC"><b><font face="Verdana" size="2">Page Name</font></b><BR>
<?php 
if($pagename=="thanks"){
?>
<input class="txtbox" type=hidden name=pagename size=24 value="<? echo $pagename; ?>">
<? echo $pagename; ?>
<?php 
}else{
?>
<input class="txtbox" type=text name=pagename size=24 value="<? echo $pagename; ?>">
<?php 
}
?>
</TD>
<td BGCOLOR="#CCCCCC" width="102"><b><font face="Verdana" size="2">Active?</font></b><BR>
<select name="active" class="txtbox"  >
<option value="<?php print($active); ?>" selected><?php print($active); ?></option>
<option value="Yes">Yes</option>
<option value="No">No</option>
</select>
</TD>

<td BGCOLOR="#CCCCCC"><b><font face="Verdana" size="2">Order</font></b><BR>
<?php 
if($pagename=="thanks"){
?>
<input class="txtbox" type=hidden name=pageorder size=4 value="<? echo $pageorder; ?>">
<? echo $pageorder; ?>
<?php 
}else{
?>
<input class="txtbox" type=text name=pageorder size=4 value="<? echo $pageorder; ?>">
<?php 
}
?>
</TD>
 
<td BGCOLOR="#CCCCCC" width="102"><b><font face="Verdana" size="2">On Header?</font></b><BR>
<select name="onheader" class="txtbox"  >
<option value="<?php print($onheader); ?>" selected><?php print($onheader); ?></option>
<option value="Yes">Yes</option>
<option value="No">No</option>
</select>
</TD>

<td BGCOLOR="#CCCCCC" width="102"><b><font face="Verdana" size="2">On Footer?</font></b><BR>
<select name="onfooter" class="txtbox"  >
<option value="<?php print($onfooter); ?>" selected><?php print($onfooter); ?></option>
<option value="Yes">Yes</option>
<option value="No">No</option>
</select>
</TD>

</tr>


<tr>
<td BGCOLOR="#CCCCCC" width="102"><b><font face="Verdana" size=2>Title:</font></b> </td>
<td BGCOLOR="#CCCCCC" colspan="7" width="784"><input class="txtbox" type=text name=pagetitle size=88 value="<? echo $pagetitle; ?>">
</TD>
</TR>

<tr>
<td BGCOLOR="#CCCCCC" width="102"><b><font face="Verdana" size=2>Meta Codes:</font></b> </td>
<td BGCOLOR="#CCCCCC" colspan="7" width="784"><textarea class="txtbox" rows="3" cols="110" name="pagemetas"><? echo $pagemetas; ?></textarea>
</TD>
</TR>

<tr><td colspan="7" BGCOLOR="#CCCCCC" align="center" width="100%">
<textarea class="txtbox" rows="15" name="message" cols="110" id="message"><?php echo $stylesheet; ?><? echo "$pagecontent" ?></textarea>
 <script language=JavaScript src='../include/gui/scripts/innovaeditor.js'></script>

   <script>
    var oEdit1 = new InnovaEditor("oEdit1");

    /***************************************************
      SETTING EDITOR DIMENSION (WIDTH x HEIGHT)
    ***************************************************/

    oEdit1.width=1100;//You can also use %, for example: oEdit1.width="100%"
    oEdit1.height=600;


    /***************************************************
      SHOWING DISABLED BUTTONS
    ***************************************************/

    oEdit1.btnPrint=true;
    oEdit1.btnPasteText=true;
    oEdit1.btnFlash=true;
    oEdit1.btnMedia=true;
    oEdit1.btnLTR=true;
    oEdit1.btnRTL=true;
    oEdit1.btnSpellCheck=false;
    oEdit1.btnStrikethrough=true;
    oEdit1.btnSuperscript=true;
    oEdit1.btnSubscript=true;
    oEdit1.btnClearAll=true;
    oEdit1.btnSave=false;
    oEdit1.btnStyles=false; //Show "Styles/Style Selection" button


    /***************************************************
      ADDING YOUR CUSTOM CONTENT LOOKUP
    ***************************************************/

    oEdit1.cmdCustomObject = "modelessDialogShow('objects.htm',365,270)"; //Command to open your custom content lookup page.

   /***************************************************
      USING CUSTOM TAG INSERTION FEATURE
    ***************************************************/

    oEdit1.arrCustomTag=[
["Company","{COMPANY}"],
["Company Address","{COMPANYADDR}"],
["Company City","{COMPANYCITY}"],
["Company State","{COMPANYSTATE}"],
["Company Zip","{COMPANYZIP}"],
["Company Phone","{COMPANYPHONE}"],
["Company Email","{COMPANYEMAIL}"],
["Company Fax","{COMPANYFAX}"],
["Tracker Website","{SITE}"],
["Three In One","{THREEINONE}"],
["Today's Date","{TODAYDATE}"],
["Year","{YEAR}"],
["Header","{HEADER}"],
["Footer","{FOOTER}"]];//Define custom tag selection


    /***************************************************
      SETTING COLOR PICKER's CUSTOM COLOR SELECTION
    ***************************************************/

    oEdit1.customColors=["#ff4500","#ffa500","#808000","#4682b4","#1e90ff","#9400d3","#ff1493","#a9a9a9"];//predefined custom colors

    /***************************************************
      SETTING EDITING MODE

      Possible values:
        - "HTMLBody" (default)
        - "XHTMLBody"
        - "HTML"
        - "XHTML"
    ***************************************************/

    oEdit1.mode="XHTMLBody";
oEdit1.cmdAssetManager="modalDialogShow('/include/gui/assetmanager/assetmanager.php',800,600);";

    oEdit1.REPLACE("message");

</script>



</TD></TR>
</table><br>
<input type="submit" value="Update <? echo $pagename; ?> page">



</center>
</div>


</center>


  
</form>

<?php 
}
?>







































<?php 
} if($page==5 && $_SESSION['usname']=="admin"){

?>


<form  action=""    method="post" >
       <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="800">
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Company Skin</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

  <table bgcolor="#<?php print($bgcolor);?>" border="1" cellspacing="1" cellpadding="8" width="800" id="AutoNumber1">
        
    
    
    <tr>
      <td width="100%"><textarea rows="10" name="companyskin" cols="95"><?php echo $companyskin; ?></textarea></td>
    </tr>
    
    
    
    </table> 
  <input type="hidden" name="updateskin" value="1">
                            <p align="center">
                            <input type="submit" name="Update" value="Update">
  </p>
     </form>
     </td>
  </tr>
  </table>
  This is a preview of your 
skin using the Client Welcome email.<BR>
<center><iframe name="I1" src="companyinfo.php?preview=yes" width="850" height="500">
</center>







<?php 
}

?>

     <?php
 }                

        ?>

    
   



<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>