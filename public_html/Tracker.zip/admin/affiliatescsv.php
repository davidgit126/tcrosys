<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1 && $_SESSION['usname']=="admin"){
   include("connection.php");
   $i =1;

   $filename = "List of Affiliates " . date("Y-m-d");
   $ext = 'csv';

   header("Content-type: text/plain");
   header('Content-Disposition: attachment; filename="' . $filename . '.' . $ext . '"');
   header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
   header('Pragma: no-cache');
   header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
   header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1

       echo("id,Username,Password,Company,First Name,Last Name,Email,Phone,Work Phone,Alt Phone,Fax,Address,City,State,Zip,SSN,Comm Rate\r\n");
       $query = "SELECT id, user, password, company, fname, lname, email, phone, work_phone, alt_phone, fax, address, city, state, zip, ssn, commission_rate FROM sales_affiliates WHERE
                type='Affiliate' and status!='del' ORDER BY id";
       $result = mysql_query($query, $conn) or die("error:" . mysql_error());
       $col_count = mysql_num_fields($result);
       while($row=mysql_fetch_row($result))
       {
           $id = '"'.$row[0].'"';
           $username = '"'.$row[1].'"';
           $password = '"'.$row[2].'"';
           $company = '"'.$row[3].'"';
           $firstname = '"'.$row[4].'"';
           $lastname = '"'.$row[5].'"';
           $email = '"'.$row[6].'"';
           $telephone = '"'.$row[7].'"';
           $work_phone = '"'.$row[8].'"';
           $alt_phone = '"'.$row[9].'"';
		   $fax = '"'.$row[10].'"';
           $address = '"'.$row[11].'"';
           $city = '"'.$row[12].'"';
           $prov = '"'.$row[13].'"';
           $zipcode = '"'.$row[14].'"';
           $ssn = '"'.$row[15].'"';
           $commrate = '"'.$row[16].'"';
           echo("$id,$username,$password,$company,$firstname,$lastname,$email,$telephone,$work_phone,$alt_phone,$fax,$address,$city,$prov,$zipcode,$ssn,$commrate\r\n"); //--- without numbers
           $i = $i+1;
          // print("$row[0], $row[1], $row[2]");
          // print("\n");
      }

  
}
else
{
    header("Location: login.php");
    exit();
}

?>
