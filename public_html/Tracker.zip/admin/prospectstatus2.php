<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";
$today = date("Y-m-d");


$nowday = date("d");
$nowmonthword = date("M");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
include('template.php');


if ($editmode=="yes"  && $_SESSION['usname']=="admin") {

$sql_note = "INSERT INTO salesnotes

(clientid,action,counselor,repairdate,filelocation)
               VALUES
(\"$id\",
\"Changed Prospect Info\",
\"$user\",
\"$today\",
\"$tstamp\")";
$result_note = @mysql_query($sql_note,$conn);


 $query = "UPDATE clients SET
                name='" . mysql_real_escape_string($_POST['name']) . "',
                address='" . mysql_real_escape_string($_POST['address']) . "',
                city='" . mysql_real_escape_string($_POST['city']) . "',
                state='" . mysql_real_escape_string($_POST['state']) . "',
                zip='" . mysql_real_escape_string($_POST['zip']) . "',
                email='" . mysql_real_escape_string($_POST['email']) . "',
                phone='" . mysql_real_escape_string($_POST['phone']) . "',
                broker_id='" . mysql_real_escape_string($_POST['broker_id']) . "',
                affiliate_id='" . mysql_real_escape_string($_POST['affiliate_id']) . "',
                altphone='" . mysql_real_escape_string($_POST['altphone']) . "'
WHERE id = \"$id\"";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=prospectstatus.php?id=$id\">"; 

}




if ($note) {
$sql_note = "INSERT INTO salesnotes

(clientid,action,counselor,repairdate,filelocation)
               VALUES
(\"$id\",
\"$note\",
\"$user\",
\"$today\",
\"$tstamp\")";
$result_note = @mysql_query($sql_note,$conn);
}
$sql = "UPDATE clients SET
dateresults = \"$today\"
WHERE id = \"$id\"";

$result = @mysql_query($sql,$conn);



if ($calhour !="") {
$webpage = $_SERVER["HTTP_REFERER"];

 if (($calampm == "pm") && ($calhour < 12)){
$calhour += 12;
}
 if (($calampm == 'am') && ($calhour == 12)){
$calhour = 0;
}
$date = mktime ( 3, 0, 0, $calmonth, $calday, $calyear );
  $str_cal_date = date ( "Ymd", $date );
  $changefollowup = date ( "Y-m-d", $date );
  $str_cal_time = sprintf ( "%d%02d00", $calhour, $calminute );
  $modtime = date ( "Gis" );
$sqlcal1 = "INSERT INTO calendar (cal_contactid, cal_create_by, cal_date, cal_time, cal_mod_date, cal_mod_time, cal_name, cal_link, cal_description)
			VALUES(
	\"$id\",
	\"$username\",
	\"$str_cal_date\",
	\"$str_cal_time\",
	\"$julian\",
	\"$modtime\",
	\"Call $clientname $typeofreminder\",
	\"$webpage\",
	\"$note\")";
                $result = mysql_query($sqlcal1, $conn) or die("error:" . mysql_error());

$query = "UPDATE clients SET
                scheduleddate='$changefollowup'
                WHERE id='$id'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

if ($comments) {
$query = "UPDATE clients SET
                comments='$comments'
                WHERE id='$id'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

include('main.php');

$GET_id=$_GET["id"];

 
       
$sql = "SELECT * FROM clients WHERE id = '$GET_id' AND prospectclient = 'Prospect' and clientdelete !='yes' $restrictleads";
$result = mysql_query($sql, $conn);
$line=mysql_fetch_array($result, MYSQL_ASSOC);
$number_results = mysql_num_rows($result);
$bgcolor = "FF9900";

$entered_year = substr("$line[createdate]", 0, 4);
$entered_month = substr("$line[createdate]", 5, 2);
$entered_day = substr("$line[createdate]", 8, 2);

$query3 = "SELECT user, fname, lname FROM sales_affiliates WHERE id = '$line[affiliate_id]'";
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $affiliatename = $row3[0];
                   $fname = $row3[1];
                   $lname = $row3[2];
}
$SA_sql = "SELECT firstname,lastname,username,dealership FROM dealers where dealer_id='$line[broker_id]'";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $brokerfirstname = $srow['firstname'];
		    $brokerlastname = $srow['lastname'];
		    $brokerusername = $srow['username'];		    
		    $brokercompany = $srow['dealership'];		    
		}

if ($line[prospectclient] == "Client"){
?>

<font color="red"><B>This record is not a Prospect and cannot be accessed through here. </font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 }
if ($line[prospectclient] == "Prospect"){
?>
<style type="text/css">
table.bordered {border-left: 1px solid black;border-top: 1px solid black; }
table.bordered tr td, table.bordered tbody tr td {border-right: 1px solid black;border-bottom:1px solid black}
body, td {font-family:Verdana,Arial,sans-serif}
body {font-size:0.8em}
button, input[type="submit"] {font-weight:bold;border:1px solid black;cursor:hand;}
h1 {font-size:1.4em;border:1px solid black;text-align:center;padding:0;margin:0;}
.coloredbg, h1, th {background-color:lightgrey}
h2 {font-size:1.2em;text-align:center;padding:0;margin:0;}
.note {font-style:italic;}
.bl, .blr, .blt, .blb, .blrt, .blrb, .bltb, .blrtb {border-left: 1px solid black}
.br, .blr, .brt, .brb, .blrt, .blrb, .brtb, .blrtb {border-right: 1px solid black}
.bt, .blt, .brt, .btb, .blrt, .bltb, .brtb, .blrtb {border-top: 1px solid black}
.bb, .blb, .brb, .btb, .blrb, .bltb, .brtb, .blrtb {border-bottom: 1px solid black}
a.footnote {border-bottom: 1px dotted black; text-decoration: none}
tr.odd td{background-color:lightyellow}
tr.even td{background-color:lightgrey}
.graph1, .graph2 {background-color:lightyellow; border-left: 1px solid black;border-right: 1px solid black;border-top: 1px solid black; font-size:1px;border-bottom:1px solid black}
.graph1 {background-color:lightyellow}
.graph2 {background-color:darkgray}
</style>
<SCRIPT LANGUAGE="JavaScript" SRC="http://www.700score.com/CalendarPopup.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript">document.write(getCalendarStyles());</SCRIPT>
<SCRIPT LANGUAGE="JavaScript">
var cal = new CalendarPopup("testdiv1");
cal.setReturnFunction("setMultipleValues3"); 
function setMultipleValues3(y,m,d) { 
     document.forms[0].calyear.value=y; 
     document.forms[0].calmonth.selectedIndex=m; 
     document.forms[0].calday.selectedIndex=d; 
     }
     


function finalCheck(form) {
if(! document.Subscribe.note.value){
alert("You must enter a \"Note\"")
document.Subscribe.note.focus();return false}



	}

</SCRIPT>

                 <font color="red">  <B> <?php print($error); ?></B></font>
                  


   <center> 
   
   <?php
if ($mode!="edit" && $mode !="email") {

?>      

<TABLE width="400" border="0" cellpadding="0" cellspacing="0">
<TR>
<td valign="top">
<table class="blrtb" width="400" border="0" cellpadding="0" cellspacing="0">
<form method="POST" action="" name="Subscribe" >
<input type="hidden" name="id" value="<? echo "$line[id]"; ?>">
<input type="hidden" name="addnote" value="yes">
<input type="hidden" name="user" value="<? print $_SESSION['usfname']; ?>">
<input type="hidden" name="username" value="<? print $_SESSION['usname']; ?>">

<TR><TD colspan="2" align="center"><h1>Prospect Record</h1></TD></tr>

<tr class="odd"><td colspan="2" height="15" align="center">
 <?php
if ($_SESSION['usname']=="admin") {
?>     
  <a href="prospectstatus.php?mode=edit&id=<? echo "$line[id]"; ?>">edit mode</a></td></tr>
<?php
}
?>
<tr class="even"><td colspan="2" height="15"></td></tr>




<tr class="odd"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Name</font>   </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><? echo "$line[name]"; ?></font>
</td></tr>


<tr class="even"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Address</font></td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><? echo "$line[address]"; ?></font>
</td></tr>

<tr class="even"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">City, State Zip</font>   </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><? echo "$line[city]"; ?>, <? echo "$line[state]"; ?> <? echo "$line[zip]"; ?></font>
</td></tr>

<tr class="odd"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp;
  <font size="1">Phone</font>   </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><? echo "$line[phone]"; ?></font>
</td></tr>



<tr class="odd"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Alt. Phone</font>   </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><? echo "$line[altphone]"; ?></font>
</td></tr>


<tr class="even"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Email</font><BR><BR>   </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1">
<a href="mailto:<? echo "$line[email]"; ?>"><? echo "$line[email]"; ?></a><BR><BR>

</font>
</td></tr>


<tr class="even">
  <td colspan="2" ?>&nbsp;
  <?php

$query = "SELECT id, name FROM systememails WHERE type='sales'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
           
        $emailid = $row[0]; 
        $emailname = $row[1]; 

  
    ?>
<a href="prospectstatus2.php?id=<? echo "$id"; ?>&mode=email&emailid=<? echo "$emailid"; ?>"><? echo $emailname; ?></a>&nbsp;
<?php
}

  
    ?>

  </td></tr>

<tr class="even"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1">
 <?php
  if($welcomeresend == "Yes"){
        ?>
                                      Welcome Email Sent!
                                <?php
  }else{
        ?>
       <input type="button" value="Resend Welcome Email" onClick="javascript:window.location.href='welcomeresend.php?t=Prospect&prospectid=<? echo "$id"; ?>'">
                                <?php
 }
        ?>


</font>
</td></tr>




	

<tr class="odd"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Entered Date  </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><? echo "$entered_month/$entered_day/$entered_year"; ?></font>
</td></tr>

<tr class="even">
  <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Affiliate Name  </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><?php print($affiliatename); ?>  (<?php print($lname); ?>, <?php print($fname); ?>)</font>
</td>
</tr>

  <tr class="odd"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Broker Name  </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><?php print($brokercompany); ?>  (<?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?>) <?php print($brokerusername); ?></font>
</td></tr>

<tr class="even"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Comments </td><td >
<textarea class="txtbox"  name="comments" rows="3" cols="35"><?php print($line[comments]); ?></textarea></font>
</td></tr>




<tr class="odd"><td width="100%" colspan="2" align="center"> 
&nbsp;</td></tr>


<tr class="odd"><td width="100%" colspan="2" align="center"> 
<font size="1"><center><input type="button" name="OK" value="Enroll as Single" label="OK" onClick="javascript:window.location.href='conversion.php?id=<? echo "$line[id]"; ?>'">&nbsp;&nbsp;&nbsp;
                                        <input type="button" name="OK1" value="Enroll as Joint" label="OK" onClick="javascript:window.location.href='conversionjoint.php?id=<? echo "$line[id]"; ?>'"></font></td></tr>


<tr class="odd"><td width="100%" colspan="2" align="center"> 
&nbsp;</td></tr>


<tr class="odd"><td width="100%" colspan="2" align="center"> 
<center>
<p>
<b><font size="1">NOTES</font></b><br>
<textarea name="note" rows="5" cols="45">
</textarea><br>
<font size="1">&nbsp;</font></p>
</center>
</td></tr>

<tr class="even"><td width="100%" colspan="2" align="center"> 
<center><font size="1"><b>SET FOLLOWUP</b><br>
			<select class="txtbox" name="calday">
<option value="<? echo "$nowday"; ?>" selected="selected"><? echo "$nowday"; ?></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22"">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<select class="txtbox" name="calmonth">
<option value="<? echo "$nowmonth"; ?>" selected="selected"><? echo "$nowmonthword"; ?></option>
<option value="1">Jan</option>
<option value="2">Feb</option>
<option value="3">Mar</option>
<option value="4">Apr</option>
<option value="5">May</option>
<option value="6">Jun</option>
<option value="7">Jul</option>
<option value="8">Aug</option>
<option value="9">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
<input maxlength="4" class="txtbox" type="text" name="calyear" size="4" value=<? echo "$nowyear"; ?> >

<A HREF="#" onClick="cal.showCalendar('anchor1'); return false;" NAME="anchor1" ID="anchor1">
<img border="0" src="http://www.700score.com/icon_light_green.gif" width="13" height="12"></A>




&nbsp;&nbsp;
			<input class="txtbox" type="text" name="calhour" size="2" value="" maxlength="2" />:<input class="txtbox" type="text" name="calminute" size="2" value="" maxlength="2" />
<label><input type="radio" name="calampm" value="am" checked="" />AM</label>
<label><input type="radio" name="calampm" value="pm"  />PM<br>
<input type="radio" name="typeofreminder" value="to FU"  checked="" />Follow up</label>
<label><input type="radio" name="typeofreminder" value="to Enroll"  />To Enroll</label>
<input type="hidden" name="clientname" value="<? echo "$line[name]"; ?>">

</td></tr>
 
<tr class="odd"><td colspan="2" height="10"></td></tr>

<tr class="odd"><td align="center" colspan="2" width="100%">
<center><input type="submit" name="submit" value="Update">
<? if ($line[category] == "Prospect") { ?>
<input type="submit" name="delete" value="Delete"> 
<? } ?>
</td></tr>

<tr class="odd"><td colspan="2" height="15"></td></tr>



</table>
</form>
<DIV ID="testdiv1" STYLE="position:absolute;visibility:hidden;background-color:white;layer-background-color:white;"></DIV>
</TD><TD VALIGN="TOP">

</TD>

<TD>
&nbsp;</TD>






<td valign="top">
<table class="blrtb" width="400" border="0" cellpadding="0" cellspacing="0">
<?


echo "<center>";

$sql = "SELECT * FROM salesnotes WHERE clientid = '$GET_id' ORDER BY repairdate, id";
$result = @mysql_query($sql,$conn) or die("Couldn't execute");

$num_results = mysql_num_rows($result);

if (! $num_results || $num_results == "0") {
echo "<font color=red><b>$accesscomment</font></b><BR>";
echo "<b><font face=\"Verdana\" size=\"2\" color=\"#FF0000\">No notes added.</font></b>";
}else{

  $change_color = "1";
echo "<TABLE width=\"400\" BORDER=\"0\" bordercolor=\"#000000\" class=\"blrtb\" cellpadding=\"0\" cellspacing=\"0\">";
echo  "<TR>";
echo  "<TD colspan=\"3\" align=center><h1>Notes</h1></TD>";
echo  "</TR>";


  while ($row = mysql_fetch_array($result)) {	
    $NOTE_id = $row['id'];
    $NOTE_contact_id = $row['clientid'];
    $NOTE_view = $row['action'];
    $NOTE_user = $row['counselor'];
    $NOTE_julian = $row['repairdate'];
    $NOTE_tstamp = $row['filelocation'];

$NOTE_year = substr("$NOTE_julian", 0, 4);
$NOTE_month = substr("$NOTE_julian", 5, 2);
$NOTE_day = substr("$NOTE_julian", 8, 2);

if ($change_color == "2") {
$bgcolor = "class=\"even\"";
$change_color = "1";
}else{
$bgcolor = "class=\"odd\"";
$change_color = "2";
}

echo "<TR $bgcolor>";
echo "<TD align=\"center\"><font size=\"1\">$NOTE_month/$NOTE_day/$NOTE_year at $NOTE_tstamp </font></TD>";
echo "<TD align=\"center\"><font face=\"Verdana\" ><font size=\"1\">$NOTE_view</font></TD>";
echo "<TD align=\"center\"><font face=\"Verdana\" ><font size=\"1\">$NOTE_user</font></TD>";
echo "</TR>";


} // end while loop //
echo "</TABLE>
<p>";
	} // end if results //

echo "<br><br>";


?>






</table>
                      
                      
                      
      <?php
      }
if ($mode=="edit" && $_SESSION['usname']=="admin") {

/* Connection to Affiliates People */

		$SA_sql = "SELECT * FROM sales_affiliates WHERE type='Affiliate' AND status !='suspend' ORDER BY lname";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $affiliateid = $srow['id'];
		    $fname = $srow['fname'];
		    $lname = $srow['lname'];


                if ($username == "$user") {
		$user_select6 .= "<option value=\"$affiliateid\">$lname, $fname</option>";
		}else{
		$user_select6 .= "<option value=\"$affiliateid\">$lname, $fname</option>";
		}

		$ARUSERS{"$affiliateid"} = "$affiliateid";
		
		}

$SA_sql = "SELECT fname,lname FROM sales_affiliates where id= '$line[affiliate_id]'";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $affiliatefirstname = $srow['fname'];
		    $affiliatelastname = $srow['lname'];
		}


/* Connection to Brokers */

		$SA_sql = "SELECT * FROM dealers WHERE status !=9 ORDER BY lastname";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $dealerid = $srow['dealer_id'];
		    $firstname = $srow['firstname'];
		    $lastname = $srow['lastname'];


                if ($username == "$user") {
		$user_select5 .= "<option value=\"$dealerid\">$lastname, $firstname</option>";
		}else{
		$user_select5 .= "<option value=\"$dealerid\">$lastname, $firstname</option>";
		}

		$ARUSERS{"$dealerid"} = "$dealerid";
		
		}
$SA_sql = "SELECT firstname,lastname,email,username,password FROM dealers where dealer_id='$line[broker_id]' and status !=9";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $brokerfirstname = $srow['firstname'];
		    $brokerlastname = $srow['lastname'];
		    $brokeremail = $srow['email'];		    
		    $brokerusername = $srow['username'];		
		    $brokerpassword = $srow['password'];				    		    
		}
?>      

          
     
<TABLE width="400" border="0" cellpadding="0" cellspacing="0">
<TR>
<td valign="top">
<table class="blrtb" width="400" border="0" cellpadding="0" cellspacing="0">
<form method="POST" action="" name="EDIT" >
<input type="hidden" name="id" value="<? echo "$line[id]"; ?>">
<input type="hidden" name="editmode" value="yes">
<input type="hidden" name="user" value="<? print $_SESSION['usfname']; ?>">
<input type="hidden" name="username" value="<? print $_SESSION['usname']; ?>">

<TR><TD colspan="2" align="center"><h1>Edit Prospect Record</h1></TD></tr>





<tr class="odd"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Name</font>   </td><td width="<?php echo "$width_ctwo"; ?>">
<input class="txtbox" name="name" size="37" value="<? echo "$line[name]"; ?>" >
</td></tr>


<tr class="even"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Address</font></td><td width="<?php echo "$width_ctwo"; ?>">
<input class="txtbox" name="address" size="37" value="<? echo "$line[address]"; ?>" >
</td></tr>

<tr class="even"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">City, State Zip</font>   </td><td width="<?php echo "$width_ctwo"; ?>">
<input class="txtbox" name="city" size="15" value="<? echo "$line[city]"; ?>" >,
<input class="txtbox" name="state" size="4" value="<? echo "$line[state]"; ?>" > &nbsp; 
<input class="txtbox" name="zip" size="6" value="<? echo "$line[zip]"; ?>" >
</td></tr>

<tr class="odd"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp;
  <font size="1">Phone</font>   </td>
  <td width="<?php echo "$width_ctwo"; ?>">
<input class="txtbox" name="phone" size="15" value="<? echo "$line[phone]"; ?>" >

</td></tr>



<tr class="odd"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Alt. Phone</font>   </td><td width="<?php echo "$width_ctwo"; ?>">
<input class="txtbox" name="altphone" size="15" value="<? echo "$line[altphone]"; ?>" >
</td></tr>


<tr class="even"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Email</font></td><td width="<?php echo "$width_ctwo"; ?>">
<input class="txtbox" name="email" size="37" value="<? echo "$line[email]"; ?>" >
</td></tr>



<tr class="even">
  <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Affiliate Name  </td><td width="<?php echo "$width_ctwo"; ?>">
<select name="affiliate_id"  class="txtbox" >
					    <option value="<? echo "$line[affiliate_id]"; ?>" selected><?php print($affiliatelastname); ?>, <?php print($affiliatefirstname); ?></option>
					    <? echo "$user_select6"; ?>
						<option value="">----Remove Affiliate from this client----</option>
					    </select>
					    
</td>
</tr>

  <tr class="odd"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Broker Name  </td><td width="<?php echo "$width_ctwo"; ?>">
<select name="broker_id" class="txtbox"  >
					    <option value="<? echo "$line[broker_id]"; ?>" selected><?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?></option>
					    <? echo "$user_select5"; ?>
						<option value="">----Remove Brokers from this client----</option>
					    </select>
    
</td></tr>




<tr class="odd"><td align="center" colspan="2" width="100%">
&nbsp;</td></tr>




<tr class="odd"><td align="center" colspan="2" width="100%">
<center><input type="submit" name="submit" value="Update">
</td></tr>

<tr class="odd"><td colspan="2" height="15"></td></tr>



</table>
</form>
</TD>
</table>
                 
                      
   <?php
} 
//END EDIT MODE

if ($mode=="email") {

$query = "SELECT id, subject, message, name FROM systememails WHERE id='$emailid'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
           
        $emailid = $row[0]; 
        $subject = $row[1]; 
        $message = $row[2]; 
        $emailname = $row[3]; 

    }
    $query = "SELECT fname, email FROM users WHERE id='" . $_SESSION['usid'] . "'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
           
        $salesfname = $row[0]; 
        $salesemail = $row[1]; 

    }
    $fname = explode(' ', $line[name]); 
if ($fname[2] != ""){
$lname = $fname[2];
}else{
$lname = $fname[1];
}
$fname = $fname[0];

$fname = ucwords(strtolower($fname)); 
$lname = ucwords(strtolower($lname)); 
$email=$line[email];


    include_once("companystrip.php");
    include_once("clientstrip.php");

$message2 = str_replace("{SALESFNAME}", "$salesfname", $message2);
$subject2 = str_replace("{SALESFNAME}", "$salesfname", $subject2);

$message2 = str_replace("{SALESEMAIL}", "$salesemail", $message2);
$subject2 = str_replace("{SALESEMAIL}", "$salesemail", $subject2);


if($_POST['sendsalesmail'] == 'yes'){
$emailthatwassent = $_POST['email'];
$salesfname = $_POST['salesfname'];
$salesemail = $_POST['salesemail'];
$EMAIL_Message = "$message2";
$EMAIL_Subject = "$subject2";
$EMAIL_Reply = "$salesemail";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $salesfname ($companyname) <$salesemail>\r\n";
                  $formsent = mail($emailthatwassent, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $salesemail");  

    $note = "Sent $emailname email to $emailthatwassent";


$sql_note = "INSERT INTO salesnotes

(clientid,action,counselor,repairdate,filelocation)
               VALUES
(\"$id\",
\"$note\",
\"$salesfname\",
\"$today\",
\"$tstamp\")";
$result_note = @mysql_query($sql_note,$conn);


echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=prospectstatus.php?id=$id\">"; 


}

?>      

          
     
<TABLE width="60%" border="0" cellpadding="0" cellspacing="0">
<TR>
<td valign="top">
<table class="blrtb" width="100%" border="0" cellpadding="3" cellspacing="3" style="border-width:0; border-collapse: collapse" bordercolor="#111111">
<form method="POST" action="" name="EMAIL" >
<input type="hidden" name="id" value="<? echo "$line[id]"; ?>">
<input type="hidden" name="salesfname" value="<? echo $salesfname; ?>">
<input type="hidden" name="salesemail" value="<? echo $salesemail; ?>">

<input type="hidden" name="sendsalesmail" value="yes">



<TR><TD align="center"><h1>Send <input class="txtbox" name="fname" size="15" value="<? echo $fname; ?>"> <? echo "$emailname"; ?>  email to 
<input class="txtbox" name="email" size="35" value="<? echo $email; ?>"><br>
   From <i><font color="#800000"><? echo $salesfname; ?> (<? echo $companyname; ?>) <? echo $salesemail; ?></font></i></h1></TD></tr>





<tr width="60%" bgcolor="#FFFFF"><td width="80%">
<p><b>Subject:</b> <? echo "$subject2"; ?>
<p><? echo "$message2"; ?></p>


</td></tr>




<tr ><td align="center" width="100%">
&nbsp;</td></tr>



<tr ><td align="center" width="100%">
<center><input type="submit" name="submit" value="SEND EMAIL"></td></tr>
<tr ><td height="15"></td></tr></table></form></TD></table><?php















} 
//END EMAIL MODE
?><?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>