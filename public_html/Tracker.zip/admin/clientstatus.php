<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();
extract ($_SESSION );



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);


$nowday = date("d");
$nowmonthword = date("M");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

$todaydate = date("Y-m-d");
$todaydate2 = date("m-d-Y");

function dateDiff($dformat, $endDate, $beginDate) 
{ 
$date_parts1=explode($dformat, $beginDate); 
$date_parts2=explode($dformat, $endDate); 
$start_date=gregoriantojd( intval( $date_parts1[0] ), intval( $date_parts1[1] ), intval( $date_parts1[2] )); 
$end_date=gregoriantojd( intval( $date_parts2[0]) , intval( $date_parts2[1] ), intval( $date_parts2[2])) ; 
// var_dump( $date_parts1 );
// var_dump( $date_parts2 );
// echo "<br/>";
return $end_date - $start_date; 
} 


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
 include("connection.php");
     include('template.php');


     $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload, passisssn, demanddraft, portals, privatelabel FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 
        $passisssn = $row[14]; 
        $demanddraft = $row[15]; 
        $portals = $row[16]; 
        $privatelabel = $row[17]; 
    }
$poweredbymessage = "<BR><BR><p align=right><a href=\"http://www.creditrepairtracking.com\"><img border=0 src=http://www.creditrepairtracking.com/trackstarlogoforemail.png></a></p>";

///////////////////////////////////////////////////////////////////////////////////////////////
$clientonform = $_POST['clientonform'];
$sessionedclient = $_SESSION['clientid'];

      if($_POST['updatecl'] == 1)
      {

if ($clientonform == $sessionedclient)
{

        $date_array = split("-", $_POST['birthdate']);
        $birthdate = $date_array[2]."-".$date_array[0]."-".$date_array[1];
        
        $date_array = split("-", $_POST['dateresults']);
        $dateresults = $date_array[2]."-".$date_array[0]."-".$date_array[1];

        $date_array = split("-", $_POST['canceldate']);
        $canceldate = $date_array[2]."-".$date_array[0]."-".$date_array[1];

		$query = "UPDATE clients SET
                name='" . mysql_real_escape_string($_POST['clientinfoname']) . "',
                address='" . mysql_real_escape_string($_POST['address']) . "',
                city='" . mysql_real_escape_string($_POST['city']) . "',
                state='" . mysql_real_escape_string($_POST['state']) . "',
                zip='" . mysql_real_escape_string($_POST['zip']) . "',
				email='" . mysql_real_escape_string($_POST['email']) . "',
                fax='" . mysql_real_escape_string($_POST['fax']) . "',
                phone='" . mysql_real_escape_string($_POST['phone']) . "',
                altphone='" . mysql_real_escape_string($_POST['altphone']) . "',
                ssnum='" . mysql_real_escape_string($_POST['ssnum']) . "',
                birthdate='$birthdate',
                fonttype='" . mysql_real_escape_string($_POST['fonttype']) . "',                
                username='" . mysql_real_escape_string($_POST['usernameu']) . "',
                password='" . mysql_real_escape_string($_POST['pwdu']) . "',
                comments='" . mysql_real_escape_string($_POST['comments']) . "',
                status='" . mysql_real_escape_string($_POST['status']) . "',
                plan='" . mysql_real_escape_string($_POST['plan']) . "',                
                budgetday='" . mysql_real_escape_string($_POST['budgetday']) . "',                                
                dateresults='$dateresults',
                showstatus='" . mysql_real_escape_string($_POST['showstatus']) . "',    
                jointwith='" . mysql_real_escape_string($_POST['jointwith']) . "',                   
                canceldate='$canceldate',
                cellphone='" . mysql_real_escape_string($_POST['cellphone']) . "',                   
                cellcarrier='" . mysql_real_escape_string($_POST['cellcarrier']) . "',                   
				singlecouple='" . mysql_real_escape_string($_POST['singlecouple']) . "'        
                WHERE id='" . $_SESSION['clientid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Client Status Sheet',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

   ///////////ENROLLMENT
        $date_array = split("-", $_POST['dateenrol']);
        $dateenrol = $date_array[2]."-".$date_array[0]."-".$date_array[1];

        $date_array = split("-", $_POST['reportreceived']);
        $reportreceived = $date_array[2]."-".$date_array[0]."-".$date_array[1];

        $date_array = split("-", $_POST['addressreceived']);
        $addressreceived = $date_array[2]."-".$date_array[0]."-".$date_array[1];

        $date_array = split("-", $_POST['ssdate']);
        $ssdate = $date_array[2]."-".$date_array[0]."-".$date_array[1];

        $date_array = split("-", $_POST['welcomepacket']);
        $welcomepacket = $date_array[2]."-".$date_array[0]."-".$date_array[1];

        $date_array = split("-", $_POST['returndoc']);
        $returndoc = $date_array[2]."-".$date_array[0]."-".$date_array[1];


        $query = "UPDATE enrolment SET dateenrol='$dateenrol',  reportreceived='$reportreceived', addressreceived='$addressreceived', ssdate='$ssdate', welcomepacket='$welcomepacket', returndoc='$returndoc' WHERE clientid='" . $_SESSION['clientid'] . "' ";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
   

//////////////BILLING

    if($_SESSION['usaccess']!="processing"){

        $date_array = split("-", $_POST['paid']);
        $paid = $date_array[2]."-".$date_array[0]."-".$date_array[1];
        $query = "UPDATE billing SET 
                auditfee='" . mysql_real_escape_string($_POST['auditfee']) . "',
                paid='" . $paid . "',
                monthlyfee='" . mysql_real_escape_string($_POST['monthlyfee']) . "',
                monthlydue='" . mysql_real_escape_string($_POST['monthlydue']) . "',
                payment='" . mysql_real_escape_string($_POST['payment']) . "',
                onlinepayment='" . mysql_real_escape_string($_POST['onlinepayment']) . "',
                bankname='" . mysql_real_escape_string($_POST['bankname']) . "',
                bankrtg='" . mysql_real_escape_string($_POST['bankrtg']) . "',
                bankact='" . mysql_real_escape_string($_POST['bankact']) . "',                                                
                checknum='" . mysql_real_escape_string($_POST['checknum']) . "',
                aba='" . mysql_real_escape_string($_POST['aba']) . "' ,
                holder='" . mysql_real_escape_string($_POST['holder']) . "' ,
                holderaddress='" . mysql_real_escape_string($_POST['holderaddress']) . "' ,
                holdercity='" . mysql_real_escape_string($_POST['holdercity']) . "' ,
                holderstate='" . mysql_real_escape_string($_POST['holderstate']) . "' ,
                holderzip='" . mysql_real_escape_string($_POST['holderzip']) . "' 				
                WHERE clientid='" . $_SESSION['clientid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

if($_POST['status'] == "canceled" AND $_POST['status'] != $oldstatus AND $oldstatus != "Debtor" AND $oldstatus != "Debtor1" AND $oldstatus != "Debtor2" AND $oldstatus != "Debtor3" AND $oldstatus != "Debtor4" AND $oldstatus != "3rdprty1" AND $oldstatus != "3rdprty2"){
$canceldate = "$year-$month-$day";

        $query = "UPDATE clients SET
        canceldate='$canceldate'
        WHERE id='" . $_SESSION['clientid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}


}else{
print("<font color=red><b>Your Client Session Has Expired.  You can prevent this from happening by not keeping old client windows open after opening new client files. </b></font>");
exit(); 
}


    }


    if($_REQUEST['del'] == 1)
    {
        $query = "DELETE FROM repair WHERE id='" . mysql_real_escape_string($_REQUEST['repairid']) . "' ";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Delete Credit Repair Record',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

    }

    if($_POST['u'] == 1)
    {
        $date_array = split("-", $_POST['repairdate']);
        $repairdate = $date_array[2]."-".$date_array[0]."-".$date_array[1];
        $query = "UPDATE repair SET
                repairdate='$repairdate',
                received='" . mysql_real_escape_string($_POST['received']) . "',
                action='" . mysql_real_escape_string($_POST['action']) . "',
                filelocation='" . mysql_real_escape_string($_POST['filelocation']) . "',
                counselor='" . mysql_real_escape_string($_POST['counselor']) . "'
                WHERE id='" . mysql_real_escape_string($_POST['repairid']) . "' ";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        
$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Changed Credit Repair Record',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

    }

    if($_POST['add'] == 1)
    {
        {
        $date_array = split("-", $adddate);
        $adddate = $date_array[2]."-".$date_array[0]."-".$date_array[1];
        $query = "INSERT INTO repair(clientid, repairdate, received, action, filelocation, counselor)
                VALUES(
                '" . $_SESSION['clientid'] . "',
                '$adddate',
                '" . mysql_real_escape_string($_POST['addreceived']) . "',
                '" . mysql_real_escape_string($_POST['addaction']) . "',
                '" . mysql_real_escape_string($_POST['addfile']) . "',
                '" . mysql_real_escape_string($_POST['addcounselor']) . "'
                )";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Add New Credit Repair Record',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

        }
        
          
   
$HEADERS  = "MIME-Version: 1.0\r\n";
$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
$HEADERS .= "From: $companyname <$companyreply>\r\n";

$tempemail = str_replace(array(" "),"",$email);      
$emaillist = explode(',', $tempemail); 
     
////////EMAIL TO CLIENT
if($emaillist[0] != "" AND $emaillist[0] != "none@none.com"){
$subject = "$subject2 Account Update";
$message = "$companyskin<B>Date:</B>  $adddate<BR><BR>$clientinfoname, your account has recently been updated, please view the details below:<BR><BR>

<B>Received:</B>  $addreceived <BR><BR><B>Action Taken:</B>  $addaction <BR><BR>";
if($portals== "Yes"){
$message .= "<HR>Remember, you can log into your account at <a href=$companywebsite>$companywebsite</a> to check your status at any time.   <BR><BR>Username - $username <BR>Password - $password";
}
if($privatelabel== "No"){
$message .= $poweredbymessage;
}

$formsent = mail($emaillist[0], $subject, $message, $HEADERS, "-f $companyreply");  
}
if($emaillist[1] != "" AND $emaillist[1] != "none@none.com"){
$formsent = mail($emaillist[1], $subject, $message, $HEADERS, "-f $companyreply");  
}
if($emaillist[2] != "" AND $emaillist[2] != "none@none.com"){
$formsent = mail($emaillist[2], $subject, $message, $HEADERS, "-f $companyreply");  
}
if($emaillist[3] != "" AND $emaillist[3] != "none@none.com"){
$formsent = mail($emaillist[3], $subject, $message, $HEADERS, "-f $companyreply");  
}


/////////////////SMS TO CLIENT
//$sendsms = $_POST['sendsms'];
$tempphone = str_replace(array("(",")","-"," ","."),"",$cellphone);      
$tempphone2 = "1$tempphone";

if($sendsms == "Yes"){

if($cellcarrier == "Teleflip"){
$smsemail = "@teleflip.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Alltel"){
$smsemail = "@message.alltel.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Ameritech"){
$smsemail = "@paging.acswireless.com";
$smsprefix = $tempphone;
}if($cellcarrier == "ATT Wireless"){
$smsemail = "@txt.att.net";
$smsprefix = $tempphone;
}if($cellcarrier == "Bell Mobility"){
$smsemail = "@txt.bell.ca";
$smsprefix = $tempphone;
}if($cellcarrier == "Bellsouth"){
$smsemail = "@bellsouth.cl";
$smsprefix = $tempphone;
}if($cellcarrier == "Boost"){
$smsemail = "@myboostmobile.com";
$smsprefix = $tempphone;
}if($cellcarrier == "CellularOne"){
$smsemail = "@mobile.celloneusa.com";
$smsprefix = $tempphone;
}if($cellcarrier == "CellularOne MMS"){
$smsemail = "@mms.uscc.net";
$smsprefix = $tempphone;
}if($cellcarrier == "Cingular"){
$smsemail = "@mobile.mycingular.com";
$smsprefix = $tempphone2;
}if($cellcarrier == "Cricket"){
$smsemail = "@sms.mycricket.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Fido"){
$smsemail = "@sms.fido.ca";
$smsprefix = $tempphone;
}if($cellcarrier == "Edge Wireless"){
$smsemail = "@sms.edgewireless.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Sprint PCS"){
$smsemail = "@messaging.sprintpcs.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Simple"){
$smsemail = "@smtext.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Straight Talk"){
$smsemail = "@vtext.com";
$smsprefix = $tempphone;
}if($cellcarrier == "T-Mobile"){
$smsemail = "@tmomail.net";
$smsprefix = $tempphone;
}if($cellcarrier == "TracFone"){
$smsemail = "@mmst5.tracfone.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Metro PCS"){
$smsemail = "@mymetropcs.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Nextel"){
$smsemail = "@messaging.nextel.com";
$smsprefix = $tempphone;
}if($cellcarrier == "O2"){
$smsemail = "@mobile.celloneusa.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Orange"){
$smsemail = "@mobile.celloneusa.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Qwest"){
$smsemail = "@qwestmp.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Rogers Wireless"){
$smsemail = "@pcs.rogers.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Telus Mobility"){
$smsemail = "@msg.telus.com";
$smsprefix = $tempphone;
}if($cellcarrier == "US Cellular"){
$smsemail = "@email.uscc.net";
$smsprefix = $tempphone;
}if($cellcarrier == "Verizon"){
$smsemail = "@vtext.com";
$smsprefix = $tempphone;
}if($cellcarrier == "Virgin Mobile"){
$smsemail = "@vmobl.com";
$smsprefix = $tempphone;
}

if($addreceived != ""){
$smsreceived = "$addreceived \n\n";
}else{
$smsreceived = "";
}
if($addaction != ""){
$smsaction = "$addaction \n";
}else{
$smsaction = "";
}

$SMSHEADERS  = "From: $companyreply\r\nReply-To: $companyreply";
$smssubject = "Account Update";

$smsmessage = "****\n$smsreceived $smsaction****";
if($portals== "Yes"){
$smsmessage .= "\n\nLog into your account at $companywebsite to check your status at any time.";
}
$smsformsent = mail($smsprefix.$smsemail, $smssubject, $smsmessage, $SMSHEADERS, "-f $companyreply");  




}
//////////END SMS

//////////EMAIL TO BROKER
if($brokeremail != "" && $brokeremailnotify >= 1){
$subject3 = "$brokerfirstname, $clientinfoname 's account has been updated";
$message3 = "$companyskin$brokerfirstname, Here are the details of the update <BR><BR><b>Client Name:</b>  $clientinfoname<BR><B>Date:</B>  $adddate <BR><B>Received:</B>  $addreceived <BR><B>Action Taken:</B>  $addaction <BR><BR>";
if($portals== "Yes"){
$message3 .= "Remember, you can log into your account at <a href=$companywebsite/brokers>$companywebsite/brokers</a> to check this client in detail at anytime.   <BR><BR>Username - $brokerusername <BR>Password - $brokerpassword";
}
if($privatelabel== "No"){
$message3 .= $poweredbymessage;
}



$formsent3 = mail($brokeremail, $subject3, $message3, $HEADERS, "-f $companyreply");  
}

}

    if($_POST['addpay'] == 1)
    {
        $date_array = split("-", $paymentmade);
        $paymentmade = $date_array[2]."-".$date_array[0]."-".$date_array[1];
        $query = "INSERT INTO payments(clientid, paymentmade)
                VALUES(
                '" . $_SESSION['clientid'] . "',
                '$paymentmade'
                )";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    }


    if($_POST['delpay'] == 1)
    {
        $query = "DELETE FROM payments WHERE id='" . mysql_real_escape_string($_POST['delid']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    }

    if($_POST['editpay'] == 1)
    {
        $date_array = split("-", $editpayment);
        $editpayment = $date_array[2]."-".$date_array[0]."-".$date_array[1];
        $query = "UPDATE payments SET paymentmade='$editpayment' WHERE id='" . mysql_real_escape_string($_POST['editid']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    }

   
  



if ($_POST['action'] == "addpic")
if ($HTTP_POST_VARS['submit']) {
  print_r($HTTP_POST_FILES);
  if (!is_uploaded_file($HTTP_POST_FILES['file']['tmp_name'])) {
    $error = "You did not upload a file!";
    unlink($HTTP_POST_FILES['file']['tmp_name']);
    // assign error message, remove uploaded file, redisplay form.
  } else {
    //a file was uploaded
    $maxfilesize=907200;


    if ($HTTP_POST_FILES['file']['size'] > $maxfilesize) {
      $error = "file is too large"; unlink($HTTP_POST_FILES['file']['tmp_name']);
      // assign error message, remove uploaded file, redisplay form.
    } else {

      if ($HTTP_POST_FILES['file']['type'] == "image/gif"){
		//File has passed all validation, copy it to the final destination and remove the temporary file:
		$jpg = ".gif";
		$successupload = "yes";
		copy($HTTP_POST_FILES['file']['tmp_name'],"$upload".$_POST['ssnforfile'].$jpg);
       unlink($HTTP_POST_FILES['file']['tmp_name']);
       $error = "AV and SSN file successfully uploaded!";
	  }else if ($HTTP_POST_FILES['file']['type'] == "image/pjpeg"){
		$jpg = ".jpg";
		$successupload = "yes";
		copy($HTTP_POST_FILES['file']['tmp_name'],"$upload".$_POST['ssnforfile'].$jpg);
       unlink($HTTP_POST_FILES['file']['tmp_name']);
       $error = "AV and SSN file successfully uploaded!";
	  }else if ($HTTP_POST_FILES['file']['type'] == "application/pdf"){
		$jpg = ".pdf";
		$successupload = "yes";
		copy($HTTP_POST_FILES['file']['tmp_name'],"$upload".$_POST['ssnforfile'].$jpg);
       unlink($HTTP_POST_FILES['file']['tmp_name']);
       $error = "AV and SSN file successfully uploaded!";
	  }else{ 
		  		$successupload = "no";

        $error = "This file type is not allowed";
        unlink($HTTP_POST_FILES['file']['tmp_name']);
        // assign error message, remove uploaded file, redisplay form.
      }
      


if ($successupload=="yes") {
$httpurl = "proofs/";
$file = $_POST['ssnforfile'].$jpg;
$newurl = $httpurl.$file;

$query = "UPDATE clients SET
                avssnurl='$newurl'
                WHERE id='" . $_SESSION['clientid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Add AV/SSN Image',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

       
     
    } 
  }
}
  if ($_POST['action'] == "removepic")
    {
        $query = "UPDATE clients SET
                avssnurl=''
                WHERE id='" . $_SESSION['clientid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Remove AV/SSN Image',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

    }
 if ($_POST['addappt'] == "yes"){
    
 if ($calhour !="") {
     $client_id=$_SESSION['clientid'];
$client_name=$_SESSION['clname'];
$client_nameforlink=str_replace(" ", "%20", "$client_name");     
     
   
     
  $loggedinuser = $_SESSION['usname'];
$webpage = "setclient.php?cid=$client_id&cname=$client_nameforlink";
$typeofreminder = "(Client)";
if (($calampm == "pm") && ($calhour < 12)){
$calhour += 12;
}
 if (($calampm == 'am') && ($calhour == 12)){
$calhour = 0;
}
 if ($priority == ""){
$priority = "";
}else  if ($priority == "Medium"){
$priority = "(Medium Priority)";
}else if ($priority == "High"){
$priority = "(HIGH Priority)";
}

$date = mktime ( 3, 0, 0, $calmonth, $calday, $calyear );
  $str_cal_date = date ( "Ymd", $date );
  $changefollowup = date ( "Y-m-d", $date );
  $str_cal_time = sprintf ( "%d%02d00", $calhour, $calminute );
  $modtime = date ( "Gis" );
  
$sqlcal1 = "INSERT INTO calendar (cal_contactid, cal_create_by, cal_date, cal_time, cal_mod_date, cal_mod_time, cal_name, cal_link, cal_description)
			VALUES(
	\"$client_id\",
	\"$loggedinuser\",
	\"$str_cal_date\",
	\"$str_cal_time\",
	\"$julian\",
	\"$modtime\",
	\"Call $client_name $typeofreminder $priority\",
	\"$webpage\",
	\"$note\")";
                $result = mysql_query($sqlcal1, $conn) or die("error:" . mysql_error());
}








    }


    $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, comments, reseller_id, status, plan, DATE_FORMAT(dateresults, \"%m-%d-%Y\") as dateresults, singlecouple, showstatus, budgetday, avssnurl, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, altphone, dateresults, fonttype, jointwith, prospectclient, sendtohtdi, pp, altphone2, altphone3, altphone4, DATE_FORMAT(canceldate, \"%m-%d-%Y\") as canceldate, cellphone, cellcarrier  FROM clients WHERE id='" . $_SESSION['clientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $usernameu = $row[11];
        $pwdu = $row[12];
        $broker_id = $row[13];
	  $dealer_id = $row[14];
	  $affiliate_id = $row[15];
	  $comments = $row[16];
	  $reseller_id = $row[17];
	  $status = $row[18];
	  $plan = $row[19];
	  $dateresults = $row[20];
	  $singlecouple = $row[21];
	  $showstatus = $row[22];	  
	  $budgetday = $row[23];	  	  
	  $avssnurl = $row[24];	  	  	  
  	  $logins = $row[25];	  	 
	  $lastlogin = $row[26];	  	   	  
	  $altphone = $row[27];	  	   	  
	  $dateresults2 = $row[28];	  
	  $fonttype = $row[29];	  	  
	  $jointwith = $row[30];	  	 	  
	  $prospectclient = $row[31];		  
	  $sendtohtdi = $row[32];		  
  	  $pp = $row[33];	  
  	  $altphone2 = $row[34];	  
  	  $altphone3 = $row[35];	  
  	  $altphone4 = $row[36];	 
  	  $canceldate = $row[37];	 
  	  $cellphone = $row[38];	 
  	  $cellcarrier = $row[39];	 
    }
    

	if($dateresults !="00-00-0000"){
$sendday = dateDiff("-", $dateresults, $todaydate2);
}else{
$sendday = "N/A";
}

    $SA_sql = "SELECT font FROM fonttypes ORDER BY font";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $font = $srow['font'];



               
		$font_select .= "<option value=\"$font\">$font</option>";
		
}


    $query = "SELECT DATE_FORMAT(dateenrol, \"%m-%d-%Y\") as dateenrol,  DATE_FORMAT(reportreceived, \"%m-%d-%Y\") as repdate, DATE_FORMAT(addressreceived, \"%m-%d-%Y\") as adddate, DATE_FORMAT(ssdate, \"%m-%d-%Y\") as ssdate, DATE_FORMAT(welcomepacket, \"%m-%d-%Y\") as welcomedate, DATE_FORMAT(returndoc, \"%m-%d-%Y\") as returndoc, DATE_FORMAT(dateexpire, \"%m-%d-%Y\") as dateexpire, dateexpire  FROM enrolment WHERE clientid='" . $_SESSION['clientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dateenrol = $row[0];
        $reportreceived = $row[1];
        $addressreceived = $row[2];
        $ssdate = $row[3];
        $welcomepacket = $row[4];
        $returndoc = $row[5];
        $dateexpire = $row[6];
        $dateexpire2 = $row[7];

   }


    $query = "SELECT auditfee, DATE_FORMAT(paid, \"%m-%d-%Y\") as paid, monthlyfee, monthlydue, payment, onlinepayment, bankname, bankrtg, bankact, checknum, aba, holder, holderaddress, holdercity, holderstate, holderzip FROM billing WHERE clientid='" . $_SESSION['clientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $auditfee = $row[0];
        $paid = $row[1];
        $monthlyfee = $row[2];
        $monthlydue = $row[3];
        $payment = $row[4];
        $onlinepayment = $row[5];
    	  $bankname = $row[6];	  
	  $bankrtg = $row[7];	  
	  $bankact = $row[8];	
	  $checknum = $row[9];		  
	  $aba = $row[10];		  
	  $holder = $row[11];		  
	  $holderaddress = $row[12];		  
	  $holdercity = $row[13];		  
	  $holderstate = $row[14];		  
	  $holderzip = $row[15];		  

    }
    
    



    //mysql_close($conn);
?>
<?php



/* Connection to Joint Accounts */

		$SA_sql = "SELECT id, name, address FROM clients WHERE singlecouple = 'Joint' and (jointwith = '' or jointwith = '" . $_SESSION['clientid'] . "') and reseller_id = '' ORDER BY id";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $jointid = $srow['id'];
		    $jointname = $srow['name'];
		    $jointaddress = $srow['address'];		    



                if ($username == "$user") {
		$joint_select .= "<option value=\"$jointid\">$jointname -- ($jointaddress)</option>";
		}else{
		$joint_select .= "<option value=\"$jointid\">$jointname -- ($jointaddress)</option>";
		}

		$ARUSERS{"$jointname"} = "$jointid";
		
		}

$SA_sql = "SELECT name FROM clients where id='$jointwith'";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $jointcurrentname = $srow['name'];
		}

/* Connection to Affiliates People */

		$SA_sql = "SELECT * FROM sales_affiliates WHERE type='Affiliate' AND status !='del' ORDER BY lname";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $affiliateid = $srow['id'];
		    $fname = $srow['fname'];
		    $lname = $srow['lname'];
		$user_select6 .= "<option value=\"$affiliateid\">$lname, $fname</option>";

		}

$SA_sql = "SELECT fname,lname FROM sales_affiliates where id='$affiliate_id'";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $affiliatefirstname = $srow['fname'];
		    $affiliatelastname = $srow['lname'];
		}


/* Connection to Brokers */

		$SA_sql = "SELECT * FROM dealers WHERE status !=9 ORDER BY lastname LIMIT 1000";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $dealerid = $srow['dealer_id'];
		    $firstname = $srow['firstname'];
		    $lastname = $srow['lastname'];


		$user_select5 .= "<option value=\"$dealerid\">$lastname, $firstname</option>";
		}

$SA_sql = "SELECT firstname,lastname,email,username,password, emailnotify FROM dealers where dealer_id='$broker_id' and status !=9";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $brokerfirstname = $srow['firstname'];
		    $brokerlastname = $srow['lastname'];
		    $brokeremail = $srow['email'];		    
		    $brokerusername = $srow['username'];		
		    $brokerpassword = $srow['password'];				    		    
		    $brokeremailnotify = $srow['emailnotify'];				    		    
		}


/* Connection to Sales */

		$SA_sql = "SELECT id, fname, lname FROM sales_affiliates WHERE type='Sales' and status !='del' ORDER BY lname";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $sales_id = $srow['id'];
		    $fname = $srow['fname'];
		    $lname = $srow['lname'];
			$user_select7 .= "<option value=\"$sales_id\">$lname, $fname</option>";
		}

$SA_sql = "SELECT fname,lname FROM sales_affiliates where id='$dealer_id'";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $salesfirstname = $srow['fname'];
		    $saleslastname = $srow['lname'];
		}




if ($status == "pending"){
	        $bgcolor = "FFFF00"; 
	        
  }
  else if ($status == "canceled"){
	        $bgcolor = "98877e";
	       
	}
    else if ($status == "NSF"){
	        $bgcolor = "FF00FF";
	       
	}

	  else if ($status == "contact1"){
	        $bgcolor = "FF4444";
	       
	}
  else if ($status == "contact2"){
	        $bgcolor = "FF0000";
	       
	}
  else if ($status == "contact3"){
	        $bgcolor = "888888";
	       
	}
  else if ($status == "inactive"){
	        $bgcolor = "888888";
	       
	}
else if ($status == "complete"){
	        $bgcolor = "008000";
	       
	}
else if ($status == "scheduled"){
	        $bgcolor = "FFCCCC";
	       
	}
else if ($status == "expired"){
	        $bgcolor = "888888";
	       
	}
	else if ($plan == "Budget"){
	        $bgcolor = "c0c0c0";
	       
	}
	
else if ($dateresults2 <= date("Y-m-d")){
	        $bgcolor = "FF6666";
	       
	}
else{

$bgcolor = "c0c0c0";
}

if ($prospectclient == "Prospect" or $_SESSION['usaccess']=="sales"){
?>
<font color="red"><B>You do not have access to this area </font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 }else {
 if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")
    {
$menuwidth = 99;
}else{
$menuwidth = 118;
}

?>
 <title>Client Status Sheet</title>

                 <font color="red">  <B> <?php print($error); ?></B></font>
                            <?php
    include('main.php');
   ?>     
   <style type="text/css"> 
/* <![CDATA[ */

textarea
{
	clear: both;
	display: block;
	padding: 4px 4px 4px 4px;
	border: 0px;
	font-family: Verdana, sans-serif; 
	font-size: 11px;

}
 
/* ]]> */
</style>
  
          

<script language="JavaScript" fptype="dynamicanimation">
<!--
function dynAnimation() {}
function clickSwapImg() {}
//-->
</script>
 <script type="text/javascript">

	subject_id = '';
	function handleHttpResponse() {
		if (http.readyState == 4) {
			if (subject_id != '') {
				document.getElementById(subject_id).innerHTML = http.responseText;
			}
		}
	}
	function getHTTPObject() {
		var xmlhttp;
		/*@cc_on
		@if (@_jscript_version >= 5)
			try {
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (E) {
					xmlhttp = false;
				}
			}
		@else
		xmlhttp = false;
		@end @*/
		if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
			try {
				xmlhttp = new XMLHttpRequest();
			} catch (e) {
				xmlhttp = false;
			}
		}
		return xmlhttp;
	}
	var http = getHTTPObject(); // We create the HTTP Object

	function getScriptPage(div_id,content_id)
	{
		subject_id = div_id;
		content = document.getElementById(content_id).value;
		http.open("GET", "template.php?searchpage=client&content=" + escape(content), true);
		http.onreadystatechange = handleHttpResponse;
		http.send(null);
		if(content.length>0)
			box('1');
		else
			box('0');

	}	

	function highlight(action,id)
	{
	  if(action)	
		document.getElementById('word'+id).bgColor = "#184EAE";
	  else
		document.getElementById('word'+id).bgColor = "#2E2E2E";
	}
	function display(word)
	{
		document.getElementById('text_content').value = word;
		document.getElementById('box').style.display = 'none';
		document.getElementById('text_content').focus();
	}
	function box(act)
	{
	  if(act=='0')	
	  {
		document.getElementById('box').style.display = 'none';

	  }
	  else
		document.getElementById('box').style.display = 'block';
		document.getElementById('topbox').style.display = 'block';
	}
	</script> 

	<SCRIPT LANGUAGE="JavaScript" SRC="CalendarPopup.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript">document.write(getCalendarStyles());</SCRIPT>
<SCRIPT LANGUAGE="JavaScript">
var cal = new CalendarPopup("testdiv1");
cal.setReturnFunction("setMultipleValues3"); 
function setMultipleValues3(y,m,d) { 
     document.setappt.calyear.value=y; 
     document.setappt.calmonth.selectedIndex=m; 
     document.setappt.calday.selectedIndex=d; 
     }
     
</script> 


 <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber4">
                          <tr>
                            <td width="33%">
                            
                            <form action="search.php" method="get">
        <table>
            <tr>
               
                <td class='ss-round-inputs' class="pointer" width="34%">
                            <div class="ajax-div">
	<div class="input-div">
	&nbsp;
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" Value="Quick Client Switch" onKeyUp="getScriptPage('box','text_content')" id="text_content" size="40" 
	onblur="if(this.value.length == 0) this.value='Quick Client Switch';" onclick="if(this.value == 'Quick Client Switch') this.value='';"><img border="0" src="input-right.gif" width="7" >
	</div>

	<div id="box"></div>
</div></td>
               
            </tr>
            </table>
        
    </form>

                            
                            
                            
                            
                            
                            </td>
                            <td  valign="top" width="33%">
                            
                            
                            
                            
                            <p align="center">
                                      
<div align="center">
  <center>
<table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="50" id="AutoNumber4" cellpadding="0" height="18">
                          
                        <tr>
                            <td width="50%" height="33">
                            <a onmouseover="document['fpAnimswapImgFP1'].imgRolln=document['fpAnimswapImgFP1'].src;document['fpAnimswapImgFP1'].src=document['fpAnimswapImgFP1'].lowsrc;" onmouseout="document['fpAnimswapImgFP1'].src=document['fpAnimswapImgFP1'].imgRolln" href="clientstatus.php">
                            <img border="0" src="cssoff.gif" id="fpAnimswapImgFP1" name="fpAnimswapImgFP1" dynamicanimation="fpAnimswapImgFP1" lowsrc="csson.gif" width="97" height="31"></a></td>
                            <td width="25%" height="33">
                            <a href="creditreport.php" onmouseover="document['fpAnimswapImgFP2'].imgRolln=document['fpAnimswapImgFP2'].src;document['fpAnimswapImgFP2'].src=document['fpAnimswapImgFP2'].lowsrc;" onmouseout="document['fpAnimswapImgFP2'].src=document['fpAnimswapImgFP2'].imgRolln">
                            <img border="0" src="rtoff.gif" id="fpAnimswapImgFP2" name="fpAnimswapImgFP2" dynamicanimation="fpAnimswapImgFP2" lowsrc="rton.gif" width="97" height="31"></a></td>
                            <td width="25%" height="33">
                            <a href="creditreportnodelete.php" onmouseover="document['fpAnimswapImgFP4'].imgRolln=document['fpAnimswapImgFP4'].src;document['fpAnimswapImgFP4'].src=document['fpAnimswapImgFP4'].lowsrc;" onmouseout="document['fpAnimswapImgFP4'].src=document['fpAnimswapImgFP4'].imgRolln">
                            <img border="0" src="rtoffoo.gif" id="fpAnimswapImgFP4" name="fpAnimswapImgFP4" dynamicanimation="fpAnimswapImgFP4" lowsrc="rtonoo.gif" width="97" height="31"></a></td>
                            
                              <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")
    {
        ?>
                            <td width="25%" height="33">
                            <a href="javascript:OpenWindow2('letters.php','1024','768')" onmouseover="document['fpAnimswapImgFP5'].imgRolln=document['fpAnimswapImgFP5'].src;document['fpAnimswapImgFP5'].src=document['fpAnimswapImgFP5'].lowsrc;" onmouseout="document['fpAnimswapImgFP5'].src=document['fpAnimswapImgFP5'].imgRolln">
                            <img border="0" src="lmoff.gif" id="fpAnimswapImgFP5" name="fpAnimswapImgFP5" dynamicanimation="fpAnimswapImgFP5" lowsrc="lmon.gif" width="97" height="31"></a></td>
                            <?php
}
        ?>

                            
                            <td width="25%" height="33">
                            <a href="search.php?cname=&zip=&email=&f=1&Find=Find" onmouseover="document['fpAnimswapImgFP3'].imgRolln=document['fpAnimswapImgFP3'].src;document['fpAnimswapImgFP3'].src=document['fpAnimswapImgFP3'].lowsrc;" onmouseout="document['fpAnimswapImgFP3'].src=document['fpAnimswapImgFP3'].imgRolln">
                            <img border="0" src="searchoff.gif" id="fpAnimswapImgFP3" name="fpAnimswapImgFP3" dynamicanimation="fpAnimswapImgFP3" lowsrc="searchon.gif" width="97" height="31"></a></td>
                          </tr>
                          <tr>
                            <td width="50%" height="1">
                            </td>
                            <td width="25%" valign="top" height="1">
                            <p align="center">
                            <a href="creditreport.php?bureauid=1">
                            <img border="0" src="efx.gif" width="32" height="10"></a><a href="creditreport.php?bureauid=2"><img border="0" src="exp.gif" width="32" height="10"></a><a href="creditreport.php?bureauid=3"><img border="0" src="tu.gif" width="32" height="10"></a></td>
                            <td width="25%" valign="top" height="1">
                            <p align="center">
                            <a href="creditreportnodelete.php?bureauid=1">
                            <img border="0" src="efx.gif" width="32" height="10"></a><a href="creditreportnodelete.php?bureauid=2"><img border="0" src="exp.gif" width="32" height="10"></a><a href="creditreportnodelete.php?bureauid=3"><img border="0" src="tu.gif" width="32" height="10"></a></td>
                            
                            <td width="25%" height="1">
                            </td>

                            
                            <td width="25%" height="1">
                            </td>
                          </tr>
</table>

            
            
            </center>
</div></td>
                           
                            
                            
                            
                             <td>&nbsp;

                </td>
                          </tr>
                          </table>


            
            
            </p></center> 
                        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="95%" id="AutoNumber3">
                      
    <tr>
                            <td width="50%" valign="top">
                            
 
 <p>
     
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="455">
<tr>
<td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="414">Broker/Affiliate/Sales Set</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td>
</tr>

<tr>
<td width="450" bgcolor="#6666FE" style="padding-left:5px" colspan="3">
<form name="affiliate" action="affiliatechange.php" method="post" onSubmit = "return validate2(affiliate)";>
<input type="hidden" name="oldaffiliate" value="<?php print($affiliate_id); ?>">     
<?php
if($_SESSION['affiliate']=="Yes" && $affiliate_id !=""){

?>
<a STYLE="text-decoration: none; color: black;" href="setaffiliate.php?cid=<?php print($affiliate_id); ?>&cname=<?php print($affiliatefirstname); ?> <?php print($affiliatelastname); ?>">Affiliate</a> - 
<?php
}else{
?>
Affiliate - 
<?php
}
?>
<select name="affiliate_id"  class="txtbox" >
<option value="<?php print($affiliate_id); ?>" selected><?php print($affiliatelastname); ?>, <?php print($affiliatefirstname); ?></option>
<? echo "$user_select6"; ?>
<option value="">----Remove Affiliate from this client----</option>
</select>
<font color="#FF0000"><B><?php print($rep_id); ?></B></font>
                           
 
    




<?php
             if($country =="" or $country=="United States")   {
 $countryquery = "WHERE country = 'United States'";
 } else if($country=="Canada")   {
 $countryquery = "WHERE country = '$country'";
 } else{
 $countryquery = "WHERE country = '$country'";
 }


    if($showbargraph =="Yes"){


                  $query = "SELECT id, type FROM accounttype $countryquery "; 
      $result = mysql_query($query, $conn) or die("error:" . mysql_error());
      $col_count = mysql_num_fields($result);
      while($row=mysql_fetch_row($result))
      {
        $actypeid = $row[0];
        $actype = $row[1];


   $query3 = "SELECT count(deleted) FROM accounts WHERE (deleted='Deleted' OR deleted='Fixed') and accounttype='$actypeid' and clientid='" . $_SESSION['clientid'] . "'";
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $deleted2 = $row3[0];
                   $i = $i+1;
}
 $query4 = "SELECT count(id) FROM accounts WHERE accounttype='$actypeid' and clientid='" . $_SESSION['clientid'] . "'";
              $result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result4))
              {
                   $totalaccts = $row3[0];
                   $i = $i+1;
}

$totaldeletes = $totaldeletes + $deleted2;
$totalaccounts = $totalaccounts + $totalaccts;
$percentagefixed = @($deleted2/$totalaccts*100);
$datavalues .= "<set label='$actype' value='$percentagefixed' />";
   }  
 
 
 
 $query5 = "SELECT count(deleted) FROM accounts WHERE (deleted='Deleted' OR deleted='Fixed') AND beginstatus NOT LIKE 'Not%' and clientid='" . mysql_real_escape_string($_SESSION['clientid']) . "'";
              $result5 = @mysql_query($query5, $conn) or die("error:" . mysql_error());
              while($row5=mysql_fetch_row($result5))
              {
                   $deleted3 = $row5[0];
                   $i = $i+1;
}

 $query6 = "SELECT count(id) FROM accounts WHERE beginstatus NOT LIKE 'Not%' AND clientid='" . mysql_real_escape_string($_SESSION['clientid']) . "'";
              $result6 = @mysql_query($query6, $conn) or die("error:" . mysql_error());
              while($row6=mysql_fetch_row($result6))
              {
                   $totalaccounts2 = $row6[0];
                   $i = $i+1;
}

}//END IF CHART
if($totalaccounts !=""){
$delpercentage = $totaldeletes/$totalaccounts*100;
}
$delpercentage = number_format($delpercentage, 2, '.', '');

 
if($_SESSION['affiliate']=="Yes" AND $_SESSION['usaccess']=="full" AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete")
{
?>
         <input class="txtboxclear" type="submit" name="Update" value="Update" ><BR>
<input type="hidden" name="updateaffiliate" value="1">
<?php } ?>
</form>
     
     
     </td>
   </tr>
   
   
<tr>
<td width="450" bgcolor="#6666FE"  style="padding-left:5px" colspan="3">
<form name="brokers" action="affiliatechange.php"    method="post" onSubmit = "return validate3(brokers)";>
<input type="hidden" name="oldbroker" value="<?php print($broker_id); ?>">
<?php
if($_SESSION['brokers']=="Yes"  && $broker_id !=""){
?>
<a STYLE="text-decoration: none; color: black;" href="setbroker.php?cid=<?php print($broker_id); ?>&cname=<?php print($brokerfirstname); ?> <?php print($brokerlastname); ?>">Broker</a> - 
<?php
}else{
?>
Broker - 
<?php
}
?>

<select name="broker_id" class="txtbox"  >
<option value="<?php print($broker_id); ?>" selected><?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?></option>
<? echo "$user_select5"; ?>
<option value="">----Remove Broker from this client----</option>
</select>
<?php
if($_SESSION['usaccess']=="full" AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete"){
?>
<input class="txtboxclear" type="submit" name="Update" value="Update" ><BR>
<input type="hidden" name="updatebroker" value="1">
<?php } ?>
</form>
     </td>
   </tr>

   <tr>
<td width="450" bgcolor="#6666FE"  style="padding-left:5px" colspan="3">
<form name="sales" action="affiliatechange.php"    method="post" onSubmit = "return validate4(sales)";>
<input type="hidden" name="oldsales" value="<?php print($dealer_id); ?>">
Sales - <select name="sales_id" class="txtbox"  >
<option value="<?php print($dealer_id); ?>" selected><?php print($saleslastname); ?>, <?php print($salesfirstname); ?></option>
<? echo "$user_select7"; ?>
<option value="">----Remove Sales Person from this client----</option>
</select>
 <?php

    if($_SESSION['usname']=="admin" AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete")
    {
        ?>
        <input class="txtboxclear" type="submit" name="Update" value="Update" ><BR>
<input type="hidden" name="updatesales" value="1">
<?php } ?>

</form>
     </td>
   </tr>



 </table>






<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="455">
<tr><td width="1"><img border="0" src="bottomleftcorner.gif" ></td>
<td class="miniheaders" background="bottombackground.gif" width="99%"></td>
<td width="1"><img border="0" src="bottomrightcorner.gif"></td></tr>
</table>
 <p>
     
<p>
 
















 <form  name="inform" action="" method="post" >
<input type="hidden" name="clientonform" value="<?php print($clientid); ?>">



 <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" id="AutoNumber7" >
                           

   <!-- START HELPDESK EMBED -->
                        <tr>
                                <td valign="top" colspan="5">

  <?php
   

  $queryh = "SELECT id, status, subject, description, DATE_FORMAT(date, \"%m-%d-%Y\") as hdlogdate,  tstamp, ip, clientid FROM helpdesk WHERE clientid ='" . $_SESSION['clientid'] . "' ORDER BY id DESC LIMIT 3"; 
    $resulth = mysql_query($queryh, $conn) or die("error:" . mysql_error());
    $col_counth = mysql_num_rows($resulth);
    if($col_counth !=""){
        ?>





<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="90%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Recent Helpdesk Tickets <?php print($smsprefix); ?><?php print($smsemail); ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
<table width="90%" border="0" cellspacing="1" cellpadding="4">
 <tr bgcolor="#DEDEEB"> 
  <td height="11" width="81" colspan="2"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Call ID</font></td>
<td width="59"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Status</font></td>
              <td height="11" width="495">
<font size="1" face="Verdana, Arial, Helvetica, sans-serif">Subject</font>              </td>
              <td height="11" width="137"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Logged</font></td>
            </tr>



     <?php
    while($row=mysql_fetch_row($resulth))
    {
        $hdid= $row[0];
        $hdstatus = $row[1];
        $hdsubject = $row[2];
        $hddescription = $row[3];
        $hdlogdate= $row[4];
        $hdtstamp= $row[5];
        $hdip= $row[6];
        $hdclid= $row[7];

        ?>
  

            
           <tr bgcolor="#f1f1f1">

              <td height="11" width="46"><center>
              <img src="../client/mail.gif" width="11" height="9"></center></td>
              <td height="11" width="26"><a href="viewticket.php?helpdeskid=<?php print($hdid); ?>"><?php print($hdid); ?></a>
              </td>
              <td height="11" width="59"><?php print($hdstatus); ?></td>
              <td height="11" width="495">
               <a href="viewticket.php?helpdeskid=<?php print($hdid); ?>"><?php print($hdsubject); ?></a>
              </td>
              <td height="11" width="137"><?php print($hdlogdate); ?></td>
            </tr>
 <?php
    }
    //mysql_close($conn);
    ?>



          </table>

</div>

     <?php
    } // END IF HELPDESK
      ?>
  
</td>
                              
                              </tr>
<!-- END HELPDESK EMBED -->






   <tr>
                                <td width="13%" height="20"></td>
                                <td class='ss-round-inputs' width="37%" colspan="2" height="20"> </td>
                                <td width="25%" height="20"></td>
                                <td width="25%" height="20">&nbsp;</td>
                              </tr>

   <tr>
                                <td width="13%" height="20">Username</td>
                                <td class='ss-round-inputs' width="37%" colspan="2" height="20"> 
<img border="0" src="input-left.gif" width="7" ><input type="text" class="txtbox" class="txtbox" name="usernameu" value="<?php print($usernameu);?>" size="29"><img border="0" src="input-right.gif" width="7" ></td>
                                <td width="25%" height="20">Number of logins - <b><?php print($logins); ?></b></td>
                                <td width="25%" height="20">&nbsp;</td>
                              </tr>
                              <tr>
                                <td width="13%" height="20">Password</td>
                                <td class='ss-round-inputs' width="37%" colspan="2" height="20"> 
<img border="0" src="input-left.gif" width="7" ><input type="text" class="txtbox" class="txtbox" name="pwdu" value="<?php print($pwdu);?>" size="29"><img border="0" src="input-right.gif" width="7" ></td>
                                <td width="50%" colspan="2" height="20">Date of Last login - <b><?php print($lastlogin); ?></b></td>
                              </tr>
   




                             
                            </table></td>
                            <td width="50%" valign="top">
                            
                           

                             <p align="center" >
                                                
    <?php
    if($showbargraph =="Yes")
    {

    if($totalaccounts !="")
    {
       function encodeDataURL($strDataURL, $addNoCacheStr=false) {
    if ($addNoCacheStr==true) {
		if (strpos($strDataURL,"?")<>0)
			$strDataURL .= "&FCCurrTime=" . Date("H_i_s");
		else
			$strDataURL .= "?FCCurrTime=" . Date("H_i_s");
    }
	return urlencode($strDataURL);
}


function datePart($mask, $dateTimeStr) {
    @list($datePt, $timePt) = explode(" ", $dateTimeStr);
    $arDatePt = explode("-", $datePt);
    $dataStr = "";
    if (count($arDatePt) == 3) {
        list($year, $month, $day) = $arDatePt;
        // determine the request
        switch ($mask) {
        case "m": return $month;
        case "d": return $day;
        case "y": return $year;
        }
        return (trim($month . "/" . $day . "/" . $year));
    }
    return $dataStr;
}


function renderChart($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false, $registerWithJS=false, $setTransparent="true") {
	if ($strXML=="")
        $tempData = "//Set the dataURL of the chart\n\t\tchart_$chartId.setDataURL(\"$strURL\")";
    else
        $tempData = "//Provide entire XML data using dataXML method\n\t\tchart_$chartId.setDataXML(\"$strXML\")";

    $chartIdDiv = $chartId . "Div";
    $ndebugMode = boolToNum($debugMode);
    $nregisterWithJS = boolToNum($registerWithJS);
	$nsetTransparent=($setTransparent?"true":"false");
$render_chart = <<<RENDERCHART

	<!-- START Script Block for Chart $chartId -->
	<div id="$chartIdDiv" align="center">
		Chart.
	</div>
	<script type="text/javascript">	
		var chart_$chartId = new FusionCharts("$chartSWF", "$chartId", "$chartWidth", "$chartHeight", "$ndebugMode", "$nregisterWithJS");
      chart_$chartId.setTransparent("$nsetTransparent");
    
		$tempData
		chart_$chartId.render("$chartIdDiv");
	                         </script>	
	<!-- END Script Block for Chart $chartId -->
RENDERCHART;

  return $render_chart;
}


function renderChartHTML($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false,$registerWithJS=false, $setTransparent="true") {
    $strFlashVars = "&chartWidth=" . $chartWidth . "&chartHeight=" . $chartHeight . "&debugMode=" . boolToNum($debugMode);
    if ($strXML=="")
        $strFlashVars .= "&dataURL=" . $strURL;
    else
        $strFlashVars .= "&dataXML=" . $strXML;
    
    $nregisterWithJS = boolToNum($registerWithJS);
    if($setTransparent!=""){
      $nsetTransparent=($setTransparent==false?"opaque":"transparent");
    }else{
      $nsetTransparent="window";
    }
$HTML_chart = <<<HTMLCHART
	<!-- START Code Block for Chart $chartId -->
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" 

codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="$chartWidth" height="$chartHeight" id="$chartId">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="$chartSWF"/>		
		<param name="FlashVars" value="$strFlashVars&registerWithJS=$nregisterWithJS" />
		<param name="quality" value="high" />
		<param name="wmode" value="$nsetTransparent" />
		<embed src="$chartSWF" FlashVars="$strFlashVars&registerWithJS=$nregisterWithJS" quality="high" width="$chartWidth" height="$chartHeight" 

name="$chartId" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" 

wmode="$nsetTransparent" /></object>
	<!-- END Code Block for Chart $chartId -->
HTMLCHART;

  return $HTML_chart;
}

function boolToNum($bVal) {
    return (($bVal==true) ? 1 : 0);
}





	$fixed = $deleted2/$totalaccounts*100;
	$open = ($totalaccounts-$deleted2)/($totalaccounts)*100;
$strXML  = "<chart numberSuffix='%25' chartLeftMargin='0' bgAlpha='0,0' caption='Items fixed/deleted: $totaldeletes out of $totalaccounts ($delpercentage%25)'  

chartBottomMargin='0' decimals='2' chartRightMargin='0' palette='2' labelDisplay='Rotate' slantLabels='1' numDivLines ='3' YAxisMaxValue 

='100' showPrintMenuItem='0' showValues='1' use3DLighting ='1' showAboutMenuItem='0' showBorder='0'>";
	$strXML .= "$datavalues";
	
	$strXML .= "<styles>";

$strXML .= "<definition>";

$strXML .= "<style name='myFont' type='font' isHTML='1' bold='1' size='11' color='FFFFFF' />";
$strXML .= "<style name='myShadow' type='shadow' color='333333' angle='45' strength='3'/>";
$strXML .= "<style name='myShadow2' type='shadow' angle='45' distance='1' color='FFFFFF'/>";
$strXML .= "<style name='myAnim3' type='animation' param='_xScale' start='0' duration='1'/>";
$strXML .= "<style name='myAnim4' type='animation' param='_alpha' start='0' duration='1'/>";
$strXML .= "<style name='myAnim5' type='animation' param='_xScale' start='0' duration='1'/>";
$strXML .= "<style name='myAnim6' type='animation' param='_y' start='$canvasStartY' duration='1'/>";
$strXML .= "</definition>";


$strXML .= "<application>";
$strXML .= "<apply toObject='DataValues' styles='myFont,myShadow,myAnim' />";
//$strXML .= "<apply toObject='DataLabels' styles='myFont,myShadow,myAnim' />";
$strXML .= "<apply toObject='DIVLINES' styles='myShadow2' />";
$strXML .= "<apply toObject='ANCHORS' styles='myAnim2' />";
$strXML .= "<apply toObject='ANCHORS' styles='myBevel' />";
$strXML .= "<apply toObject='HGRID' styles='myAnim3, myAnim4' />";
$strXML .= "<apply toObject='DIVLINES' styles='myAnim5' />";
$strXML .= "<apply toObject='YAXISVALUES' styles='myAnim6' />";
$strXML .= "</application>";

$strXML .= "</styles>";

	$strXML .= "</chart>";
	
	echo renderChartHTML("Column3D.swf", "", $strXML, "bargraph", 475, 275, false, false);
 }


////////END IF CHART
}
        ?>   



</td>
                          </tr>
                          </table>
                        
<!--
function validate(formCheck)
{
 if (formCheck.status.value =="inactive")
    {
        confirm("**ALERT**  By putting this client in an Inactive status, you are only able to view this record for historical purposes.  No updates will be able to be done.  Are you sure?"); 
   
    }
    
    if (formCheck.status.value =="canceled")
    {
        confirm("**ALERT**  By putting this client in an Canceled status, you are only able to view this record for historical purposes.  No updates will be able to be done.  Are you sure?"); 
   
    }
    if (formCheck.status.value =="archived")
    {
        confirm("**ALERT**  By putting this client in an Archived status, you are only able to view this record for historical purposes.  No updates will be able to be done.  Are you sure?"); 
   
    }
     if (formCheck.status.value =="complete")
    {
        confirm("**ALERT**  By putting this client in an Completed status, you are only able to view this record for historical purposes.  No updates will be able to be done.  Are you sure?"); 
   
    }

    }
    -->
                            <SCRIPT LANGUAGE="JavaScript">

    function validate2(formCheck)
{
   if (formCheck.affiliate_id.value =="")
    {
        return confirm("By removing the affiliate from this account, you will be removing any commission they have earned.  Are you sure you want to do this?"); 
   
    }  
    
    if (formCheck.affiliate_id.value !="")
    {
        return confirm("You are about to credit this affiliate with this commission.  Additionally, if you are changing to this affiliate from a different one in this system, you will be removing any commission the original affiliate has earned  Are you sure you want to do this?"); 
   
    }  

    
    
    }
    
     function validate3(formCheck)
{
   if (formCheck.broker_id.value =="")
    {
   return confirm("By removing this broker from this account, you will be removing any commission associated with this broker and will no longer be able to track this client or receive automatic email notifications.  Are you sure you want to do this?"); 
   
    }  
    
    if (formCheck.broker_id.value !="")
    {
           return confirm("You are about to tie this broker to this client.  This broker will be able to track this client's progress and receive automatic email updates and will earn any commission that has been established in the broker record.  Are you sure you want to do this?"); 
   
    }  

    
    
    }

    
         function validate4(formCheck)
{
   if (formCheck.sales_id.value =="")
    {
   return confirm("By removing this sales person from this account, you will be removing any commission associated with this sales person.  Are you sure you want to do this?"); 
   
    }  
    
    if (formCheck.sales_id.value !="")
    {
           return confirm("You are about to tie this sales person to this client.  This sales person will earn any commission that has been established in the sales record.  Are you sure you want to do this?"); 
   
    }  

    
    
    }
    
    
         </SCRIPT>


</B></font>
     
     
                       
                            
                            </p>
                            </p>
                          
                            
                            
                            
                            
                            
                           
                          Status Line (shows on their main menu)&nbsp;
                            <?php
  if($sendtohtdi != "Yes"){
        ?>
                            <input class="txtbox" size="100" name="showstatus" value="<?php print($showstatus); ?>">
                            <?php
  }else{
        ?>
 -- <?php print($showstatus); ?> <input class="txtbox" type=hidden size="121" name="showstatus" value="<?php print($showstatus); ?>">

                                        <?php
  
    }
        ?>               
                            
                            
                            
                            
                            <br>
                            
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="98%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Personal Information</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

                                                    <table style="BORDER-COLLAPSE: collapse" bordercolor="#000080"
                            cellspacing="0" cellpadding="0" width="98%" bgcolor="#<?php print($bgcolor);?>" border="0">
                                <tbody>
                                <tr>
                                    <td class='ss-round-inputs' width="25%" style="border-left-style: solid; border-left-width: 1" colspan="2">&nbsp;Name 
                                    
                                    
                                     <?php
  if($sendtohtdi != "Yes"){
        ?>

<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="clientinfoname" value="<?php print($name); ?>" size="30"><img border="0" src="input-right.gif" width="7" >
                                        
                                 <?php
  }else{
        ?>
     -- <?php print($name); ?>    <input class="txtbox" type=hidden name="clientinfoname" value="<?php print($name); ?>" size="37">
                                        <?php
  
    }
        ?>               
            
                                        
                                        
                                    </td>
                                    <td width="25%" style="border-right-style: solid; border-right-width: 1; border-top-style:none; border-top-width:medium">Status: <input type="hidden" name="oldstatus" value="<?php print($status); ?>">
									<select name="status" class="txtbox" >
                <option value="<?php print($status); ?>" selected><?php print($status); ?></option>
                 <?php
  if($sendtohtdi != "Yes"){
        ?>
<option value="pending">pending</option>
                <option value="active">active</option>
                <option value="complete">complete</option>
                <option value="scheduled">scheduled</option>
                <option value="contact1">contact1</option>
                <option value="contact2">contact2</option>
                <option value="contact3">contact3</option>                
                <option value="inactive" >inactive</option> 
                <option value="expired" >expired</option> 
                <option value="NSF">NSF</option> 
                     <?php
  
    }
        ?>

   
   <?php
  if($sendtohtdi == "Yes" && $status!="canceled"){
        ?>
                <option value="NSF">NSF</option> 
           <?php
}
        ?>
 
   <?php
  if($sendtohtdi == "Yes" && $status=="NSF"){
        ?>
                <option value="active">active</option>
                <option value="canceled">canceled</option> 
  <?php
}
        ?>
                <option value="canceled">canceled</option> 


  
              </select> </td>
                                    <td class='ss-round-inputs' width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style:solid; border-right-width:1" colspan="2">&nbsp;E-mail 
                                        <img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="email" value="<?php print($email); ?>" size="40"><img border="0" src="input-right.gif" width="7" >&nbsp;&nbsp;
                                          <?php
  if($welcomeresend == "Yes"){
        ?>
                                      Welcome Email Sent!
                                <?php
  }else{
        ?>
<img border="0" src="input-left.gif" width="7" ><input type="button" value="Resend Welcome Email" onClick="javascript:window.location.href='welcomeresend.php?t=Client'"><img border="0" src="input-right.gif" width="7" >
                                <?php
 }
        ?>

                                    
                                    
                                    
                                    
                                    </td>
                                </tr>
                                <tr>
                                    <td class='ss-round-inputs' width="50%" colspan="3" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1">
                                    
                                      <?php
  if($sendtohtdi != "Yes"){
        ?>

                                    
                                    
                                    &nbsp;Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="45" name="address" value="<?php print($address); ?>"><img border="0" src="input-right.gif" width="7" >
                                    <br>
                                    &nbsp;City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="22" name="city" value="<?php print($city); ?>"><img border="0" src="input-right.gif" width="7" >
                                    <br>
                                        &nbsp;State/Province&nbsp;&nbsp;&nbsp; &nbsp;
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"
                                                         size="4" name="state" value="<?php print($state); ?>"><img border="0" src="input-right.gif" width="7" >
                                    
                                        &nbsp;Zip&nbsp; 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10" name="zip" value="<?php print($zip); ?>"><img border="0" src="input-right.gif" width="7" >
                                        <?php
  }else{
        ?>
   &nbsp;Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                       -- <?php print($address); ?> <input class="txtbox" type=hidden size="45" name="address" value="<?php print($address); ?>">
                                    <br>
                                    &nbsp;City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                        -- <?php print($city); ?><input class="txtbox" type=hidden size="22" name="city" value="<?php print($city); ?>">
                                    <br>
                                        &nbsp;State/Province&nbsp;&nbsp;&nbsp; 
                                        -- <?php print($state); ?><input class="txtbox" type=hidden 
                                                         size="4" name="state" value="<?php print($state); ?>">
                                    <br>
                                        &nbsp;Zip/Postal Code 
                                        -- <?php print($zip); ?><input class="txtbox" type=hidden size="10" name="zip" value="<?php print($zip); ?>">

                                         <?php
  
    }
        ?>              
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    </td>
                                    <td width="25%" style="border-left-style: solid; border-left-width: 1">
                                        
 &nbsp;Single or Joint account 
                                        <select name="singlecouple" class="txtbox"  >
                <option value="<?php print($singlecouple); ?>" selected><?php print($singlecouple); ?></option>
                <option value="Single">Single</option>
                <option value="Joint">Joint</option>
                
              </select><br><br>
              
            

 <?php
            if ($singlecouple == "Joint"){
            ?> 

  
&nbsp;              Joint With:  <select name="jointwith" class="txtbox"  >
                <option value="<?php print($jointwith); ?>" selected><?php print($jointcurrentname); ?></option>
					    <? echo "$joint_select"; ?>
					    <option value="">----Remove Spouse----</option>
                
                
              </select><br>
              
           
 <?php
            }else{
            ?> 
 <input class="txtbox" type="hidden" name="jointwith" value="<?php print($jointwith); ?>">


 <?php
            }
            ?> 
 <?php
            if ($jointwith != ""){
            ?>    &nbsp;
<a href="setclient.php?cid=<?php print($jointwith); ?>&cname=<?php print($jointcurrentname); ?>">Access <?php print($jointcurrentname); ?>'s account</a>&nbsp;

    <?php
            }
            ?> 


                                         </td>
                                    <td width="25%" style="border-right-style:solid; border-right-width:1">
                                        
  <?php

  
$today=date("Y-m-d");
 $query7 = "SELECT count(id) FROM repair WHERE repairdate='$today' AND counselor='" . $_SESSION['usfname'] . "' AND clientid='" . mysql_real_escape_string($_SESSION['clientid']) . "'";
    $result7 = mysql_query($query7, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result7);
    while($row7=mysql_fetch_row($result7))
    {
        $numnotes = $row7[0];
}
$datetoschedule = date("Y-m-d", time()+10*24*3600);
if ($datetoschedule >= $dateresults2 AND ($status=="active" or $status=="contact1" or $status=="contact2" or $status=="contact3") AND $numnotes > 0){
            ?> 
  <p align="center">
  <a href="scheduleclient.php?scn=1">
  <img border="0" src="schedulenewround.gif" width="85" height="83" align="left"></a>
               <?php
}
            ?>   </td>
                                </tr>
                                <tr>
                                    <td class='ss-round-inputs' width="25%" style="border-left-style: solid; border-left-width: 1" colspan="2">&nbsp;Daytime# 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="phone" value="<?php print($phone); ?>" size="13"><img border="0" src="input-right.gif" width="7" >
<BR>&nbsp;Alt# 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="altphone" value="<?php print($altphone); ?>" size="13"><img border="0" src="input-right.gif" width="7" >
                                    </td>
                                    <td class='ss-round-inputs' width="25%" style="border-right-style: solid; border-right-width: 1">Cell# 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="cellphone" value="<?php print($cellphone); ?>" size="13"><img border="0" src="input-right.gif" width="7" >
<BR>                        
									
 <?php
if ($cellcarrier == "" or $cellcarrier == "Do Not SMS"){
$cellcarrier = "Do Not SMS";
 }
?>		Carrier: <select name="cellcarrier" class="txtbox" >
<option value="<?php print($cellcarrier); ?>" selected><?php print($cellcarrier); ?></option>
<option value="Alltel">Alltel</option>
<option value="Ameritech">Ameritech</option>
<option value="ATT Wireless">ATT Wireless</option>
<option value="Bell Mobility">Bell Mobility</option>
<option value="Bellsouth">Bellsouth</option>
<option value="Boost">Boost</option>
<option value="CellularOne">CellularOne</option>
<option value="CellularOne MMS">CellularOne MMS</option>
<option value="Cingular">Cingular</option>
<option value="Cricket">Cricket</option>
<option value="Edge Wireless">Edge Wireless</option>
<option value="Fido">Fido</option>
<option value="Metro PCS">Metro PCS</option>
<option value="Nextel">Nextel</option>
<option value="O2">O2</option>
<option value="Orange">Orange</option>
<option value="Qwest">Qwest</option>
<option value="Rogers Wireless">Rogers Wireless</option>
<option value="Sprint PCS">Sprint PCS</option>
<option value="Simple">Simple</option>
<option value="Straight Talk">Straight Talk</option>
<option value="Teleflip">Teleflip</option>
<option value="Telus Mobility">Telus Mobility</option>
<option value="T-Mobile">T-Mobile</option>
<option value="TracFone">TracFone</option>
<option value="US Cellular">US Cellular</option>
<option value="Verizon">Verizon</option>
<option value="Virgin Mobile">Virgin Mobile</option>
<option value="Do Not SMS">Do Not SMS</option>
</select>							
									
									
									
									</td>
                                    <td class='ss-round-inputs' width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style:solid; border-right-width:1" colspan="2">&nbsp;Fax# 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="fax" value="<?php print($fax); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
                                    </td>
                                </tr>
                                <tr>
                                    <td class='ss-round-inputs' width="50%" bgcolor="#<?php print($bgcolor);?>" colspan="3" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1; border-bottom-style:solid; border-bottom-width:1">&nbsp;SS# 
                                      

   <?php
  if($sendtohtdi != "Yes"){
        ?>
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="ssnum" value="<?php print($ssnum); ?>" size="10"><img border="0" src="input-right.gif" width="7" >
   <?php
 }else{
        ?>
-- <?php print($ssnum); ?> <input class="txtbox" type=hidden name="ssnum" value="<?php print($ssnum); ?>" size="20">
   <?php
}
        ?>
                                    </td>
                                    <td class='ss-round-inputs' width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style:solid; border-right-width:1; border-bottom-style:solid; border-bottom-width:1" colspan="2">&nbsp;Date Of Birth 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="birthdate" value="<?php print($birthdate); ?>" size="10"><img border="0" src="input-right.gif" width="7" >
                                    </td>
                                </tr>
                                <tr>
                                    <td style="border-left-style: solid; border-left-width: 1; border-right-style:solid; border-right-width:1" width="100%" bgcolor="#<?php print($bgcolor);?>" colspan="5" valign="top">


<table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber2">
<tr>
<td width="1%" valign="top">Comments</td>
<td width="50%" valign="top"><textarea  class="expand75-250 " style="font-size:8pt;" name="comments" size="20" rows="6" cols="80"><?php print($comments); ?></textarea></td>
<td class='ss-round-inputs' width="25%"> 
<?php if($sendtohtdi != "Yes"){ ?>
Date for Results to come back 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="dateresults" value="<?php print($dateresults); ?>" size="10"><img border="0" src="input-right.gif" width="7" ><br>
<input class="txtbox" type="hidden" name="budgetday" value="<?php print($budgetday); ?>"
<font size="1" color="#008000" face="Arial">typically set NLT 60 days from date of drafted letters</font>
<BR><BR>Font Type      
<select name="fonttype" class="txtbox" >
<option value="<?php print($fonttype); ?>" selected><?php print($fonttype); ?></option>
<? echo "$font_select"; ?>
</select>
					    
<?php }else{ ?>
Date for Results to come back -- <?php print($dateresults); ?> <input class="txtbox" type=hidden name="dateresults" value="<?php print($dateresults); ?>" size="20">
<input class="txtbox" type=hidden name="fonttype" value="<?php print($fonttype); ?>" size="20">
<?php } ?>
</td>


<td class='ss-round-inputs' width="25%"> 
<font size=3><strong>DFR</font><BR><font size=5><?php print($sendday); ?> days</font></strong>

</td>







</tr>
                                    </table>
                                    </td>
                                </tr>
    </tbody>
                            </table>
                            
                            <input class="txtbox" type="hidden" name="info" value="1">

                            
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="98%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Enrollment Information</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
                             <table style="BORDER-COLLAPSE: collapse" bordercolor="#000080"
                            cellspacing="0" cellpadding="0" width="98%" bgcolor="#<?php print($bgcolor);?>" border="0">

                                <tbody>
<tr>
<td class='ss-round-inputs' width="50%" colspan="2" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1">&nbsp;Date Of Enrollment 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10" name="dateenrol" value="<?php print($dateenrol); ?>"><img border="0" src="input-right.gif" width="7" >
</td>
               
<td class='ss-round-inputs' width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1">&nbsp;Reports Received <img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10" name="reportreceived" value="<?php print($reportreceived); ?>"><img border="0" src="input-right.gif" width="7" >

&nbsp;Contracts Returned <img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10" name="returndoc" value="<?php print($returndoc); ?>"><img border="0" src="input-right.gif" width="7" >
</td>
</tr>

<tr>
<td class='ss-round-inputs' width="50%" colspan="2" style="border-left-style: solid; border-left-width: 1; border-right-style:solid; border-right-width:1">&nbsp;Welcome Packet Mailed <img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10"
name="welcomepacket" value="<?php print($welcomepacket); ?>"><img border="0" src="input-right.gif" width="7" >
</td>

<td class='ss-round-inputs' width="50%" style="border-right-style: solid; border-right-width: 1; border-left-style:solid; border-left-width:1">&nbsp;SS# Proof Received <img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10" name="ssdate" value="<?php print($ssdate); ?>"><img border="0" src="input-right.gif" width="7" >
</td>
</tr>

<tr>
<td class='ss-round-inputs' width="50%" colspan="2" style="border-left-style: solid; border-left-width: 1; border-right-style:solid; border-right-width:1">&nbsp;Date of Cancellation <img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10"
name="canceldate" value="<?php print($canceldate); ?>"><img border="0" src="input-right.gif" width="7" >
</td>

<td class='ss-round-inputs' width="50%" style="border-right-style: solid; border-right-width: 1; border-left-style:solid; border-left-width:1">&nbsp;Address Verification Received <img border="0" src="input-left.gif" width="7" ><input class="txtbox" size="10"
name="addressreceived" value="<?php print($addressreceived); ?>"><img border="0" src="input-right.gif" width="7" >
</td>
</tr>
                                
                      
         
                    <?php
  if($sendtohtdi == "Yes"){
        ?>             
                           <tr>
<td width="50%" colspan="2" style="border-left-style: solid; border-left-width: 1; border-right-style:solid; border-right-width:1">
<p align="center">&nbsp;Expire Date - <?php print($dateexpire); ?>
  <?php

  
$today=date("Y-m-d");
$datetorenew = date("Y-m-d", time()+30*24*3600);
if ($datetorenew >= $dateexpire2 AND $status !="completed" AND $sendtohtdi == "Yes" ){
            ?> 
  
        <input type="button" value="Renew Client" onClick="javascript:window.location.href='scheduleclient.php?renew=1'">
               <?php
}
            ?>  
                                  </td>
<td width="50%" style="border-right-style: solid; border-right-width: 1; border-left-style:solid; border-left-width:1">&nbsp;
                                    </td>
                                </tr>
             
                         <?php
 
    }
        ?>          
                                
                                
                                
                   <input class="txtbox" type="hidden" name="enrol" value="1">
   <?php
            if ($reseller_id < "1" && $_SESSION['usaccess']!="processing"){
            ?>                
                                
                                
                                
                                
                                </tbody>
                            </table>
                            
                          
<!--------
///////////BILLING SECTION 
-->
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="98%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Billing Information</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>                            
                            <table style="BORDER-COLLAPSE: collapse" bordercolor="#000080"
                            cellspacing="0" cellpadding="0" width="98%" bgcolor="#<?php print($bgcolor);?>" border="0">
                                <tbody>
                                <tr>
                                    <td class='ss-round-inputs' width="50%" style="border-left-style: solid; border-left-width: 1" colspan="2">&nbsp;Setup Fee 
<img border="0" src="input-left.gif" width="7" ><input type="text" class="txtbox" size="7"
                                                         name="auditfee" value="<?php print($auditfee); ?>"><img border="0" src="input-right.gif" width="7" >
                                        Paid 
<img border="0" src="input-left.gif" width="7" ><input type="text" class="txtbox" name="paid" value="<?php print($paid); ?>" size="11"><img border="0" src="input-right.gif" width="7" >
                                   <a target="_blank" href="checkprint.php">
                                    Draft Check</a>
                                     
        </td>
                                    <td class='ss-round-inputs' width="50%" style="border-right-style: solid; border-right-width: 1">&nbsp;Payment Link 
<img border="0" src="input-left.gif" width="7" ><input type="text" class="txtbox" size="60"
                                                         name="onlinepayment" value="<?php print($onlinepayment); ?>"><img border="0" src="input-right.gif" width="7" ></td>
                                </tr>
                                <tr>
                                    <td class='ss-round-inputs' width="50%" style="border-left-style: solid; border-left-width: 1" colspan="2">&nbsp;Monthly Fee 
<img border="0" src="input-left.gif" width="7" ><input type="text" class="txtbox" name="monthlyfee" value="<?php print($monthlyfee); ?>" size="10"><img border="0" src="input-right.gif" width="7" >
                                        Monthly Due Date 
<img border="0" src="input-left.gif" width="7" ><input type="text" class="txtbox" size="4" name="monthlydue" value="<?php print($monthlydue); ?>"><img border="0" src="input-right.gif" width="7" >
                                    </td>
                                    <td width="50%" style="border-right-style: solid; border-right-width: 1">
                                    <a target="_blank" href="<?php print($onlinepayment); ?>"><?php print($onlinepayment); ?></a>&nbsp;</td>
                                </tr>
                                <tr>
                                    <td class='ss-round-inputs' width="50%" style="border-left-style: solid; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium" colspan="2">&nbsp;Payment Method 
<img border="0" src="input-left.gif" width="7" ><input type="text" class="txtbox" size="8" name="payment" value="<?php print($payment); ?>"><img border="0" src="input-right.gif" width="7" >
                                    </td>
                                    <td width="50%" style="border-right-style: solid; border-right-width: 1; border-bottom-style: none; border-bottom-width: medium">&nbsp;

                </td>
                                </tr>
   <?php
if ($holder ==""){
$holder = $name;
}if ($holderaddress ==""){
$holderaddress = $address;
}if ($holdercity ==""){
$holdercity = $city;
}if ($holderstate ==""){
$holderstate = $state;
}if ($holderzip ==""){
$holderzip = $zip;
}			
            ?>                


<tr>
<td class='ss-round-inputs' width="50%" style="border-left-style: solid; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium" colspan="2">
&nbsp;Bank: <img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" name="bankname" value="<?php print($bankname); ?>" size="30"><img border="0" src="input-right.gif" width="7" >&nbsp; Routing: 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" name="bankrtg" value="<?php print($bankrtg); ?>" size="10"><img border="0" src="input-right.gif" width="7" >
</td>

<td class='ss-round-inputs' width="50%" style="border-right-style: solid; border-right-width: 1; border-bottom-style: none; border-bottom-width: medium">
&nbsp;Account Holder: <img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" name="holder" value="<?php print($holder); ?>" size="30"><img border="0" src="input-right.gif" width="7" >&nbsp; Address: 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" name="holderaddress" value="<?php print($holderaddress); ?>" size="30"><img border="0" src="input-right.gif" width="7" >
</td>
</tr>

<tr>
<td class='ss-round-inputs' width="50%" style="border-left-style: solid; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium" colspan="2">
&nbsp;Account# <img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" name="bankact" value="<?php print($bankact); ?>" size="15"><img border="0" src="input-right.gif" width="7" >&nbsp; ABA 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" name="aba" value="<?php print($aba); ?>" size="11"><img border="0" src="input-right.gif" width="7" > Start Check 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" name="checknum" value="<?php print($checknum); ?>" size="7"><img border="0" src="input-right.gif" width="7" > 
</td>

<td class='ss-round-inputs' width="50%" style="border-right-style: solid; border-right-width: 1; border-bottom-style: none; border-bottom-width: medium">
&nbsp;City: <img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" name="holdercity" value="<?php print($holdercity); ?>" size="15"><img border="0" src="input-right.gif" width="7" >&nbsp; State: 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" name="holderstate" value="<?php print($holderstate); ?>" size="5"><img border="0" src="input-right.gif" width="7" > Zip: 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="text" name="holderzip" value="<?php print($holderzip); ?>" size="7"><img border="0" src="input-right.gif" width="7" > 
</td>
</tr>

<script type="text/javascript" src="lightbox.js"></script>
<link rel="stylesheet" type="text/css" href="lightbox.css" />

                                <tr>
                                    <td width="100%" style="border-left-style: solid; border-left-width: 1; border-bottom-style: solid; border-right-style: solid; border-right-width: 1; border-bottom-width: 1; border-top-style:none; border-top-width:medium" colspan="3">
                                    <p align="center">
                                    <a rel="lightbox" href="check.jpg">
                                    Click for a sample check</a></td>
                                </tr>

 <?php
           
}
?>

                                <tr>
                                    <td width="50%" style="border-left-style: solid; border-left-width: 1; border-bottom-style: solid; border-bottom-width: 1; border-top-style:none; border-top-width:medium" colspan="2">
                                    <br>
                                    
                                    
                                    
                                    <input class="txtbox" type="hidden" name="updatecl" value="1">
                           

 
              <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND (($_SESSION['contract']!="OLD") or ($status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete")))
    {

        ?>&nbsp;&nbsp;&nbsp;&nbsp;
 <input type="submit" name="Update" value="Update">
 
  
              <?php
 }
        ?>
                                    
                                    
                                    
                                    
                                    
                                    </td>
                                    <td width="50%" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1; border-top-style:none; border-top-width:medium">&nbsp;</td>
                                </tr>
                                </tbody>
                            </table> 

                           
                            

                        </form>
                        
                        
              <table width="98%" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" cellspacing="0">
              <tr>
                    
              <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")

    {
        ?>
        <td class='ss-round-inputs' width="50%">    
AV and SSN proof - <a target="_blank" href="<?php print($avssnurl); ?>"><?php print($avssnurl); ?></a>

 <form action="" method="post" enctype="multipart/form-data">

 <?php
            if ($avssnurl == ""){
            ?>

Choose AV and SSN file to upload:<br>
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" type="file" name="file" size="60"><br>
<input type="hidden" name="ssnforfile" value="<?php print($ssnum); ?>">
<input type="hidden" name="action" value="addpic"><br>
<input type="submit" name="submit" value="Submit"> <br>
&nbsp;</form>

<?php
           
}
?>
<?php
            if ($avssnurl != ""){
            ?>

 
             
 <form action="" method="post" enctype="multipart/form-data">


Remove this AV and SSN file
<br>

<input type="hidden" name="action" value="removepic">
<input type="submit" name="submit" value="Remove"> <br>
&nbsp;</form>
 </td>

              <?php
  }

           
}

?>
<td width="50%">
 <form action="" method="post" name="setappt" enctype="multipart/form-data">

 <p align="center"> 
                                     
                                        <font size="1"><b>SET FOLLOWUP</b><br>
			<select class="txtbox" name="calday">
<option value="<? echo "$nowday"; ?>" selected="selected"><? echo "$nowday"; ?></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22"">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<select class="txtbox" name="calmonth">
<option value="<? echo "$nowmonth"; ?>" selected="selected"><? echo "$nowmonthword"; ?></option>
<option value="1">Jan</option>
<option value="2">Feb</option>
<option value="3">Mar</option>
<option value="4">Apr</option>
<option value="5">May</option>
<option value="6">Jun</option>
<option value="7">Jul</option>
<option value="8">Aug</option>
<option value="9">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
<input maxlength="4" class="txtbox" type="text" name="calyear" size="4" value=<? echo "$nowyear"; ?> >

<A HREF="#" onClick="cal.showCalendar('anchor1'); return false;" NAME="anchor1" ID="anchor1">
<img border="0" src="calendar.gif"></A>




&nbsp;&nbsp;
			<input class="txtbox" type="text" name="calhour" size="2" value="" maxlength="2" />:<input class="txtbox" type="text" name="calminute" size="2" value="" maxlength="2" />
<label><input type="radio" name="calampm" value="am" checked="" />AM</label>
<label><input type="radio" name="calampm" value="pm"  />PM</label><BR>
<strong>Priority</strong>     
<label><input type="radio" name="priority" value=""  checked="" />Low</label>
<label><input type="radio" name="priority" value="Medium"  />Medium</label>
<label><input type="radio" name="priority" value="High"  />High</label>
<br>
<input type="hidden" name="addappt" value="yes">
<input type="submit" name="submit" value="Submit">
</form>
<DIV ID="testdiv1" STYLE="position:absolute;visibility:hidden;background-color:white;layer-background-color:white;"></DIV>


</td></tr> 
          </table>             

                        
                        <p align="left">



                        <table width="956" border="0" cellspacing="0" bordercolor="#000080" cellpadding="0" style="border-collapse: collapse">
                            <tbody>
                            <tr>
                                <td width="1%" >
                                <img border="0" src="leftupcorner.gif" width="31" height="29"></td>
                                <td class="miniheaders" width="99%" background="titlebackground.gif">
                                Credit Repair Process</td>
                                <td width="1%" align="right">
                                <p align="right">
                                <img border="0" src="rightupcorner.gif" width="10" height="29"></td>

                            </tr>
                            </tbody>
                            </table>
                            
                            
                            
                            
                              <table width="700" border="0" cellspacing="0" bordercolor="#000080" cellpadding="0" style="border-collapse: collapse">
                            <tbody>

                            <tr>
                                <td  background="bluestripshort.gif" width="77" style="border-left-style: solid; border-left-width: 1;" colspan="2">
                                <font color="#FFFFFF"><b>Date</b></font></td>
                                <td  background="bluestripshort.gif" width="661">
                                <font color="#FFFFFF"><b>Received (e-mail, phone, reports, etc.)</b></font></td>
                                <td  background="bluestripshort.gif" width="661">
                                <font color="#FFFFFF"><b>Action Taken</b></font></td>
                                <td  background="bluestripshort.gif" width="78" >
                                <font color="#FFFFFF"><b>Counselor</b></font></td>
 <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $counselor != "HTDI" AND $counselor != "Processor")

    {
        ?>
<td width="67"></td>
<td width="39"></td>
                                 
              <?php
}
        ?>

                            </tr>
                    <?php
    $query = "SELECT DATE_FORMAT(repairdate, \"%m-%d-%Y\") as repdate,  received, action,  filelocation, counselor, id FROM  repair WHERE clientid='" . $_SESSION['clientid'] . "' ORDER BY repairdate DESC, id DESC";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $repairdate= $row[0];
        $received = $row[1];
        $action = $row[2];
        $filelocation = $row[3];
        $counselor= $row[4];
        $repairid= $row[5];

  
          if($filelocation !=""){
         $textcss = "FFCCCC";
}else {

                    $textcss = "FFFFFF";

                    }
  
?>

                    
                            <tr>
                                <form action="" method="post">
                                <td bgcolor="#<?php print($textcss);?>" width="78" style="border-bottom-style: solid; border-bottom-width: 1" colspan="2">
                                    <input name="repairdate" type="text" class="txtbox" value="<?php print($repairdate); ?>" size="10">
                                </td>
                                <td bgcolor="#<?php print($textcss);?>" width="661" style="border-bottom-style: solid; border-bottom-width: 1">
                                <textarea class="expand txtboxclear" name="received" cols="80"><?php print($received); ?></textarea></td>
                                <td bgcolor="#<?php print($textcss);?>" width="661" style="border-bottom-style: solid; border-bottom-width: 1">
                                <textarea class="expand txtboxclear" name="action" cols="80"><?php print($action); ?></textarea></td>
                                <td bgcolor="#<?php print($textcss);?>" width="78" >
                                    <input name="counselor" type="text" class="txtbox" value="<?php print($counselor);?>" size="10">
                                </td>
                                
                                
              <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $counselor != "HTDI" AND $counselor != "Processor")

    {
        ?>
<td width="67" >
                                    <input type="hidden" name="u" value="1">
                                    <input type="hidden" name="repairid" value="<?php print($repairid);?>">
<input class="txtboxdeleted" type="submit" name="Update" value="Update">
                     
                                </td>
 <td width="39">&nbsp;&nbsp;<a href="clientstatus.php?del=1&repairid=<?php print($repairid);?>"><img border="0" src="deletebutton.png" width="13" height="15"></a></td>
                                 
              <?php
}
        ?>


</form>
                            </tr>
<?php
       }
      
?>              
                            </tbody>
                        </table>
                      
<SCRIPT LANGUAGE="javascript">
   function SentLetters()
   {
document.formname.addaction.value = 'Drafted letters to bureaus.  You should receive their responses in your mailbox within 45-50 days.   Please mail these responses to our office immediately.';
document.formname.subject2.value = '';
}
 function NSF()
   {
document.formname.addaction.value = 'Notification of Insufficient Funds.  Account suspended until resolved.';
document.formname.subject2.value = 'Your Account has been Suspended!';
}
function NSF2()
   {
document.formname.addaction.value = 'Notification of Second Insufficient Funds.  Account has been canceled due to non resolution.';
document.formname.subject2.value = 'Your Account has been Canceled';
}
function Canceled()
   {
document.formname.addaction.value = 'Your account with us has been canceled.  Thank you for being a client of <?php print($companyname); ?>.';
document.formname.subject2.value = 'Your Account has been Canceled';
}
function OverdueLM()
   {
document.formname.addaction.value = 'Left message with client checking on results from bureaus.  Please contact us at <?php print($companyphone); ?> to discuss your account.';
document.formname.subject2.value = 'Your Account is Overdue';
}
function OverdueRNA()
   {
document.formname.addaction.value = 'Called client checking on results from bureaus.  Rang no answer.  Please contact us at <?php print($companyphone); ?> to discuss your account.';
document.formname.subject2.value = 'Your Account is Overdue';
}

function LateResults()
   {
document.formname.addaction.value = 'Please ensure to mail in results within 5 days of receipt.  Some bureau letters require an immediate response.  To increase effectiveness of our responses, we need to be able to send responses to bureaus within a timely fashion.';
document.formname.subject2.value = 'Results sent in late';
}

function faxresults()
   {
document.formname.addreceived.value = 'Credit Reports via fax - Illegible and Unusable';
document.formname.addaction.value = 'Please mail original reports to <?php print($companyaddress); ?>, <?php print($companycity); ?>, <?php print($companystate); ?> <?php print($companyzip); ?>.  We do not accept credit report updates by fax.';
document.formname.subject2.value = 'Illegible faxes';
}


   function Experian()
   {
document.formname.addreceived.value = 'Updated Experian Response';
document.formname.addaction.value = 'Filed and Updated';
document.formname.subject2.value = '';
}

function FrivolousExperian()
   {
document.formname.addreceived.value = 'Updated Experian Previously Investigated Response';
document.formname.addaction.value = 'Filed and Updated-Sent a response back to Experian regarding these specific accounts.  You will receive another response from Experian';
document.formname.subject2.value = '';
}

   function Equifax()
   {
document.formname.addreceived.value = 'Updated Equifax Response';
document.formname.addaction.value = 'Filed and Updated';
document.formname.subject2.value = '';
}
   function Transunion()
   {
document.formname.addreceived.value = 'Updated Transunion Response';
document.formname.addaction.value = 'Filed and Updated';
document.formname.subject2.value = '';
}
function FrivolousTransunion()
   {
document.formname.addreceived.value = 'Updated Transunion Frivolous Response';
document.formname.addaction.value = 'Filed and Updated-Sent a response back to Transunion regarding these specific accounts.  You will receive another response from Transunion';
document.formname.subject2.value = '';
}


function EquifaxACK()
   {
document.formname.addreceived.value = 'Equifax Acknowledgment';
document.formname.addaction.value = 'Filed.  You will still receive another response with results from this bureau';
document.formname.subject2.value = '';
}
   function TransunionACK()
   {
document.formname.addreceived.value = 'Transunion Acknowledgment';
document.formname.addaction.value = 'Filed.  You will still receive another response with results from this bureau';
document.formname.subject2.value = '';
}
function ExperianACK()
   {
document.formname.addreceived.value = 'Experian Acknowledgment';
document.formname.addaction.value = 'Filed.  You will still receive another response with results from this bureau';
document.formname.subject2.value = '';
}

         </SCRIPT>


                        <p align="left">
                        
                        
                        <form action="" method="post" name="formname">

                            <table width="956" border="0" cellpadding="0" cellspacing="0" bordercolor="#000080" style="border-collapse: collapse">
                                <tr>
                                    <td width="1%" >
                                    <img border="0" src="leftupcorner.gif" width="31" height="29"></td>
                                    <td class="miniheaders" width="99%" background="titlebackground.gif">
                                      Add New Credit Repair Record
                                      </td>
                                         <td width="1%">
                                    <img border="0" src="rightupcorner.gif" width="10" height="29"></td>

                                </tr>
                </table>
                 
                                 <table width="956" border="0" cellpadding="0" cellspacing="0" bordercolor="#000080" style="border-collapse: collapse" background="bluestripshort.gif">

                                <tr>
                                    <td width="98" style="border-left-style: solid; border-left-width: 1">&nbsp;<font color="#FFFFFF"><b>Date</b></font></td>
                                    <td class='ss-round-inputs' width="582" style="border-right-style: solid; border-right-width: 1">
<img border="0" src="input-left.gif" width="7" ><input name="adddate" type="text" class="txtbox" size="10" value="<? print date("m-d-Y"); ?>"><img border="0" src="input-right.gif" width="7" >
                                    </td>
                                    <td width="392" rowspan="6" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                                 <font color="#FFFFFF"><B>HARD CODED CANNED HOT LINKS</B></font><BR>  <?php
  if($sendtohtdi != "Yes"){
        ?>
              <a href="javascript:Experian()">
                                        <font color="#FFFFFF">Updated Experian</font></a><font color="#FFFFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        </font>
                                        <a href="javascript:ExperianACK()">
                                        <font color="#FFFFFF">Acknowledgments</font></a><font color="#FFFFFF"><br>
                                        </font>
                                        <a href="javascript:Equifax()">
                                        <font color="#FFFFFF">Updated Equifax</font></a><font color="#FFFFFF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        </font>
                                        <a href="javascript:EquifaxACK()">
                                        <font color="#FFFFFF">Acknowledgments</font></a><font color="#FFFFFF"><br>
                                        </font>
                                        <a href="javascript:Transunion()">
                                        <font color="#FFFFFF">Updated 
                                        Transunion</font></a><font color="#FFFFFF">&nbsp;&nbsp;&nbsp;&nbsp;
                                        </font>
                                        <a href="javascript:TransunionACK()">
                                        <font color="#FFFFFF">Acknowledgments</font></a><p>
                                        <a href="javascript:FrivolousExperian()">
                                        <font color="#FFFFFF">Updated Frivolous Experian</font></a><font color="#FFFFFF"><br>
                                        </font>
                                        <a href="javascript:FrivolousTransunion()">
                                        <font color="#FFFFFF">Updated Frivolous Transunion</font></a><font color="#FFFFFF"><br>
                                        <br>
                                        </font>
                                        </p>
                                        <p>
                                        <a href="javascript:LateResults()">
                                        <font color="#FFFFFF">Late 
                                        Results</font></a><font color="#FFFFFF"><br>
                                        <br>
                                        </font>
                                        <a href="javascript:SentLetters()">
                                        <font color="#FFFFFF">Drafted Letters</font></a><BR><BR>
                                         <?php
}
        ?>
        <a href="javascript:NSF()">
                                        <font color="#FFFFFF">NSF</font></a><font color="#FFFFFF">&nbsp;&nbsp;&nbsp;&nbsp;
                                        </font>
                                        <a href="javascript:NSF2()">
                                        <font color="#FFFFFF">NSF x2</font></a><font color="#FFFFFF">&nbsp;&nbsp;
                                        </font>
                                        <a href="javascript:Canceled()">
                                        <font color="#FFFFFF">Canceled</font></a><font color="#FFFFFF"><br>
                                        </font>
                                        <a href="javascript:OverdueLM()">
                                        <font color="#FFFFFF">Overdue 
                                        Account - Left Message</font></a><font color="#FFFFFF"><br>
                                        </font>
                                        <a href="javascript:OverdueRNA()">
                                        <font color="#FFFFFF">Overdue Account - Ring no answer</font></a><font color="#FFFFFF"><br>
                                        <br>
                                        </font>
                                        <a href="javascript:faxresults()">
                                        <font color="#FFFFFF">Credit 
                                        Results via fax</font></a></td>
                                </tr>
                                <tr>
                                    <td width="98" style="border-left-style: solid; border-left-width: 1">
                                    <font color="#FFFFFF"><b>&nbsp;Received</b></font></td>
                                    <td class='ss-round-inputs' width="582" style="border-right-style: solid; border-right-width: 1">
<img border="0" src="input-left.gif" width="7" ><input name="addreceived" type="text" class="txtbox" size="80"><img border="0" src="input-right.gif" width="7" >
<input name="subject2" type="hidden" size="80">
                                    </td>
                                </tr>
                                <tr>
                                    <td width="98" style="border-left-style: solid; border-left-width: 1">
                                    <font color="#FFFFFF"><b>&nbsp;Action Taken</b></font></td>
                                    <td class='ss-round-inputs' width="582" style="border-right-style: solid; border-right-width: 1">
<img border="0" src="input-left.gif" width="7" ><input name="addaction" type="text" class="txtbox" size="80"><img border="0" src="input-right.gif" width="7" >
                                    </td>
                                </tr>
                                <tr>
                                    <td width="98" style="border-left-style: solid; border-left-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                                    &nbsp;<font color="#FFFFFF"><b>Counselor</b></font></td>
                                    <td class='ss-round-inputs' width="582" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
<img border="0" src="input-left.gif" width="7" ><input name="addcounselor" type="text" class="txtbox" size="10" value="<? print $_SESSION['usfname']; ?>"><img border="0" src="input-right.gif" width="7" >
                                    </td>
                                </tr>

 <tr>
                                    <td width="680" colspan="2" style="border-style: solid; border-width: 1"><font color="#FFFFFF"><B>CUSTOM CANNED HOT LINKS</B>
 <?php
if($_SESSION['usaccess']=="full")
    {
        ?>
  <a href="canned.php?type=hotlinks"><font color="#FFFFFF">(manage)</font></a>
 <?php
}
        ?>

</font><BR>
 <?php
    $query = "SELECT id, cannedreceived, cannedaction, cannedsubject, cannedname FROM companyhotlinks where (cannedsubject='ClientStatusSheet' or cannedsubject='')";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $cannedid= $row[0];
        $cannedreceived= $row[1];
        $cannedaction= $row[2];
        $cannedsubject= $row[3];
        $cannedname = $row[4];
  
?>
<SCRIPT LANGUAGE="javascript">
   function canned<?php print($cannedid);?>()
   {
document.formname.addreceived.value = '<?php print($cannedreceived);?>';
document.formname.addaction.value = '<?php print($cannedaction);?>';
}
</script>
<a href="javascript:canned<?php print($cannedid);?>()"><font color="#FFFFFF"><?php print($cannedname);?></font></a>
&nbsp;
 <?php
}
?>


</td>
                                </tr>
 
                                <tr>
                                    <td width="680" colspan="2" style="border-style: solid; border-width: 1">&nbsp;<p>
                                    
                                    
                                    
                                    
                                    
                                    
                                     <input type="hidden" name="add" value="1">
                                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="Add" type="submit" value="Add">
                            <input type="reset" name="Reset" value="Clear">
                            <input name="email" value="<?php print($email); ?>" size="20" type="hidden">
                            <input type="hidden" name="username" value="<?php print($usernameu);?>" size="20">
                            
                            <?php
            if ($passisssn == "Yes"){
            ?>
             <input type="hidden" name="password" value="*********" size="20">
     <?php
            }else{
            ?>
                            <input type="hidden" name="password" value="<?php print($pwdu);?>" size="20">
                            
                       <?php
           }
            ?>
        
                            <?php
if ($cellcarrier == "Do Not SMS"){
echo "<input name=\"sendsms\" value=\"No\" type=\"hidden\">";
}else{
echo "<input name=\"sendsms\" value=\"Yes\" type=\"hidden\">";
}

?> 
                            <input name="cellphone" value="<?php print($cellphone); ?>" size="20" type="hidden">
                            <input name="cellcarrier" value="<?php print($cellcarrier); ?>" size="20" type="hidden">

							<input name="companyname" value="<?php print($companyname); ?>" size="20" type="hidden">
                            <input name="companyemail" value="<?php print($companyemail); ?>" size="20" type="hidden">
                            <input name="companyreply" value="<?php print($companyreply); ?>" size="20" type="hidden">
                            <input name="companyaddress" value="<?php print($companyaddress); ?>" size="20" type="hidden">
                            <input name="companycity" value="<?php print($companycity); ?>" size="20" type="hidden">                            
                            <input name="companystate" value="<?php print($companystate); ?>" size="20" type="hidden">                            
                            <input name="companyzip" value="<?php print($companyzip); ?>" size="20" type="hidden">
                            <input name="companyphone" value="<?php print($companyphone); ?>" size="20" type="hidden">                            
                            <input name="companyfax" value="<?php print($companyfax); ?>" size="20" type="hidden">                            
                            <input name="companywebsite" value="<?php print($companywebsite); ?>" size="20" type="hidden">   
                            <input name="clientinfoname" value="<?php print($name); ?>" size="20" type="hidden">
                            <input name="brokerfirstname" value="<?php print($brokerfirstname); ?>" size="20" type="hidden">
                            <input name="brokerlastname" value="<?php print($brokerlastname); ?>" size="20" type="hidden">
                            <input name="brokeremail" value="<?php print($brokeremail); ?>" size="20" type="hidden">                            
                            <input name="brokerusername" value="<?php print($brokerusername); ?>" size="20" type="hidden">                            
                            <input name="brokerpassword" value="<?php print($brokerpassword); ?>" size="20" type="hidden">       
                            <input name="brokeremailnotify" value="<?php print($brokeremailnotify); ?>" size="20" type="hidden">       
                                    
                                    
                                    
                                    
                                    </p>
                                    <p>&nbsp;</td>
                                </tr>


 
                               
                            </table>
                                                

                        </form>
                        <p align="left">&nbsp;
                        
                        </p>
                        
                        
                        
                        
                        
               <?php
                    $salesclientid = $_SESSION['clientid'];
$salessql = "SELECT * FROM salesnotes WHERE clientid = '$salesclientid' AND (received !='broker' or received IS NULL) ORDER BY repairdate, id";
$salesresult = @mysql_query($salessql,$conn) or die("Couldn't execute");
$num_results = mysql_num_rows($salesresult);
if (! $num_results || $num_results == "0") {
}else{
?>            
         <p align="left">

                        <table width="700" border="0" cellspacing="0" bordercolor="#000080" cellpadding="0" style="border-collapse: collapse">
                            <tbody>
                            <tr>
                                <td width="1%" background="titlebackground.gif">
                                <img border="0" src="leftupcorner.gif" width="31" height="29"></td>
                                <td class="miniheaders" width="99%" background="titlebackground.gif">
                                Prior Sales Notes</td>
                                <td width="1%" background="titlebackground.gif" align="right">
                                <p align="right">
                                <img border="0" src="rightupcorner.gif" width="10" height="29"></td>

                            </tr>
                            </tbody>
                            </table>
                            
                            
                            
                              
                              <table width="700" border="0" cellspacing="0" bordercolor="#000080" cellpadding="0" style="border-collapse: collapse">
                            <tbody>

                            <tr>
                                <td  background="bluestripshort.gif" width="120" style="border-left-style: solid; border-left-width: 1;">
                                <font color="#FFFFFF"><b>Date</b></font></td>
                                <td  background="bluestripshort.gif" width="661">
                                <font color="#FFFFFF"><b>Note</b></font></td>
                               
                                <td  background="bluestripshort.gif" width="78" >
                                <font color="#FFFFFF"><b>Sales Person</b></font></td>
 
                            </tr>
                    <?php
                 
while ($row = mysql_fetch_array($salesresult)) {	
    $NOTE_id = $row['id'];
    $NOTE_contact_id = $row['clientid'];
    $NOTE_view = $row['action'];
    $NOTE_user = $row['counselor'];
    $NOTE_julian = $row['repairdate'];
    $NOTE_tstamp = $row['filelocation'];

$NOTE_year = substr("$NOTE_julian", 0, 4);
$NOTE_month = substr("$NOTE_julian", 5, 2);
$NOTE_day = substr("$NOTE_julian", 8, 2);
///ADJUST FOR TIMEZONE
if ($NOTE_tstamp != "") {
$notetime = date("m/d/Y h:i:sa",strtotime("$NOTE_julian $NOTE_tstamp $timezoneoffset"));
}else{
$notetime = date("m/d/Y",strtotime("$NOTE_julian $NOTE_tstamp $timezoneoffset"));
}
  $textrows = strlen($NOTE_view);
  $textrows = $textrows / 81;
  $textrows = floor($textrows);
  $textrows = $textrows +1;
  
?>

                    
                            <tr>
                               
                                <td bgcolor="#B3C1E1" width="120" style="border-bottom-style: solid; border-bottom-width: 1">
<?php print($notetime); ?> 
                                </td>
                                <td bgcolor="#B3C1E1" width="661" style="border-bottom-style: solid; border-bottom-width: 1">
<?php print($NOTE_view); ?></td>
                                <td bgcolor="#B3C1E1" width="78" >
                                    <input name="counselor" type="text" class="txtbox" value="<?php print($NOTE_user);?>" size="10">
                                </td>
                                
                                
             


                            </tr>
<?php
       }
      
?>              
                            </tbody>
                        </table>
                <?php
       }
      
?>      
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    <BR><BR>    
                        
                        
                        
                        
                        
                      
                        <a href="creditreport.php">Client Credit Report Results</a>
                        </p>
                        <p align="left">
                        <a href="intervieweradmin.php">Interviewer</a>
                        </p>
                        <p align="left">
                        <a href="menu.php">Main Menu</a>
                        </p>
                        <p align="left">
                        <a href="search.php?status=pending&zip=&email=&f=1&Find=Find">Search Another Client</a>
                        </p>
                        <p align="left">&nbsp;
                        
                        </p>
						<script type="text/javascript" src="jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery.textarea-expander.js"></script>

<?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>