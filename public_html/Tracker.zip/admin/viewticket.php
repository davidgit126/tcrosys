<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
include('template.php');
    include('main.php');

    if($helpdesk=="Yes" && ($_SESSION['usaccess']=="support" or $_SESSION['usaccess']=="full")){


      if($_POST['addhdresponse'] == 1){
      
 $query = "SELECT id FROM helpdeskresponses WHERE ticketid='$helpdeskid' and response='" . mysql_real_escape_string($_POST['response']) . "' LIMIT 1"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $checkid = $row[0];
 
    } 

      if($checkid == ""){

      $hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";
$ip=$_SERVER["REMOTE_ADDR"];

      $query = "INSERT INTO helpdeskresponses(ticketid, byuser, response, date, tstamp, ip)
                    VALUES(
                    '$helpdeskid',
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
					'" . mysql_real_escape_string($_POST['response']) . "',
                    '$today',
                    '$tstamp',
                    '$ip')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

      }
        $query = "UPDATE helpdesk SET status='" . mysql_real_escape_string($_POST['status']) . "' WHERE id='$helpdeskid'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

    
       $query = "SELECT id, status, subject, description, DATE_FORMAT(date, \"%m-%d-%Y\") as hdlogdate,  tstamp, ip, clientid FROM helpdesk WHERE deleted !='Yes' and id='$helpdeskid'"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $helpdeskid= $row[0];
        $hdstatus = $row[1];
        $hdsubject = $row[2];
        $hddescription = $row[3];
        $hdlogdate= $row[4];
        $hdtstamp= $row[5];
        $hdip= $row[6];
        $hdclientid= $row[7];
$hddescription = nl2br($hddescription);         

}
      if($hdstatus !=""){
     
//-------client
 
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country FROM clients WHERE id='$hdclientid' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $clientname = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $active = $row[11];
    } 


    //mysql_close($conn);
    ?>
<STYLE type=text/css>
A:active  {	COLOR: #006699; TEXT-DECORATION: none      }
A:visited { COLOR: #334A9B; TEXT-DECORATION: none      }
A:hover   { COLOR: #334A9B; TEXT-DECORATION: underline }
A:link    { COLOR: #334A9B; TEXT-DECORATION: none      }
td { font-family:Tahoma;font-size:11px;color:#000000 }

 .title, h1, h2	{ font-size: 23px; font-weight: bold; font-family: Trebuchet MS,Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000066; }
 .forminput     { font-size: 8pt; background-color: #CCCCCC; font-family: verdana, helvetica, sans-serif; vertical-align:middle }
 .tbox          { FONT-SIZE: 11px; FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif; COLOR: #000000; BACKGROUND-COLOR: #ffffff }
 .gbox          { FONT-SIZE: 11px; FONT-FAMILY: Verdana; COLOR: #000000; BACKGROUND-COLOR: #F7F7F7 }
TR.usertab {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #C4CDDB
}
TD.usertab {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #C4CDDB
}
TR.userresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #FAFAFA
}

TD.userresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #FAFAFA
}

TR.userstaffresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #EFEFEF
}

TD.userstaffresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #EFEFEF
}

</STYLE>
<script type="text/javascript" src="jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery.textarea-expander.js"></script>
   <style type="text/css"> 
/* <![CDATA[ */

textarea
{
	clear: both;
	display: block;
	font-family: Verdana, sans-serif; 
	font-size: 11px;
	padding: 4px 4px 4px 4px;
	margin: 6px auto;

}
 
/* ]]> */
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000">

<br>
<table width="700" border="0" cellspacing="1" cellpadding="0" align="center">
  <tr> 
    <td height="18" valign="top"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
       <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Helpdesk Ticket ID #<?php print($helpdeskid); ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
  <table width="100%" border="0" cellspacing="0" align="center" cellpadding="0">
    <tr> 
      <td colspan="4"> <div align="right"> 
          <table width="100%" border="0" height="81">

           <tr bgcolor="#F1F1F8"> 
              <td width="29%" height="13"> Status</td>
              <td width="71%" height="13"><b><?php print($hdstatus); ?></b></td>
            </tr>
            <tr bgcolor="#F1F1F8"> 

              <font size="2" face="Verdana, Arial, Helvetica, sans-serif">

              <td width="29%" height="13"> Logged</td>
              <td width="71%" bgcolor="#F1F1F8" height="13"><?php print($hdlogdate); ?></td>
		</font> 
            </tr>
            <tr bgcolor="#F1F1F8"> 
              <td width="29%" height="13"> Logged By</td>
              <td width="71%" bgcolor="#F1F1F8" height="13"><?php print($clientname); ?> ( <a href="setclient.php?cid=<?php print($hdclientid); ?>&cname=<?php print($clientname); ?>">View User Details</a> ) </td>
            </tr>
            <tr bgcolor="#F1F1F8"> 
              <td width="29%" height="13"> IP Address</td>
              <td width="71%" bgcolor="#F1F1F8" height="13"><?php print($hdip); ?></td>
            </tr>
          </table>
        </div></td>
    </tr>
    <tr> 
      <td colspan="4">&nbsp; </td>
    </tr>
    <tr> 
      <td colspan="4" valign="top"> <table width="99%" border="0" align="center" cellpadding="7">
          <tr> 
            <td class="usertab"><b><?php print($hdsubject); ?></b></td>
          </tr>
          <tr> 
            <td bgcolor="#F1F1F8"> <div align="left"><?php print($hddescription); ?></div></td>
          </tr>
        </table>
        <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr> 
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td class="usertab"><b> User/Staff Follow-ups</b></td>
          </tr>
          <tr> 
            <td> <div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">
            
            
<?php

           $query = "SELECT id, byuser, response, DATE_FORMAT(date, \"%m-%d-%Y\") as hdresponsedate,  tstamp, ip FROM helpdeskresponses WHERE ticketid='$helpdeskid' order by id"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $rsid= $row[0];
        $byuser = $row[1];
        $response = $row[2];
        $hdresponsedate= $row[3];
        $rststamp= $row[4];
        $rsiptstamp= $row[5];

$response = nl2br($response);         

        ?>
          <table width="100%" border="0" cellspacing="1" cellpadding="3">
            <tr class="userstaffresponse">
              <td width="30%" height="14" valign="top"><b><?php print($byuser); ?><br></b><?php print($hdresponsedate); ?> at <?php print($rststamp); ?> <br><br></td>
              <td width="70%" height="14" valign="top"><?php print($response); ?></td>
            </tr>
            <tr class="userstaffresponse">
              <td colspan=2 valign="top" style="background-color: #FFFFFF">
              <hr color="#F1F1F8" width="50%"></td>
            </tr>
            </table>
              

<?php

 }
		$SA_sql = "SELECT subject, content FROM helpdeskcanned ORDER BY subject";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $cannedsubject = $srow['subject'];
		    $cannedcontent = $srow['content'];
		$cannedselect .= "<option value=\"$cannedcontent\">$cannedsubject</option>";
	
		}

        ?>
  <form action="" name="formname" method="post">

   <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Add a Response?</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

              <table width="100%" border="0" cellspacing="1" cellpadding="3">

            <tr class="userstaffresponse">
              <td width="100%" height="14" valign="top">
              <p align="center">
              <textarea  class="expand50-250 txtbox" name="response" size="20" rows="12" cols="100%"></textarea><br>

              
              <select onChange = "document.formname.response.value=this.options[this.selectedIndex].value"; name="cannedresponse" class="txtbox" >
              <option value="" selected>## Select Canned Response ##</option>
              					    <? echo "$cannedselect"; ?>

              
                

            </select><p align="center">
              <font size="1" face="Verdana, Arial, Helvetica, sans-serif">
            
             <input class="txtbox" type="hidden" name="addhdresponse" value="1">

<label><input type="radio" name="status" value="HOLD"  checked="" />Put this Ticket on HOLD</label>
<label><input type="radio" name="status" value="CLOSED"  />CLOSE this Ticket</label>
<br>

              <br>

 <input type="submit" name="Update" value="Submit"></font><br><br></td>
            </tr>
            </table>
</form>
            
           </div></td>
          </tr>
        </table></td>
    </tr>
   
  </table>
		</font> </div></td>
  </tr>
</table>






    <?php
}}

}
else
{
    header("Location: clientlogin.php");
    exit();
}

?>