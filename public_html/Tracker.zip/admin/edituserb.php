<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
 include("connection.php");





    if($_POST['updatecl'] == 1)      {
          $query = "UPDATE users SET
                    username='" . mysql_real_escape_string($_POST['newusername']) . "',
                    password='" . mysql_real_escape_string($_POST['newpassword']) . "',
                    fname='" . mysql_real_escape_string($_POST['newfname']) . "',
                    lname='" . mysql_real_escape_string($_POST['newlname']) . "',
                    title='" . mysql_real_escape_string($_POST['title']) . "',
                    email='" . mysql_real_escape_string($_POST['newemail']) . "',
                    extension='" . mysql_real_escape_string($_POST['newextension']) . "',
                    access='" . mysql_real_escape_string($_POST['newaccess']) . "',                                        
                    affiliate='" . mysql_real_escape_string($_POST['affiliate']) . "',
                    brokers='" . mysql_real_escape_string($_POST['brokers']) . "',                                        
                    modletters='" . mysql_real_escape_string($_POST['modletters']) . "',                                        
                    modemails='" . mysql_real_escape_string($_POST['modemails']) . "',                                        
                    modleads='" . mysql_real_escape_string($_POST['restrict']) . "',                                      
                    mon1='" . mysql_real_escape_string($_POST['mon1']) . "',                                      
                    mon2='" . mysql_real_escape_string($_POST['mon2']) . "',                                      
                    tue1='" . mysql_real_escape_string($_POST['tue1']) . "',                                      
                    tue2='" . mysql_real_escape_string($_POST['tue2']) . "',                                      
                    wed1='" . mysql_real_escape_string($_POST['wed1']) . "',                                      
                    wed2='" . mysql_real_escape_string($_POST['wed2']) . "',                                      
                    thu1='" . mysql_real_escape_string($_POST['thu1']) . "',                                      
                    thu2='" . mysql_real_escape_string($_POST['thu2']) . "',                                      
                    fri1='" . mysql_real_escape_string($_POST['fri1']) . "',                                      
                    fri2='" . mysql_real_escape_string($_POST['fri2']) . "',                                      
                    sat1='" . mysql_real_escape_string($_POST['sat1']) . "',                                      
                    sat2='" . mysql_real_escape_string($_POST['sat2']) . "',                                      
                    sun1='" . mysql_real_escape_string($_POST['sun1']) . "',                                      
                    sun2='" . mysql_real_escape_string($_POST['sun2']) . "'                                    
					WHERE id='" . mysql_real_escape_string($_POST['uid']) . "'";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          echo("<br>The User <b>" . $_POST['newusername'] . "</b> has been edited.<br><br>");
          }

		  if($_POST['updatesales'] == 1)      {
          $query = "UPDATE sales_affiliates SET
                address='" . mysql_real_escape_string($_POST['address']) . "',
                city='" . mysql_real_escape_string($_POST['city']) . "',
                state='" . mysql_real_escape_string($_POST['state']) . "',
                zip='" . mysql_real_escape_string($_POST['zip']) . "',
                ssn='" . mysql_real_escape_string($_POST['ssn']) . "',
                commission_rate='" . mysql_real_escape_string($_POST['commission_rate']) . "'    
				WHERE id='" . mysql_real_escape_string($_POST['affiliate_id']) . "'";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          echo("<br>The User <b>" . $_POST['username'] . "</b> has been edited.<br><br>");
          }


$query = "SELECT id, username, fname, access, affiliate, password, brokers, modletters, modemails, modleads, email, extension, lname, title, mon1, mon2, tue1, tue2, wed1, wed2, thu1, thu2, fri1, fri2, sat1, sat2, sun1, sun2 FROM users WHERE id='$uid'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
 while($row=mysql_fetch_row($result))
    {
      $id = $row[0];
      $name = $row[1];
      $fname = $row[2];
      $access = $row[3];      
      $affiliateaccess = $row[4];      
      $password = $row[5];      
      $brokeraccess = $row[6];       
      $modletters = $row[7];       
      $modemails = $row[8];       
      $restrict = $row[9];       
      $email = $row[10];       
      $extension = $row[11];       
      $lname = $row[12];       
      $title = $row[13];       
      $mon1 = $row[14];       
      $mon2 = $row[15];       
      $tue1 = $row[16];       
      $tue2 = $row[17];       
      $wed1 = $row[18];       
      $wed2 = $row[19];       
      $thu1 = $row[20];       
      $thu2 = $row[21];       
      $fri1 = $row[22];       
      $fri2 = $row[23];       
      $sat1 = $row[24];       
      $sat2 = $row[25];       
      $sun1 = $row[26];       
      $sun2 = $row[27];
	  } 

//////ROUND ROBIN CODING
$query = "SELECT salesid FROM roundrobin WHERE salesid='$uid'";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
 while($row=mysql_fetch_row($result))
    {
      $salesid = $row[0];
    } 

if($salesid =="" && $_POST['roundrobin'] == "Yes"){
$query = "INSERT INTO roundrobin(name, salesid, affid, status)
                VALUES(
                '$fname $lname', 
                '$uid', 
                '" . mysql_real_escape_string($_POST['affid']) . "', 
                'IN')";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

		$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Add Sales ID to Round Robin',
                    '$uid',
                    '$fname $lname',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

}
if($salesid == $uid && $_POST['roundrobin'] == "No"){
        $query = "DELETE FROM roundrobin WHERE salesid='$uid'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Delete Sales ID from Round Robin',
                    '$uid',
                    '$fname $lname',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
	}
	if($salesid == $uid && $_POST['roundrobin'] == "Yes"){
          $query = "UPDATE roundrobin SET
                    affid='" . mysql_real_escape_string($_POST['affid']) . "'                                      
                    WHERE salesid='$uid'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

	}


$salesid ="";
/////FINAL QUERY
$query = "SELECT salesid, affid, status FROM roundrobin WHERE salesid='$uid'";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
 while($row=mysql_fetch_row($result))
    {
      $salesid = $row[0];
      $affid2 = $row[1];
      $rrstatus = $row[2];
    } 

	if($salesid ==""){
		$roundrobin = "No";
	}else{
		$roundrobin = "Yes";
	}

////////////END ROUND ROBIN CODING

  $query = "SELECT lname, fname, address, city, state, zip, email, fax, phone, ssn, user, password, comments, alt_phone, commission_rate, id, type FROM sales_affiliates WHERE id='$id' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lname = $row[0];
        $fname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $state = $row[4];
        $zip = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $phone = $row[8];
        $ssn = $row[9];
        $user = $row[10];
        $password = $row[11];
	    $comments = $row[12];
	    $altphone = $row[13];	  	   	  
		$commission_rate = $row[14];	 
		$affiliate_id = $row[15];			
		$type = $row[16];			
    }

	if($affiliate_id !="" && $type!="Affiliate"){
$salesrecord = "yes";
$LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_sales WHERE rep_id = '$affiliate_id' GROUP BY rep_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}


}else{

	if($affiliate_id !="" && $type=="Affiliate"){
$idconflict = "yes";
$salesrecord = "ID CONFLICT!";

  $query = "SELECT max(id) FROM sales_affiliates GROUP BY id";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
		$maxid = $row[0];			
$maxid = $maxid +1;
    }

}else{
$salesrecord = "no";
$createsalesrecord="<input type=\"button\" value=\"Create Sales Record\" onClick=\"javascript:window.location.href='edituserb.php?createsales=yes&uid=$uid'\">";
}

}

		     if($createsales == "yes" && $salesrecord=="no"){

				 $createdate = date("Y-m-d");
        $query = "INSERT INTO sales_affiliates(id, fname, lname, company, address, city, state, zip, email, fax, phone, ssn, type, commission_rate)
                VALUES(
                '$uid', 
                '$fname', 
                '$lname', 
                '" . mysql_real_escape_string($_POST['company']) . "', 
                '" . mysql_real_escape_string($_POST['saddress']) . "', 
                '" . mysql_real_escape_string($_POST['city']) . "', 
                '" . mysql_real_escape_string($_POST['state']) . "',
                '" . mysql_real_escape_string($_POST['szip']) . "',
                '$email',
                '" . mysql_real_escape_string($_POST['fax']) . "',
                '" . mysql_real_escape_string($_POST['phone']) . "',
                '" . mysql_real_escape_string($_POST['ssnum']) . "',
                'Sales',
                '" . mysql_real_escape_string($_POST['commission_rate']) . "')";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());


    header("Location: edituserb.php?uid=$uid");
          }


if($reassign == "yes" && $maxid !=""){
$query = "UPDATE users SET
id='$maxid'
WHERE id='$uid'";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
header("Location: edituserb.php?uid=$maxid");
}

//////////STANDARD QUERY
$query = "SELECT id, username, fname, access, affiliate, password, brokers, modletters, modemails, modleads, email, extension, lname, title FROM users WHERE id='$uid'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
 while($row=mysql_fetch_row($result))
    {
      $id = $row[0];
      $name = $row[1];
      $fname = $row[2];
      $access = $row[3];      
      $affiliateaccess = $row[4];      
      $password = $row[5];      
      $brokeraccess = $row[6];       
      $modletters = $row[7];       
      $modemails = $row[8];       
      $restrict = $row[9];       
      $email = $row[10];       
      $extension = $row[11];       
      $lname = $row[12];       
      $title = $row[13];       
    } 
    

      
      
    
          ?>
     <title>Edit User</title>

           <?php
			   include('template.php');

    include('main.php');
    include('rolloverhelp.php');
   ?>     
  

<body onLoad="Tooltip.init()">
<h3 class="elegantLG" align="center"><?php print($fname); ?> <?php print($lname); ?>'s Employee Record</h3>

<table width="100%">
<tr>
<td valign="top" align="center">

    <FORM  action="" method="POST">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="500">
<tr><td width="1"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Edit User</td>
<td width="1"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>


<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="500">
               <tr> 
            <td> 
            <table width="100%" border="0" cellspacing="4" cellpadding="2" bgcolor="#FFFFFF" style="border-collapse: collapse" bordercolor="#111111">
            <tr> 
                <td width="157" height="11"> 
                    <div align="right"><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>User name:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="11"> 
<?php
  if($name == "admin"){
	?>
&nbsp;<?php print($name); ?><input type="hidden" name="newusername" value="<?php print($name); ?>">
<?php
}else{
	?>
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newusername" type="text" value="<?php print($name); ?>" size="20"><img border="0" src="input-right.gif" width="7" ><?php
	}
	?>
                </td>
            </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>Password:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newpassword" type="text" value="<?php print($password); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
             </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      First Name</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newfname" type="text" value="<?php print($fname); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
             </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Last Name</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newlname" type="text" value="<?php print($lname); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
             </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Title</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="title" type="text" value="<?php print($title); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
<img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Title</B><BR>Enter the title of this employee if applicable.<font color=#0364C4 style=font-size:9px;><br><br>I.E. Glorified Janitor</font>')" 
    onmouseout="hideTip()" width="19" height="19">
                </td>
             </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Email</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newemail" type="text" value="<?php print($email); ?>" size="30"><img border="0" src="input-right.gif" width="7" >
<img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Email</B><BR>Please enter a valid email.  If this email field is blank, then this user will not be able to send any of the Preformatted Sales Emails that you have in the system.  Preformatted Sales Emails are created under Adminstration --> System Emails --> Sales Emails.  Once created, the sales user can click on them from any Prospect Record.<font color=#0364C4 style=font-size:9px;><br><br>I.E. user@domain.com.  We can setup emails for you free of charge.  Please contact your Account Executive if you need them.</font>')" 
    onmouseout="hideTip()" width="19" height="19">
                </td>
             </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Extension</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newextension" type="text" value="<?php print($extension); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
<img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Extension</B><BR>If this user has an extension that is dialed off of the main number to be reached, then enter it here.<font color=#0364C4 style=font-size:9px;><br><br>I.E. 7525</font>')" 
    onmouseout="hideTip()" width="19" height="19">
                </td>
             </tr>

            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Access</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td width="246" height="17"> 
                    <select name="newaccess" class="txtbox"  >
                     <option value="<?php print($access); ?>" selected><?php print($access); ?></option>

                
                <option value="full">full</option>
                <option value="processing">processing</option>
                <option value="support">support</option>
                <option value="sales">sales</option>                
                <option value="WebCMS">WebCMS</option>                
                
                
                                
              </select>
                </td>
             </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Manage Affiliate<br>
                      Program</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td width="246" height="17"> 
                    <select name="affiliate" class="txtbox"  >
     <option value="<?php print($affiliateaccess); ?>" selected><?php print($affiliateaccess); ?></option>

                <option value="No">No</option>
                <option value="Yes">Yes</option>                
                
                                
              </select>
			  <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Manage Affiliate Program</B><BR>If this is set to Yes, then this user has complete and full access to the Affiliate section of the system.<font color=#0364C4 style=font-size:9px;><br><br>Not recommended for anyone other than the ADMIN username.</font>')" 
    onmouseout="hideTip()" width="19" height="19">
                </td>
             </tr>
            <tr> 
                <td width="157" height="9"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Manage
                      Broker Program</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td width="246" height="9"> 
                    <select name="brokers" class="txtbox"  >
     <option value="<?php print($brokeraccess); ?>" selected><?php print($brokeraccess); ?></option>

                <option value="No">No</option>
                <option value="Yes">Yes</option>                
                
                                
              </select>
			  <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Manage Broker Program</B><BR>If this is set to Yes, then this user has complete and full access to the Broker section of the system.<font color=#0364C4 style=font-size:9px;><br><br>Not recommended for anyone other than the ADMIN username.</font>')" 
    onmouseout="hideTip()" width="19" height="19">
                </td>
             </tr>


             <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Modify Leads</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td width="231" height="17"> 
                    <select name="modemails" class="txtbox"  >
     <option value="<?php print($modemails); ?>" selected><?php print($modemails); ?></option>

                <option value="No">No</option>
                <option value="Yes">Yes</option>                
                
                                
              </select>
                <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Modify Leads</B><BR>If this is set to Yes, then this user can modify the data contained in a Prospect Record.')" 
    onmouseout="hideTip()" width="19" height="19"></td>
             </tr>


            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Restrict Lead View?</font></b></div>
                </td>
<td width="231" height="17"><select name="restrict" class="txtbox"  >
     <option value="<?php print($restrict); ?>" selected><?php print($restrict); ?></option>

                <option value="No">No</option>
                <option value="Yes">Yes</option>                
                
                                
              </select>
                 <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Lead Restriction</B><BR>If this is set to No or Blank, then this user can see all leads without restriction.  If set to Yes, then this user can only see leads with the affiliate username of <b><i><?php print($name); ?></i></b> tied to it.<font color=#0364C4 style=font-size:9px;><br><br>Good for locking down to self generated leads.</font>')" 
    onmouseout="hideTip()" width="19" height="19">
</td>
             </tr>
         
</table>

<BR><BR>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="500">
<tr><td width="1"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Access Hours <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Access Hours</B><BR>If you would like to restrict the hours <?php print($fname); ?> can log in, please adjust accordingly.  If you leave it blank then there is no restriction.<BR><BR>Please enter in 24 hour format.  I.E.  8am is 0800 and 5pm is 1700.')" 
    onmouseout="hideTip()" width="19" height="19">
</td>
<td width="1"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
<table width="100%" border="0" cellspacing="4" cellpadding="2" bgcolor="#FFFFFF" style="border-collapse: collapse" bordercolor="#111111">

<tr>
<td width="157" height="17"> 
<div align="right"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#336600">Monday</font></b></div>
</td>
<td width="231" height="17">
<input class="txtbox" type="text" name="mon1" size="5" value="<?php print($mon1); ?>" maxlength="5" />
<img src="cp_orange_arrow.gif" border="0">
<input class="txtbox" type="text" name="mon2" size="5" value="<?php print($mon2); ?>" maxlength="5" />
</td>
</tr>
<tr><tr>
<td width="157" height="17"> 
<div align="right"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#336600">Tuesday</font></b></div>
</td>
<td width="231" height="17">
<input class="txtbox" type="text" name="tue1" size="5" value="<?php print($tue1); ?>" maxlength="5" />
<img src="cp_orange_arrow.gif" border="0">
<input class="txtbox" type="text" name="tue2" size="5" value="<?php print($tue2); ?>" maxlength="5" />
</td>
</tr>
<tr><tr>
<td width="157" height="17"> 
<div align="right"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#336600">Wednesday</font></b></div>
</td>
<td width="231" height="17">
<input class="txtbox" type="text" name="wed1" size="5" value="<?php print($wed1); ?>" maxlength="5" />
<img src="cp_orange_arrow.gif" border="0">
<input class="txtbox" type="text" name="wed2" size="5" value="<?php print($wed2); ?>" maxlength="5" />
</td>
</tr>
<tr> <tr>
<td width="157" height="17"> 
<div align="right"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#336600">Thursday</font></b></div>
</td>
<td width="231" height="17">
<input class="txtbox" type="text" name="thu1" size="5" value="<?php print($thu1); ?>" maxlength="5" />
<img src="cp_orange_arrow.gif" border="0">
<input class="txtbox" type="text" name="thu2" size="5" value="<?php print($thu2); ?>" maxlength="5" />
</td>
</tr>
<tr> <tr>
<td width="157" height="17"> 
<div align="right"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#336600">Friday</font></b></div>
</td>
<td width="231" height="17">
<input class="txtbox" type="text" name="fri1" size="5" value="<?php print($fri1); ?>" maxlength="5" />
<img src="cp_orange_arrow.gif" border="0">
<input class="txtbox" type="text" name="fri2" size="5" value="<?php print($fri2); ?>" maxlength="5" />
</td>
</tr>
<tr> <tr>
<td width="157" height="17"> 
<div align="right"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#336600">Saturday</font></b></div>
</td>
<td width="231" height="17">
<input class="txtbox" type="text" name="sat1" size="5" value="<?php print($sat1); ?>" maxlength="5" />
<img src="cp_orange_arrow.gif" border="0">
<input class="txtbox" type="text" name="sat2" size="5" value="<?php print($sat2); ?>" maxlength="5" />
</td>
</tr>
<tr> <tr>
<td width="157" height="17"> 
<div align="right"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#336600">Sunday</font></b></div>
</td>
<td width="231" height="17">
<input class="txtbox" type="text" name="sun1" size="5" value="<?php print($sun1); ?>" maxlength="5" />
<img src="cp_orange_arrow.gif" border="0">
<input class="txtbox" type="text" name="sun2" size="5" value="<?php print($sun2); ?>" maxlength="5" />
</td>
</tr>
<tr> 





 
                <td width="157" height="8">&nbsp; 
                    </td>
                <td width="246" height="8">&nbsp; 
                    </td>
             </tr>
             <tr> 
                <td width="157">&nbsp;</td>
                <td width="246"> &nbsp;&nbsp; 
               <input type="hidden" name="updatecl" value="1">
   <input type="hidden" name="uid" value="<?php print($uid); ?>">               
    <INPUT type=submit value="Submit" name="submit">
            
                </td>
             </tr>
             </table>
          </td>
        </tr>
        </table>
        </FORM>

</td>
<td valign="top" align="center">





<FORM  action="" method="POST">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="500">
<tr><td width="1"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Sales Record = <?php print($salesrecord); ?>  <?php print($createsalesrecord); ?></td>
<td width="1"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>

<?php
if($idconflict =="yes"){
  ?>

<tr><td colspan=3><BR><font size=3>The ID assigned to this employee is already being used in the sales/affiliate database by an existing affiliate.  <BR><BR>We need to reassign the ID of this employee.  Once the ID has been reassigned, then you may create a sales record for this employee. <BR><BR>Please instruct this employee, if logged in, to log out completely and log back in once this process is complete.<BR><BR>
<input type="button" value="Reassign Employee ID to <?php print($maxid); ?>" onClick="javascript:window.location.href='edituserb.php?reassign=yes&newid=<?php print($maxid); ?>&uid=<?php print($uid); ?>'">
</td></tr>
<?php
}  ?>

</table>
<?php
if($salesrecord =="yes"){
  ?>


<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="500">
               <tr> 
            <td> 
            <table width="100%" border="0" cellspacing="4" cellpadding="2" bgcolor="#FFFFFF" style="border-collapse: collapse" bordercolor="#111111">
            <tr> 
                <td width="157" height="11"> 
                    <div align="right"><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>Address:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="11"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="address" type="text" value="<?php print($address); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>City:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="city" type="text" value="<?php print($city); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
             </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      State</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="state" type="text" value="<?php print($state); ?>" size="5"><img border="0" src="input-right.gif" width="7" >
                </td>
             </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Zip</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="zip" type="text" value="<?php print($zip); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
             </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      SSN</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="ssn" type="text" value="<?php print($ssn); ?>" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
             </tr>
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Commission</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="commission_rate" type="text" value="<?php print($commission_rate); ?>" size="15"><img border="0" src="input-right.gif" width="7" ><font size="2">(I.E. 50.00)</font>
                </td>
             </tr>
          
            <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Round Robin</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
  <select name="roundrobin" class="txtbox"  >
     <option value="<?php print($roundrobin); ?>" selected><?php print($roundrobin); ?></option>

                <option value="No">No</option>
                <option value="Yes">Yes</option>                
                
                                
              </select> <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Round Robin</B><BR>If this is set to Yes, then when a lead is added to the system, this sales ID will be included in the pool of Sales IDs to be assigned.<font color=#0364C4 style=font-size:9px;><br><br>Remember to turn the Round Robin feature on in your System Settings if you want to use this.  You may add Sales IDs to the Round Robin pool at anytime, but feature will not be turned on unless you turn it on.</font>')" 
    onmouseout="hideTip()" width="19" height="19">
                </td>
             </tr>


 <tr>
                <td width="157" height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Affiliate ID Exemption</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' width="246" height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="affid" type="text" value="<?php print($affid2); ?>" size="5"><img border="0" src="input-right.gif" width="7" > <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Affiliate ID Exemption</B><BR>Any lead submitted under the Affiliate ID entered in this field will go directly to this Sales Person and will not take this Sales Person out of the Round Robin pool.  <BR><BR>This is usually used if this sales person also generates leads under an Affiliate account, and it would not be fair for these leads to be distribued to others in the Round Robin pool, or for this Sales Person to be taken out of the Round Robin pool because one of his/her leads came in. <font color=#0364C4 style=font-size:9px;><br><br>You can find the Affiliate ID under Affiliate Search and when you have a list of Affiliates it is the first column called <B>ID</B>.  Simply enter that ID here.</font>')" 
    onmouseout="hideTip()" width="19" height="19">
                </td>
             </tr>




             <tr> 
                <td width="157">&nbsp;</td>
                <td width="246"> &nbsp;&nbsp; 
               <input type="hidden" name="updatesales" value="1">
   <input type="hidden" name="affiliate_id" value="<?php print($affiliate_id); ?>">               
    <INPUT type=submit value="Submit" name="submit">
            
                </td>
             </tr>
             </table>
          </td>
        </tr>
        </table>
        </FORM>







		
        
                          <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="500" id="AutoNumber3" height="1">
                            <tr>
                              <td width="50%"><b>
                              <a href="totalearned.php?salescheck=yes&sales_id=<?php print($affiliate_id); ?>">Total Comms</a><br>
                              <a href="totalpaid.php?salescheck=yes&sales_id=<?php print($affiliate_id); ?>">Total Paid</a><br>
                              Total Owed</b></td>
                              <td width="50%">$<?php print($COM_total_comish); ?><BR>
                                  $<?php print($COM_total_pd); ?> <BR>  
								$<?php print($COM_total_comish - $COM_total_pd); ?>  
                              </td>

                            </tr>
                            </table>
                            
                            <BR>
                            
                           
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="500">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Make Payment</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="500" id="AutoNumber3" cellpadding="0" background="bluestripshort.gif">
<form  action="addcommission.php"    method="post" >
<input type="hidden" name="salescommission" value="Yes">                           
<input type="hidden" name="sales_id" value="<?php print($affiliate_id); ?>">                           
<input type="hidden" name="adminuser" value="<?php print($_SESSION['usname']); ?>">                           
                            <tr>
                              <td width="100%" valign="top" colspan="2">
                              <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5" cellpadding="3">
                                <tr>
                                  <td width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style: none; border-right-width: medium">
                                  <font color="#FFFFFF"><b>Pay Date</b></font>
                                  <font size="1" color="#FF9900" face="Verdana">(I.E. 
                                  03-01-2006)</font></td>
                                  <td width="50%" style="border-left-style: none; border-left-width: medium; border-right-style: solid; border-right-width: 1"> 
                                        <input class="txtbox"  name="check_date" value="<? print date("m-d-Y"); ?>" size="20"></td>
                                </tr>
                                <tr>
                                  <td width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style: none; border-right-width: medium">
                                  <font color="#FFFFFF"><b>Pay Amount</b></font>
								  <font size="1" color="#FF9900" face="Verdana">(I.E. 1000.00 - no commas)</font></td>
                                  <td width="50%" style="border-left-style: none; border-left-width: medium; border-right-style: solid; border-right-width: 1"> 
                                        <input class="txtbox"  name="amount_paid" value="" size="13">
                                  </td>
                                </tr>
                                <tr>
                                  <td width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style: none; border-right-width: medium">
                                  <font color="#FFFFFF"><b>Check #</b></font></td>
                                  <td width="50%" style="border-left-style: none; border-left-width: medium; border-right-style: solid; border-right-width: 1"> 
                                        <input class="txtbox"  name="ck_number" value="" size="20"></td>
                                </tr>
                                <tr>
                                  <td width="100%" colspan="2" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1">
                                  <p align="center"><b>NOTES<br>
                                  </b> 
                                        <textarea class="txtbox"  name="notes" size="60" rows="6" cols="70"></textarea></td>
                                </tr>
                                <tr>
                                  <td width="100%" colspan="2" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                                  <p align="center"><input type="submit" value="Submit"></td>
                                </tr>
                              </table>
                              </td>
                            </tr>
                            </table>
  </center>
</div>



<?php
  }  ?>



  </td>
        </tr>
        </table>




   



        <?php
   
      
}
else
{
    header("Location: login.php");
    exit();
}

?>