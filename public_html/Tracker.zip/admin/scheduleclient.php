<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");
$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";
$scheduledbywho = $_SESSION['usfname'];


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
 $query = "SELECT companyskin, single FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyskin = $row[0]; 
        $creditprice = $row[1]; 
    }

if($scn == 1)
    {
  $scheduleddate = date("Y-m-d", time()+5*24*3600);

        $query = "UPDATE clients SET
        scheduleddate='$scheduleddate',
        status='scheduled',
        showstatus='Next round scheduled by $scheduledbywho'
        WHERE id='" . $_SESSION['clientid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

/////////////////////////////////
/////////////////////////////////
/////////////////////////////////

if($renew == 1)
    {

 $query = "SELECT resellercredit, status FROM clients WHERE id='" . $_SESSION['clientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $resellercredit = $row[0];
        $status = $row[1];
    }
    $query = "SELECT dateexpire FROM enrolment WHERE clientid='" . $_SESSION['clientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dateexpire = $row[0];
   }

function calc_due_date( $date, $interval, $add, $return_date_format='Y-m-d' )
{
  $date  =  strtotime( $date );
  if( $date !== -1 )
  {
    $date  =  getdate( $date );
    switch( strtolower($interval) )
    {
      case  'month'  :  $date['mon']  +=  $add;  break;
      case  'day'    :  $date['mday'] +=  $add;  break;
      default        :  $date['year'] +=  $add;
    }
    return( date($return_date_format, mktime(0, 0, 0, $date['mon'], $date['mday'], $date['year'])) );
  }
  return( false );
}





if($creditprice =="200.00"){
$nummonthrenew = 6;
$creditprice = "100.00";
}else if($creditprice =="150.00"){
$nummonthrenew = 3;
$creditprice = "50.00";
}else if($creditprice =="100.00"){
$nummonthrenew = 2;
$creditprice = "50.00";
}

$dateexpire  =  calc_due_date( $dateexpire, 'month', $nummonthrenew );

$creditprice = $resellercredit + $creditprice;
  if( $status == "canceled" or $status == "expired")
  {
$changestatus = "status='active',";
}

        $query = "UPDATE clients SET
		$changestatus
        resellercredit='$creditprice'
        WHERE id='" . $_SESSION['clientid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());


        $query2 = "UPDATE enrolment SET
        dateexpire='$dateexpire'
        WHERE clientid='" . $_SESSION['clientid'] . "'";
        $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());


$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Client Renewal',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

  














header("Location: clientstatus.php");  //redirect   
exit;


?>
              
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>


