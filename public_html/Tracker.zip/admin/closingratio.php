<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);


$nowday = date("d");
$nowmonthword = date("M");
$nowmonthword2 = date("F");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

$thismonth = date("Y-m");


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    include("connection.php");
    include('template.php');
    include('main.php');


if ($startdate !="" and $enddate !=""){
$leadquery = "((leadentered >= '$startdate' AND leadentered <= '$enddate') or (createdate >= '$startdate' AND createdate <= '$enddate')) ";
$salesquery= "createdate >= '$startdate' AND createdate <= '$enddate' ";



	}else{
$leadquery = "((leadentered like '$thismonth%') or (createdate like '$thismonth%')) ";
$salesquery= "createdate like '$thismonth%' ";
$daterange = " - $nowmonthword2 $nowyear";
$startdate = "YYYY-MM-DD";
$enddate = "YYYY-MM-DD";
}
    $query = "SELECT users.id, users.fname, users.lname, users.email FROM users,sales_affiliates where users.id = sales_affiliates.id and sales_affiliates.type='Sales' order by users.lname";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
      $salesid = $row[0];
      $fname = $row[1];
      $lname = $row[2];
      $email = $row[3];



$query2 = "SELECT id, name, address, email, singlecouple FROM clients WHERE ((leadassigned ='$salesid' and prospectclient ='Prospect') or (dealer_id='$salesid' and prospectclient='Client')) and $leadquery AND clientdelete != 'yes'";
$result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
$numberprospects = 0;
while($row2=mysql_fetch_row($result2))
{
              $id           = $row2[0];
              $clientname   = $row2[1];
              $address      = $row2[2];
              $cemail       = $row2[3];
              $singlecouple = $row2[4];

if ($singlecouple ==""){
	$prospectvalue = 1;
} elseif ($singlecouple =="Single"){
	$prospectvalue = 1;
} elseif ($singlecouple =="Joint"){
	$prospectvalue = .5;
}

$numberprospects = $numberprospects + $prospectvalue;
$totalprospects = $totalprospects + $prospectvalue;
}




$query3 = "SELECT id, name, address, email, singlecouple FROM clients WHERE (dealer_id=$salesid) and $salesquery AND clientdelete != 'yes' and prospectclient='Client'";
$result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
$numberclients = 0;
while($row3=mysql_fetch_row($result3))
{
              $id2           = $row3[0];
              $clientname2   = $row3[1];
              $address2      = $row3[2];
              $cemail2       = $row3[3];
              $singlecouple2 = $row3[4];

if ($singlecouple2 ==""){
	$clientvalue2 = 1;
} elseif ($singlecouple2 =="Single"){
	$clientvalue2 = 1;
} elseif ($singlecouple2 =="Joint"){
	$clientvalue2 = .5;
}

$numberclients = $numberclients + $clientvalue2;
$totalclients= $totalclients + $clientvalue2;

/*
if ($salesid ==59){
$tablerowdata2 .="<tr><td>$clientname2</td><td>$id2</td><td>$singlecouple2</td><td>$numberclients - $clientvalue2</td></tr> ";     
}
*/

}
$closingratio =0;
if ($numberprospects !="0"){
$closingratio = $numberclients/$numberprospects*100;
  $closingratio = number_format($closingratio, 2, '.', '');
$datavalues .= "<set label='$fname $lname' value='$closingratio' />";
}
$tablerowdata .="<tr bgcolor=\"#e8edff\" onMouseOver=\"this.bgColor='#d0dafd';\" onMouseOut=\"this.bgColor='#e8edff';\"><td>$fname $lname</td><td>$numberprospects</td><td>$numberclients</td><td>$closingratio %</td></tr> ";     

   } 
if ($totalprospects !="0"){
$totalclosingratio = $totalclients/$totalprospects*100;
  $totalclosingratio = number_format($totalclosingratio, 2, '.', '');
}

	$tablerowdata2 .="<tr bgcolor=\"#e8edff\"><td></td><td><B>$totalprospects</td><td><B>$totalclients</td><td><B>$totalclosingratio %</td></tr> ";     

    mysql_close($conn);
    ?>
	 <script type="text/javascript" src="FusionCharts.js"></script>
<link href="calendar.css" type="text/css" rel="stylesheet" />
<script src="calendar.js" type="text/javascript"></script>
<script type="text/javascript"> 
function init() {
	calendar.set("startdate");
	calendar.set("enddate");
}
</script>
<h3 class="elegantLG" align="center">Closing Ratio <?php print($daterange); ?></h3>
<form action="" method="get">
<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="350">
<tr><td class='ss-round-inputs' align="center"><b>&nbsp;Date Range:</b>
<img border="0" src="input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="startdate" id="startdate" size="11" value="<?php print($startdate); ?>"><img border="0" src="input-right.gif" width="7" > <b>&nbsp;to&nbsp; </b> 
<img border="0" src="input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="enddate" id="enddate" size="11" value="<?php print($enddate); ?>"><img border="0" src="input-right.gif" width="7" ></td>
<td><INPUT TYPE="image" SRC="go.png"></td>
</tr></table></form>

<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">

<tr>
<td align="center" >
	
	<?php





       function encodeDataURL($strDataURL, $addNoCacheStr=false) {
    if ($addNoCacheStr==true) {
		if (strpos($strDataURL,"?")<>0)
			$strDataURL .= "&FCCurrTime=" . Date("H_i_s");
		else
			$strDataURL .= "?FCCurrTime=" . Date("H_i_s");
    }
	return urlencode($strDataURL);
}


function datePart($mask, $dateTimeStr) {
    @list($datePt, $timePt) = explode(" ", $dateTimeStr);
    $arDatePt = explode("-", $datePt);
    $dataStr = "";
    if (count($arDatePt) == 3) {
        list($year, $month, $day) = $arDatePt;
        // determine the request
        switch ($mask) {
        case "m": return $month;
        case "d": return $day;
        case "y": return $year;
        }
        return (trim($month . "/" . $day . "/" . $year));
    }
    return $dataStr;
}


function renderChart($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false, $registerWithJS=false, $setTransparent="true") {
	if ($strXML=="")
        $tempData = "//Set the dataURL of the chart\n\t\tchart_$chartId.setDataURL(\"$strURL\")";
    else
        $tempData = "//Provide entire XML data using dataXML method\n\t\tchart_$chartId.setDataXML(\"$strXML\")";

    $chartIdDiv = $chartId . "Div";
    $ndebugMode = boolToNum($debugMode);
    $nregisterWithJS = boolToNum($registerWithJS);
	$nsetTransparent=($setTransparent?"true":"false");
$render_chart = <<<RENDERCHART

	<!-- START Script Block for Chart $chartId -->
	<div id="$chartIdDiv" align="center">
		Chart.
	</div>
	<script type="text/javascript">	
		var chart_$chartId = new FusionCharts("$chartSWF", "$chartId", "$chartWidth", "$chartHeight", "$ndebugMode", "$nregisterWithJS");
      chart_$chartId.setTransparent("$nsetTransparent");
    
		$tempData
		chart_$chartId.render("$chartIdDiv");
	                         </script>	
	<!-- END Script Block for Chart $chartId -->
RENDERCHART;

  return $render_chart;
}


function renderChartHTML($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false,$registerWithJS=false, $setTransparent="true") {
    $strFlashVars = "&chartWidth=" . $chartWidth . "&chartHeight=" . $chartHeight . "&debugMode=" . boolToNum($debugMode);
    if ($strXML=="")
        $strFlashVars .= "&dataURL=" . $strURL;
    else
        $strFlashVars .= "&dataXML=" . $strXML;
    
    $nregisterWithJS = boolToNum($registerWithJS);
    if($setTransparent!=""){
      $nsetTransparent=($setTransparent==false?"opaque":"transparent");
    }else{
      $nsetTransparent="window";
    }
$HTML_chart = <<<HTMLCHART
	<!-- START Code Block for Chart $chartId -->
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" 

codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="$chartWidth" height="$chartHeight" id="$chartId">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="$chartSWF"/>		
		<param name="FlashVars" value="$strFlashVars&registerWithJS=$nregisterWithJS" />
		<param name="quality" value="high" />
		<param name="wmode" value="$nsetTransparent" />
		<embed src="$chartSWF" FlashVars="$strFlashVars&registerWithJS=$nregisterWithJS" quality="high" width="$chartWidth" height="$chartHeight" 

name="$chartId" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" 

wmode="$nsetTransparent" /></object>
	<!-- END Code Block for Chart $chartId -->
HTMLCHART;

  return $HTML_chart;
}

function boolToNum($bVal) {
    return (($bVal==true) ? 1 : 0);
}
$strXML  = "<chart numberSuffix='%25' align='center' decimals='2' palette='2' chartTopMargin='50' labelDisplay='Rotate' slantLabels='1' numDivLines ='3' YAxisMaxValue ='100' showPrintMenuItem='0' showValues='1' use3DLighting ='1' showAboutMenuItem='0' showBorder='0'>";
	$strXML .= "$datavalues";
	
	$strXML .= "<styles>";

$strXML .= "<definition>";

$strXML .= "<style name='myFont' type='font' isHTML='1' bold='1' size='11' color='FFFFFF' />";
$strXML .= "<style name='myShadow' type='shadow' color='333333' angle='45' strength='3'/>";
$strXML .= "<style name='myShadow2' type='shadow' angle='45' distance='1' color='FFFFFF'/>";
$strXML .= "<style name='myAnim3' type='animation' param='_xScale' start='0' duration='1'/>";
$strXML .= "<style name='myAnim4' type='animation' param='_alpha' start='0' duration='1'/>";
$strXML .= "<style name='myAnim5' type='animation' param='_xScale' start='0' duration='1'/>";
$strXML .= "<style name='myAnim6' type='animation' param='_y' start='$canvasStartY' duration='1'/>";
$strXML .= "</definition>";


$strXML .= "<application>";
$strXML .= "<apply toObject='DataValues' styles='myFont,myShadow,myAnim' />";
//$strXML .= "<apply toObject='DataLabels' styles='myFont,myShadow,myAnim' />";
$strXML .= "<apply toObject='DIVLINES' styles='myShadow2' />";
$strXML .= "<apply toObject='ANCHORS' styles='myAnim2' />";
$strXML .= "<apply toObject='ANCHORS' styles='myBevel' />";
$strXML .= "<apply toObject='HGRID' styles='myAnim3, myAnim4' />";
$strXML .= "<apply toObject='DIVLINES' styles='myAnim5' />";
$strXML .= "<apply toObject='YAXISVALUES' styles='myAnim6' />";
$strXML .= "</application>";

$strXML .= "</styles>";

	$strXML .= "</chart>";
	
	echo renderChartHTML("Column3D.swf", "", $strXML, "bargraph", 900, 400, false, false);
 ?>
</td>
</tr>
</table>

<BR><BR><BR>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="600">
<tr><td width="1%"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Detailed Sales Data</td>
<td width="1%"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
 <table id="rounded-corner" width="600">

<tr bgcolor="#e8edff" onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
 <th class="rounded-company">Name</th>
<th class="rounded-q1">Prospects</th>
<th class="rounded-q1">Sales</th>
<th class="rounded-q1">Closing Ratio</th>

</tr>



	<?php
		echo $tablerowdata;
			echo $tablerowdata2;
	echo "</table>";

	?>
<script src="http://www.openjs.com/js/jsl.js" type="text/javascript"></script>
<script src="http://www.openjs.com/common.js" type="text/javascript"></script>
<?php

}
else
{
    header("Location: login.php");
    exit();
}


?>