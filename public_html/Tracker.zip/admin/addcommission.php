<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
    include("connection.php");
      
$ip=$_SERVER["REMOTE_ADDR"];
$user = $_SESSION['usfname'];

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$hour = date("h");
$min = date("i");
$sec = date("s");

$tstamp = "$hour:$min:$sec";

$method = "Check";

///////AFFILIATES                
if($_POST['affiliatecommission'] == 'Yes'){
$sql = "INSERT INTO commission_affiliate

(id,contact_id,affiliate_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,user,remove_amount_paid,payment_amount,payment_date)
               VALUES
(\"\",
\"\",
\"$affiliate_id\",
\"\",
\"\",
\"\",
\"$ck_number\",
\"Paid\",
\"verified\",
\"$method\",
\"$notes\",
\"$julian\",
\"$tstamp\",
\"$ip\",
\"$user\",
\"\",
\"$amount_paid\",
\"$check_date\")";

$result = @mysql_query($sql,$conn);
header("Location: affiliatestatus.php?message=Commission Credited");  //redirect   

   }             
///////BROKERS                
if($_POST['brokercommission'] == 'Yes'){
$sql = "INSERT INTO commission_brokers

(id,contact_id,broker_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,user,remove_amount_paid,payment_amount,payment_date)
               VALUES
(\"\",
\"\",
\"$broker_id\",
\"\",
\"\",
\"\",
\"$ck_number\",
\"Paid\",
\"verified\",
\"$method\",
\"$notes\",
\"$julian\",
\"$tstamp\",
\"$ip\",
\"$user\",
\"\",
\"$amount_paid\",
\"$check_date\")";

$result = @mysql_query($sql,$conn);
header("Location: brokerstatus.php?message=Commission Paid");  //redirect   

   }             

///////SALESPERSONS 
if($_POST['salescommission'] == 'Yes'){
$sql = "INSERT INTO commission_sales

(id,contact_id,rep_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,user,remove_amount_paid,payment_amount,payment_date)
               VALUES
(\"\",
\"\",
\"$sales_id\",
\"\",
\"\",
\"\",
\"$ck_number\",
\"Paid\",
\"verified\",
\"$method\",
\"$notes\",
\"$julian\",
\"$tstamp\",
\"$ip\",
\"$user\",
\"\",
\"$amount_paid\",
\"$check_date\")";

$result = @mysql_query($sql,$conn);
header("Location: edituserb.php?uid=$sales_id&message=Commission Paid");  //redirect   

   }   

exit;
}
?>