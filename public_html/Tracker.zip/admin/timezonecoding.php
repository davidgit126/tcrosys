<?php
if($timezone =="Hawaii"){
$timezoneoffset ="-3 hour";
}else if($timezone =="Alaska"){
$timezoneoffset ="-1 hour";
}else if($timezone =="Pacific"){
$timezoneoffset ="+0 hour";
}else if($timezone =="Mountain"){
$timezoneoffset ="+1 hour";
}else if($timezone =="Arizona"){
$timezoneoffset ="+0 hour";
}else if($timezone =="Central"){
$timezoneoffset ="+2 hour";
}else if($timezone =="Eastern"){
$timezoneoffset ="+3 hour";
}
?>
