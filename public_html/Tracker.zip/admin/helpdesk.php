<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
include('template.php');
    include('main.php');


    if($helpdesk=="Yes" && ($_SESSION['usaccess']=="support" or $_SESSION['usaccess']=="full")){

//-------client
/* $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country FROM clients WHERE id='" . $_SESSION['usid'] . "' "; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $active = $row[11];
    } 
*/

    //mysql_close($conn);
    
     if($status =="OPEN"){
                   $statusq = " and status!='CLOSED'";
                   }
                   if($status =="CLOSED"){
                   $statusq = " and status='CLOSED'";
                   }
                   if($clid !=""){
                   $clientidq = " and clientid='$clid'";
                   $clientidl = "&clid=$clid";
                   }
    ?>

          <div align="center">
            <center><BR>
  <table width="60%" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
    <tr>
      <td height="22">( <a href="helpdesk.php?status=OPEN<?php print($clientidl); ?>">open requests</a> / <a href="helpdesk.php?status=CLOSED<?php print($clientidl); ?>">resolved requests</a> 
        ) </td>
    </tr>
    <tr> 
      <td height="22"> 
      <?php
if($added=="yes"){
echo "<p align=center><font color=#008000 size=3><b>Ticket Logged!</b></font>";
}
    ?>

</td>    </tr>
    <tr> 
      <td> 
       <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Consumer Helpdesk</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>


 <table id="rounded-corner" width="100%">

 <tr >
 <th class="rounded-company"></th>
 <th class="rounded-company">Ticket ID</th>
<th class="rounded-q1">Status</th>
<th class="rounded-q2">Subject</th>
<th class="rounded-q3">When Logged</th>
</tr>

        <!-- list of calls -->
        
        
          
              <?php
              

    $query = "SELECT id, status, subject, description, DATE_FORMAT(date, \"%m-%d-%Y\") as hdlogdate,  tstamp, ip FROM helpdesk WHERE deleted !='Yes'$statusq$clientidq ORDER BY id DESC"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $hdid= $row[0];
        $hdstatus = $row[1];
        $hdsubject = $row[2];
        $hddescription = $row[3];
        $hdlogdate= $row[4];
        $hdtstamp= $row[5];
        $hdip= $row[6];


        ?>

<tr bgcolor="#e8edff" onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
            
          
              <td height="11" width="5%"><center>
              <img src="../client/mail.gif" width="11" height="9"></center></td>
              <td height="11" width="7%"><a href="viewticket.php?helpdeskid=<?php print($hdid); ?>"><?php print($hdid); ?></a>
              </td>
              <td height="11" width="10%"><?php print($hdstatus); ?></td>
              <td height="11" width="45%">
               <a href="viewticket.php?helpdeskid=<?php print($hdid); ?>"><?php print($hdsubject); ?></a>
              </td>
              <td height="11" width="24%"><?php print($hdlogdate); ?></td>
            </tr>
              <?php
    }
    //mysql_close($conn);
    ?>

          </table>
          
        
        
        <!-- list of calls -->
        </div>
        
        </td>
    </tr>
    <tr> 
      <td>&nbsp; </td>
    </tr>
    </table>
            </center>
          </div>
          
          <p align="center"><input type="button" value="Manage Canned Responses" onClick="javascript:window.location.href='canned.php?type=helpdesk'">
</p>

    <?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>