<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
 include('template.php');
  include("connection.php");

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";
$today = date("Y-m-d");
$calendaruser =$_SESSION['usname'];

if($calmonth2 != "")
{
$date2 = mktime ( 3, 0, 0, $calmonth2, $calday2, $calyear2);
  $calsearch2 = date ( "Ymd", $date2 );
    $calsearchword2 = date ( "Ymd", $date2 );

}else{
$calsearch2 = $julian;
$calsearchword2 = "today";
}

    ?>
    <style type="text/css">
table.bordered {border-left: 1px solid black;border-top: 1px solid black; }
table.bordered tr td, table.bordered tbody tr td {border-right: 1px solid black;border-bottom:1px solid black}
body, td {font-family:Verdana,Arial,sans-serif}
body {font-size:0.8em}
button, input[type="submit"] {font-weight:bold;border:1px solid black;cursor:hand;}
h1 {font-size:1.4em;border:1px solid black;text-align:center;padding:0;margin:0;}
.coloredbg, h1, th {background-color:lightgrey}
h2 {font-size:1.2em;text-align:center;padding:0;margin:0;}
.note {font-style:italic;}
.bl, .blr, .blt, .blb, .blrt, .blrb, .bltb, .blrtb {border-left: 1px solid black}
.br, .blr, .brt, .brb, .blrt, .blrb, .brtb, .blrtb {border-right: 1px solid black}
.bt, .blt, .brt, .btb, .blrt, .bltb, .brtb, .blrtb {border-top: 1px solid black}
.bb, .blb, .brb, .btb, .blrb, .bltb, .brtb, .blrtb {border-bottom: 1px solid black}
a.footnote {border-bottom: 1px dotted black; text-decoration: none}

tr.odd td{background-color:lightyellow}
tr.even td{background-color:lightgrey}
tr.dnc td{background-image:url('littleDNC.png');} 
tr.hotlead td{background-image:url('littlefire.jpg');} 
tr.ni td{background-image:url('littlenotinterested.png');} 
tr.nc td{background-image:url('littlehand.png');} 
tr.nr td{background-image:url('littlehourglass.png');} 
tr.contractout td{background-image:url('littlecontractout.png');} 
tr.creditreview td{background-image:url('littlecreditreview.png');} 

.graph1, .graph2 {background-color:lightyellow; border-left: 1px solid black;border-right: 1px solid black;border-top: 1px solid black; font-size:1px;border-bottom:1px solid black}
.graph1 {background-color:lightyellow}
.graph2 {background-color:darkgray}
</style>
<SCRIPT LANGUAGE="JavaScript" SRC="CalendarPopup.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript">document.write(getCalendarStyles());</SCRIPT>
<SCRIPT LANGUAGE="JavaScript">
var cal = new CalendarPopup("testdiv1");
cal.setReturnFunction("setMultipleValues3"); 
function setMultipleValues3(y,m,d) { 
     document.forms[0].calyear2.value=y; 
     document.forms[0].calmonth2.selectedIndex=m; 
     document.forms[0].calday2.selectedIndex=d; 
     }
     
</SCRIPT>    
<!--------BROKER ID ONLY SCRIPT ---->
 <script type="text/javascript">

	subject_id = '';
	function handleHttpResponse() {
		if (http.readyState == 4) {
			if (subject_id != '') {
				document.getElementById(subject_id).innerHTML = http.responseText;
			}
		}
	}
	function getHTTPObject() {
		var xmlhttp;
		/*@cc_on
		@if (@_jscript_version >= 5)
			try {
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (E) {
					xmlhttp = false;
				}
			}
		@else
		xmlhttp = false;
		@end @*/
		if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
			try {
				xmlhttp = new XMLHttpRequest();
			} catch (e) {
				xmlhttp = false;
			}
		}
		return xmlhttp;
	}
	var http = getHTTPObject(); // We create the HTTP Object

	function getBrokerIdScriptPage(div_id,content_id)
	{
		subject_id = div_id;
		content = document.getElementById(content_id).value;
		http.open("GET", "template.php?searchpage=brokeridonly&content=" + escape(content), true);
		http.onreadystatechange = handleHttpResponse;
		http.send(null);
		if(content.length>0)
			brokerid_box('1');
		else
			brokerid_box('0');

	}	

	function highlight(action,id)
	{
	  if(action)	
		document.getElementById('word'+id).bgColor = "#184EAE";
	  else
		document.getElementById('word'+id).bgColor = "#2E2E2E";
	}
	function display(word)
	{
		document.getElementById('brokerid_text_content').value = word;
		document.getElementById('brokerid_box').style.display = 'none';
		document.getElementById('brokerid_text_content').focus();
	}
	function brokerid_box(act)
	{
	  if(act=='0')	
	  {
		document.getElementById('brokerid_box').style.display = 'none';

	  }
	  else
		document.getElementById('brokerid_box').style.display = 'block';
		document.getElementById('topbox').style.display = 'block';
	}
</script> 
   <title>Search Prospects</title>
    <font color="red">  <B> <?php print($message); ?></B></font>
    
    
    
    
 <?php
    include('main.php');
 

if($search  == "on")
{

 $sql = "SELECT * FROM sales_affiliates where status !='del' ORDER BY user";
  $result = @mysql_query($sql,$conn);
  while ($row = mysql_fetch_array($result)) {
  $ALL_username = $row['user'];
  $ALL_id = $row['id'];
  
  $AFFILIATE_select .= "<option value=\"$ALL_id\">$ALL_username</option>";
  }
  
   $sql2 = "SELECT * FROM dealers ORDER BY username";
  $result2 = @mysql_query($sql2,$conn);
  while ($row2 = mysql_fetch_array($result2)) {
  $ALLBROKER_username = $row2['username'];
  $ALLBROKER_id = $row2['dealer_id'];
  
  $BROKER_select .= "<option value=\"$ALLBROKER_id\">$ALLBROKER_username</option>";
  }

?>
<BR>

<link href="calendar.css" type="text/css" rel="stylesheet" />
<script src="calendar.js" type="text/javascript"></script>
<script type="text/javascript"> 
function init() {
	calendar.set("enrollfrom");
	calendar.set("enrollto");
}
</script>


      <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="650">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Search Prospects</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
               <table background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="650">
            <tr>
                <td width="75"><form action="" method="get"><font color="#FFFFFF"><b>&nbsp;Name: </b></font> </td>
                <td class='ss-round-inputs' width="225">
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="searchname" size="20" value="<? echo "$searchname"; ?>"><img border="0" src="input-right.gif" width="7" >
                </td>
                <td width="76" style="font-family: Verdana,Arial,sans-serif"><font color="#FFFFFF"><b>&nbsp;Affiliate:</b></font> </td>
                <td width="224" style="font-family: Verdana,Arial,sans-serif">
                    <select class="txtbox"  name="searchaffiliate">
<option value="<? echo "$searchaffiliate"; ?>"><? echo "$searchaffiliate"; ?></option>
<? echo "$AFFILIATE_select"; ?>
<option value="">REMOVE</option>
</select>
                </td>
            </tr>
            <tr>
                <td width="75"><font color="#FFFFFF"><b>&nbsp;Phone:</b></font> </td>
                <td class='ss-round-inputs' width="225">
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="searchphone" size="20" value ="<? echo "$searchphone"; ?>"><img border="0" src="input-right.gif" width="7" >
                </td>
 <td width="76" style="font-family: Verdana,Arial,sans-serif"><font color="#FFFFFF"><b>&nbsp;Broker:</b></font></td>
<td width="224" style="font-family: Verdana,Arial,sans-serif" class='ss-round-inputs' >
<div class="ajax-div">
<div class="input-div">
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="searchbroker" type="text" onKeyUp="getBrokerIdScriptPage('brokerid_box','brokerid_text_content')" id="brokerid_text_content" size="20"><img border="0" src="input-right.gif" width="7" ></div>
<div id="brokerid_box"></div>
</div>

</td>

            </tr>
            <tr>
                <td width="75"><font color="#FFFFFF"><b>&nbsp;E-mail:</b></font> </td>
                <td class='ss-round-inputs' width="225">
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="searchemail" size="20" value="<? echo "$searchemail"; ?>"><img border="0" src="input-right.gif" width="7" >
                </td>
                <td width="76" style="font-family: Verdana,Arial,sans-serif"><font color="#FFFFFF"><b>&nbsp;Status:</b></font></td>
<td width="224" style="font-family: Verdana,Arial,sans-serif"><select class="txtbox"  name="searchstatus">
<option value="<? echo "$searchstatus"; ?>" selected><? echo "$searchstatus"; ?></option>
<option value="DoNotCall">DoNotCall</option>
<option value="NonResponsive">NonResponsive</option>
<option value="NotInterested">NotInterested</option>
<option value="NotCandidate">NotCandidate</option>
<option value="HotLead">HotLead</option>
<option value="CreditReview">CreditReview</option>
<option value="ContractOut">ContractOut</option>
<option value="">REMOVE</option>
</select>
</td>
            </tr>


            <tr>
                <td width="128"><font color="#FFFFFF"><b>&nbsp;Entered From</b></font> </td>
                <td class='ss-round-inputs' width="375" colspan="3">
<img border="0" src="input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="enrollfrom" id="enrollfrom"  size="11" value="YYYY-MM-DD"><img border="0" src="input-right.gif" width="7" > <b><font color="#FFFFFF">&nbsp;to&nbsp; </font></b> 
<img border="0" src="input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="enrollto" id="enrollto" size="11" value="YYYY-MM-DD"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>



             <tr>
                <td width="600" colspan="4"> <input type="hidden" name="search" value="on">
                <p align="center">
                
        <input type="submit" name="Find" value="Find"></td>
            </tr>
            </table>
       
    </form>

   
<?php
}
/*
else{
?>


<form action="" method="get">
                <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="600">
<tr>
<td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Your calendar appointments for <? echo "$calsearchword2"; ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td>
</tr>
</table>

<table background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="600">
<tr>
<td width="600" align="center"> <pre style="
margin: 0px;
border: 1px inset;
width: 598px;
height: 100px;
text-align: left;
link: #FFFFFF;
overflow: auto">  
<?php

		$calsql2 = "SELECT * FROM calendar where cal_date='$calsearch2' and cal_create_by ='$calendaruser' ORDER BY cal_time";
		$calresult2 = @mysql_query($calsql2,$conn) or die("Couldn't execute");
		$number_appts = @mysql_num_rows($calresult2);
  while ($calrow2 = mysql_fetch_array($calresult2)) {	
		    $cal_id2 = $calrow2['cal_id'];
		    $cal_contactid2 = $calrow2['cal_contactid'];
		    $cal_create_by2 = $calrow2['cal_create_by'];
		    $cal_link2 = $calrow2['cal_link'];
		    $cal_name2 = $calrow2['cal_name'];
		    $cal_date2 = $calrow2['cal_date'];
		    $cal_time2 = $calrow2['cal_time'];
		    $active2 = $calrow2['cal_mod_time'];
		    
$cal_year2 = substr("$cal_date2", 0, 4);
$cal_month2 = substr("$cal_date2", 4, 2);
$cal_day2 = substr("$cal_date2", 6, 2);
$cal_time2 = substr("$cal_time2", 0, -2);
if (strlen($cal_time2) == 3){
$cal_time2 = "0$cal_time2";
}

		    
$caldateformat2 = $cal_year2/$cal_month2/$cal_day2;		    
//$cal_link2 = "prospectstatus.php?id=$cal_contactid2";
$strike_link2 = "menu.php?strike=$cal_id2";
$outlook_link = "menu.php?page=outlook&cal_id=$cal_id2";


if ($active2 != 0){
echo "</center><font color=\"#FFFFFF\">$cal_month2/$cal_day2/$cal_year2 at $cal_time2 :: <a \"text-decoration: none;\" href=$cal_link2><strong><font color=\"#FFFFFF\">$cal_name2</font></strong></a>  <a \"text-decoration: none;\" href=$strike_link2><strong><font color=\"#FFFFFF\">STRIKE</font></strong></a>  <a \"text-decoration: none;\" href=$outlook_link><strong><font color=\"#00FF7F\">Add to Outlook</font></strong></a><br>";		    
}else{
echo "</center><font color=\"#FFFFFF\"><strike>$cal_month2/$cal_day2/$cal_year2 at $cal_time2 :: <a \"text-decoration: none;\" href=$cal_link2><strong><font color=\"#FFFFFF\">$cal_name2</font></strong></a></strike><br>";		    
}
	
		  }

?> </pre>
		   </td>
            </tr>
</table>

<table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="600">
           
             <tr>
                <td width="600"> <input type="hidden" name="search" value="on">
                <p align="center">
                <select class="txtbox" name="calday2">
<option value="<? echo "$nowday"; ?>" selected="selected"><? echo "$nowday"; ?></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22"">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<select class="txtbox" name="calmonth2">
<option value="<? echo "$nowmonth"; ?>" selected="selected"><? echo "$nowmonthword"; ?></option>
<option value="1">Jan</option>
<option value="2">Feb</option>
<option value="3">Mar</option>
<option value="4">Apr</option>
<option value="5">May</option>
<option value="6">Jun</option>
<option value="7">Jul</option>
<option value="8">Aug</option>
<option value="9">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
<input maxlength="4" class="txtbox" type="text" name="calyear2" size="4" value=<? echo "$nowyear"; ?> >

<A HREF="#" onClick="cal.showCalendar('anchor1'); return false;" NAME="anchor1" ID="anchor1">
<img border="0" src="calendar.gif"></A>

        <input type="submit" name="search" value="search"></td>
            </tr>
            </table>
       
    </form>
    <DIV ID="testdiv1" STYLE="position:absolute;visibility:hidden;background-color:white;layer-background-color:white;"></DIV>

    <?php
}
*/
$limit=50;

if (! $start) {
$start = "0";
}

if ($pagenum != "") {
$start = 50*($pagenum - 1);
}else{
$pagenum = ($start / $limit) + 1;
}








$sort_by_ar[1] = "createdate";
$sort_by_ar[2] = "best_time_to_call";
$sort_by_ar[3] = "dateresults";
$sort_by_ar[4] = "createdate";


	if (! $sort_order) {
	$sort_order = "ASC";
	}

		if ($sort_order == "ASC") {
		$next_sort_order = "DESC";
		}else{
		$next_sort_order = "ASC";
		}

if (! $sort_by) {
$SORT = " ORDER BY createdate DESC";
}else{
$SORT = " ORDER BY $sort_by_ar[$sort_by] $sort_order";
}
if (! $searchbroker) {
$brokerquery = "";
}else{
$brokerquery = " AND broker_id='$searchbroker'";
}

if (! $searchaffiliate) {
$affquery = "";
}else{
$affquery = " AND affiliate_id='$searchaffiliate'";
}

if ($enrollfrom == "" or $enrollfrom =="YYYY-MM-DD" or $enrollto == "" or $enrollto =="YYYY-MM-DD") {
$enrollquery = "";
}else{
$enrollquery = " AND clients.createdate >= '$enrollfrom' AND clients.createdate <= '$enrollto'";
}

if (! $searchemail) {
$emailquery = "";
}else{
$emailquery = " AND email LIKE('%".$searchemail."%')";
}
if (! $searchname) {
$namequery = "";
}else{
$namequery = " AND name LIKE('%".$searchname."%')";
}
if (! $searchphone) {
$phonequery = "";
}else{
$phonequery = " AND phone LIKE('%".$searchphone."%')";
}
if (! $searchstatus) {
$statusquery = "";
}else{
$statusquery = " AND status LIKE('%".$searchstatus."%')";
}


if (! $searchphone && ! $searchname && ! $searchemail && ! $searchaffiliate && ! $searchbroker && ! $searchstatus) {
$bsleadquery = " AND status !='NotInterested' and status !='NotCandidate' and status !='DoNotCall' and status != 'NonResponsive'";
$notcurrent = " AND scheduleddate < '$today'";
}

if ($Find == "Find") {
$bsleadquery = "";
$notcurrent = "";
}


$query = "SELECT * FROM clients WHERE clientdelete !='yes' and prospectclient = 'Prospect' $bsleadquery $brokerquery $affquery $emailquery $namequery $phonequery $enrollquery $statusquery $notcurrent $restrictleads";
$endquery = "$query$SORT LIMIT $start,$limit";
$result = @mysql_query($endquery);


$total_result = @mysql_query($query);
$number_total_results = @mysql_num_rows($total_result);
$number_results = @mysql_num_rows($result);
$numberofpages = ceil($number_total_results / 50);
if (! $number_results || $number_results == "0"){
echo "<center><font color=\"#ff0000\"><b>No Results.</font></b></center>";
              
 $ERROR = "<center><font color=\"#ff0000\"><b>No Results.</font></b></center>";
               	exit;
}
 ?> <BR>
<?php
 if($_SESSION['usname']=="admin" && $Find =="Find"){
 ?>
 <input type="button" style="position:absolute;color: #07c;font-family: Georgia,serif;font-size: 12px;" name="OK" value="Export CSV" label="OK" onClick="javascript:window.location.href='leadscsv.php?searchname=<?php print($searchname);?>&searchaffiliate=<?php print($searchaffiliate);?>&searchphone=<?php print($searchphone);?>&searchbroker=<?php print($searchbroker);?>&searchemail=<?php print($searchemail);?>&searchstatus=<?php print($searchstatus);?>&enrollfrom=<?php print($enrollfrom);?>&enrollto=<?php print($enrollto);?>&Find=<?php print($Find);?>';">
<?php
 }
 ?>
<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="80%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">View All Prospects </td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<?php
$row_numb = "2";

echo "<table class=\"blrtb\" align=\"center\" width=\"80%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr>";


	if ($sort_by == "1") {
	$link = "prospectsearch.php?sort_by=1&sort_order=$next_sort_order$GET_NEXT_RSLT";
	}else{
	$link = "prospectsearch.php?sort_by=1&sort_order=ASC$GET_NEXT_RSLT";
	}
echo "<td align=\"center\" background=bluestripshort.gif ></td>";
echo "<td background=bluestripshort.gif ><a href=$link><font color=\"#FFFFFF\" size=\"2\"><b>Name</font></b></a></td>";
echo "<td background=bluestripshort.gif ><font color=\"#FFFFFF\" size=\"2\"><b>Phone</b></font></td>";
echo "<td background=bluestripshort.gif ><font color=\"#FFFFFF\" size=\"2\"><b>Email</b></font></td>";

	if ($sort_by == "2") {
	$link = "prospectsearch.php?sort_by=2&sort_order=$next_sort_order$GET_NEXT_RSLT";
	}else{
	$link = "prospectsearch.php?sort_by=2&sort_order=ASC$GET_NEXT_RSLT";
	}
//echo "<td background=bluestripshort.gif align=\"center\"><a href=$link><font color=\"#FFFFFF\" size=\"2\"><b>Best TTC</b></font></a></td>";


	if ($sort_by == "3") {
	$link = "prospectsearch.php?sort_by=3&sort_order=$next_sort_order$GET_NEXT_RSLT";
	}else{
	$link = "prospectsearch.php?sort_by=3&sort_order=ASC$GET_NEXT_RSLT";
	}
echo "<td background=bluestripshort.gif align=\"center\"><a href=$link><font color=\"#FFFFFF\" size=\"2\"><b>Last Contact</b></font></a></td>";
//echo "<td background=bluestripshort.gif align=\"center\"><font color=\"#FFFFFF\" size=\"2\"><b>Email</b></font></td>";

	if ($sort_by == "4") {
	$link = "prospectsearch.php?sort_by=4&sort_order=$next_sort_order$GET_NEXT_RSLT";
	}else{
	$link = "prospectsearch.php?sort_by=4&sort_order=ASC$GET_NEXT_RSLT";
	}
echo "<td background=bluestripshort.gif align=\"center\"><a href=$link><font color=\"#FFFFFF\" size=\"2\"><b>Enter Date</b></font></a></td>";
echo "<td background=bluestripshort.gif align=\"center\"><font color=\"#FFFFFF\" size=\"2\"><b>Follow Up Date</b></font></td>";
echo "<td background=bluestripshort.gif align=\"center\"><b><font color=\"#FFFFFF\" size=\"2\">Broker</font></b></td>";
echo "<td background=bluestripshort.gif align=\"center\"><font color=\"#FFFFFF\" size=\"2\"><b>Referrer</b></font></td>";
if ($roundrobinfeature == "ON"){
echo "<td background=bluestripshort.gif align=\"center\"><font color=\"#FFFFFF\" size=\"2\"><b>Round Robin</b></font></td>";
}
echo "<td background=bluestripshort.gif align=\"center\"></td>";
echo "</tr>";

$cnt=0;
while ($row = @mysql_fetch_array($result)) {

		$CLIENT_id = $row['id'];
		$CLIENT_fname = $row['name'];
		$CLIENT_lname = $row['lname'];
		$CLIENT_phone = $row['phone'];
		$CLIENT_work_phone = $row['work_phone'];
		$CLIENT_email = $row['email'];
		$CLIENT_company = $row['company'];
		$CLIENT_julian = $row['createdate'];
		$CLIENT_best_ttc = $row['best_time_to_call'];
		$CLIENT_last_contact_date = $row['dateresults'];
		$CLIENT_timezone = $row['timezone'];
		$CLIENT_referrer = $row['affiliate_id'];
		$CLIENT_broker_id = $row['broker_id'];
		$CLIENT_follow_up = $row['scheduleddate'];
		$CLIENT_status = $row['status'];
		$CLIENT_leadassigned = $row['leadassigned'];
		$CLIENT_doubleopt = $row['doubleopt'];
		$roundrobinname = ""; 
$cnt=$cnt+1;


if ($CLIENT_doubleopt == "Yes"){
$doubleoptmessage ="<font color='green'><b><i>validated</i></b></font>";
}else{
$doubleoptmessage ="<font color='red'><b><i>not validated</i></b></font>";
}
if ($roundrobinfeature == "ON"){

	$queryrr = "SELECT name FROM roundrobin WHERE salesid='$CLIENT_leadassigned'";
    $resultrr = mysql_query($queryrr, $conn) or die("error:" . mysql_error());
    while($rowrr=mysql_fetch_row($resultrr))
    {
		$roundrobinname = $rowrr[0]; 
    }
}

$SHOW_notes = "";
$fontcolor = "";
$bold = "";
$endbold = "";
if ($CLIENT_follow_up < $today){
$fontcolor = "color=red";
$bold = "<b>";
$endbold = "</b>";

}

if ($CLIENT_broker_id != ""){
$SA_sql = "SELECT username FROM dealers WHERE dealer_id = $CLIENT_broker_id";
		$SA_result = @mysql_query($SA_sql,$conn);
		  while ($srow = @mysql_fetch_array($SA_result)) {
		    $brokerusername = $srow['username'];
		}
}else {
$brokerusername = "";
}

if ($CLIENT_referrer != ""){
$SA_sql2 = "SELECT user FROM sales_affiliates WHERE id= $CLIENT_referrer";
		$SA_result2 = @mysql_query($SA_sql2,$conn);
		  while ($srow2 = @mysql_fetch_array($SA_result2)) {
		    $referrer = $srow2['user'];
		}
}else {
$referrer = "";
}


$entered_year = substr("$CLIENT_julian", 0, 4);
$entered_month = substr("$CLIENT_julian", 5, 2);
$entered_day = substr("$CLIENT_julian", 8, 2);

$lcd_year = substr("$CLIENT_last_contact_date", 0, 4);
$lcd_month = substr("$CLIENT_last_contact_date", 5, 2);
$lcd_day = substr("$CLIENT_last_contact_date", 8, 2);

$fu_year = substr("$CLIENT_follow_up", 0, 4);
$fu_month = substr("$CLIENT_follow_up", 5, 2);
$fu_day = substr("$CLIENT_follow_up", 8, 2);

	if ($row_numb == "1"){
	        $bgcolor = "class=\"even\""; 
	        $row_numb = "2";  
	}else{
	        $bgcolor = "class=\"odd\"";
	        $row_numb = "1";  
	}

if($CLIENT_status == "HotLead"){
	        $bgcolor = "class=\"hotlead\"";
	        $row_numb = "1";  
$showstatus = "Status is $CLIENT_status";
	}else if($CLIENT_status == "NotInterested"){
	        $bgcolor = "class=\"ni\"";
	        $row_numb = "1";  
$fontcolor = "color=white";
$bold = "<b>";
$endbold = "</b>";
$showstatus = "<b><font color=white>Status is $CLIENT_status</font></b>";

	}else if($CLIENT_status == "NotCandidate"){
	        $bgcolor = "class=\"nc\"";
	        $row_numb = "1";  
$fontcolor = "color=white";
$bold = "<b>";
$endbold = "</b>";
$showstatus = "<b><font color=white>Status is $CLIENT_status</font></b>";
	}else if($CLIENT_status == "DoNotCall"){
	        $bgcolor = "class=\"dnc\"";
	        $row_numb = "1"; 
$fontcolor = "color=white";
$bold = "<b>";
$endbold = "</b>"; 
$showstatus = "<b><font color=white>Status is $CLIENT_status</font></b>";
	}else if($CLIENT_status == "NonResponsive"){
	        $bgcolor = "class=\"nr\"";
	        $row_numb = "1";  
$fontcolor = "color=white";
$bold = "<b>";
$endbold = "</b>";
$showstatus = "<b><font color=white>Status is $CLIENT_status</font></b>";
	}else if($CLIENT_status == "ContractOut"){
	        $bgcolor = "class=\"contractout\"";
	        $row_numb = "1";  
$fontcolor = "color=white";
$bold = "<b>";
$endbold = "</b>";
$showstatus = "<b><font color=white>Status is $CLIENT_status</font></b>";
	}else if($CLIENT_status == "CreditReview"){
	        $bgcolor = "class=\"creditreview\"";
	        $row_numb = "1";  
$fontcolor = "color=black";
$bold = "<b>";
$endbold = "</b>";
$showstatus = "<b><font color=black>Status is $CLIENT_status</font></b>";
	}else{
$showstatus = "";
}









		$nsql = "SELECT * FROM salesnotes WHERE clientid = '$CLIENT_id'  AND (received !='broker' or received IS NULL) ORDER BY repairdate DESC, id DESC LIMIT 0,1";
		$nresult = @mysql_query($nsql,$conn) or die("Couldn't execute");
		$number_notes = @mysql_num_rows($nresult);
if (! $number_notes || $number_notes == "0"){
$fontcolor = "color=green";
$bold = "<b>";
$endbold = "</b>";
$NOTE_year ="";
$NOTE_month ="";
$NOTE_day ="";
}		
		  while ($nrow = mysql_fetch_array($nresult)) {	
		    $NOTE_id = $nrow['id'];
		    $NOTE_contact_id = $nrow['clientid'];
		    $NOTE_view = $nrow['action'];
		    $NOTE_user = $nrow['counselor'];
		    $NOTE_julian = $nrow['repairdate'];

		    $NOTE_year = substr("$NOTE_julian", 0, 4);
		    $NOTE_month = substr("$NOTE_julian", 5, 2);
		    $NOTE_day = substr("$NOTE_julian", 8, 2);

if ($roundrobinfeature == "ON"){
		$SHOW_notes = "<tr $bgcolor><td align=\"left\" colspan=\"100%\" valign=\"middle\"><font size=\"1\">&nbsp; $showstatus $SHOW_notes By: $NOTE_user - $NOTE_view </font></td></tr>";
}else{
		$SHOW_notes = "<tr $bgcolor><td align=\"left\" colspan=\"100%\" valign=\"middle\"><font size=\"1\">&nbsp; $showstatus $SHOW_notes By: $NOTE_user - $NOTE_view </font></td></tr>";
}
		  }


echo "<tr $bgcolor>";
echo "<td align=\"center\"><font size=\"1\">$cnt</font></td>";
echo "<td ><font $fontcolor size=\"1\">$bold $CLIENT_fname $CLIENT_lname</font></td>";
echo "<td ><font $fontcolor size=\"1\">$bold $CLIENT_phone</font></td>";
echo "<td ><font $fontcolor size=\"1\">$bold $CLIENT_email - $doubleoptmessage</font></td>";

echo "<td align=\"center\"><font $fontcolor size=\"1\">$bold $NOTE_month/$NOTE_day/$NOTE_year</font></td>";
echo "<td align=\"center\"><font $fontcolor size=\"1\">$bold $entered_month/$entered_day/$entered_year</font></td>";
echo "<td align=\"center\"><font $fontcolor size=\"1\">$bold $fu_month/$fu_day/$fu_year</font></td>";

echo "<td align=\"center\"><font $fontcolor size=\"1\">$bold $brokerusername</font></td>";
echo "<td align=\"center\"><font $fontcolor size=\"1\">$bold $referrer</font></td>";
if ($roundrobinfeature == "ON"){
echo "<td align=\"center\"><font $fontcolor size=\"1\">$bold $roundrobinname</font></td>";
}
echo "<td align=\"center\" width=\"75\">$CALL_bold<a href=prospectstatus.php?id=$CLIENT_id><font size=\"1\" color=\"$CALL_color\"><img border=\"0\" src=\"access.png\"></a>";
if($_SESSION['usaccess']=="full"){
echo "&nbsp;&nbsp;&nbsp;<a href=prospectdelete.php?cid=$CLIENT_id&cname=$CLIENT_fname><img border=\"0\" src=\"deletebutton.png\"></a>";
}

echo "</font>$CALL_ebold</td></tr>";


echo "$SHOW_notes $endbold";

}
echo "</table>";




$next_start=$start+$limit;
$previous_start=$start-$limit;

   echo "<br><center><table cellpadding=\"0\" width=\"80%\" border=\"0\"><tr>"; 
  
   if ($start >= "$limit") {
  	
  	echo "<td width=\"33%\">";
  	echo "<form method=\"POST\" action=prospectsearch.php>";
  	echo "<input type=\"hidden\" name=\"limit\" value=\"$limit\" size=20>";
  	echo "<input type=\"hidden\" name=\"start\" value=\"$previous_start\" size=20>";
  	echo "<input type=\"hidden\" name=\"pagenum\" value=\"\" size=1>";

  	echo "<input type=\"hidden\" name=\"sort_by\" value=\"$sort_by\" size=20>";
  	echo "<input type=\"hidden\" name=\"sort_order\" value=\"$sort_order\" size=20>";
  	echo "<input type=\"hidden\" name=\"searchname\" value=\"$searchname\" size=20>";
  	echo "<input type=\"hidden\" name=\"searchstatus\" value=\"$searchstatus\" size=20> ";
	echo "<input type=\"hidden\" name=\"searchphone\" value=\"$searchphone\" size=20>";
  	echo "<input type=\"hidden\" name=\"searchemail\" value=\"$searchemail\" size=20>";
  	echo "<input type=\"hidden\" name=\"searchbroker\" value=\"$searchbroker\" size=20>";
  	echo "<input type=\"hidden\" name=\"searchaffiliate\" value=\"$searchaffiliate\" size=20>";
  	echo "<input type=\"hidden\" name=\"enrollfrom\" value=\"$enrollfrom\" size=20>";
  	echo "<input type=\"hidden\" name=\"enrollto\" value=\"$enrollto\" size=20>";
  	echo "<input type=\"hidden\" name=\"search\" value=\"$search\" size=20>";
	echo "<input type=\"hidden\" name=\"Find\" value=\"$Find\" size=20>";


  	echo "$next_form";
  	echo "<input type=\"submit\" name=\"submit\" value=\"<<< Previous\" size=20>";
  	echo "</td>";
  	echo "</form>";
  	
   }else{
   echo "<td width=\"33%\">";
   echo "</td>";
   }
  

//////////////PAGE NUMBER CODE
  	echo "<td align=center width=\"33%\">";
  	echo "<form method=\"POST\" action=prospectsearch.php>";
	echo "<B><I>Page $pagenum of $numberofpages</I></B><BR>";
  	echo "Go To Page#<input type=\"text\" name=\"pagenum\" value=\"$pagenum\" size=1>";
  	echo "<input type=\"hidden\" name=\"limit\" value=\"$limit\" size=20>";
  	echo "<input type=\"hidden\" name=\"sort_by\" value=\"$sort_by\" size=20>";
  	echo "<input type=\"hidden\" name=\"sort_order\" value=\"$sort_order\" size=20>";
  	echo "<input type=\"hidden\" name=\"searchname\" value=\"$searchname\" size=20>";
  	echo "<input type=\"hidden\" name=\"searchstatus\" value=\"$searchstatus\" size=20> ";
	echo "<input type=\"hidden\" name=\"searchphone\" value=\"$searchphone\" size=20>";
  	echo "<input type=\"hidden\" name=\"searchemail\" value=\"$searchemail\" size=20>";
  	echo "<input type=\"hidden\" name=\"searchbroker\" value=\"$searchbroker\" size=20>";
  	echo "<input type=\"hidden\" name=\"searchaffiliate\" value=\"$searchaffiliate\" size=20>";
  	echo "<input type=\"hidden\" name=\"enrollfrom\" value=\"$enrollfrom\" size=20>";
  	echo "<input type=\"hidden\" name=\"enrollto\" value=\"$enrollto\" size=20>";
  	echo "<input type=\"hidden\" name=\"search\" value=\"$search\" size=20>";
  	echo "<input type=\"hidden\" name=\"Find\" value=\"$Find\" size=20>";


  	echo "<input type=\"submit\" name=\"submit\" value=\"Go\" size=20>";
  	echo "</td>";
  	echo "</form>";
/////////////END PAGE NUMBER




  if ($number_total_results > "$next_start") {
  
    	echo "<td width=\"33%\" align=right>";
  	echo "<form method=\"POST\" action=prospectsearch.php>";
  	echo "<input type=\"hidden\" name=\"limit\" value=\"$limit\" size=20> ";
  	echo "<input type=\"hidden\" name=\"start\" value=\"$next_start\" size=20> ";
  	echo "<input type=\"hidden\" name=\"pagenum\" value=\"\" size=1>";

  	echo "<input type=\"hidden\" name=\"sort_by\" value=\"$sort_by\" size=20> ";
  	echo "<input type=\"hidden\" name=\"sort_order\" value=\"$sort_order\" size=20> ";
  	echo "<input type=\"hidden\" name=\"searchname\" value=\"$searchname\" size=20> ";
  	echo "<input type=\"hidden\" name=\"searchstatus\" value=\"$searchstatus\" size=20> ";
	echo "<input type=\"hidden\" name=\"searchphone\" value=\"$searchphone\" size=20> ";
  	echo "<input type=\"hidden\" name=\"searchemail\" value=\"$searchemail\" size=20> ";
  	echo "<input type=\"hidden\" name=\"searchbroker\" value=\"$searchbroker\" size=20> ";
  	echo "<input type=\"hidden\" name=\"searchaffiliate\" value=\"$searchaffiliate\" size=20> ";
  	echo "<input type=\"hidden\" name=\"enrollfrom\" value=\"$enrollfrom\" size=20> ";
  	echo "<input type=\"hidden\" name=\"enrollto\" value=\"$enrollto\" size=20> ";
  	echo "<input type=\"hidden\" name=\"search\" value=\"$search\" size=20>";
  	echo "<input type=\"hidden\" name=\"Find\" value=\"$Find\" size=20> ";
  	echo "$next_form";
  	echo "<input type=\"submit\" name=\"submit\" value=\"Next\" size=20>";
  	echo "</td>";
  	echo "</form>";

   }else{
   echo "<td width=\"33%\">";
   echo "</td>";
   }

echo "</tr></table></center>";  

?>
 
    
<script src="http://www.openjs.com/js/jsl.js" type="text/javascript"></script>
<script src="http://www.openjs.com/common.js" type="text/javascript"></script>
    
    <?php
    



}
else
{
    header("Location: login.php");
    exit();
}

?>