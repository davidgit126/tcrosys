<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   
    ?>
   
  <?php
    if($_SESSION['usname']=="admin")
    {
    
    
    include('template.php');
     include("connection.php");
     $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload, autoresponder FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 
        $autoresponder = $row[14]; 

    }

     $query = "SELECT id, subject, message, type, days FROM autoresponders WHERE id='$autoid'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $autoid           = $row[0];
              $subject   = $row[1];
              $message   = $row[2];
              $type = $row[3];
              $days = $row[4];              
}

        ?>
  
    
   
<form method="POST" action="updateautoemail.php">
                            <input type="hidden" name="autoid" value="<?php print($autoid); ?>">



<div align="center">
  <center>
<font color="#FF0000"><b><?php print($success); ?></b></font>


<table width="100%"><tr><td width="100%" align=center valign="top">


<table border=1 width="100" cellspacing="1" cellpadding="6">


<tr>
  <td BGCOLOR="#CCCCCC" align="right">
<b><font face="Verdana" size="2">Days to send</font></b> </td><td BGCOLOR="#CCCCCC"> 
                                        <input class="txtbox" type=text name=days size=6 value="<? echo $days; ?>">
</TD>
</tr>


<tr><td BGCOLOR="#CCCCCC" align="right">
<b><font face="Verdana" size=2>Subject:</font></b> </td><td BGCOLOR="#CCCCCC"> 
<input class="txtbox" type=text name=subject size=88 value="<? echo $subject; ?>">
</TD></TR>

<tr><td colspan="2" BGCOLOR="#CCCCCC" align="center">
<textarea class="txtbox" rows="15" name="message"  id="message" cols="110"><? echo "$message" ?></textarea>
  <script language=JavaScript src='../include/gui/scripts/innovaeditor.js'></script>
   <script language=JavaScript src='http://www.tcrosystems.net/scripts/editautoresponder.js'></script>














</TD></TR>

</table>
<br>
<input type="submit" value="Update Email"> 



</td></tr></table>
</center>
</div>


</center>


  
</form>




  
<p><a href="menu.php">Main Menu</a></p>





  
<?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>