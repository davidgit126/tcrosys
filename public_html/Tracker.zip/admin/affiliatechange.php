<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
$_GET = str_replace("'", "`", $_GET);
$_GET = str_replace('"', '�', $_GET);
extract($_GET);
$ip=$_SERVER["REMOTE_ADDR"];
$year = date("Y");
$month = date("m");
$day = date("d");
$julian = "$year$month$day";
$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";


/////////AFFILIATES
if($_POST['updateaffiliate'] == 1)
    {
$sql = "SELECT * FROM sales_affiliates WHERE id = '$affiliate_id'";
$result = mysql_query($sql, $conn);
$AFFIL_DATA=mysql_fetch_array($result, MYSQL_ASSOC);

        $query = "UPDATE clients SET
        affiliate_id='" . mysql_real_escape_string($_POST['affiliate_id']) . "'
        WHERE id='" . $_SESSION['clientid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Affiliate Set',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$oldaffiliate = $_POST['oldaffiliate'];
$contact_id = $_SESSION['clientid'];
$user = $_SESSION['usfname'];

if ($oldaffiliate != $affiliate_id){
$sql = "DELETE FROM commission_affiliate WHERE contact_id = '$contact_id' AND affiliate_id = '$oldaffiliate'";
			$result = @mysql_query($sql,$conn);
}

if ($affiliate_id != ''){
// if affiliate has already been credited - stops accidental double commissions
$sql = "SELECT * FROM commission_affiliate WHERE contact_id = '$contact_id' AND affiliate_id = '$affiliate_id'";
$result = mysql_query($sql, $conn);
$number_results = @mysql_num_rows($result);
if (! $number_results || $number_results == "0"){
	$sql = "INSERT INTO commission_affiliate
	(id,contact_id,affiliate_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$affiliate_id\",
	\"$AFFIL_DATA[commission_rate]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"$user\")";
	$result = @mysql_query($sql,$conn);
	}
}
}
/////////BROKERS

  if($_POST['updatebroker'] == 1)
    {
$sql = "SELECT * FROM dealers WHERE dealer_id = '$broker_id'";
$result = mysql_query($sql, $conn);
$BROKER_DATA=mysql_fetch_array($result, MYSQL_ASSOC);

        $query = "UPDATE clients SET
        broker_id='" . mysql_real_escape_string($_POST['broker_id']) . "'
        WHERE id='" . $_SESSION['clientid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Broker Set',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
$oldbroker = $_POST['oldbroker'];
$contact_id = $_SESSION['clientid'];
$user = $_SESSION['usfname'];

if ($oldbroker != $broker_id){
$sql = "DELETE FROM commission_brokers WHERE contact_id = '$contact_id' AND broker_id = '$oldbroker'";
			$result = @mysql_query($sql,$conn);
}
if ($broker_id != '' and $BROKER_DATA[commission] !='0'){
// if broker has already been credited - stops accidental double commissions
$sql = "SELECT * FROM commission_brokers WHERE contact_id = '$contact_id' AND broker_id = '$broker_id'";
$result = mysql_query($sql, $conn);
$number_results = @mysql_num_rows($result);
if (! $number_results || $number_results == "0"){
	$sql = "INSERT INTO commission_brokers
	(id,contact_id,broker_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$broker_id\",
	\"$BROKER_DATA[commission]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"$user\")";
	$result = @mysql_query($sql,$conn);
	}
}
}




/////////SALESPERSONS
  if($_POST['updatesales'] == 1)
    {

$sql3 = "SELECT * FROM sales_affiliates WHERE id = '$sales_id'";
$result3 = mysql_query($sql3, $conn);
$SALES_DATA=mysql_fetch_array($result3, MYSQL_ASSOC);

		$query = "UPDATE clients SET
        dealer_id='" . mysql_real_escape_string($_POST['sales_id']) . "'
        WHERE id='" . $_SESSION['clientid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Sales Person Set',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
$oldsales = $_POST['oldsales'];
$contact_id = $_SESSION['clientid'];
$user = $_SESSION['usfname'];

if ($oldsales != $sales_id){
$sql = "DELETE FROM commission_sales WHERE contact_id = '$contact_id' AND rep_id = '$oldsales'";
			$result = @mysql_query($sql,$conn);
}
if ($sales_id != '' and $SALES_DATA[commission_rate] !='0'){
// if sales has already been credited - stops accidental double commissions
$sql = "SELECT * FROM commission_sales WHERE contact_id = '$contact_id' AND rep_id = '$sales_id'";
$result = mysql_query($sql, $conn);
$number_results = @mysql_num_rows($result);
if (! $number_results || $number_results == "0"){
	$sql = "INSERT INTO commission_sales
	(id,contact_id,rep_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$sales_id\",
	\"$SALES_DATA[commission_rate]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"$user\")";
	$result = @mysql_query($sql,$conn);
	}
}
}


header("Location: clientstatus.php");  //redirect   
exit;

?>
<?php
}
else
{
    header("Location: login.php");
    exit();
}
?>
