<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
     include('template.php');
 include("connection.php");

      if($_POST['updatecl'] == 1)
      {
        
        $query = "UPDATE sales_affiliates SET
                lname='" . mysql_real_escape_string($_POST['lname']) . "',
                fname='" . mysql_real_escape_string($_POST['fname']) . "',
                address='" . mysql_real_escape_string($_POST['address']) . "',
                city='" . mysql_real_escape_string($_POST['city']) . "',
                state='" . mysql_real_escape_string($_POST['state']) . "',
                zip='" . mysql_real_escape_string($_POST['zip']) . "',
                email='" . mysql_real_escape_string($_POST['email']) . "',
                fax='" . mysql_real_escape_string($_POST['fax']) . "',
                phone='" . mysql_real_escape_string($_POST['phone']) . "',
                alt_phone='" . mysql_real_escape_string($_POST['altphone']) . "',
                ssn='" . mysql_real_escape_string($_POST['ssnum']) . "',
                user='" . mysql_real_escape_string($_POST['user']) . "',
                password='" . mysql_real_escape_string($_POST['password']) . "',
                comments='" . mysql_real_escape_string($_POST['comments']) . "',
                commission_rate='" . mysql_real_escape_string($_POST['commission_rate']) . "'    
                WHERE id='" . $_SESSION['affiliateid'] . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Affiliate',
                    '" . mysql_real_escape_string($_SESSION['affiliateid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

   }
        
          
   
                	

    $query = "SELECT lname, fname, address, city, state, zip, email, fax, phone, ssn, user, password, comments, alt_phone, commission_rate, id FROM sales_affiliates WHERE status !='del' and id='" . $_SESSION['affiliateid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lname = $row[0];
        $fname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $state = $row[4];
        $zip = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $phone = $row[8];
        $ssn = $row[9];
        $user = $row[10];
        $password = $row[11];
	    $comments = $row[12];
	    $altphone = $row[13];	  	   	  
		$commission_rate = $row[14];	 
		$affiliate_id = $row[15];			

    }
    
  

  $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_affiliate WHERE affiliate_id = '$affiliate_id' GROUP BY affiliate_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}
    
    

$bgcolor = "c0c0c0";


    //mysql_close($conn);
?>
 <?php
    if($_SESSION['affiliate']=="Yes")
    {
?>
         <title>Affiliate Status Sheet</title>           <font color="red">  <B> <?php print($error); ?></B></font>
                    <?php
    include('main.php');
   ?>     
  
       
 



                        <form  action="affiliatestatus.php"    method="post" >
                                        <input type="hidden" name="budgetday" value="<?php print($budgetday); ?>"
                                        <font size="1" color="#008000" face="Arial">
                            <input type="hidden" name="enrol" value="1">
                            Username: 
                            <input class="txtbox"  type="text" name="user" value="<?php print($user);?>" size="20">
                            <br>
                            Password: 
                            <input class="txtbox"  type="text" name="password" value="<?php print($password);?>" size="20">

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="98%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Personal Information</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>


                             <table style="BORDER-COLLAPSE: collapse" bordercolor="#000080"
                            cellspacing="0" cellpadding="0" width="98%" bgcolor="#<?php print($bgcolor);?>" border="0">
                                <tbody>
                                <tr>
                                    <td width="25%" style="border-left-style: solid; border-left-width: 1">&nbsp;First Name 
                                        <input class="txtbox"  name="fname" value="<?php print($fname); ?>" size="20">
                                    </td>
                                    <td width="25%">Last Name 
                                        <input class="txtbox"  name="lname" value="<?php print($lname); ?>" size="20"> </td>
                                    <td width="50%" style="border-right-style: solid; border-right-width: 1">E-mail 
                                        <input class="txtbox"  name="email" value="<?php print($email); ?>" size="35">&nbsp;&nbsp;
                                        <?php
  if($welcomeresend == "Yes"){
        ?>
                                      Welcome Email Sent!
                                <?php
  }else if($welcomeresend == "No"){
        ?>
                                      Email not activated
                                <?php
 }else{
        ?>
       <input type="button" value="Resend Welcome Email" onClick="javascript:window.location.href='welcomeresend.php?t=Affiliate'">
                                <?php
 }

        ?>
</td>
                                </tr>
                                <tr>
                                    <td width="50%" colspan="2" style="border-left-style: solid; border-left-width: 1">
                                    &nbsp;Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                        <input class="txtbox"  size="45" name="address" value="<?php print($address); ?>">
                                    <br>
                                    &nbsp;City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                        <input class="txtbox"  size="22" name="city" value="<?php print($city); ?>">
                                    <br>
                                        &nbsp;State/Province&nbsp;&nbsp;&nbsp; 
                                        <input
                                                         size="4" name="state" value="<?php print($state); ?>">
                                    <br>
                                        &nbsp;Zip/Postal Code 
                                        <input class="txtbox"  size="10" name="zip" value="<?php print($zip); ?>">
                                    </td>
                                    <td width="50%" style="border-right-style: solid; border-right-width: 1">
                                        


                                         Commission: 
                                        <input class="txtbox"  
                                                         size="10" name="commission_rate" value="<?php print($commission_rate); ?>">
                                        
 
 
 
 
 
 
 
                                         </td>
                                </tr>
                                <tr>
                                    <td width="25%" style="border-left-style: solid; border-left-width: 1">
                                    &nbsp;Daytime Phone# 
                                        <input class="txtbox"  name="phone" value="<?php print($phone); ?>" size="20">
                                    </td>
                                    <td width="25%">Alt Phone# 
                                        <input class="txtbox"  name="altphone" value="<?php print($altphone); ?>" size="20">
                                    </td>
                                    <td width="50%" style="border-right-style: solid; border-right-width: 1">Fax# 
                                        <input class="txtbox"  name="fax" value="<?php print($fax); ?>" size="20">
                                    </td>
                                </tr>
                                <tr>
                                    <td width="50%" bgcolor="#<?php print($bgcolor);?>" colspan="2" style="border-left-style: solid; border-left-width: 1">
                                    &nbsp;SS# 
                                        <input class="txtbox"  name="ssnum" value="<?php print($ssn); ?>" size="20">
                                    </td>
                                    <td width="50%" style="border-right-style: solid; border-right-width: 1">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="border-left-style: solid; border-left-width: 1; border-bottom-style: solid; border-bottom-width: 1; border-right-style:solid; border-right-width:1"  width="100%" bgcolor="#<?php print($bgcolor);?>" colspan="3" valign="top">
                                    <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber2">
                                      <tr>
                                        <td width="6%" valign="top">Comments</td>
                                        <td width="47%"> 
                                        <textarea class="txtbox"  name="comments" size="20" rows="6" cols="64"><?php print($comments); ?></textarea></td>
                                        <td width="47%">&nbsp; 
                                     
                                        </td>
                                      </tr>
                                    </table>
                                    </td>
                                </tr>
    </tbody>
                            </table>
                            <br>
                            <input type="hidden" name="info" value="1">

                   
                            <input type="hidden" name="updatecl" value="1">
                           

 
              <?php
    if($_SESSION['usaccess']=="full")
    {
        ?>
 <input type="submit" name="Update" value="Update">
 
  
              <?php
 }
        ?>

                            </p>

                        </form>

                       

                        
                      
                     
                        <div align="center">
                          <center>
                         <b><font color="#FF0000" face="Verdana" size="2"><?php print($message); ?>
                          </font></b>
                          <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber3">
                            <tr>
                              <td width="10%" valign="top" rowspan="3"><b>Payee:</b></td>
                              <td width="40%" rowspan="3">
                              <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber4">
                                <tr>
                                  <td width="100%"><?php print($fname); ?>&nbsp;<?php print($lname); ?><BR>
                                  					<?php print($address); ?><BR>
                                  					<?php print($city); ?>, <?php print($state); ?>&nbsp;<?php print($zip); ?></td>
                                </tr>
                              </table>
                              </td>
                              <td width="2%" rowspan="3">&nbsp;</td>
                              <td width="24%" rowspan="3"><b>Total Commissions<br>
                              Total Paid<br>
                              Total Owed</b></td>
                              <td width="6%" rowspan="3">$<?php print($COM_total_comish); ?> <BR>
                                                    $<?php print($COM_total_pd); ?> <BR>  

                                                    $<?php print($COM_total_comish - $COM_total_pd); ?>  
                              </td>
                              <td width="18%"><font size="1" face="Verdana">
                              <a href="totalearned.php?affiliatecheck=yes">Details</a> </font></td>
                            </tr>
                            <tr>
                              <td width="18%"><font size="1" face="Verdana">
                              <a href="totalpaid.php?affiliatecheck=yes">Details</a></font></td>
                            </tr>
                            <tr>
                              <td width="18%">&nbsp;</td>
                            </tr>
                            </table>
                            
                            <BR>
                            
                           
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="50%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Make Payment</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
                             <table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="50%" id="AutoNumber3" cellpadding="0" background="bluestripshort.gif">
 										<form  action="addcommission.php"    method="post" >
                                         <input type="hidden" name="affiliatecommission" value="Yes">                           
										<input type="hidden" name="affiliate_id" value="<?php print($_SESSION['affiliateid']); ?>">                           
										<input type="hidden" name="adminuser" value="<?php print($_SESSION['usname']); ?>">                           
                            <tr>
                              <td width="100%" valign="top" colspan="2">
                              <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5" cellpadding="3">
                                <tr>
                                  <td width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style: none; border-right-width: medium">
                                  <font color="#FFFFFF"><b>Pay Date</b></font>
                                  <font size="1" color="#FF9900" face="Verdana">(I.E. 
                                  03-01-2006)</font></td>
                                  <td width="50%" style="border-left-style: none; border-left-width: medium; border-right-style: solid; border-right-width: 1"> 
                                        <input class="txtbox"  name="check_date" value="" size="20"></td>
                                </tr>
                                <tr>
                                  <td width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style: none; border-right-width: medium">
                                  <font color="#FFFFFF"><b>Pay Amount</b></font></td>
                                  <td width="50%" style="border-left-style: none; border-left-width: medium; border-right-style: solid; border-right-width: 1"> 
                                        <input class="txtbox"  name="amount_paid" value="" size="13">
                                  <font size="1" color="#FF9900" face="Verdana">
                                        (I.E. 1000.00 - no commas)</font></td>
                                </tr>
                                <tr>
                                  <td width="50%" style="border-left-style: solid; border-left-width: 1; border-right-style: none; border-right-width: medium">
                                  <font color="#FFFFFF"><b>Check #</b></font></td>
                                  <td width="50%" style="border-left-style: none; border-left-width: medium; border-right-style: solid; border-right-width: 1"> 
                                        <input class="txtbox"  name="ck_number" value="" size="20"></td>
                                </tr>
                                <tr>
                                  <td width="100%" colspan="2" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1">
                                  <p align="center"><b>NOTES<br>
                                  </b> 
                                        <textarea class="txtbox"  name="notes" size="60" rows="6" cols="70"></textarea></td>
                                </tr>
                                <tr>
                                  <td width="100%" colspan="2" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                                  <p align="center"><input type="submit" value="Submit"></td>
                                </tr>
                              </table>
                              </td>
                            </tr>
                            </table>

                          </center>
</div>
                    
<?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>