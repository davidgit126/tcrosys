<?php
include_once('common.inc.php');

$conn = mysql_connect($db_settings['host'],$db_settings['user'],$db_settings['password']);
if (!$conn)
{
  echo "connection error " . $mysql_error . "<br/>";
}
$selectresult = mysql_select_db($db_settings['dbname'],$conn) or die("error:" . mysql_error());
if ($selectresult == false)
{
  echo "selection error " . $mysql_error . "<br/>";
}


?>