<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    
     include('template.php');
 include("connection.php");

 $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, autoscheduler, reseller, htdiwebsite, adminsinglepayment1, adminsinglepayment2, admincouplepayment1, admincouplepayment2, single, couple, creditcard, paypal2, ach, singlefull, singledownpay1, singlepayment, couplefull, coupledownpay1, couplepayment, threeinone, paypal, months, perdelete, livehuman, dbname, dropdowncreditors, dropdownbegin, dropdowntails, autoresponder, bautoresponder, cautoresponder FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $autoscheduler = $row[12];          
        $reseller = $row[13];           
        $htdiwebsite = $row[14];           
        $adminsinglepayment1 = $row[15];
        $adminsinglepayment2 = $row[16];
        $admincouplepayment1 = $row[17];
        $admincouplepayment2 = $row[18];                                
        $single = $row[19];                                
        $couple = $row[20];                                
        $creditcard = $row[21];                 
        $paypal2 = $row[22];                 
        $ach = $row[23];                 
        $singlefull = $row[24];          
        $singledownpay1 = $row[25];          
        $singlepayment = $row[26];          
        $couplefull = $row[27];          
        $coupledownpay1 = $row[28];          
        $couplepayment = $row[29];          
        $threeinone = $row[30];          
        $paypal = $row[31];          
        $months = $row[32];          
        $perdelete = $row[33];          
        $livehuman = $row[34];          
        $dbname = $row[35];          
        $dropdowncreditors = $row[36];    
        $dropdownbegin = $row[37];    
        $dropdowntails = $row[38];                            
        $autoresponder = $row[39];                            
        $bautoresponder = $row[40];                            
        $cautoresponder = $row[41];                            
    }
 

?>


   
 <?php
    include('main.php');
   ?> 
  <?php
    if($_SESSION['usname']=="admin")
    {
        ?>
  
  



  </tr>
   <?php

if($reseller =="Yes")
{
  
                  	include "700score_connection2.php"; 
            	
            	    $query = "SELECT dealer_id  FROM dealers WHERE dbname='$dbname' limit 1";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dealer_id = $row[0];
  
        }
 
    $query = "SELECT SUM(amountpurchased) as amountpurchased FROM bulktracking WHERE dealer_id='$dealer_id'";
$result = @mysql_query($query,$conn2);
while ($row = mysql_fetch_array($result)) {	
$totalamountpurchased = $row['amountpurchased'];
}


    
$query2 = "SELECT SUM(resellercredit) as resellercredit FROM clients";
$result2 = @mysql_query($query2,$conn);
while ($row2 = mysql_fetch_array($result2)) {	
$totalresellercredit = $row2['resellercredit'];

}



           
      

?>

  <tr>
    <td width="100%" valign="top" colspan="2" style="border-bottom-style: solid; border-bottom-width: 1" height="20">
    <p align="center"> <b>Accounting</b></td>
  </tr>
  <tr>
    <td width="100%" valign="top" colspan="2" style="border-bottom-style: solid; border-bottom-width: 1" height="20">
    <p align="center"> Your account has <?php print($totalamountpurchased - $totalresellercredit) / 100;?> available credits
</td>
  </tr>
  <tr>
    <td width="50%" style="border-right-style: solid; border-right-width: 1" height="19">
    
    <p align="center"><a href="clientaccounting.php">List Clients</a></td>
    <td width="50%" style="border-left-style: solid; border-left-width: 1" height="19">
  <a href="depositaccounting.php">List Deposits</a></td>



  </tr>
  <tr>
    <td width="50%" style="border-right-style: solid; border-right-width: 1" height="19">&nbsp;
    
    </td>
    <td width="50%" style="border-left-style: solid; border-left-width: 1" height="19">&nbsp;
  </td>



  </tr>
   <?php
}
?>

</table>

<p>
<?php
}
?>

    </p>


<?php
mysql_close($conn);

}
else
{
    header("Location: login.php");
    exit();
}

?>