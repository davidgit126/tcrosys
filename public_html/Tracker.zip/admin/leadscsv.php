<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1 && $_SESSION['usname']=="admin"){
   include("connection.php");
   $i =1;

   $filename = "List of Leads " . date("Y-m-d");
   $ext = 'csv';

   header("Content-type: text/plain");
   header('Content-Disposition: attachment; filename="' . $filename . '.' . $ext . '"');
   header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
   header('Pragma: no-cache');
   header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
   header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1

       echo("id,Name,Address,City,State,Zip,Phone,Alt Phone,Email,Creation,Lead Assigned\r\n");

if (! $searchbroker) {
$brokerquery = "";
}else{
$brokerquery = " AND broker_id='$searchbroker'";
}

if (! $searchaffiliate) {
$affquery = "";
}else{
$affquery = " AND affiliate_id='$searchaffiliate'";
}

if ($enrollfrom == "" or $enrollfrom =="YYYY-MM-DD" or $enrollto == "" or $enrollto =="YYYY-MM-DD") {
$enrollquery = "";
}else{
$enrollquery = " AND clients.createdate >= '$enrollfrom' AND clients.createdate <= '$enrollto'";
}

if (! $searchemail) {
$emailquery = "";
}else{
$emailquery = " AND email LIKE('%".$searchemail."%')";
}
if (! $searchname) {
$namequery = "";
}else{
$namequery = " AND name LIKE('%".$searchname."%')";
}
if (! $searchphone) {
$phonequery = "";
}else{
$phonequery = " AND phone LIKE('%".$searchphone."%')";
}
if (! $searchstatus) {
$statusquery = "";
}else{
$statusquery = " AND status LIKE('%".$searchstatus."%')";
}


if (! $searchphone && ! $searchname && ! $searchemail && ! $searchaffiliate && ! $searchbroker && ! $searchstatus) {
$bsleadquery = " AND status !='NotInterested' and status !='NotCandidate' and status !='DoNotCall' and status != 'NonResponsive'";
$notcurrent = " AND scheduleddate < '$today'";
}

if ($Find == "Find") {
$bsleadquery = "";
$notcurrent = "";
}
	   
	   $query = "SELECT id, name, address, city, state, zip, phone, altphone, email, comments, createdate, leadassigned FROM clients WHERE
                prospectclient='Prospect' and clientdelete!='yes' $bsleadquery $brokerquery $affquery $emailquery $namequery $phonequery $enrollquery $statusquery $notcurrent $restrictleads ORDER BY id";
       $result = mysql_query($query, $conn) or die("error:" . mysql_error());
       $col_count = mysql_num_fields($result);
       while($row=mysql_fetch_row($result))
       {
           $id = $row[0];
           $name = $row[1];
           $address = $row[2];
           $city = $row[3];
           $state= $row[4];
           $zip= $row[5];
           $phone= $row[6];
           $altphone= $row[7];
           $email= $row[8];
           $comments= $row[9];
		   $createdate= $row[10];
		   $leadassigned= $row[11];
           echo("$id,$name,$address,$city,$state,$zip,$phone,$altphone,$email,$createdate,$leadassigned\r\n"); //--- without numbers
           $i = $i+1;
          // print("$row[0], $row[1], $row[2]");
          // print("\n");
      }

  
}
else
{
    header("Location: login.php");
    exit();
}

?>
