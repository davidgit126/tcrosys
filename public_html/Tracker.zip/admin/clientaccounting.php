<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();


$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
include('template.php');
    include('main.php');


    
     $query = "SELECT reseller FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $reseller = $row[0];
                 
    }
$bgcolor = "c0c0c0";


    //mysql_close($conn);
?>

                 <font color="red">  <B> <?php print($error); ?></B></font>
                      
     
 




                  
                        
                        
                        
                        
                          <?php
                                if($reseller =="Yes")
                                 {
        ?>
                             

                        
                        
                  <BR>                       
            <center>
       <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="40%">
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Client Accounting</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
          <table border="1" cellspacing="1" width="40%" id="AutoNumber1">
            <tr>
              <td width="20%"><b>Date</b></td>
              <td width="60%"><b>Client Name</b></td>
              <td width="20%"><b>Amount</b></td>
            </tr>
            <?php
            
            	
             $query = "SELECT id, name, createdate, resellercredit FROM clients WHERE resellercredit != '' order by createdate desc";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $purchasedate      = $row[2];
              $resellercredit = $row[3];
              $cnt++;
      
        
?>
             

            <tr>
            

              <td width="20%"><?php print($purchasedate); ?>
&nbsp;</td>
              <td width="60%"><a href="setclient.php?cid=<?php print($id); ?>&cname=<?php print($clientname); ?>"><?php print($clientname); ?></a></td>
              <td width="20%"><?php print($resellercredit / 100); ?>&nbsp;credits</td>
              
            </tr>
        <?php
       }
       
       
     



       mysql_close($conn);
?>              
   

          </table>
            </center>
</div>
          </TD>

                        
                        
                        <p align="center">
                        <font size="4" color="#008000">
                        </font></p>
                        
                        
                          <?php
                            }
        ?>
                             

                        <p align="left">
                        <a href="menu.php">Main Menu</a>
                        </p>
                        <p align="left">&nbsp;
                        </p>
                        <p align="left">&nbsp;
                        
                        </p>
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>