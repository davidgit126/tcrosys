<?php

extract ($_GET );
extract ($_POST );

	include('connection.php');
$query = "SELECT backgroundimage, maintextsize, maintextfont, backgroundcolor,showbargraph FROM companycss WHERE id='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $backgroundimage= $row[0];
        $maintextsize= $row[1];
        $maintextfont = $row[2];
        $backgroundcolor= $row[3];
        $showbargraph = $row[4];
    }
if ($backgroundcolor == ""){
$backgroundsettings = "background-image:   url('$backgroundimage')";
}else{
$backgroundsettings = "background-color:'$backgroundcolor'";
}
?>

<STYLE>
body {
        margin: 20px;
        padding: 0px;
        
<?php echo "$backgroundsettings "; ?>;
}
body, td, th {
        
font: <?php echo "$maintextsize"; ?> <?php echo "$maintextfont"; ?>;
}
thead th {
        font-weight: bold;
}
//////CANNOT FIND
#content {
        color: #333333;
        padding: 20px;
}
h1 {
        font-size: 18px;
        color: #374C76;
}
h2 {
        font-size: 12px;
        color: #374C76;
}
//////////////


a:link {
        color: #032CA8;
}
a:visited {
        color: #A80319;
}
.miniheaders{
	font-family:Georgia, "Times New Roman", Times, serif; 
	font-size: 16px;
	color: #000000;
font-weight: bold; 
font-style: italic; 
	}

.txtbox{
	background-color: #FFFFFF;


	font-family: Verdana, sans-serif; 
	font-size: 11px;
	color: #000000;
	background-image:   url('formshadow.gif');
}
.txtboxsmall{
	background-color: #FFFFFF;


	font-family: Verdana, sans-serif; 
	font-size: 11px;

	color: #000000;
	background-image:   url('formshadow.gif');
}
.txtboxclear{
	background-color: #FFFFFF;
border:0px;
overflow:hidden;

	font-family: Tahoma, Arial, Verdana, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;

}

.txtboxdeleted{
	background-color: #FFFFFF;


	font-family: Verdana, sans-serif; 
	font-size: 11px;
	color: #000000;
	background-image:   url('formshadow2.gif');
	}
.nothing{	
font: 11px/16px Verdana, sans-serif;
}
#box
{
  width : 262px;
  height : auto;
  overflow : none ;
	font-family: Verdana, sans-serif; 
	font-size: 11px;
	color: #FFFFFF;
  border-top : none;
        text-align: left;
  display : none;
}



h3.elegant { letter-spacing: -2px; font-family:Georgia, "Times New Roman", Times, serif; font-weight: 100; font-size: 200%; }
h3.elegantLG { letter-spacing: -2px; font-family:Georgia, "Times New Roman", Times, serif; font-weight: 100; font-size: 300%; }

.ss-round-inputs {
margin:0;padding:0;
}
.ss-round-inputs input{
background:url('input-bg.gif') repeat-x 0 0;

border:medium none;
color:#494C4F;
	font-family: Verdana, sans-serif; 
	font-size: 11px;

height:24px;
_margin-top:-1px; padding-left:0; padding-right:0; padding-top:4px; padding-bottom:0;
}


/* Gradient 2 */
.tb7 {
	width: 221px;
	background: transparent url('bg.jpg');
background-repeat:repeat-x;
	color : #747862;
	height:30px;
	border:0;
	padding:4px 8px;
	margin-bottom:0px;
}
/* Gradient 1 */
.tb10 {
	background-image:url('form_bg.jpg');
	background-repeat:repeat-x;
	border:1px solid #d1c7ac;
	width: 230px;
	color:#333333;
	padding:3px;
	margin-right:4px;
	margin-bottom:8px;
	font-family:tahoma, arial, sans-serif;
}

#rounded-corner{font-family:"Lucida Sans Unicode", "Lucida Grande", Sans-Serif;font-size:12px;text-align:left;border-collapse:collapse;}
#rounded-corner th{font-weight:normal;font-size:13px;color:#039;background:#b9c9fe;padding:4px;}
#rounded-corner td{border-top:1px solid #fff;color:#669;padding:4px;}

</STYLE>

<?php
//	include('connection.php');

if ($searchpage == "client"){

	$str = strtolower($_GET['content']);
	if(strlen($str))
	{
		$sel = mysql_query("select * from clients where clientdelete = '' AND prospectclient = 'Client' AND (name like '%".trim($str)."%' or email like '%".trim($str)."%' or altphone like '%".trim($str)."%' or phone like '%".trim($str)."%') order by name Limit 100",$conn);
		if(mysql_num_rows($sel))
		{
			echo "<table style=\"border-collapse: collapse\" border =\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">";
			echo "<tr><td colspan=\"3\" style=\"padding: 0px 10px 0px 10px;\"><img border=\"0\" src=\"as_pointer.gif\"></td></tr>";
			echo "<tr><td height=\"6\"><img border=\"0\" src=\"ul_corner_tl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\"></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_tr.png\">";
			echo "</td></tr>\n";
			if(mysql_num_rows($sel))
			{
				echo "<script language=\"javascript\">box('1');</script>";
				while($row = mysql_fetch_array($sel))
				{
$name = $row['name'];
$status = $row['status'];
$contactid = $row['id'];
$email = $row['email'];
$phone = $row['phone'];
$alt_phone = $row['altphone'];
$font="";
					$country = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['name']));
					$email = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['email']));
					$phone = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['phone']));

$country = "<a style=\"text-decoration: none; font-size:x-small; font-family:arial; font-weight:bold\" href=\"setclient.php?cid=$contactid&cname=$name\"><font color=\"#F2F2F2\">$country ($status)</font></a>";
$country .= "<BR><a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" href=\"setclient.php?cid=$contactid&cname=$name\"><font color=\"#707070\">($phone)</font></a>";
$country .= "<a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" href=\"setclient.php?cid=$contactid&cname=$name\"><font color=\"#707070\">&nbsp;&nbsp;&nbsp;$email</font></a>";

					echo "<tr BGCOLOR=\"#2E2E2E\" id=\"word".$row['id']."\" onmouseover=\"highlight(1,'".$row['id']."');\" onmouseout=\"highlight(0,'".$row['id']."');\" onClick=\"display('".$row['name']."');\" >\n<td></td><td width=\"500\" style=\"padding: 0px 2px 0px 2px;\">".$country."</td><td></td>\n</tr>\n";
//					echo "<tr id=\"word".$row['id']."\" onmouseover=\"highlight(1,'".$row['id']."');\" onmouseout=\"highlight(0,'".$row['id']."');\" onClick=\"window.location.href('setclient.php?cid=$contactid&cname=$name');\" >\n<td></td><td width=\"500\" style=\"padding: 0px 2px 0px 2px;\">".$country."</td><td></td>\n</tr>\n";
				}
			}
			echo "<tr><td height=\"6\"><img border=\"0\" src=\"ul_corner_bl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\"></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_br.png\">";
			echo "</td></tr>\n";

			echo "</table>";
		}
	}
	else
	{
		echo "<script language=\"javascript\">box('0');</script>";
	}

}
//END CLIENT SEARCH



//START PROSPECT SEARCH

if ($searchpage == "prospect"){

	$str = strtolower($_GET['content']);
	if(strlen($str))
	{
		$sel = mysql_query("select * from clients where clientdelete = '' AND prospectclient = 'Prospect' AND (name like '%".trim($str)."%' or email like '%".trim($str)."%' or altphone like '%".trim($str)."%' or phone like '%".trim($str)."%') order by name Limit 100",$conn);
		if(mysql_num_rows($sel))
		{
			echo "<table style=\"border-collapse: collapse\" border =\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">";
			echo "<tr><td colspan=\"3\" style=\"padding: 0px 10px 0px 10px;\"><img border=\"0\" src=\"as_pointer.gif\"></td></tr>";
			echo "<tr><td height=\"6\"><img border=\"0\" src=\"ul_corner_tl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\"></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_tr.png\">";
			echo "</td></tr>\n";
			if(mysql_num_rows($sel))
			{
				echo "<script language=\"javascript\">box('1');</script>";
				while($row = mysql_fetch_array($sel))
				{
$name = $row['name'];
$status = $row['status'];
$contactid = $row['id'];
$email = $row['email'];
$phone = $row['phone'];
$alt_phone = $row['altphone'];
$font="";
					$country = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['name']));
					$email = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['email']));
					$phone = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['phone']));

$country = "<a style=\"text-decoration: none; font-size:x-small; font-family:arial; font-weight:bold\" href=\"prospectstatus.php?id=$contactid\"><font color=\"#F2F2F2\">$country ($status)</font></a>";
$country .= "<BR><a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" href=\"prospectstatus.php?id=$contactid\"><font color=\"#707070\">($phone)</font></a>";
$country .= "<a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" href=\"prospectstatus.php?id=$contactid\"><font color=\"#707070\">&nbsp;&nbsp;&nbsp;$email</font></a>";

					echo "<tr BGCOLOR=\"#2E2E2E\" id=\"word".$row['id']."\" onmouseover=\"highlight(1,'".$row['id']."');\" onmouseout=\"highlight(0,'".$row['id']."');\" onClick=\"display('".$row['name']."');\" >\n<td></td><td width=\"500\" style=\"padding: 0px 2px 0px 2px;\">".$country."</td><td></td>\n</tr>\n";
				}
			}
			echo "<tr><td height=\"6\"><img border=\"0\" src=\"ul_corner_bl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\"></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_br.png\">";
			echo "</td></tr>\n";
			echo "</table>";
		}
	}
	else
	{
		echo "<script language=\"javascript\">box('0');</script>";
	}

}
//END PROSPECT SEARCH


//START CREDITOR SEARCH

if ($searchpage == "creditor"){

	$str = strtoupper($_GET['content']);
	if(strlen($str))
	{
		$sel = mysql_query("select id, name from creditors where name like '%".trim($str)."%' order by name Limit 50",$conn);
		if(mysql_num_rows($sel))
		{
			echo "<table style=\"border-collapse: collapse\" border =\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">";
			echo "<tr><td colspan=\"3\" style=\"padding: 0px 10px 0px 10px;\"><img border=\"0\" src=\"as_pointer.gif\"></td></tr>";
			echo "<tr ><td height=\"6\"><img border=\"0\" src=\"ul_corner_tl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\"></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_tr.png\">";
			echo "</td></tr>\n";
			if(mysql_num_rows($sel))
			{
				echo "<script language=\"javascript\">box('1');</script>";
				while($row = mysql_fetch_array($sel))
				{
$name = $row['name'];
$contactid = $row['id'];

$font="";
$country = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['name']));
$country = "<a style=\"text-decoration: none; font-size:x-small; font-family:arial; font-weight:bold\" href=\"javascript: void(0)\"><font color=\"#F2F2F2\">$country</font></a>";

					echo "<tr BGCOLOR=\"#2E2E2E\" id=\"word".$row['id']."\" onmouseover=\"highlight(1,'".$row['id']."');\" onmouseout=\"highlight(0,'".$row['id']."');\" onClick=\"display('".$row['name']."');\" >\n<td></td><td width=\"500\" style=\"padding: 0px 2px 0px 2px;\">".$country."</td><td></td>\n</tr>\n";
//					echo "<tr id=\"word".$row['id']."\" onmouseover=\"highlight(1,'".$row['id']."');\" onmouseout=\"highlight(0,'".$row['id']."');\" onClick=\"window.location.href('setclient.php?cid=$contactid&cname=$name');\" >\n<td></td><td width=\"500\" style=\"padding: 0px 2px 0px 2px;\">".$country."</td><td></td>\n</tr>\n";
				}
			}
			echo "<tr><td height=\"6\"><img border=\"0\" src=\"ul_corner_bl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\"></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_br.png\">";
			echo "</td></tr>\n";

			echo "</table>";
		}
	}
	else
	{
		echo "<script language=\"javascript\">box('0');</script>";
	}

}
//END CREDITOR SEARCH

//START MASTER BROKER SEARCH

if ($searchpage == "masterbroker"){

	$str = strtolower($_GET['content']);
	if(strlen($str))
	{
		$sel = mysql_query("select dealer_id, dealership, firstname, lastname from dealers where (firstname like '%".trim($str)."%' or lastname like '%".trim($str)."%' or username like '%".trim($str)."%' or dealership like '%".trim($str)."%') ORDER BY lastname Limit 40",$conn);
		if(mysql_num_rows($sel))
		{
			echo "<table style=\"border-collapse: collapse\" border =\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"300\">";
			echo "<tr><td colspan=\"3\" style=\"padding: 0px 10px 0px 10px;\"><img border=\"0\" src=\"as_pointer.gif\"></td></tr>";
			echo "<tr><td height=\"6\"><img border=\"0\" src=\"ul_corner_tl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\" ></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_tr.png\">";
			echo "</td></tr>\n";
			if(mysql_num_rows($sel))
			{
				echo "<script language=\"javascript\">box('1');</script>";
				while($row = mysql_fetch_array($sel))
				{
$firstname = $row['firstname'];
$lastname = $row['lastname'];
$contactid = $row['dealer_id'];
$dealership = $row['dealership'];
$font="";


$country = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['firstname']));
$country2 = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['lastname']));
$dealership = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['dealership']));

$country = "<a style=\"text-decoration: none; font-size:x-small; font-family:arial; font-weight:bold\" href=\"javascript:confirmDelete('brokerstatus.php?masteraccount=$contactid&updatebroker=1')\"><font color=\"#F2F2F2\">$country2, $country</font></a>";
$country .= "<BR><a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" href=\"javascript:confirmDelete('brokerstatus.php?masteraccount=$contactid&updatebroker=1')\"><font color=\"#707070\">($dealership)</font></a>";
$country .= "<a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" href=\"javascript:confirmDelete('brokerstatus.php?masteraccount=$contactid&updatebroker=1')\"><font color=\"#707070\">&nbsp;&nbsp;&nbsp;$email</font></a>";

$remove = "<a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" href=\"javascript:confirmDelete('brokerstatus.php?masteraccount=0&updatebroker=1')\"><font color=\"#707070\">&nbsp;&nbsp;&nbsp;Remove Master Broker</font></a>";

					echo "<tr BGCOLOR=\"#2E2E2E\" id=\"word".$row['dealer_id']."\" onmouseover=\"highlight(1,'".$row['dealer_id']."');\" onmouseout=\"highlight(0,'".$row['dealer_id']."');\" onClick=\"window.location.href('javascript:confirmDelete('brokerstatus.php?masteraccount=$contactid&updatebroker=1')');\" >\n<td></td><td width=\"300\" style=\"padding: 0px 2px 0px 2px;\">".$country."</td><td></td>\n</tr>\n";
				}
			}
echo "<tr BGCOLOR=\"#2E2E2E\" id=\"word".$row['dealer_id']."\" onmouseover=\"highlight(1,'".$row['dealer_id']."');\" onmouseout=\"highlight(0,'".$row['dealer_id']."');\" onClick=\"window.location.href('javascript:confirmDelete('brokerstatus.php?masteraccount=$contactid&updatebroker=1')');\" >\n<td></td><td width=\"300\" style=\"padding: 0px 2px 0px 2px;\">".$remove."</td><td></td>\n</tr>\n";

			echo "<tr ><td height=\"6\"><img border=\"0\" src=\"ul_corner_bl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\" ></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_br.png\">";
			echo "</td></tr>\n";
			echo "</table>";
		}
	}
	else
	{
		echo "<script language=\"javascript\">box('0');</script>";
	}

}
//END MASTER BROKER SEARCH


//START  BROKER SEARCH

if ($searchpage == "broker"){

	$str = strtolower($_GET['content']);
	if(strlen($str))
	{
		$sel = mysql_query("select dealer_id, dealership, firstname, lastname, telephone from dealers where (firstname like '%".trim($str)."%' or lastname like '%".trim($str)."%' or username like '%".trim($str)."%' or dealership like '%".trim($str)."%' or telephone like '%".trim($str)."%') and status !=9 ORDER BY lastname Limit 40",$conn);
		if(mysql_num_rows($sel))
		{
			echo "<table style=\"border-collapse: collapse\" border =\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"300\">";
			echo "<tr><td colspan=\"3\" style=\"padding: 0px 10px 0px 10px;\"><img border=\"0\" src=\"as_pointer.gif\"></td></tr>";
			echo "<tr><td height=\"6\"><img border=\"0\" src=\"ul_corner_tl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\" ></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_tr.png\">";
			echo "</td></tr>\n";
			if(mysql_num_rows($sel))
			{
				echo "<script language=\"javascript\">box('1');</script>";
				while($row = mysql_fetch_array($sel))
				{
$firstname = $row['firstname'];
$lastname = $row['lastname'];
$fullname = "$firstname $lastname";
$contactid = $row['dealer_id'];
$dealership = $row['dealership'];
$telephone = $row['telephone'];
$font="";


$country = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['firstname']));
$country2 = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['lastname']));
$dealership = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['dealership']));
$telephone = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['telephone']));

$country = "<a style=\"text-decoration: none; font-size:x-small; font-family:arial; font-weight:bold\" href=\"setbroker.php?cid=$contactid&cname=$fullname\"><font color=\"#F2F2F2\">$country2, $country</font></a>";
$country .= "<BR><a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" href=\"setbroker.php?cid=$contactid&cname=$fullname\"><font color=\"#707070\">($dealership)</font></a>";
$country .= "<a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" href=\"setbroker.php?cid=$contactid&cname=$fullname\"><font color=\"#707070\">&nbsp;&nbsp;&nbsp;$email</font></a>";
$country .= "<BR><a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" href=\"setbroker.php?cid=$contactid&cname=$fullname\"><font color=\"#707070\">&nbsp;&nbsp;&nbsp;$telephone</font></a>";

					echo "<tr BGCOLOR=\"#2E2E2E\" id=\"word".$row['dealer_id']."\" onmouseover=\"highlight(1,'".$row['dealer_id']."');\" onmouseout=\"highlight(0,'".$row['dealer_id']."');\" onClick=\"window.location.href('setbroker.php?cid=$contactid&cname=$fullname')');\" >\n<td></td><td width=\"300\" style=\"padding: 0px 2px 0px 2px;\">".$country."</td><td></td>\n</tr>\n";
				}
			}
echo "<tr BGCOLOR=\"#2E2E2E\" id=\"word".$row['dealer_id']."\" onmouseover=\"highlight(1,'".$row['dealer_id']."');\" onmouseout=\"highlight(0,'".$row['dealer_id']."');\" onClick=\"window.location.href('setbroker.php?cid=$contactid&cname=$fullname')');\" >\n<td></td><td width=\"300\" style=\"padding: 0px 2px 0px 2px;\">".$remove."</td><td></td>\n</tr>\n";

			echo "<tr ><td height=\"6\"><img border=\"0\" src=\"ul_corner_bl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\" ></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_br.png\">";
			echo "</td></tr>\n";
			echo "</table>";
		}
	}
	else
	{
		echo "<script language=\"javascript\">box('0');</script>";
	}

}
//END BROKER SEARCH



//START BROKER ID ONLY SEARCH

if ($searchpage == "brokeridonly"){

	$str = strtolower($_GET['content']);
	if(strlen($str))
	{
		$sel = mysql_query("select dealer_id, dealership, firstname, lastname, telephone from dealers where (firstname like '%".trim($str)."%' or lastname like '%".trim($str)."%' or username like '%".trim($str)."%' or dealership like '%".trim($str)."%' or telephone like '%".trim($str)."%') and status !=9 ORDER BY lastname Limit 40",$conn);
		if(mysql_num_rows($sel))
		{
			echo "<table style=\"border-collapse: collapse\" border =\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"300\">";
			echo "<tr><td colspan=\"3\" style=\"padding: 0px 10px 0px 10px;\"><img border=\"0\" src=\"as_pointer.gif\"></td></tr>";
			echo "<tr><td height=\"6\"><img border=\"0\" src=\"ul_corner_tl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\" ></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_tr.png\">";
			echo "</td></tr>\n";
			if(mysql_num_rows($sel))
			{
				echo "<script language=\"javascript\">brokerid_box('1');</script>";
				while($row = mysql_fetch_array($sel))
				{
$firstname = $row['firstname'];
$lastname = $row['lastname'];
$fullname = "$firstname $lastname";
$contactid = $row['dealer_id'];
$dealership = $row['dealership'];
$telephone = $row['telephone'];
$font="";


$country = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['firstname']));
$country2 = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['lastname']));
$dealership = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['dealership']));
$telephone = eregi_replace($str,"<font color=\"#6b95b8\">".$str."</font>",($row['telephone']));

$country = "<a style=\"text-decoration: none; font-size:x-small; font-family:arial; font-weight:bold\" ><font color=\"#F2F2F2\">$country2, $country</font></a>";
$country .= "<BR><a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" ><font color=\"#707070\">($dealership)</font></a>";
$country .= "<a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" ><font color=\"#707070\">&nbsp;&nbsp;&nbsp;$email</font></a>";
$country .= "<BR><a style=\"text-decoration: none; font-size:xx-small; font-family:arial\" ><font color=\"#707070\">&nbsp;&nbsp;&nbsp;$telephone</font></a>";

					echo "<tr BGCOLOR=\"#2E2E2E\" id=\"word".$row['dealer_id']."\" onmouseover=\"highlight(1,'".$row['dealer_id']."');\" onmouseout=\"highlight(0,'".$row['dealer_id']."');\" onClick=\"display('".$row['dealer_id']."');\" >\n<td></td><td width=\"300\" style=\"padding: 0px 2px 0px 2px;\">".$country."</td><td></td>\n</tr>\n";
				}
			}

			echo "<tr ><td height=\"6\"><img border=\"0\" src=\"ul_corner_bl.png\"></td>";
			echo "<td BGCOLOR=\"#2E2E2E\" ></td>";
			echo "<td height=\"6\" ><img border=\"0\" src=\"ul_corner_br.png\">";
			echo "</td></tr>\n";
			echo "</table>";
		}
	}
	else
	{
		echo "<script language=\"javascript\">brokerid_box('0');</script>";
	}

}
//END BROKER ID ONLY SEARCH
?>






