<?php
extract ($_GET );
extract ($_POST );

include("connection.php");



$sql = "UPDATE autoresponders SET
subject = \"$subject\",
message = \"$message\",
days = \"$days\"
WHERE id = \"$autoid\"";

$result = @mysql_query($sql,$conn);


header("Location: editautoemail.php?autoid=$autoid&success=Email Updated!");  
exit;


?>