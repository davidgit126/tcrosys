<?php
extract ($_GET );
extract ($_POST );


$message2 = str_replace("{NAME}", "$name", $message2);
$subject2 = str_replace("{NAME}", "$name", $subject2);
$message2 = str_replace("{ADDRESS}", "$address", $message2);
$subject2 = str_replace("{ADDRESS}", "$address", $subject2);
$message2 = str_replace("{CITY}", "$city", $message2);
$subject2 = str_replace("{CITY}", "$city", $subject2);
$message2 = str_replace("{STATE}", "$state", $message2);
$subject2 = str_replace("{STATE}", "$state", $subject2);
$message2 = str_replace("{ZIP}", "$zip", $message2);
$subject2 = str_replace("{ZIP}", "$zip", $subject2);
$message2 = str_replace("{PHONE}", "$phone", $message2);
$subject2 = str_replace("{PHONE}", "$phone", $subject2);
$message2 = str_replace("{FAX}", "$fax", $message2);
$subject2 = str_replace("{FAX}", "$fax", $subject2);
$message2 = str_replace("{EMAIL}", "$email", $message2);
$subject2 = str_replace("{EMAIL}", "$email", $subject2);
$message2 = str_replace("{USERNAME}", "$username", $message2);
$subject2 = str_replace("{USERNAME}", "$username", $subject2);
$message2 = str_replace("{PASSWORD}", "$password", $message2);
$subject2 = str_replace("{PASSWORD}", "$password", $subject2);
$message2 = str_replace("{STATUS}", "$showstatus", $message2);
$subject2 = str_replace("{STATUS}", "$showstatus", $subject2);
$message2 = str_replace("{NUMLOGINS}", "$logins", $message2);
$subject2 = str_replace("{NUMLOGINS}", "$logins", $subject2);
$message2 = str_replace("{LASTLOGIN}", "$lastlogin", $message2);
$subject2 = str_replace("{LASTLOGIN}", "$lastlogin", $subject2);
$message2 = str_replace("{SSN}", "$ssnum", $message2);
$subject2 = str_replace("{SSN}", "$ssnum", $subject2);
$message2 = str_replace("{DOB}", "$birthdate", $message2);
$subject2 = str_replace("{DOB}", "$birthdate", $subject2);

$firstname = explode(' ', $name); 
if ($firstname[2] != ""){
$lastname = $firstname[2];
}else{
$lastname = $firstname[1];
}
$firstname = $firstname[0];


$message2 = str_replace("{FNAME}", "$firstname", $message2);
$subject2 = str_replace("{FNAME}", "$firstname", $subject2);
$message2 = str_replace("{LNAME}", "$lastname", $message2);
$subject2 = str_replace("{LNAME}", "$lastname", $subject2);

?>