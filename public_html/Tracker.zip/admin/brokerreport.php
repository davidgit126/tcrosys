<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);


$nowday = date("d");
$nowmonthword = date("M");
$nowmonthword2 = date("F");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

$thismonth = date("Y-m");


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
include('template.php');
 include("connection.php");


    ?>
    
    
 <title>Broker Creation Report</title> 
  <?php
    if($_SESSION['brokers']=="Yes")
    {
    ?>

    <font color="red">  <B> <?php print($message); ?></B></font>
      <?php
    include('main.php');
    

	if ($startdate !="" and $enddate !=""){
$leadquery = "((leadentered >= '$startdate' AND leadentered <= '$enddate') or (createdate >= '$startdate' AND createdate <= '$enddate')) ";
$salesquery= "(createdate >= '$startdate' AND createdate <= '$enddate') ";
$brokercreatequery= "createdate >= '$startdate' AND createdate <= '$enddate' ";


	}else{
$leadquery = "((leadentered like '$thismonth%') or (createdate like '$thismonth%')) ";
$salesquery= "createdate like '$thismonth%' ";
$brokercreatequery= "createdate like '$thismonth%' ";
$daterange = " - $nowmonthword2 $nowyear";
$startdate = "YYYY-MM-DD";
$enddate = "YYYY-MM-DD";
}


    $beginvar = "firstname=$firstname&lastname=$lastname&searchaffiliate=$searchaffiliate&email=$email&dealership=$dealership";

   ?>     

    
        <?php
    

    include("connection.php");
?>

<link href="calendar.css" type="text/css" rel="stylesheet" />
<script src="calendar.js" type="text/javascript"></script>
<script type="text/javascript"> 
function init() {
	calendar.set("startdate");
	calendar.set("enddate");
}
</script>
<h3 class="elegantLG" align="center">Broker Creation Report <?php print($daterange); ?></h3>
<form action="" method="get">
<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="350">
<tr><td class='ss-round-inputs' align="center"><b>&nbsp;Date Range:</b>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="startdate" id="startdate" size="11" value="<?php print($startdate); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" > <b>&nbsp;to&nbsp; </b> 
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="enddate" id="enddate" size="11" value="<?php print($enddate); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
<td><INPUT TYPE="image" SRC="go.png"></td>
</tr></table></form>

Disclaimer on numbers:  This report contains number of prospects and sales per broker.  If a joint sale has been made, this report, to accurately calculate a closing ratio, adds two prospects to the prospect list, even though only one prospect may have originally been submitted by said broker.  The number of prospects listed may not be the same as the data shown under Referral Statistics the Broker Status Sheet for the corresponding broker.
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="90%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Detailed Broker Referral Report </td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

 <table id="rounded-corner" width="90%">

 <tr >
 <th class="rounded-company"></th>
 <th class="rounded-company">Name</th>
<th class="rounded-q1">Email</th>
<th class="rounded-q2">Phone</th>
<th class="rounded-q3">Company</th>
<th class="rounded-q3">Prospects</th>
<th class="rounded-q3">Sales</th>
<th class="rounded-q3">Closing Ratio</th>

<th class="rounded-q3">Total Prospects</th>
<th class="rounded-q3">Total Sales</th>
<th class="rounded-q3">Total Closing Ratio</th>
</tr>



<?php
$bgcolor = "#e8edff";

       
$query2 = "SELECT firstname, lastname, dealership, email, telephone, dealer_id FROM dealers WHERE $brokercreatequery and dealers.status !='9' ORDER BY createdate DESC" ;
$result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
while($row2=mysql_fetch_row($result2))
{
              $brokerfirstname           = $row2[0];
              $brokerlastname           = $row2[1];
              $brokercompany           = $row2[2];
              $brokeremail           = $row2[3];
              $brokerphone = $row2[4];
              $broker_id = $row2[5];

       $cnt++;



$numberclients = '0';
$query = "SELECT COUNT(id) FROM clients WHERE broker_id ='$broker_id' and clientdelete != 'yes' and status != 'inactive' and prospectclient='Client' and $salesquery GROUP BY broker_id";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
while($row=mysql_fetch_row($result))
{
 $numberclients = $row[0];
 $totalclients = $totalclients + $numberclients;
}


$numberprospects = '0';
$query3 = "SELECT COUNT(id) FROM clients WHERE broker_id ='$broker_id' and clientdelete != 'yes' and prospectclient='Prospect' and $leadquery GROUP BY broker_id";
$result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
while($row3=mysql_fetch_row($result3))
{
 $numberprospects = $row3[0];
 $totalprospects = $totalprospects + $numberprospects;
}


$closingratio =0;
if ($numberprospects !="0"){
$closingratio = $numberclients/$numberprospects*100;
  $closingratio = number_format($closingratio, 2, '.', '');
}





/////////TOTAL SALES QUERY
$totalnumberclients = '0';
$query4 = "SELECT COUNT(id) FROM clients WHERE broker_id ='$broker_id' and clientdelete != 'yes' and status != 'inactive' and prospectclient='Client' GROUP BY broker_id";
$result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
while($row4=mysql_fetch_row($result4))
{
              $totalnumberclients = $row4[0];
			   $totalclients2 = $totalclients2 + $totalnumberclients;
}
/////////TOTAL LEAD QUERY
$totalnumberprospects = '0';
$query5 = "SELECT COUNT(id) FROM clients WHERE broker_id ='$broker_id' and clientdelete != 'yes' and prospectclient='Prospect'  GROUP BY broker_id";
$result5 = mysql_query($query5, $conn) or die("error:" . mysql_error());
while($row5=mysql_fetch_row($result5))
{
              $totalnumberprospects = $row5[0];
			  			   $totalprospects2 = $totalprospects2 + $totalnumberprospects;
}

$totalclosingratio =0;
if ($totalnumberprospects !="0"){
$totalclosingratio = $totalnumberclients/$totalnumberprospects*100;
  $totalclosingratio = number_format($totalclosingratio, 2, '.', '');
}


              ?>
<tr bgcolor="#e8edff" onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
<td ><?php print($cnt); ?></td>
<td ><a href="setbroker.php?cid=<?php print($broker_id); ?>&cname=<?php print($brokerfirstname); ?> <?php print($brokerlastname); ?>"><?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?></a></td>
<td ><?php print($brokeremail); ?></td>
<td ><?php print($brokerphone); ?></td>

<td ><?php print($brokercompany); ?></td>
<td ><a href="prospectsearch.php?searchbroker=<?php print($broker_id); ?>&f=1"><?php print($numberprospects); ?></a></td>
<td ><a href="search.php?searchbroker=<?php print($broker_id); ?>&f=1"><?php print($numberclients); ?></a></td>
<td ><?php print($closingratio); ?>%</td>

<td ><a href="prospectsearch.php?searchbroker=<?php print($broker_id); ?>&f=1"><?php print($totalnumberprospects); ?></a></td>
<td ><a href="search.php?searchbroker=<?php print($broker_id); ?>&f=1"><?php print($totalnumberclients); ?></a></td>
<td ><?php print($totalclosingratio); ?>%</td>
</tr>
              <?php
          }

  $totalclosingratio2 = $totalclients/$totalprospects*100;
  $totalclosingratio2 = number_format($totalclosingratio2, 2, '.', '');

  $totalclosingratio3 = $totalclients2/$totalprospects2*100;
  $totalclosingratio3 = number_format($totalclosingratio3, 2, '.', '');

  $tablerowdataend .="<tr bgcolor=$bgcolor><td>&nbsp;</td><td>&nbsp;</td></td><td></td><td><td>&nbsp;</td><td><b>$totalprospects</b></td><td><b>$totalclients</b></td><td><b>$totalclosingratio2 %</b></td> ";     
  $tablerowdataend .="<td><b>$totalprospects2</b></td><td><b>$totalclients2</b></td><td><b>$totalclosingratio3 %</b></td></tr> ";     

		  		echo $tablerowdataend;	

          mysql_close($conn);
          ?>
          </table>
		  <script src="http://www.openjs.com/js/jsl.js" type="text/javascript"></script>
<script src="http://www.openjs.com/common.js" type="text/javascript"></script>

          <?php

}}
else
{
    header("Location: login.php");
    exit();
}

?>