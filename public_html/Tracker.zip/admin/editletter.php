<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   include('template.php');

    ?>
   
  <?php
 if($_SESSION['usname']=="admin" or ($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing")){
    
    
    
    
     include("connection.php");

     $query = "SELECT id, lettername, abovedisputes, belowdisputes, showdisputes, showproof, letterorder, disputecolumn FROM letters WHERE id='$letterid'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $letterid           = $row[0];
              $lettername   = $row[1];
              $abovedisputes   = $row[2];
              $belowdisputes   = $row[3];
              $showdisputes = $row[4];
              $showproof = $row[5];              
              $letterorder = $row[6];              
              $disputecolumn = $row[7];              
}

    if($belowdisputes !=""){
		$usingbelow = "Yes";
	}


        ?>
  
    
   
<form method="POST" action="editlettersuccess.php">
                            <input type="hidden" name="letterid" value="<?php print($letterid); ?>">



<div align="center">
  <center>
<font color="#FF0000"><b><?php print($success); ?></b></font>


<table width="70%"><tr><td width="95%" align=center valign="top">


<table border=1 width="919" cellspacing="1" cellpadding="6">


<tr>
  <td BGCOLOR="#CCCCCC" align="right" width="821" colspan="4">
<p align="left">
<b><font face="Verdana" size="2">Letter Name:</font></b> 
<input class="txtbox" type=text name=lettername size=85 value="<?php print($lettername); ?>"> </td>
</tr>


<tr>
  <td BGCOLOR="#CCCCCC" align="right" width="229">
<p align="left">
<b><font face="Verdana" size="2">List Disputes?</font></b>
<br><select name="showdisputes" class="txtbox"  >
                                  <option value="<?php print($showdisputes); ?>" selected><?php print($showdisputes); ?></option>

                 <option value="Yes">Yes</option>
 <option value="No">No</option>

              </select></td>
  <td BGCOLOR="#CCCCCC" width="229"> 
                                        &nbsp;<b><font face="Verdana" size="2">Display AV/SSN Proof?</font></b> 
                                        <br><select name="showproof" class="txtbox"  >
                  <option value="<?php print($showproof); ?>" selected><?php print($showproof); ?></option>

                 <option value="Yes">Yes</option>
 <option value="No">No</option>

              </select></TD>
  <td BGCOLOR="#CCCCCC" align="right" width="229">
<b><font face="Verdana" size="2">Order on letter menu&nbsp;&nbsp; </font></b><br>
<input class="txtbox" type=text name=letterorder size=6 value="<?php print($letterorder); ?>"></td>
  <td BGCOLOR="#CCCCCC" width="229"> 
                                        &nbsp;<b><font face="Verdana" size="2">Dispute 
                                        Column?</font></b><br>
                                        <select name="disputecolumn" class="txtbox"  >
                                  <option value="<?php print($disputecolumn); ?>" selected><?php print($disputecolumn); ?></option>

                 <option value="s1dispute">s1dispute</option>
                 <option value="s2dispute">s2dispute</option>
 

              </select></TD>
</tr>
<?php
    if($usingbelow =="Yes"){
        ?>

<tr>
  <td colspan="4" align=center width="901"><font color="ffffff">
  <font face="Verdana" size=3>
<b><? echo $emailname; ?> Top Half</b><br></font>
</TD>
</tr>
<?php
			  }
?>
<tr>
  <td colspan="4" BGCOLOR="#CCCCCC" align="center" width="901">
<textarea rows="15" name="abovedisputes" id="abovedisputes" cols="110"><? echo "$abovedisputes" ?></textarea>
<script language=JavaScript src='../include/gui/scripts/innovaeditor.js'></script>
   <script language=JavaScript src='http://www.tcrosystems.net/scripts/addbureau.js'></script>

</TD>
</tr>
<?php
    if($usingbelow =="Yes"){
        ?>
<tr><td colspan="4" align=center width="901"><font color="ffffff">
  <font face="Verdana" size=3>
<b><? echo $emailname; ?> Bottom Half</b><br></font>
</TD></TR><tr><td colspan="4" BGCOLOR="#CCCCCC" align="center" width="901">
<textarea rows="15" name="belowdisputes" id="belowdisputes" cols="110"><? echo "$belowdisputes" ?></textarea>
  <script language=JavaScript src='http://www.tcrosystems.net/scripts/addbureau2.js'></script>
</TD></TR>
<?php
}        ?>
</table><br>
<input type="submit" value="Update <? echo $lettername; ?> Letter">



</td></table>
</center>
</div>


</center>


  
</form>
<p>
<BR><BR><a href="letters.php">Letter Menu</a>
</p>



  
<?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>