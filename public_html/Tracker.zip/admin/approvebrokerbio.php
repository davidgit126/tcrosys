<?php
require_once('common.inc.php');
session_start();

extract ($_GET );
extract ($_POST );
if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
include('template.php');
 include("connection.php");


    ?>
    
    
 <title>Broker Search</title> 
  <?php
    if($_SESSION['brokers']=="Yes")
    {
include('main.php');
include("connection.php");

if($_POST['updatebio'] == 1){
             $query = "UPDATE dealers SET
                bioapproved='Yes'
                WHERE dealer_id='" . mysql_real_escape_string($_POST['dealer_id']) . "' ";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

?>
<script type="text/javascript" src="jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery.textarea-expander.js"></script>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="80%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">List of brokers that need bio approval</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

 <style type="text/css"> 
/* <![CDATA[ */

textarea
{
	clear: both;
	display: block;
	padding: 4px 4px 4px 4px;
	border: 0px;
	font-family: Verdana, sans-serif; 
	font-size: 11px;

}
 
/* ]]> */
</style>
<table width="80%" background="bluestrip.gif" border="0" cellpadding="5" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
<tr>
<td ><font color="#FFFFFF"><b>Name&nbsp;&nbsp;&nbsp;</b></font></td>
<td ><font color="#FFFFFF"><b>Bio&nbsp;&nbsp;&nbsp;</b></font></td>
</tr>

<?php
        
 
              $query = "SELECT dealer_id, firstname, lastname, email, telephone, createdate, affiliate_id, dealership, bio, bioapproved FROM dealers WHERE status != 9 and bioapproved ='No'";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $firstname   = $row[1];
              $lastname      = $row[2];
              $cemail       = $row[3];
              $phone = $row[4];
              $createdate = $row[5];
              $affiliate_id  = $row[6];
              $dealership  = $row[7];
              $bio  = $row[8];
              $bioapproved  = $row[9];
			  $cnt++;
              
  $bio = nl2br($bio);               

$bgcolor = "FFFFFF";



              ?>
<tr>
<td valign="Top" style="border-bottom-style: solid; border-bottom-width: 1; border-left-style:solid; border-left-width:1" bgcolor=<?php print($bgcolor); ?>><a href="setbroker.php?cid=<?php print($id); ?>&cname=<?php print($firstname); ?> <?php print($lastname); ?>"><?php print($lastname); ?>, <?php print($firstname); ?></a>
<form action="" method="post">
<input type=hidden name="dealer_id" value="<?php print($id); ?>">
<input type=hidden name="bioapproved" value="Yes">
<input type=hidden name="updatebio" value="1">
<input type="submit" name="Approve" value="Approve">
</form>
</td>
<td style="border-bottom-style: solid; border-bottom-width: 1; border-left-style:solid; border-left-width:1" bgcolor=<?php print($bgcolor); ?>><?php print($bio); ?></td>


</tr>

              <?php
          }
          mysql_close($conn);
          ?>
          </table>
          <?php
          if($cnt==0)
          {
              print("There are no matching records to your search criteria. Please try again.");
          }
    }
}
else
{
    header("Location: login.php");
    exit();
}

?>