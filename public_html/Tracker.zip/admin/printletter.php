<?php
extract ($_GET );
extract ($_POST );


require_once('common.inc.php');
session_start();

	


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   
    ?>
   
  <?php
  if($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing")
    {
    
    
    
     include("connection.php");
   include('template2.php');

     $query3 = "SELECT id, lettername, abovedisputes, belowdisputes, showdisputes, showproof, disputecolumn FROM letters WHERE id='$letterid'";
          $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
          while($row3=mysql_fetch_row($result3))
          {
              $letterid           = $row3[0];
              $lettername   = $row3[1];
              $abovedisputes   = $row3[2];
              $belowdisputes   = $row3[3];
              $showdisputes = $row3[4];
              $showproof = $row3[5];  
              $disputecolumn = $row3[6];  
}


     $query3 = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, avssnurl, fonttype, status, sendtohtdi, country FROM clients WHERE id='" . $_SESSION['clientid'] . "' ";
    $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
    while($row3=mysql_fetch_row($result3))
    {
        $name = $row3[0];
        $address = $row3[1];
        $city = $row3[2];
        $state = $row3[3];
        $zip = $row3[4];
        $email = $row3[5];
        $fax = $row3[6];
        $phone = $row3[7];
        $ssn = $row3[8];
        $dob = $row3[9];
        $country = $row3[10];
        $username = $row3[11];
        $password = $row3[12];
        $broker_id = $row3[13];
	  $dealer_id = $row3[14];
	  $affiliate_id = $row3[15];
	  $avssnurl = $row3[16];	  
	  $fonttype = $row3[17];	  	  
	  $status = $row3[18];	  	  
	  $sendtohtdi= $row3[19];	  	  
 	  $country= $row3[20];	  	  
   }
   ?>
   <style>
<!--
P.breakhere {page-break-before: always}
-->
</style>
<?php

  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")
    {

if($bureauid!=""){
 $bureauquery = " AND id = '$bureauid'";
}

             if($country =="" or $country=="United States")   {
 $countryquery = "WHERE country = 'United States'";
 } else if($country=="Canada")   {
 $countryquery = "WHERE country = '$country'";
 } else{
 $countryquery = "WHERE country = '$country'";
 }

    $query = "SELECT id, type, address, citystatezip FROM accounttype $countryquery $bureauquery";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          while($row=mysql_fetch_row($result))
          {
              $bureauidforletter   = $row[0];
              $bureaunametemp= $row[1];
              $bureauaddresstemp= $row[2];
              $citystateziptemp= $row[3];


if($bureauid=="1"){
$bureauname = "<a href=\"printletter.php?letterid=$letterid&bureauid=2\" style=\"text-decoration: none\"><font color=#000000 face = \"<?php print($fonttype); ?>\">$bureaunametemp</a>"; 
$bureauaddress = $bureauaddresstemp;
$citystatezip = $citystateziptemp; 
}else if($bureauid=="2"){
$bureauname = "<a href=printletter.php?letterid=$letterid&bureauid=3 style=\"text-decoration: none\"><font color=#000000 face = \"<?php print($fonttype); ?>\">$bureaunametemp</a>"; 
$bureauaddress = $bureauaddresstemp;
$citystatezip = $citystateziptemp; 
}else if($bureauid=="3"){
$bureauname = $bureaunametemp; 
$bureauaddress = $bureauaddresstemp;
$citystatezip = $citystateziptemp; 
}else if($bureauid=="8"){
$bureauname = "<a href=printletter.php?letterid=$letterid&bureauid=9 style=\"text-decoration: none\"><font color=#000000 face = \"<?php print($fonttype); ?>\">$bureaunametemp</a>"; 
$bureauaddress = $bureauaddresstemp;
$citystatezip = $citystateziptemp; 
}else{
$bureauname = $bureaunametemp; 
$bureauaddress = $bureauaddresstemp;
$citystatezip = $citystateziptemp; 
}

include("bureaustrip.php");
include("clientletterstrip.php");
$todaysdate =  date("F d, Y");
$abovedisputes2 = str_replace("{TODAYDATE}", "$todaysdate", $abovedisputes2);
$disputes ="";
			  $i = 0;
              $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, comments, dispute, $disputecolumn  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientid']) . "' and accounttype='$bureauidforletter' and deleted='open'";
              $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
              while($row2=mysql_fetch_row($result2))
              {
                   $accid = $row2[0];
                   $acname = $row2[1];
                   $acnumber = $row2[2];
                   $beginstatus = $row2[3];
                   $s1action = $row2[4];
                   $s1result = $row2[5];
                   $s2action = $row2[6];
                   $s2result = $row2[7];
                   $s3action = $row2[8];
                   $s3result = $row2[9];
                   $s4action = $row2[10];
                   $s4result = $row2[11];
                   $comments = $row2[12];
                   $dispute = $row2[13];
                   $s1dispute = $row2[14];
                   $i = $i+1;

$disputes .="<font face = $fonttype>$i. $acname,&nbsp;$acnumber,&nbsp;$s1dispute</font><BR>";

}
$abovedisputes2 = str_replace("{INSERTDISPUTES}", "$disputes", $abovedisputes2);
        ?>

  
<style type="text/css"> 
/* <![CDATA[ */

textarea
{
	clear: both;
	display: block;
	font-family: sans-serif;
	font-size: 1em;
	width: 100%;
	padding: 2px 4px;
	margin: 6px auto;
	border: 0px;
}
 
/* ]]> */
</style>
 <script type="text/javascript" src="jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery.textarea-expander.js"></script>

<!--<textarea name="textarea1" rows="3" cols="60" class="expand"><? echo $abovedisputes2; ?></textarea>-->
    
 <font size="2" face = "<?php print($fonttype); ?>">  
<? echo $abovedisputes2; ?><BR>
 <?   if($showdisputes=="Yes"){ ?>


              
<?php
			  $i = 0;
              $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, comments, dispute, $disputecolumn  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientid']) . "' and accounttype='$bureauidforletter' and deleted='open'";
              $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
              while($row2=mysql_fetch_row($result2))
              {
                   $accid = $row2[0];
                   $acname = $row2[1];
                   $acnumber = $row2[2];
                   $beginstatus = $row2[3];
                   $s1action = $row2[4];
                   $s1result = $row2[5];
                   $s2action = $row2[6];
                   $s2result = $row2[7];
                   $s3action = $row2[8];
                   $s3result = $row2[9];
                   $s4action = $row2[10];
                   $s4result = $row2[11];
                   $comments = $row2[12];
                   $dispute = $row2[13];
                   $s1dispute = $row2[14];
                   $i = $i+1;
?>

    <BR>
<font size="2" face = "<?php print($fonttype); ?>"><?php print($i); ?>.&nbsp;
<?php print($acname); ?>,&nbsp;<?php print($acnumber); ?>,&nbsp;<?php print($s1dispute); ?></font>
<?php
    }
?>
              
             
<BR><BR><BR>

 <?  }?>
<? echo $belowdisputes2; ?>

 <?   if($showproof=="Yes"){ ?>

<P CLASS="breakhere">
<CENTER><IMG SRC="<?php print($avssnurl); ?>"></font></font></font></font></font></font></font>
</CENTER>
 <?   } ?>


 <?   if($bureauidforletter!="3" && $bureauidforletter!="9" && $bureauid ==""){ ?>
<P CLASS="breakhere">
 </font>

 <?   } ?>

<?php
}}}}
else
{
    header("Location: login.php");
    exit();
}

?>