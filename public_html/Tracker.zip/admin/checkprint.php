<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
ob_start();
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    include("connection.php");
/*
** Function: convert_number
** Arguments: int
** Returns: string
** Description:
** Converts a given integer (in range [0..1T-1], inclusive) into
** alphabetical format ("one", "two", etc.).
*/
function convert_number($number)
{
if (($number < 0) || ($number > 999999999))
{
return "$number";
}

$Gn = floor($number / 1000000); /* Millions (giga) */
$number -= $Gn * 1000000;
$kn = floor($number / 1000); /* Thousands (kilo) */
$number -= $kn * 1000;
$Hn = floor($number / 100); /* Hundreds (hecto) */
$number -= $Hn * 100;
$Dn = floor($number / 10); /* Tens (deca) */
$n = $number % 10; /* Ones */

$res = "";

if ($Gn)
{
$res .= convert_number($Gn) . " Million";
}

if ($kn)
{
$res .= (empty($res) ? "" : " ") .
convert_number($kn) . " Thousand";
}

if ($Hn)
{
$res .= (empty($res) ? "" : " ") .
convert_number($Hn) . " Hundred";
}

$ones = array("", "One", "Two", "Three", "Four", "Five", "Six",
"Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen",
"Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen",
"Nineteen");
$tens = array("", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty",
"Seventy", "Eigthy", "Ninety");

if ($Dn || $n)
{
if (!empty($res))
{
$res .= " ";
}

if ($Dn < 2)
{
$res .= $ones[$Dn * 10 + $n];
}
else
{
$res .= $tens[$Dn];

if ($n)
{
$res .= " " . $ones[$n];
}
}
}

if (empty($res))
{
$res = "zero";
}

return $res;
}
?>




         
<?php

   $query3 = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, avssnurl, fonttype FROM clients WHERE id='" . $_SESSION['clientid'] . "' ";
    $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
    while($row3=mysql_fetch_row($result3))
    {
        $name = $row3[0];
        $address = $row3[1];
        $city = $row3[2];
        $state = $row3[3];
        $zip = $row3[4];
        $email = $row3[5];
        $fax = $row3[6];
        $phone = $row3[7];
        $ssnum = $row3[8];
        $birthdate = $row3[9];
        $country = $row3[10];
        $usernameu = $row3[11];
        $pwdu = $row3[12];
        $broker_id = $row3[13];
	  $dealer_id = $row3[14];
	  $affiliate_id = $row3[15];
	  $avssnurl = $row3[16];	  
	  $fonttype = $row3[17];	  	  
  	  
    }

    $query = "SELECT auditfee, DATE_FORMAT(paid, \"%b %d, %Y\") as paid, monthlyfee, monthlydue, payment, onlinepayment, bankname, bankrtg, bankact, checknum, aba, paid, holder, holderaddress, holdercity, holderstate, holderzip FROM billing WHERE clientid='" . $_SESSION['clientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $auditfee = $row[0];
        $paid = $row[1];
        $monthlyfee = $row[2];
        $monthlydue = $row[3];
        $payment = $row[4];
        $onlinepayment = $row[5];
	  $bankname = $row[6];	  
	  $bankrtg = $row[7];	  
	  $bankact = $row[8];	
	  $checknum = $row[9];		  
	  $aba = $row[10];
	  $paid2 = $row[11];
	  $holder = $row[12];		  
	  $holderaddress = $row[13];		  
	  $holdercity = $row[14];		  
	  $holderstate = $row[15];		  
	  $holderzip = $row[16];		  

$checknumbottom = str_pad((int) $checknum,6,"0",STR_PAD_LEFT);
    }
if ($paid2 != "0000-00-00" && $paid2 !=""){
$paid = $paid;
}else{
$paid = date("M d, Y");
}
    
    
$spellout = convert_number($auditfee); 
      $cents = explode('.', $auditfee); 
 $cents = $cents[1];
    
    
     $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload, passisssn, demanddraft, payname FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 
        $passisssn = $row[14]; 
        $demanddraft = $row[15]; 
        $payname = $row[16]; 
    }



if ($holder ==""){
$holder = $name;
}if ($holderaddress ==""){
$holderaddress = $address;
}if ($holdercity ==""){
$holdercity = $city;
}if ($holderstate ==""){
$holderstate = $state;
}if ($holderzip ==""){
$holderzip = $zip;
}if ($payname ==""){
$payname = $companyname;
}
			


     if($demanddraft != "Yes"){
     echo "You do not have this option.  Please contact your Account Executive for purchase";
     }else{
    
    ?>
    <meta http-equiv="Content-Language" content="en-us">
    <style>
<!--
P.breakhere {page-break-before: always}
-->
</style>



<table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="750" id="AutoNumber1" cellpadding="0" height="5">
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="205" colspan="2" height="19"><input type="text" value="<?php print($holder); ?>" size="20" style="border: 1px solid #FFFFFF; font-size: 10pt; font-family: Arial; font-weight:bold;"></td>
    <td width="90" height="19">&nbsp;</td>
    <td width="262" colspan="2" height="19"><b><font size="1" face="Arial"><?php print($bankname); ?></font></b></td>
    <td width="63" height="19">&nbsp;</td>
    <td width="87" height="19">
    <p align="right"><b><font size="2" face="Arial"><?php print($checknum); ?></font></b></td>
  </tr>
  <tr>
    <td width="93" height="13"></td>
    <td width="205" colspan="2" height="13"><font size="1" face="Arial"><?php print($holderaddress); ?></font></td>
    <td width="90" height="13"></td>
    <td width="262" colspan="2" height="13"><font size="1" face="Arial"></font></td>
    <td width="63" height="13"></td>
    <td width="87" height="13"><font size="1" face="Arial"><?php print($aba); ?></font></td>
  </tr>
  <tr>
    <td width="93" height="13"></td>
    <td width="205" colspan="2" height="13"><font size="1" face="Arial"><?php print($holdercity); ?>, <?php print($holderstate); ?> <?php print($holderzip); ?></font></td>
    <td width="90" height="13"></td>
    <td width="232" height="13"></td>
    <td width="30" height="13"></td>
    <td width="63" height="13"></td>
    <td width="87" height="13"></td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="30" height="19">&nbsp;</td>
    <td width="63" height="19">&nbsp;</td>
    <td width="87" height="19">&nbsp;</td>
  </tr>

  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="30" height="19">&nbsp;</td>
    <td width="63" height="19">
    <p align="right"><font size="2" face="Arial">Date: &nbsp;</font></td>
    <td width="87" height="19"><font size="2" face="Arial"><b><?php print($paid); ?></b></font></td>
  </tr>
  <tr>
    <td width="93" height="11">
    <p align="right"><font size="1" face="Arial">Pay to the</font></td>
    <td width="101" height="11"></td>
    <td width="104" height="11"></td>
    <td width="90" height="11"></td>
    <td width="232" height="11"></td>
    <td width="30" height="11"></td>
    <td width="63" height="11"></td>
    <td width="87" height="11"></td>
  </tr>
  <tr>
    <td width="93" height="19">    <p align="right"><font face="Arial" size="1">
    Order of</font></td>
    <td width="295" colspan="3" height="19" style="border-bottom-style: solid; border-bottom-width: 1"><font size="2" face="Arial">&nbsp;&nbsp;&nbsp;<?php print($payname); ?></font></td>
    <td width="232" height="19" style="border-bottom-style: solid; border-bottom-width: 1">&nbsp;</td>
    <td width="30" height="19">&nbsp;</td>
    <td width="63" height="19">
    <p align="right">$</td>
    <td width="87" height="19"><font size="2" face="Arial"><?php print($auditfee); ?></font></td>
  </tr>
  <tr>
    <td colspan="8" width="750" height="19">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="8" width="750" height="16"><font size="2" face="Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <u><?php print($spellout); ?> and <?php print($cents); ?>/100 
    ******************************************************************* </u>&nbsp;&nbsp;&nbsp;Dollars</font> </td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="30" height="19">&nbsp;</td>
    <td width="150" colspan="2" height="19">&nbsp;</td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="30" height="19">&nbsp;</td>
    <td width="150" colspan="2" height="19">&nbsp;</td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="180" colspan="3" height="19"><font size="2" face="Arial">Written 
    Authorization on File</font></td>
  </tr>
  <tr>
    <td width="93" height="16">
    <p align="right"><font size="2" face="Arial">For <font></td>
    <td width="101" height="16" style="border-bottom-style: solid; border-bottom-width: 1"></td>
    <td width="104" height="16" style="border-bottom-style: solid; border-bottom-width: 1"></td>
    <td width="90" height="16"></td>
    <td width="232" height="16"></td>
    <td width="192" colspan="3" height="16" style="border-bottom-style: solid; border-bottom-width: 1"><b><font face="Arial" size="2">NO 
    SIGNATURE REQUIRED</font></b></td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19" style="border-top-style: solid; border-top-width: 1">&nbsp;</td>
    <td width="104" height="19" style="border-top-style: solid; border-top-width: 1">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="180" colspan="3" height="19" style="border-top-style: solid; border-top-width: 1">&nbsp;</td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="180" colspan="3" height="19">&nbsp;</td>
  </tr>
  <tr>
    <td width="93" height="1"></td>
    <td width="101" height="1"></td>
    <td width="104" height="1"><font face="MICR E13B">C<?php print($checknumbottom); ?>C</font></td>
    <td width="502" height="1" colspan="5"><font face="MICR E13B">&nbsp;A<?php print($bankrtg); ?>A&nbsp;&nbsp; 
    <?php print($bankact); ?>C</font></td>
  </tr>
</table>

<BR><BR><BR><BR><BR><b>DUPLICATE FOR YOUR RECORDS</b>
<table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="750" id="AutoNumber1" cellpadding="0" height="5" background="http://www.tcrosystems.co/images/void.gif">
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="205" colspan="2" height="19"><b><font size="2" face="Arial"><?php print($holder); ?></font></b></td>
    <td width="90" height="19">&nbsp;</td>
    <td width="262" colspan="2" height="19"><b><font size="1" face="Arial"><?php print($bankname); ?></font></b></td>
    <td width="63" height="19">&nbsp;</td>
    <td width="87" height="19">
    <p align="right"><b><font size="2" face="Arial"><?php print($checknum); ?></font></b></td>
  </tr>
  <tr>
    <td width="93" height="13"></td>
    <td width="205" colspan="2" height="13"><font size="1" face="Arial"><?php print($holderaddress); ?></font></td>
    <td width="90" height="13"></td>
    <td width="262" colspan="2" height="13">&nbsp;</td>
    <td width="63" height="13"></td>
    <td width="87" height="13"><font size="1" face="Arial"><?php print($aba); ?></font></td>
  </tr>
  <tr>
    <td width="93" height="13"></td>
    <td width="205" colspan="2" height="13"><font size="1" face="Arial"><?php print($holdercity); ?>, <?php print($holderstate); ?> <?php print($holderzip); ?></font></td>
    <td width="90" height="13"></td>
    <td width="232" height="13"></td>
    <td width="30" height="13"></td>
    <td width="63" height="13"></td>
    <td width="87" height="13"></td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">void void void</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">void</td>
    <td width="30" height="19">&nbsp;</td>
    <td width="63" height="19">&nbsp;</td>
    <td width="87" height="19">&nbsp;</td>
  </tr>

  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">void void void</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">void</td>
    <td width="30" height="19">&nbsp;</td>
    <td width="63" height="19">
    <p align="right"><font size="2" face="Arial">Date: &nbsp;</font></td>
    <td width="87" height="19"><font size="2" face="Arial"><b><?php print($paid); ?></b></font></td>
  </tr>
  <tr>
    <td width="93" height="11">
    <p align="right"><font size="1" face="Arial">Pay to the</font></td>
    <td width="101" height="11"></td>
    <td width="104" height="11"></td>
    <td width="90" height="11"></td>
    <td width="232" height="11"></td>
    <td width="30" height="11"></td>
    <td width="63" height="11"></td>
    <td width="87" height="11"></td>
  </tr>
  <tr>
    <td width="93" height="19">    <p align="right"><font face="Arial" size="1">
    Order of</font></td>
    <td width="295" colspan="3" height="19" style="border-bottom-style: solid; border-bottom-width: 1"><font size="2" face="Arial">&nbsp;&nbsp;&nbsp;<?php print($payname); ?></font></td>
    <td width="232" height="19" style="border-bottom-style: solid; border-bottom-width: 1">&nbsp;</td>
    <td width="30" height="19">&nbsp;</td>
    <td width="63" height="19">
    <p align="right">$</td>
    <td width="87" height="19"><font size="2" face="Arial"><?php print($auditfee); ?></font></td>
  </tr>
  <tr>
    <td colspan="8" width="750" height="19">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="8" width="750" height="16"><font size="2" face="Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <u><?php print($spellout); ?> and <?php print($cents); ?>/100 
    ******************************************************************* </u>&nbsp;&nbsp;&nbsp;Dollars</font> </td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="30" height="19">&nbsp;</td>
    <td width="150" colspan="2" height="19">&nbsp;</td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="30" height="19">&nbsp;</td>
    <td width="150" colspan="2" height="19">&nbsp;</td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="180" colspan="3" height="19">&nbsp;</td>
  </tr>
  <tr>
    <td width="93" height="16">
    <p align="right"><font size="2" face="Arial">For </td>
    <td width="101" height="16" style="border-bottom-style: solid; border-bottom-width: 1"></td>
    <td width="104" height="16" style="border-bottom-style: solid; border-bottom-width: 1"></td>
    <td width="90" height="16"></td>
    <td width="232" height="16"></td>
    <td width="192" colspan="3" height="16" style="border-bottom-style: solid; border-bottom-width: 1"><b><font face="Arial" size="2">
    DO NOT CASH (VOID)</font></b></td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19" style="border-top-style: solid; border-top-width: 1">&nbsp;</td>
    <td width="104" height="19" style="border-top-style: solid; border-top-width: 1">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="180" colspan="3" height="19" style="border-top-style: solid; border-top-width: 1">&nbsp;</td>
  </tr>
  <tr>
    <td width="93" height="19">&nbsp;</td>
    <td width="101" height="19">&nbsp;</td>
    <td width="104" height="19">&nbsp;</td>
    <td width="90" height="19">&nbsp;</td>
    <td width="232" height="19">&nbsp;</td>
    <td width="180" colspan="3" height="19">&nbsp;</td>
  </tr>
  <tr>
    <td width="93" height="1"></td>
    <td width="101" height="1"></td>
    <td width="104" height="1"><font face="MICR E13B">C<?php print($checknumbottom); ?>C</font></td>
    <td width="502" height="1" colspan="5"><font face="MICR E13B">&nbsp;A<?php print($bankrtg); ?>A&nbsp;&nbsp; 
    <?php print($bankact); ?>C</font></td>
  </tr>
</table>





<?php
}}
else
{
    header("Location: login.php");
    exit();
}



?>