<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
include('template.php');
      include("connection.php");

    ?>
        <?php
    if($_SESSION['affiliate']=="Yes")
    {
    ?>
    <font color="red">  <B> <?php print($message); ?></B></font>
 <?php
    include('main.php');
   ?>
      <form action="" method="get">

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="291">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Affiliate Search</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
        <table background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="291">
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td><font color="#FFFFFF"><b>&nbsp;First Name: </b></font> </td>
                <td class='ss-round-inputs' >
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="fname" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>
			<tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td><font color="#FFFFFF"><b>&nbsp;Last Name:</b></font>  </td>
                <td class='ss-round-inputs' >
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="lname" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td><font color="#FFFFFF"><b>&nbsp;ZIP:</b></font>  </td>
                <td class='ss-round-inputs' >
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="zip" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td><font color="#FFFFFF"><b>&nbsp;E-mail: </b></font> </td>
                <td class='ss-round-inputs' >
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="email" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>
         <tr>
                <td width="107"> <input type="hidden" name="f" value="1">
                <br>&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="submit" name="Find" value="Find"></td>
                <td width="185">&nbsp;
                    </td>
            </tr>

        </table>
       
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="291">
<tr><td width="1"><img border="0" src="bottomleftcorner.gif" ></td>
<td class="miniheaders" background="bottombackground.gif" width="99%"></td>
<td width="1"><img border="0" src="bottomrightcorner.gif"></td></tr>
</table>

    </form>
    
   <br>
     <br>        <?php
   

    if($_GET['f']==1)
    {
        ?>
       <BR>

<?php  if($_SESSION['usname']=="admin"){  ?>
 <input type="button" style="position:relative;color: #07c;font-family: Georgia,serif;font-size: 12px;" name="OK" value="Export CSV" label="OK" onClick="javascript:window.location.href='affiliatescsv.php';">
<?php  }  ?>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="80%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">List of affiliates that match your criteria</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

 <table id="rounded-corner" width="80%">

 <tr >
 <th class="rounded-company">ID</th>
 <th class="rounded-company">Last Name</th>
 <th class="rounded-company">First Name</th>
<th class="rounded-q1">&nbsp;&nbsp;&nbsp</th>
<th class="rounded-q2">Address</th>
<th class="rounded-q3">Email</th>
<th class="rounded-q3">Username</th>
<th class="rounded-q3">Earned</th>
<th class="rounded-q3">Paid</th>
<th class="rounded-q3">Due</th>
<th class="rounded-q3"></th>
</tr>
        <?php
          if(($_GET['fname'] != null) && ($_GET['fname'] != ''))
          {
             $query = "SELECT id, fname, lname, address, email, user, commission_rate FROM sales_affiliates WHERE status !='del' and type='Affiliate' AND fname LIKE('" . mysql_real_escape_string($_GET['fname']) . "%')";
          } 
		  else if(($_GET['lname'] != null) && ($_GET['lname'] != ''))
          {
             $query = "SELECT id, fname, lname, address, email, user, commission_rate FROM sales_affiliates WHERE status !='del' and type='Affiliate' AND lname LIKE('" . mysql_real_escape_string($_GET['lname']) . "%')";
          }
          else if($_GET['zip'] != '')
          {
             $query = "SELECT id, fname, lname, address, email, user, commission_rate FROM sales_affiliates WHERE status !='del' and type='Affiliate' AND zip='" . mysql_real_escape_string($_GET['zip']) . "'";
          }
          else if(($_GET['email'] != null) && ($_GET['email'] != ''))
          {
             $query = "SELECT id, fname, lname, address, email, user, commission_rate FROM sales_affiliates WHERE status !='del' and type='Affiliate' AND email LIKE('" . mysql_real_escape_string($_GET['email']) . "%')";
          }
          else
             $query = "SELECT id, fname, lname, address, email, user, commission_rate FROM sales_affiliates WHERE status !='del' and type='Affiliate' ORDER BY lname";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $affiliate_id           = $row[0];
              $fname   = $row[1];
              $lname      = $row[2];
              $address       = $row[3];
              $email         = $row[4];
              $user       = $row[5];
              $commission_rate = $row[6];
              $cnt++;
              
      

$bgcolor = "#e8edff";
$COM_total_comish = "";
$COM_total_pd = "";


$LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_affiliate WHERE affiliate_id = '$affiliate_id' GROUP BY affiliate_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}




              ?>
<tr bgcolor=<?php print($bgcolor); ?> onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
              <td ><?php print($affiliate_id); ?></td>
              <td ><a href="setaffiliate.php?cid=<?php print($affiliate_id); ?>&cname=<?php print($lname); ?>, <?php print($fname); ?>"><?php print($lname); ?></a></td>
              <td ><?php print($fname); ?></td>

              <td ><a href="search.php?searchaffiliate=<?php print($affiliate_id); ?>&f=1"><font size=1>view clients</font></a></td>

              <td ><?php print($address); ?></td>
              <td ><a href="mailto:<?php print($email); ?>"><?php print($email); ?></a></td>
              <td ><?php print($user); ?></td>
              <td >$<?php print($COM_total_comish); ?></td>
              <td >$<?php print($COM_total_pd); ?></td>
              <td >$<?php print($COM_total_comish - $COM_total_pd); ?></td>
			  <td ><a href="affiliatedelete.php?cid=<?php print($affiliate_id);?>&cname=<?php print($lname); ?>, <?php print($fname); ?>"><img border="0" src="deletebutton.png"></a></td>
              
             

              </tr>
              <?php
          }
          mysql_close($conn);
          ?>
          </table>
          <?php
          if($cnt==0)
          {
              print("There are no matching records to your search criteria. Please try again.");
          }
    }
}}
else
{
    header("Location: login.php");
    exit();
}

?>