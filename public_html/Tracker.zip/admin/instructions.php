<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
 include("connection.php");

$query = "SELECT reseller FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $reseller = $row[0];

    }

    ?>


<STYLE>
body {
        margin: 2px;
        padding: 7px;
        
background-image:   url('bluebackgroundsmall.gif');
}
body, td, th {
        
font: 11px/14px Verdana, sans-serif;
}
thead th {
        font-weight: bold;
}
#content {
        color: #333333;
        padding: 20px;
}
h1 {
        font-size: 18px;
        color: #374C76;
}
h2 {
        font-size: 12px;
        color: #374C76;
}
a:link {
        color: #FFFFFF;
}
a:visited {
        color: #FFFFFF;
}

.txtbox{
	background-color: #FFFFFF;


	font-family: Verdana, sans-serif; 
	font-size: 11px;
	color: #000000;
	background-image:   url('formshadow.gif');
}
.txtboxsmall{
	background-color: #FFFFFF;


	font-family: Verdana, sans-serif; 
	font-size: 11px;

	color: #000000;
	background-image:   url('formshadow.gif');
}

.txtboxdeleted{
	background-color: #FFFFFF;


	font-family: Verdana, sans-serif; 
	font-size: 11px;
	color: #000000;
	background-image:   url('formshadow2.gif');
	}
.nothing{	
font: 11px/16px Verdana, sans-serif;
</STYLE>

<?php

 if($inst=="autoresponder"){
echo "<IFRAME scrolling=no marginwidth=0 marginheight=0 width=795 height=580  SRC=\"http://www.tcrosystems.net/instructions/autoresponder\" </IFRAME>";
}
if($inst=="demanddraft"){
echo "<IFRAME scrolling=no marginwidth=0 marginheight=0 width=795 height=580  SRC=\"http://www.tcrosystems.net/instructions/demanddraft\" </IFRAME>";
}
if($inst=="demanddraft2"){
echo "<IFRAME scrolling=no marginwidth=0 marginheight=0 width=795 height=580  SRC=\"http://www.tcrosystems.net/instructions/demanddraft2\" </IFRAME>";
}
if($inst=="addletters" && $reseller !="Yes"){
echo "<IFRAME scrolling=no marginwidth=0 marginheight=0 width=795 height=580  SRC=\"http://www.tcrosystems.net/instructions/addletters\" </IFRAME>";
}
if($inst=="helpdesk"){
echo "<IFRAME scrolling=no marginwidth=0 marginheight=0 width=795 height=580  SRC=\"http://www.tcrosystems.net/instructions/helpdesk\" </IFRAME>";
}


else if ($listall=="yes"){

?>
 <SCRIPT LANGUAGE="JavaScript">

function OpenWindow(url,winwidth,winheight) 
{
NewWindow=window.open(url,'descr','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,scrollbars=no,resizable=yes,copyhistory=no,width='+winwidth+',height='+winheight)
}
</SCRIPT>






<b><font size="2">Optional Upgrades</font></b><font size="2"> </font><BR>
<a href="javascript:OpenWindow('instructions.php?inst=autoresponder','815','605')">Autoresponder System</a>
<BR><BR>
<a href="javascript:OpenWindow('instructions.php?inst=demanddraft','815','605')">Demand Draft</a>







<BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
    <a href="menu.php">Main Menu</a><?php
}

?>







  
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>
