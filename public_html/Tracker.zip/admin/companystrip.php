<?php

extract ($_GET );
extract ($_POST );

$message2=$message;
$subject2=$subject;
$message2 = str_replace("{COMPANY}", "$companyname", $message2);
$subject2 = str_replace("{COMPANY}", "$companyname", $subject2);
$message2 = str_replace("{COMPANYADDR}", "$companyaddress", $message2);
$subject2 = str_replace("{COMPANYADDR}", "$companyaddress", $subject2);
$message2 = str_replace("{COMPANYCITY}", "$companycity", $message2);
$subject2 = str_replace("{COMPANYCITY}", "$companycity", $subject2);
$message2 = str_replace("{COMPANYSTATE}", "$companystate", $message2);
$subject2 = str_replace("{COMPANYSTATE}", "$companystate", $subject2);
$message2 = str_replace("{COMPANYZIP}", "$companyzip", $message2);
$subject2 = str_replace("{COMPANYZIP}", "$companyzip", $subject2);
$message2 = str_replace("{COMPANYPHONE}", "$companyphone", $message2);
$subject2 = str_replace("{COMPANYPHONE}", "$companyphone", $subject2);
$message2 = str_replace("{COMPANYFAX}", "$companyfax", $message2);
$subject2 = str_replace("{COMPANYFAX}", "$companyfax", $subject2);
$message2 = str_replace("{SITE}", "$companywebsite", $message2);
$subject2 = str_replace("{SITE}", "$companywebsite", $subject2);  
?>