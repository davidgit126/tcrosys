<?php
extract ($_GET );
extract ($_POST );
    include_once('common.inc.php');
    session_start();



    include("connection.php");
        $query = "INSERT INTO letters(lettername, abovedisputes, belowdisputes, showdisputes, letterorder, disputecolumn, showproof)
                VALUES(
                '" . mysql_real_escape_string($_POST['lettername']) . "', 
                '" . mysql_real_escape_string($_POST['abovedisputes']) . "',
                '" . mysql_real_escape_string($_POST['belowdisputes']) . "',
                '" . mysql_real_escape_string($_POST['showdisputes']) . "', 
                '" . mysql_real_escape_string($_POST['letterorder']) . "', 
                '" . mysql_real_escape_string($_POST['disputecolumn']) . "', 
                '" . mysql_real_escape_string($_POST['showproof']) . "')";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());


   $query = "SELECT id FROM letters WHERE lettername='$lettername'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $letterid           = $row[0];
}


//
        header("Location: editletter.php?letterid=$letterid&success=$lettername Letter Added!");
        exit();
    
?>