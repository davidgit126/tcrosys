<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    include("connection.php");

  if($_POST['addnewcreditor']==1)
    {
 
                $query = "INSERT INTO creditors(name)
                    VALUES(
                    '" . mysql_real_escape_string($_POST['newcreditorname']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
header("Location: creditreport.php");  //redirect   
            }

  if($_POST['addnewbeginstatus']==1)
    {
 
                $query = "INSERT INTO beginstatus(negativetype)
                    VALUES(
                    '" . mysql_real_escape_string($_POST['newbeginstatus']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
header("Location: creditreport.php");  //redirect   
            }

  if($_POST['addnews1dispute']==1)
    {
 
                $query = "INSERT INTO tailenddispute(tailend)
                    VALUES(
                    '" . mysql_real_escape_string($_POST['news1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
header("Location: creditreport.php");  //redirect   
            }


 if($_REQUEST['removecreditor'] == 1)
    {
        $query = "DELETE FROM creditors WHERE id='" . mysql_real_escape_string($_REQUEST['removecreditorname']) . "' ";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

header("Location: creditreport.php");  //redirect   

    }

 if($_REQUEST['removebeginstatus'] == 1)
    {
        $query = "DELETE FROM beginstatus WHERE id='" . mysql_real_escape_string($_REQUEST['removenegativetype']) . "' ";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

header("Location: creditreport.php");  //redirect   

    }
 if($_REQUEST['removetailend'] == 1)
    {
        $query = "DELETE FROM tailenddispute WHERE id='" . mysql_real_escape_string($_REQUEST['removetailid']) . "' ";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

header("Location: creditreport.php");  //redirect   

    }

?>




    <?php
}
else
{
    header("Location: login.php");
    exit();
}

?>