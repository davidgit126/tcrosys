<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
include('template.php');

	if(isset($_GET['clientid']) && isset($_GET['clname']))
	{
		$clientid   = $_GET['clientid'];
    	$clname     = $_GET['clname'];
	}
	else
	{
    	$clientid   = $_SESSION['clientid'];
    	$clname     = $_SESSION['clname'];
	}
    
    include("connection.php");
    ?>
    <h1>Interviewer for Client: <?=$clname?></h1>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111">
    <tr>
        <td colspan="3" height="19">&nbsp; </td>
    </tr>
    <tr>
        <td width="37">&nbsp;</td>
        <td rowspan="3" valign="top">
        <form action="interviewer.php" method="post">
        <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="106">
        <tr> 
            <td width="33%" valign="top" height="26"><b><font color="#000099">Account Names</font></b></td>
            <td width="33%" valign="top" height="26"><b><font color="#000099">Account Number</font></b></td>
            <td width="34%" valign="top" height="26"> <div align="left"><strong><font color="#000099">Comments</font> </strong></div></td>
        </tr>
        <?php
        $query = "SELECT id, name, number, comments, dispute FROM  accounts WHERE clientid='" . mysql_real_escape_string($clientid) . "'  GROUP BY name, number";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        $col_count = mysql_num_fields($result);
        $count=0;   
        while($row=mysql_fetch_row($result))
        {
            $accid= $row[0];
            $accname= $row[1];
            $accnumber = $row[2];
            $comments = $row[3];
            $dispute = $row[4];
            $count= $count+1;
            ?>
            <tr>
                <td valign="top" height="52"><?php print($count); ?>. <b><?php print($accname); ?></b></td>
                <td valign="top" height="52"><b><?php print($accnumber); ?></b></td>
                <td valign="top" height="52">
                    <?php print($dispute); ?>
                    <br>
                    <?php print($comments); ?>
                </td>
            </tr>
            <?php
        }
        mysql_close($conn);
        if($count==0) 
        {
            ?><tr><td>The client doesn't have any accounts yet.</td></tr><?php
        }
        ?>
        </table>
        </form>      
        </td>
        <td width="29">&nbsp;</td>
        </tr>
        </table>
    
    <?
}
else
{
    header("Location: login.php");
    exit();
}

?>