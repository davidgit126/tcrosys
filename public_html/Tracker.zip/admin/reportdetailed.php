<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    ?>
    
        <?php
         include("connection.php");
include('template.php');


             $query = "SELECT count(id) as id, name, status, createdate FROM clients GROUP BY active";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $status       = $row[2];
              $createdate  = $row[3];
              $cnt++;
  
$bgcolor = "FFFFFF";
}
              ?>
              <tr>
              
              </tr>
              
          </table>
          <p>Total Active Accounts in the system (as of <? print date("m-d-Y"); ?>): <b><?php echo $id; ?></b></p>
              
                 <?php
       
$lastmonth = strftime ("%Y-%m", strtotime("-1 month"));
$twolastmonth = strftime ("%Y-%m", strtotime("-2 month"));
$lastmonth2 = strftime ("%m/%Y", strtotime("-1 month"));
$currentmonth = date("Y-m"); 
$lastday = "-31";
$firstday = "-01";

             $query2 = "SELECT count(id) FROM clients WHERE createdate >= '$lastmonth$firstday' and createdate <= '$lastmonth$lastday' GROUP BY active";

          $result = mysql_query($query2, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $newid           = $row[0];
              $cnt++;
             }
$query3 = "SELECT count(id) FROM clients WHERE createdate <= '$twolastmonth$lastday' GROUP BY active";

          $result = mysql_query($query3, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $oldid           = $row[0];
              $cnt++;
            }

$totalcommish = ($newid * 20) + ($oldid * 5);
              ?>
    
                  <b>~~Accounting Info~~</b><BR><BR>
                     <p>Number of accounts from <?php echo $lastmonth2; ?>: <b><?php echo $newid; ?></b></p>

<p>Number of existing accounts before <?php echo $lastmonth2; ?>: <b><?php echo $oldid; ?></b></p>
~~~~~~~~~~~~~~~~~~~~~~<BR>
<br>
<u>Existing Account names</u><br>
</b></font>

<table border="1" cellspacing="1" width="80%" id="AutoNumber1">
  <tr>
    <td width="1%">&nbsp;</td>
    <td width="33%"><b>Name</b></td>
    <td width="33%"><b>Email</b></td>
    <td width="33%"><b>Date Enrolled</b></td>
  </tr>
<tr>
<?php
$query4 = "SELECT name, email, DATE_FORMAT(createdate, \"%m-%d-%Y\") as createdate FROM clients WHERE createdate <= '$twolastmonth$lastday'";

          $result = mysql_query($query4, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $name  = $row[0];
              $email  = $row[1];
              $createdate  = $row[2];                            
              $cnt++;
              $i= $cnt
   
     
?>
  
  <td width="1%"><b><?php echo "$i"; ?></b>&nbsp;</td>
    <td width="33%"><?php echo "$name"; ?>&nbsp;</td>
    <td width="33%"><?php echo "$email"; ?>&nbsp;</td>
    <td width="33%"><?php echo "$createdate"; ?>&nbsp;</td>
  </tr>
<?php

}
?>

</table>
Amount owed for existing active accounts for <?php echo $lastmonth2; ?>: <font color="#008000"><b>$<?php echo $oldid * 5; ?><br>
<p>
<br>
<u>New Account Names</u><br>
<table border="1" cellspacing="1" width="80%" id="AutoNumber1">
  <tr>
    <td width="1%">&nbsp;</td>
        <td width="33%"><b>Name</b></td>
    <td width="33%"><b>Email</b></td>
    <td width="33%"><b>Date Enrolled</b></td>
  </tr>
<tr>
<?php
$query5 = "SELECT name, email, DATE_FORMAT(createdate, \"%m-%d-%Y\") as createdate FROM clients WHERE createdate >= '$lastmonth$firstday' and createdate <= '$lastmonth$lastday'";

          $result = mysql_query($query5, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $name  = $row[0];
              $email  = $row[1];
              $createdate  = $row[2];                            
              $cnt++;
              $i= $cnt
   
     
?>
  
  <td width="1%"><b><?php echo "$i"; ?></b>&nbsp;</td>
    <td width="33%"><?php echo "$name"; ?>&nbsp;</td>
    <td width="33%"><?php echo "$email"; ?>&nbsp;</td>
    <td width="33%"><?php echo "$createdate"; ?>&nbsp;</td>
  </tr>
<?php

}
?>

</table>

</b></font>

Amount owed for new accounts for <?php echo $lastmonth2; ?>: <b>
<font color="#008000">$<?php echo $newid * 20; ?><br> <br>
</font>

</b> <font color="#008000"><b><BR>
~~~~~~~~~~~~~~~~~~~~~<BR>
</font>

Total New Accounts plus Old Accounts =<font color="#008000"> <font color="#008000">$<?php echo $totalcommish; ?></font> </font>

</b> <font color="#008000"><b>
<p>&nbsp;</p>

</b></font>

<?php
         
}
else
{
    header("Location: login.php");
    exit();
}

?>