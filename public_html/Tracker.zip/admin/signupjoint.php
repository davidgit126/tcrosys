<?php
extract ($_GET );
extract ($_POST );

    include_once('common.inc.php');
    session_start();


    include("connection.php");
    $query = "SELECT id, name FROM clients WHERE (username='" . mysql_real_escape_string($_POST['susername']) . "' or username='" . mysql_real_escape_string($_POST['spouseusername']) . "')"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
   // print($col_count);
   $reccount=0;
    while($row=mysql_fetch_row($result))
    {
         $reccount++;
    } 

    if($reccount>0)
    {

        print("<html><body>");
        print("The username <b>$username</b> already exist. Please choose another name. <br> Click on Back button of your browser");
    }  
    else
    {
$fontday = date("D");

        $query = "SELECT font FROM fonttypes WHERE fontday ='$fontday'"; 
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        $col_count = mysql_num_fields($result);

        while($row=mysql_fetch_row($result))
        {
          $fonttype = $row[0];

        } 

        $date_array = split("-", $birthdate);
        $birthdate = $date_array[2]."-".$date_array[0]."-".$date_array[1];
$createdate = date("Y-m-d");
$query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, reseller, single, dbname, creditline, companyskin, privatelabel FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $reseller = $row[12];              
        $single = $row[13];              
        $dbname = $row[14];          
        $creditline = $row[15];  
        $companyskin = $row[16]; 
        $privatelabel = $row[17]; 
        

    }
/////////////////////////////
if($reseller =="Yes")
{
if($single =="200.00")
{
$dateexpire = date("Y-m-d", time()+182*24*3600);
}else if($single =="150.00"){
$dateexpire = date("Y-m-d", time()+91*24*3600);
}else if($single =="100.00"){
$dateexpire = date("Y-m-d", time()+61*24*3600);
}
include "700score_connection2.php"; 
            	
            	    $query = "SELECT dealer_id  FROM dealers WHERE dbname='$dbname' limit 1";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dealer_id = $row[0];
  
        }
 
    $query = "SELECT SUM(amountpurchased) as amountpurchased FROM bulktracking WHERE dealer_id='$dealer_id'";
$result = @mysql_query($query,$conn2);
while ($row = mysql_fetch_array($result)) {	
$totalamountpurchased = $row['amountpurchased'];
}


    
$query2 = "SELECT SUM(resellercredit) as resellercredit FROM clients";
$result2 = @mysql_query($query2,$conn);
while ($row2 = mysql_fetch_array($result2)) {	
$totalresellercredit = $row2['resellercredit'];

}
$totalbalance = $totalamountpurchased - $totalresellercredit;
$totalbalancewithcredit = $totalbalance + $creditline;
$couple = $single*2;
if($totalbalancewithcredit < $couple){



   mysql_close($conn);
        header("Location: credits.php");
        exit();
}else{

       $email2 = "csogate@htdifinancial.com";
$balancenow = $totalbalance - $couple;
	$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $companyname <$companyreply>\r\n";
            
                $subject = "New Client Enrollment by $sname and $spousename";
                $message = "<B>Date:</B> $createdate <BR><B>Name:</B> $sname and $spousename <BR><B>Email:</B> $semail <BR><B>Phone:</B> $phone <BR><BR>$companywebsite<BR><BR>Prepaid balance is now $balancenow";
       //         $formsent = mail($email2, $subject, $message, $HEADERS); 
 
$sendtohtdi = "Yes";
$resellercredit = $single;
}
}
/////////////////////////////

$broker_id =$_POST['broker_id'];

$tier_id = $_POST['broker_id'];
if ($tier_id != "") {
    $query = "SELECT tier2aff, username, tier3aff, affiliate_id FROM dealers WHERE dealer_id='$tier_id'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $tier2aff = $row[0];
        $usernameu = $row[1];
        $tier3aff = $row[2];
        $affiliate_id = $row[3];
  }
}

 if($affiliate_id ==""){
$affiliate_id=$_POST['affiliate_id'];
}

        $query = "INSERT INTO clients(name, address, city, state, zip, email, fax, phone, altphone, cellphone, cellcarrier, ssnum, birthdate, createdate, fonttype, username, password, country, broker_id, dealer_id, affiliate_id, tier2aff, tier3aff, reseller_id, adminpayment, singlecouple, sendtohtdi, resellercredit)
                VALUES(
                '" . mysql_real_escape_string($_POST['sname']) . "', 
                '" . mysql_real_escape_string($_POST['saddress']) . "', 
                '" . mysql_real_escape_string($_POST['city']) . "', 
                '" . mysql_real_escape_string($_POST['state']) . "',
                '" . mysql_real_escape_string($_POST['szip']) . "',
                '" . mysql_real_escape_string($_POST['semail']) . "',
                '" . mysql_real_escape_string($_POST['fax']) . "',
                '" . mysql_real_escape_string($_POST['phone']) . "',
                '" . mysql_real_escape_string($_POST['altphone']) . "',
                '" . mysql_real_escape_string($_POST['cellphone']) . "',
                '" . mysql_real_escape_string($_POST['cellcarrier']) . "',
                '" . mysql_real_escape_string($_POST['ssnum']) . "',
                '$birthdate',
                '$createdate',
                '$fonttype',
                '" . mysql_real_escape_string($_POST['susername']) . "',
                '" . mysql_real_escape_string($_POST['spassword']) . "', 
                '" . mysql_real_escape_string($_POST['country']) . "',
                '$broker_id',
                '" . mysql_real_escape_string($_POST['dealer_id']) . "',
                '$affiliate_id',
                '$tier2aff',
                '$tier3aff',
                '" . mysql_real_escape_string($_POST['reseller_id']) . "',
                '" . mysql_real_escape_string($_POST['adminpayment']) . "',
                'Joint',
                '$sendtohtdi',
                '$resellercredit')";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
$clientid = mysql_insert_id($conn);
$query = "INSERT INTO enrolment(clientid, dateenrol, welcomepacket, dateexpire) VALUES('$clientid','$createdate','$createdate','$dateexpire')";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO billing(clientid, bankname, bankrtg, bankact, aba, checknum) VALUES(
'$clientid',
'" . mysql_real_escape_string($_POST['bankname']) . "',
'" . mysql_real_escape_string($_POST['bankrtg']) . "',
'" . mysql_real_escape_string($_POST['bankact']) . "',
'" . mysql_real_escape_string($_POST['bankaba']) . "',
'" . mysql_real_escape_string($_POST['checknum']) . "')";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());

 $_SESSION['clientid']   = $clientid;
        $_SESSION['clname']     = $name;
$contact_id = $clientid;


if($affiliate_id != '')
{
$ip=$_SERVER["REMOTE_ADDR"];
$year = date("Y");
$month = date("m");
$day = date("d");
$julian = "$year$month$day";
$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";

$sql = "SELECT * FROM sales_affiliates WHERE id = '$affiliate_id'";
$result = mysql_query($sql, $conn);
$AFFIL_DATA=mysql_fetch_array($result, MYSQL_ASSOC);


$sql = "INSERT INTO commission_affiliate
	(id,contact_id,affiliate_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$affiliate_id\",
	\"$AFFIL_DATA[commission_rate]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"$user\")";
	
	$result = @mysql_query($sql,$conn);
}

/////////BROKER COMMISSION CREDIT
$ip=$_SERVER["REMOTE_ADDR"];
$year = date("Y");
$month = date("m");
$day = date("d");
$julian = "$year$month$day";
$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";

if($tier_id != ''){

$sql = "SELECT * FROM dealers WHERE dealer_id = '$broker_id'";
$result = mysql_query($sql, $conn);
$BROKER_DATA=mysql_fetch_array($result, MYSQL_ASSOC);

	$sql = "INSERT INTO commission_brokers
	(id,contact_id,broker_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,level,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$broker_id\",
	\"$BROKER_DATA[commission]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"1\",
	\"$user\")";
	$result = @mysql_query($sql,$conn);
}


if($tier2aff != '' && $tier2aff != 0 ){

$sql = "SELECT tier2comm FROM dealers WHERE dealer_id = '$tier2aff'";
$result = mysql_query($sql, $conn);
$LEVEL2AFF_DATA=mysql_fetch_array($result, MYSQL_ASSOC);

	$sql = "INSERT INTO commission_brokers
	(id,contact_id,broker_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,level,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$tier2aff\",
	\"$LEVEL2AFF_DATA[tier2comm]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"2\",
	\"$user\")";
	$result = @mysql_query($sql,$conn);
}

if($tier3aff != '' && $tier3aff != 0){

$sql = "SELECT tier3comm FROM dealers WHERE dealer_id = '$tier3aff'";
$result = mysql_query($sql, $conn);
$LEVEL3AFF_DATA=mysql_fetch_array($result, MYSQL_ASSOC);

	$sql = "INSERT INTO commission_brokers
	(id,contact_id,broker_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,level,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$tier3aff\",
	\"$LEVEL3AFF_DATA[tier3comm]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"3\",
	\"$user\")";
	$result = @mysql_query($sql,$conn);
}

///////////END BROKER COMMS



  $query = "SELECT id, name, subject, message, type, activated, description FROM systememails WHERE name='Client_Welcome'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailid           = $row[0];
              $emailname   = $row[1];
              $subject   = $row[2];
              $message   = $row[3];
              $type = $row[4];
              $activated = $row[5];              
              $description = $row[6];    
}

 if($activated =="Yes"){

    $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, comments, reseller_id, status, plan, DATE_FORMAT(dateresults, \"%m-%d-%Y\") as dateresults, singlecouple, showstatus, budgetday, avssnurl, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, altphone FROM clients WHERE id='$contact_id' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password = $row[12];
        $broker_id = $row[13];
	  $dealer_id = $row[14];
	  $affiliate_id = $row[15];
	  $comments = $row[16];
	  $reseller_id = $row[17];
	  $status = $row[18];
	  $plan = $row[19];
	  $dateresults = $row[20];
	  $singlecouple = $row[21];
	  $status = $row[22];	  
	  $budgetday = $row[23];	  	  
	  $avssnurl = $row[24];	  	  	  
  	  $logins = $row[25];	  	 
	  $lastlogin = $row[26];	  	   	  
	  $altphone = $row[27];	  	   	  
		  

    }
 if($email !=""){

    include_once("companystrip.php");
    include_once("clientstrip.php");

$EMAIL_Message = "$companyskin$message2";
if($privatelabel== "No"){
$EMAIL_Message .= $poweredbymessage;
}
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyemail";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS);  
}}


// JOINT SECTION NOW

  $date_array = split("-", $spousebirthdate);
        $spousebirthdate = $date_array[2]."-".$date_array[0]."-".$date_array[1];

  $query = "INSERT INTO clients(name, address, city, state, zip, email, fax, phone, altphone, cellphone, cellcarrier, ssnum, birthdate, createdate, fonttype, username, password, country, broker_id, affiliate_id, dealer_id, adminpayment, singlecouple, sendtohtdi, jointwith, resellercredit)
                VALUES(
                '" . mysql_real_escape_string($_POST['spousename']) . "', 
                '" . mysql_real_escape_string($_POST['saddress']) . "', 
                '" . mysql_real_escape_string($_POST['city']) . "', 
                '" . mysql_real_escape_string($_POST['state']) . "',
                '" . mysql_real_escape_string($_POST['szip']) . "',
                '" . mysql_real_escape_string($_POST['spouseemail']) . "',
                '" . mysql_real_escape_string($_POST['fax']) . "',
                '" . mysql_real_escape_string($_POST['phone']) . "',
                '" . mysql_real_escape_string($_POST['altphone']) . "',
                '" . mysql_real_escape_string($_POST['cellphone']) . "',
                '" . mysql_real_escape_string($_POST['cellcarrier']) . "',

                '" . mysql_real_escape_string($_POST['spousessn']) . "',
                '$spousebirthdate',
                '$createdate',
                '$fonttype',
                '" . mysql_real_escape_string($_POST['spouseusername']) . "',
                '" . mysql_real_escape_string($_POST['spousepassword']) . "', 
                '" . mysql_real_escape_string($_POST['country']) . "',
                '$broker_id',
                '$affiliate_id',
                '" . mysql_real_escape_string($_POST['dealer_id']) . "',
                '" . mysql_real_escape_string($_POST['adminpayment']) . "',
                'Joint',
                '$sendtohtdi',
                '$clientid',
                '$resellercredit')";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$spouseclientid = mysql_insert_id($conn);

        $query = "INSERT INTO enrolment(clientid, dateenrol, welcomepacket, dateexpire) VALUES('$spouseclientid','$createdate','$createdate','$dateexpire')";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

        $query = "INSERT INTO billing(clientid, bankname, bankrtg, bankact, aba, checknum) VALUES(
'$spouseclientid',
'" . mysql_real_escape_string($_POST['bankname']) . "',
'" . mysql_real_escape_string($_POST['bankrtg']) . "',
'" . mysql_real_escape_string($_POST['bankact']) . "',
'" . mysql_real_escape_string($_POST['bankaba']) . "',
'" . mysql_real_escape_string($_POST['checknum']) . "')";

$result = mysql_query($query, $conn) or die("error:" . mysql_error());


  $query = "UPDATE clients SET
                jointwith='$spouseclientid',
                singlecouple='Joint'
                WHERE id='$clientid'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());


        mysql_close($conn);

      
        header("Location: search.php");
        exit();
    }
?>