<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();

	


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   
    ?>
   
  <?php
    if($_SESSION['usname']=="admin")
    {
    
    
    
     include("connection.php");
   include('template2.php');


      $query = "SELECT id, lettername, abovedisputes, belowdisputes, showdisputes, showproof FROM letters WHERE id='$letterid'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $letterid           = $row[0];
              $lettername   = $row[1];
              $abovedisputes   = $row[2];
              $belowdisputes   = $row[3];
              $showdisputes = $row[4];
              $showproof = $row[5];              
}

        ?>
  
  
  
    
   
<? echo $abovedisputes; ?><BR>
 <?   if($showdisputes=="Yes"){ ?>
<B><BR>LIST DISPUTES HERE</B><BR><BR>
 <?  }?>
<? echo $belowdisputes; ?>

 <?   if($showproof=="Yes"){ ?>
<center><B><BR><BR><BR><BR>PROOF OF AV/SSN HERE</B></center>
 <?  }?>


<meta http-equiv="Content-Language" content="en-us">

<BR><BR><BR><BR><BR><BR>

<a href="editletter.php?letterid=<?php print($letterid); ?>">Back</a><?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>