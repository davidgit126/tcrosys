<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$ip=$_SERVER["REMOTE_ADDR"];
$year = date("Y");
$month = date("m");
$day = date("d");
$julian = "$year$month$day";
$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
 include("connection.php");
$GET_id=$_GET["id"];

$query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, reseller, single, dbname, creditline FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $reseller = $row[12];              
        $single = $row[13];              
        $dbname = $row[14];          
        $creditline = $row[15];          

    }

if($reseller !="Yes")
{

$thismonth = date("Y-m");
$firstday = "-01";
$thismonth = $thismonth.$firstday;

 $query3 = "SELECT count(id) FROM clients WHERE prospectclient='Client' and createdate >='$thismonth'";
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $numclients = $row3[0];
                   $i = $i+1;
}

include "700score_connection2.php"; 
            	
            	    $query = "SELECT dealer_id, contract FROM dealers WHERE dbname='$dbname' limit 1";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dealer_id = $row[0];
        $contract = $row[1];
        }

if($contract !="OLD" && $contract !="UL"){
$clientsleft = $contract - $numclients;
}else{
$clientsleft = 1000;
}}
if($clientsleft <= 0 && $reseller !="Yes"){
echo "<BR>You have outgrown your Tracker Plan.  Please contact your Account Executive to upgrade.  Congratulations on your success!";
}else{


      if($_POST['updatecl'] == 1)
      {

$createdate = date("Y-m-d");

$fontday = date("D");

        $query = "SELECT font FROM fonttypes WHERE fontday ='$fontday'"; 
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        $col_count = mysql_num_fields($result);

        while($row=mysql_fetch_row($result))
        {
          $fonttype = $row[0];

        } 


/////////////////////////////
if($reseller =="Yes")
{

if($single =="200.00")
{
$dateexpire = date("Y-m-d", time()+182*24*3600);
}else if($single =="150.00"){
$dateexpire = date("Y-m-d", time()+91*24*3600);
}else if($single =="100.00"){
$dateexpire = date("Y-m-d", time()+61*24*3600);
}

include "700score_connection2.php"; 
            	
            	    $query = "SELECT dealer_id  FROM dealers WHERE dbname='$dbname' limit 1";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dealer_id = $row[0];
  
        }
 
    $query = "SELECT SUM(amountpurchased) as amountpurchased FROM bulktracking WHERE dealer_id='$dealer_id'";
$result = @mysql_query($query,$conn2);
while ($row = mysql_fetch_array($result)) {	
$totalamountpurchased = $row['amountpurchased'];
}


    
$query2 = "SELECT SUM(resellercredit) as resellercredit FROM clients";
$result2 = @mysql_query($query2,$conn);
while ($row2 = mysql_fetch_array($result2)) {	
$totalresellercredit = $row2['resellercredit'];

}
$totalbalance = $totalamountpurchased - $totalresellercredit;
$totalbalancewithcredit = $totalbalance + $creditline;
$couple = $single*2;
if($totalbalancewithcredit < $couple){



   mysql_close($conn);
        header("Location: credits.php");
        exit();
}else{

       $email2 = "csogate@htdifinancial.com";
$balancenow = $totalbalance - $couple;
	$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $companyname <$companyreply>\r\n";
            
                $subject = "New Client Enrollment by $sname and $spousename";
                $message = "<B>Date:</B> $createdate <BR><B>Name:</B> $sname and $spousename <BR><B>Email:</B> $semail <BR><B>Phone:</B> $phone <BR><BR>Account balance is now $balancenow";
          //      $formsent = mail($email2, $subject, $message, $HEADERS); 
 
$sendtohtdi = "Yes";
$resellercredit = $single;
}
}




$tier_id = $_POST['broker_id'];
if ($tier_id != "") {
    $query = "SELECT tier2aff, username, tier3aff, affiliate_id FROM dealers WHERE dealer_id='$tier_id'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $tier2aff = $row[0];
        $usernameu = $row[1];
        $tier3aff = $row[2];
        $affiliate_id = $row[3];
  }
}

  $date_array = split("-", $birthdate);
        $birthdate = $date_array[2]."-".$date_array[0]."-".$date_array[1];




        $query = "UPDATE clients SET
                prospectclient='Client',
                status='pending',
                dateresults='0000-00-00',
                adminpayment='$adminpayment',
                singlecouple='Joint',
                sendtohtdi='$sendtohtdi',
                resellercredit='$resellercredit',
                name='$sname',
                address='$saddress',
                city='$city',
                state='$state',
                zip='$szip',
                phone='$phone',
                altphone='$altphone',
                cellphone='$cellphone',
                cellcarrier='$cellcarrier',
                fax='$fax',
                email='$semail',
                ssnum='$ssnum',
                birthdate='$birthdate',
                username='$susername',
                password='$spassword',
                resellercredit='$resellercredit',
                singlecouple='Joint',                
                dealer_id='$sales_id',
                tier2aff='$tier2aff',
                tier3aff='$tier3aff',
				createdate='$createdate'
                WHERE id='$convertid'";
        $result = mysql_query($query, $conn) or die("error at main convert" . mysql_error());
 
      
 $query = "INSERT INTO enrolment(clientid, dateenrol, welcomepacket, dateexpire) VALUES('$convertid','$createdate','$createdate','$dateexpire')";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());


        $query = "INSERT INTO billing(clientid, bankname, bankrtg, bankact, aba, checknum) VALUES(
'$convertid',
'" . mysql_real_escape_string($_POST['bankname']) . "',
'" . mysql_real_escape_string($_POST['bankrtg']) . "',
'" . mysql_real_escape_string($_POST['bankact']) . "',
'" . mysql_real_escape_string($_POST['bankaba']) . "',
'" . mysql_real_escape_string($_POST['checknum']) . "')";
        $result = mysql_query($query, $conn) or die("error at main billing" . mysql_error());


    if($_POST['addreceived'] != "" or $_POST['addaction'] != ""){
        $date_array = split("-", $adddate);
        $adddate = $date_array[2]."-".$date_array[0]."-".$date_array[1];
        $query = "INSERT INTO repair(clientid, repairdate, received, action, filelocation, counselor)
                VALUES(
				'$convertid',
                '$adddate',
                '" . mysql_real_escape_string($_POST['addreceived']) . "',
                '" . mysql_real_escape_string($_POST['addaction']) . "',
                '" . mysql_real_escape_string($_POST['addfile']) . "',
                '" . mysql_real_escape_string($_POST['addcounselor']) . "'
                )";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        }


$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Converted to Client',
                    '$convertid',
                    '$clientname',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
       
    
    $convertdate = date("Y-m-d");
            $query = "INSERT INTO salesnotes(clientid, repairdate, received, action, filelocation, counselor)
                VALUES(
                '$convertid',
                '$convertdate',
                '" . mysql_real_escape_string($_POST['addreceived']) . "',
                'Became a Client',
                '" . mysql_real_escape_string($_POST['addfile']) . "',
                '" . $_SESSION['usfname'] . "'
                )";
        $result = mysql_query($query, $conn) or die("error at salesnotes" . mysql_error());
        
        
        
        
        
        $contact_id = $convertid;


if($_POST['affiliate_id'] != '')
{

$sql = "SELECT * FROM sales_affiliates WHERE id = '$affiliate_id'";
$result = mysql_query($sql, $conn);
$AFFIL_DATA=mysql_fetch_array($result, MYSQL_ASSOC);


$sql = "INSERT INTO commission_affiliate
	(id,contact_id,affiliate_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$affiliate_id\",
	\"$AFFIL_DATA[commission_rate]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"$user\")";
	
	$result = @mysql_query($sql,$conn);
}


/////////BROKER COMMS
if($tier_id != ''){


$sql = "SELECT * FROM dealers WHERE dealer_id = '$broker_id'";
$result = mysql_query($sql, $conn);
$BROKER_DATA=mysql_fetch_array($result, MYSQL_ASSOC);
$sql = "INSERT INTO commission_brokers
	(id,contact_id,broker_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,level,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$broker_id\",
	\"$BROKER_DATA[commission]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"1\",
	\"$user\")";
	$result = @mysql_query($sql,$conn);
	}


if($tier2aff != '' && $tier2aff != 0 ){

$sql = "SELECT tier2comm FROM dealers WHERE dealer_id = '$tier2aff'";
$result = mysql_query($sql, $conn);
$LEVEL2AFF_DATA=mysql_fetch_array($result, MYSQL_ASSOC);

	$sql = "INSERT INTO commission_brokers
	(id,contact_id,broker_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,level,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$tier2aff\",
	\"$LEVEL2AFF_DATA[tier2comm]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"2\",
	\"$user\")";
	$result = @mysql_query($sql,$conn);
}

if($tier3aff != '' && $tier3aff != 0){

$sql = "SELECT tier3comm FROM dealers WHERE dealer_id = '$tier3aff'";
$result = mysql_query($sql, $conn);
$LEVEL3AFF_DATA=mysql_fetch_array($result, MYSQL_ASSOC);

	$sql = "INSERT INTO commission_brokers
	(id,contact_id,broker_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,level,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$tier3aff\",
	\"$LEVEL3AFF_DATA[tier3comm]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"3\",
	\"$user\")";
	$result = @mysql_query($sql,$conn);
}

///////////END BROKER COMMS




///////SALES COMMISSIONS
if($_POST['sales_id'] != ''){

$sql = "SELECT * FROM sales_affiliates WHERE id = '$sales_id'";
$result = mysql_query($sql, $conn);
$SALES_DATA=mysql_fetch_array($result, MYSQL_ASSOC);


$sql = "INSERT INTO commission_sales
	(id,contact_id,rep_id,amount_paid,pay_date,check_date,ck_number,payment_status,payment_trans,method,notes,julian,tstamp,ip,user)
	               VALUES
	(\"\",
	\"$contact_id\",
	\"$sales_id\",
	\"$SALES_DATA[commission_rate]\",
	\"$julian\",
	\"$check_date\",
	\"$ck_number\",
	\"Paid\",
	\"verified\",
	\"$method\",
	\"$notes\",
	\"$julian\",
	\"$tstamp\",
	\"$ip\",
	\"$user\")";
	
	$result = @mysql_query($sql,$conn);
}







       $query = "SELECT id, name, subject, message, type, activated, description FROM systememails WHERE name='Client_Welcome'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailid           = $row[0];
              $emailname   = $row[1];
              $subject   = $row[2];
              $message   = $row[3];
              $type = $row[4];
              $activated = $row[5];              
              $description = $row[6];    
}

 if($activated =="Yes"){

    $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, comments, reseller_id, status, plan, DATE_FORMAT(dateresults, \"%m-%d-%Y\") as dateresults, singlecouple, showstatus, budgetday, avssnurl, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, altphone FROM clients WHERE id='$contact_id' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password = $row[12];
        $broker_id = $row[13];
	  $dealer_id = $row[14];
	  $affiliate_id = $row[15];
	  $comments = $row[16];
	  $reseller_id = $row[17];
	  $status = $row[18];
	  $plan = $row[19];
	  $dateresults = $row[20];
	  $singlecouple = $row[21];
	  $status = $row[22];	  
	  $budgetday = $row[23];	  	  
	  $avssnurl = $row[24];	  	  	  
  	  $logins = $row[25];	  	 
	  $lastlogin = $row[26];	  	   	  
	  $altphone = $row[27];	  	   	  
		  

    }

    include_once("companystrip.php");
    include_once("clientstrip.php");

$EMAIL_Message = "$message2";
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyemail";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS);  
}


// JOINT SECTION NOW

  $date_array = split("-", $spousebirthdate);
        $spousebirthdate = $date_array[2]."-".$date_array[0]."-".$date_array[1];

  $query = "INSERT INTO clients(name, address, city, state, zip, email, fax, phone, altphone, cellphone, cellcarrier, ssnum, birthdate, createdate, fonttype, username, password, country, broker_id, dealer_id, adminpayment, singlecouple, sendtohtdi, jointwith, resellercredit)
                VALUES(
                '" . mysql_real_escape_string($_POST['spousename']) . "', 
                '" . mysql_real_escape_string($_POST['saddress']) . "', 
                '" . mysql_real_escape_string($_POST['city']) . "', 
                '" . mysql_real_escape_string($_POST['state']) . "',
                '" . mysql_real_escape_string($_POST['szip']) . "',
                '" . mysql_real_escape_string($_POST['spouseemail']) . "',
                '" . mysql_real_escape_string($_POST['fax']) . "',
                '" . mysql_real_escape_string($_POST['phone']) . "',
                '" . mysql_real_escape_string($_POST['altphone']) . "',
                '" . mysql_real_escape_string($_POST['cellphone']) . "',
                '" . mysql_real_escape_string($_POST['cellcarrier']) . "',
				'" . mysql_real_escape_string($_POST['spousessn']) . "',
                '$spousebirthdate',
                '$createdate',
                '$fonttype',
                '" . mysql_real_escape_string($_POST['spouseusername']) . "',
                '" . mysql_real_escape_string($_POST['spousepassword']) . "', 
                '" . mysql_real_escape_string($_POST['country']) . "',
                '" . mysql_real_escape_string($_POST['broker_id']) . "',
                '" . mysql_real_escape_string($_POST['dealer_id']) . "',
                '" . mysql_real_escape_string($_POST['adminpayment']) . "',
                'Joint',
                '$sendtohtdi',
                '$convertid',
                '$resellercredit')";
        $result = mysql_query($query, $conn) or die("error at inserting spouse" . mysql_error());
$spouseclientid = mysql_insert_id($conn);

        $query = "INSERT INTO enrolment(clientid, dateenrol, welcomepacket, dateexpire) VALUES('$spouseclientid','$createdate','$createdate','$dateexpire')";
        $result = mysql_query($query, $conn) or die("error spouse enroll table" . mysql_error());

        $query = "INSERT INTO billing(clientid, bankname, bankrtg, bankact, aba, checknum) VALUES(
'$spouseclientid',
'" . mysql_real_escape_string($_POST['bankname']) . "',
'" . mysql_real_escape_string($_POST['bankrtg']) . "',
'" . mysql_real_escape_string($_POST['bankact']) . "',
'" . mysql_real_escape_string($_POST['bankaba']) . "',
'" . mysql_real_escape_string($_POST['checknum']) . "')";
        $result = mysql_query($query, $conn) or die("error at spouse billing" . mysql_error());

        
   $query = "UPDATE clients SET
                jointwith='$spouseclientid',
                singlecouple='Joint'
                WHERE id='$convertid'";
        $result = mysql_query($query, $conn) or die("error at joint tie" . mysql_error());     

header("Location: search.php?message=Client Successfully Created!");
        exit();

  
    }

    

        
        


 

    
    $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, comments, reseller_id, status, plan, DATE_FORMAT(dateresults, \"%m-%d-%Y\") as dateresults, singlecouple, showstatus, budgetday, avssnurl, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, altphone, dateresults, fonttype, jointwith, prospectclient FROM clients WHERE id = '$GET_id'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $usernameu = $row[11];
        $pwdu = $row[12];
        $broker_id = $row[13];
	  $dealer_id = $row[14];
	  $affiliate_id = $row[15];
	  $comments = $row[16];
	  $reseller_id = $row[17];
	  $status = $row[18];
	  $plan = $row[19];
	  $dateresults = $row[20];
	  $singlecouple = $row[21];
	  $showstatus = $row[22];	  
	  $budgetday = $row[23];	  	  
	  $avssnurl = $row[24];	  	  	  
  	  $logins = $row[25];	  	 
	  $lastlogin = $row[26];	  	   	  
	  $altphone = $row[27];	  	   	  
	  $dateresults2 = $row[28];	  
	  $fonttype = $row[29];	  	  
	  $jointwith = $row[30];	  	 	  
	  $prospectclient = $row[31];		  

    }
    
 
    
  
    $bgcolor = "FF9900";

if ($prospectclient == "Client"){
?>

<font color="red"><B>This record is not a Prospect and cannot be accessed through here. </font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 }
if ($prospectclient == "Prospect"){
     include('template.php');
    include('main.php');

echo "You've enrolled $numclients clients since $thismonth";
$sql = "SELECT id FROM sales_affiliates WHERE type='Sales' and id='" . $_SESSION['usid'] . "' ";
$result = mysql_query($sql, $conn);
$SALES_DATA2=mysql_fetch_array($result, MYSQL_ASSOC);

?>
                 <font color="red">  <B> <?php print($error); ?></B></font>
                     
  
         <script type="text/javascript">
function valid()
{
  return confirm("Click OK to convert this Prospect into a Client.  OR Cancel to exit.");
}
    </script>   


<form  action="" name="formname"   method="post" onSubmit="return valid();">
<input type="hidden" name="convertid" value="<?php print($GET_id); ?>">
<input type="hidden" name="clientname" value="<?php print($name); ?>">
<input type="hidden" name="enrol" value="1">


<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="75%">
<tr><td width="1"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Confirm <?php print($prospectclient); ?> Conversion of <?php print($name); ?></td>
<td width="1"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>






                  
<table align="center" width="75%" border="0" cellspacing="5" cellpadding="0" bgcolor="ffffff">
                <tr> 
                  <td colspan="100%"> <div align="left"><font color="ad0948" size="2">* 
                      required fields</font></div></td>
                </tr>

<tr> 
<td colspan="2">
<p align="center"><font color="#AD0948"><strong>Personal Information</strong></font>
</td>
</tr>

<tr> 
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Name</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  type="text" name="sname" size="25" maxlength="100" class="txtbox" value="<?php print($name); ?>" ><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr> 
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Address</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  type="text" name="saddress" size="25" maxlength="100" class="txtbox" value="<?php print($address); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr> 
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>City</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  type="text" name="city" size="25" maxlength="100" class="txtbox" value="<?php print($city); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr> 
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>State/Province</span></div></td>
<td width="50%"> <select class="txtbox"  name="state" class="selectbox">
                      <option value="<?php print($state); ?>" selected><?php print($state); ?></option>
                      <option value=NA>Not Applicable</option>
                      <option value="AL">Alabama</option>
                      <option value="AK">Alaska</option>
                      <option value="AZ">Arizona</option>
                      <option value="AR">Arkansas</option>
                      <option value="CA">California</option>
                      <option value="CO">Colorado</option>
                      <option value="CT">Connecticut</option>
                      <option value="DE">Delaware</option>
                      <option value="DC">Dist. of Columbia</option>
                      <option value="FL">Florida</option>
                      <option value="GA">Georgia</option>
                      <option value="HI">Hawaii</option>
                      <option value="ID">Idaho</option>
                      <option value="IL">Illinois</option>
                      <option value="IN">Indiana</option>
                      <option value="IA">Iowa</option>
                      <option value="KS">Kansas</option>
                      <option value="KY">Kentucky</option>
                      <option value="LA">Louisiana</option>
                      <option value="ME">Maine</option>
                      <option value="MD">Maryland</option>
                      <option value="MA">Massachusetts</option>
                      <option value="MI">Michigan</option>
                      <option value="MN">Minnesota</option>
                      <option value="MS">Mississippi</option>
                      <option value="MO">Missouri</option>
                      <option value="MT">Montana</option>
                      <option value="NE">Nebraska</option>
                      <option value="NV">Nevada</option>
                      <option value="NH">New Hampshire</option>
                      <option value="NJ">New Jersey</option>
                      <option value="NM">New Mexico</option>
                      <option value="NY">New York </option>
                      <option value="NC">North Carolina</option>
                      <option value="ND">North Dakota</option>
                      <option value="OH">Ohio</option>
                      <option value="OK">Oklahoma</option>
                      <option value="OR">Oregon</option>
                      <option value="PA">Pennsylvania</option>
                      <option value="RI">Rhode Island</option>
                      <option value="SC">South Carolina</option>
                      <option value="SD">South Dakota</option>
                      <option value="TN">Tennessee</option>
                      <option value="TX">Texas</option>
                      <option value="UT">Utah</option>
                      <option value="VT">Vermont</option>
                      <option value="VA">Virginia</option>
                      <option value="WA">Washington</option>
                      <option value="WV">West Virginia</option>
                      <option value="WI">Wisconsin</option>
                      <option value="WY">Wyoming</option>
                      <option value="NA">---------------</option>
                      <option value=AB>Alberta</option>
                      <option value=BC>British Columbia</option>
                      <option value=MB>Manitoba</option>
                      <option value=NB>New Brunswick</option>
                      <option value=NF>Newfoundland</option>
                      <option value=NT>Northwest Territories</option>
                      <option value=NS>Nova Scotia</option>
                      <option value=NU>Nunavut</option>
                      <option value=ON>Ontario</option>
                      <option value=PE>Prince Edward Island</option>
                      <option value=QC>Quebec</option>
                      <option value=SK>Saskatchewan</option>
                      <option value=YT>Yukon Territory</option>
                      <option value="NA">---------------</option>
                      <option value="PR">Puerto Rico</option>
                    </select>
                   </td>
                </tr>

<tr> 
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Zip/Postal Code</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  type="text" name="szip" size="7" maxlength="7" class="txtbox" value="<?php print($zip); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr> 
<td width="50%"> 
<div align="right"><span class="contact"> <font color="ad0948">*</font> Country</span></div>
</td>
<td width="50%"> 
<select class="txtbox"   name="country" class="selectbox">
<option  selected>United States</option>
<option>Canada</option>
<option value=NA></option>
<option>Afghanistan</option>
<option>Albania</option>
<option>Algeria</option>
<option>Andorra</option>
<option>Angola</option>
<option>Anguilla</option>
<option>Antigua</option>
<option>Argentina</option>
<option>Armenia</option>
<option>Aruba</option>
<option>Ascension</option>
<option>Australia</option>
<option>Austria</option>
<option>Azerbaijan</option>
<option>Azores</option>
<option>Bahamas</option>
<option>Bahrain</option>
<option>Bangladesh</option>
<option>Barbados</option>
<option>Barbuda</option>
<option>Belgium</option>
<option>Belize</option>
<option>Benin</option>
<option>Bermuda</option>
<option>Bhutan</option>
<option>Bolivia</option>
<option>Bosnia-Herzegovina</option>
<option>Botswana</option>
<option>Brazil</option>
<option>British Virgin Islands</option>
<option>Brunei</option>
<option>Bulgaria</option>
<option>Burkina</option>
<option>Burma (Myanmar)</option>
<option>Burundi</option>
<option>Byelarus</option>
<option>Caicos Islands</option>
<option>Cambodia</option>
<option>Cameroon</option>
<option>Cape Verde</option>
<option>Cayman Islands</option>
<option>Central African Republic</option>
<option>Chad</option>
<option>Chile</option>
<option>China</option>
<option>Colombia</option>
<option>Comoros</option>
<option>Congo</option>
<option>Costa Rica</option>
<option>Croatia</option>
<option>Cuba</option>
<option>Cyprus</option>
<option>Czech Republic</option>
<option>Denmark</option>
<option>Djibouti</option>
<option>Dominica</option>
<option>Dominican Republic</option>
<option>East Timor</option>
<option>Ecuador</option>
<option>Egypt</option>
<option>El Salvador</option>
<option>Equatorial Guinea</option>
<option>Eritrea</option>
<option>Estonia</option>
<option>Ethiopia</option>
<option>Falkland Islands</option>
<option>Faroe Island</option>
<option>Fiji</option>
<option>Finland</option>
<option>Fortuna Islands</option>
<option>France</option>
<option>French Guiana</option>
<option>French Polynesia</option>
<option>Gabon</option>
<option>Gambia</option>
<option>Republic of Georgia</option>
<option>Germany</option>
<option>Ghana</option>
<option>Gibraltar</option>
<option>Greece</option>
<option>Greenland</option>
<option>Grenada</option>
<option>Grenadines</option>
<option>Guadeloupe</option>
<option>Guam</option>
<option>Guatemala</option>
<option>Guinea</option>
<option>Guinea-Bissau</option>
<option>Guyana</option>
<option>Haiti</option>
<option>Holland</option>
<option>Honduras</option>
<option>Hong Kong</option>
<option>Hungary</option>
<option>Iceland</option>
<option>India</option>
<option>Indonesia</option>
<option>Iran</option>
<option>Iraq</option>
<option>Ireland</option>
<option>Israel</option>
<option>Italy</option>
<option>Ivory Coast</option>
<option>Jamaica</option>
<option>Japan</option>
<option>Jordan</option>
<option>Kampuchea</option>
<option>Kazakhstan</option>
<option>Kenya</option>
<option>Kiribati</option>
<option>Korea, North</option>
<option>Korea, South</option>
<option>Kuwait</option>
<option>Kyrgyztan</option>
<option>Laos</option>
<option>Latvia</option>
<option>Lebanon</option>
<option>Lesotho</option>
<option>Liberia</option>
<option>Libya</option>
<option>Liechtenstein</option>
<option>Lithuania</option>
<option>Luxembourg</option>
<option>Macedonia</option>
<option>Madagascar</option>
<option>Madeira Islands</option>
<option>Malawi</option>
<option>Malaysia</option>
<option>Maldives</option>
<option>Mali</option>
<option>Malta</option>
<option>Martinique</option>
<option>Mauritania</option>
<option>Mauritius</option>
<option>Mexico</option>
<option>Miquelon</option>
<option>Moldova</option>
<option>Monaco</option>
<option>Mongolia</option>
<option>Montenegro</option>
<option>Montserrat</option>
<option>Morocco</option>
<option>Mozambique</option>
<option>Namibia</option>
<option>Nauru</option>
<option>Nepal</option>
<option>Netherlands</option>
<option>Netherlands Antilles</option>
<option>Nevis</option>
<option>New Caledonia</option>
<option>New Zealand</option>
<option>Nicaragua</option>
<option>Niger</option>
<option>Nigeria</option>
<option>Norway</option>
<option>Oman</option>
<option>Pakistan</option>
<option>Panama</option>
<option>Papua New Guinea</option>
<option>Paraguay</option>
<option>Peru</option>
<option>Philippines</option>
<option>Pitcairn Island</option>
<option>Poland</option>
<option>Portugal</option>
<option>Principe</option>
<option>Qatar</option>
<option>Reunion</option>
<option>Romania</option>
<option>Russia</option>
<option>Rwanda</option>
<option>Saipan</option>
<option>San Marino</option>
<option>Sao Tome</option>
<option>Saudi Arabia</option>
<option>Senegal</option>
<option>Serbia</option>
<option>Seychelles</option>
<option>Sierra leone</option>
<option>Singapore</option>
<option>Slovak Republic</option>
<option>Slovenia</option>
<option>Solomon Islands</option>
<option>Somalia</option>
<option>South Africa</option>
<option>Spain</option>
<option>Sri Lanka</option>
<option>St. Christopher</option>
<option>St. Helena</option>
<option>St. Lucia</option>
<option>St. Pierre</option>
<option>St. Vincent</option>
<option>Sudan</option>
<option>Surinam</option>
<option>Swaziland</option>
<option>Sweden</option>
<option>Switzerland</option>
<option>Syria</option>
<option>Taiwan R.O.C.</option>
<option>Tajikistan</option>
<option>Tanzania</option>
<option>Temen</option>
<option>Thailand</option>
<option>Tobago</option>
<option>Togo</option>
<option>Tonga</option>
<option>Trinidad</option>
<option>Tristan Da Cunha</option>
<option>Tunisia</option>
<option>Turkey</option>
<option>Turkmenistan</option>
<option>Turks</option>
<option>Tuvalu</option>
<option>Uganda</option>
<option>United Kingdom</option>
<option>Ukraine</option>
<option>United Arab Emirates</option>
<option>Uruguay</option>
<option>Uzbekistan</option>
<option>Vanuatu</option>
<option>Vatican City</option>
<option>Venezuela</option>
<option>Vietnam</option>
<option>Wallis</option>
<option>Western Samoa</option>
<option>Yemen</option>
<option>Yugoslavia</option>
<option>Zaire</option>
<option>Zambia</option>
<option>Zimbabwe</option>
</select>
</td>
</tr>

<tr> 
<td width="50%" valign="middle"> <div align="right"><span class="contact"><font color="ad0948">*</font>Phone</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="phone" type="text" id="phone" size="15" maxlength="15" value="<?php print($phone); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr> 
<td width="50%" valign="middle"> <div align="right"><span class="contact">Alt Phone</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="altphone" type="text" id="altphone" size="15" maxlength="15" value="<?php print($altphone); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<!--  CELL PHONE START -->
 <tr> 
                  <td width="50%" valign="middle"> <div align="right"><span class="contact">Cell Phone</span></div></td>
                  <td width="50%" class='ss-round-inputs' > 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="cellphone" type="text" class="cellphone" id="cellphone" size="15" maxlength="15"><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>
				 <tr> 
                  <td width="50%" valign="middle"> <div align="right"><span class="contact">Carrier</span></div></td>
                  <td width="50%" class='ss-round-inputs' > 
<select name="cellcarrier" class="txtbox" >
<option value="Do Not SMS">Do Not SMS</option>
<option value="Alltel">Alltel</option>
<option value="Ameritech">Ameritech</option>
<option value="ATT Wireless">ATT Wireless</option>
<option value="Bellsouth">Bellsouth</option>
<option value="Boost">Boost</option>
<option value="CellularOne">CellularOne</option>
<option value="CellularOne MMS">CellularOne MMS</option>
<option value="Cingular">Cingular</option>
<option value="Edge Wireless">Edge Wireless</option>
<option value="Metro PCS">Metro PCS</option>
<option value="Nextel">Nextel</option>
<option value="O2">O2</option>
<option value="Orange">Orange</option>
<option value="Qwest">Qwest</option>
<option value="Rogers Wireless">Rogers Wireless</option>
<option value="Sprint PCS">Sprint PCS</option>
<option value="Teleflip">Teleflip</option>
<option value="Telus Mobility">Telus Mobility</option>
<option value="T-Mobile">T-Mobile</option>
<option value="US Cellular">US Cellular</option>
<option value="Verizon">Verizon</option>
<option value="Virgin Mobile">Virgin Mobile</option>
<option value="Do Not SMS">Do Not SMS</option>
</select>
				  </td>
                </tr>
<!-- CELL PHONE END -->


<tr> 
<td width="50%"> <div align="right"><span class="contact"> Fax</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="fax" type="text" class="txtbox" id="fax" size="15" maxlength="15" value="<?php print($fax); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr> 
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Email address</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  type="text" name="semail" size="25" maxlength="100" class="txtbox" value="<?php print($email); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr> 
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>SS#</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input name="ssnum" type="text" class="txtbox" id="ssnum" size="25" maxlength="100" value="<?php print($ssnum); ?>" ><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr> 
<td width="50%"> <div align="right"><span class="contact"> Date of Birth (mm-dd-yyyy)</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="birthdate" type="text" class="txtbox" id="birthdate" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr> 
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Username</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="susername" type="text" class="txtbox" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Password</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="spassword" type="text" class="txtbox" id="password" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
                  <td width="100%" colspan="2">&nbsp; 
                  </td>
                  </tr>

<tr>
<td width="100%" colspan="2"> 
                  <p align="center"><font color="#AD0948"><b>Spouse Information</b></font></td>
                  </tr>
<tr>
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Name</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="textbox"  type="text" name="spousename" size="25" maxlength="100" class="textbox" ><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Email address</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="textbox"  type="text" name="spouseemail" size="25" maxlength="100" class="textbox"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>SS#</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="textbox"  name="spousessn" type="text" class="textbox" id="ssnum" size="25" maxlength="100" ><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="50%"> <div align="right"><span class="contact"> Date of Birth (mm-dd-yyyy)</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="textbox"  name="spousebirthdate" type="text" class="textbox" id="birthdate" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Username</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="textbox"  name="spouseusername" type="text" class="textbox" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Password</span></div></td>
<td class='ss-round-inputs' width="50%"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="textbox"  name="spousepassword" type="text" class="textbox" id="password" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>


   <tr> 
                  <td colspan="100%">&nbsp;</td>
                </tr>











<script type="text/javascript" src="http://www.tcrosystems.net/lightbox.js"></script>
<link rel="stylesheet" type="text/css" href="http://www.tcrosystems.net/lightbox.css" />

<tr> 
<td colspan="2">
<p align="center"><font color="#AD0948"><strong>Banking Information</strong></font><BR>
<a rel="lightbox" href="http://www.tcrosystems.net/check.jpg">Click for a sample check</a>
</td>
</tr>
<tr> 
<td width="737"> <div align="right"><span class="contact"> Bank Name</span></div></td>
<td  class='ss-round-inputs' width="723"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="bankname" type="text" class="textbox" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
</tr>

<tr> 
<td width="737"> <div align="right"><span class="contact"> Routing#</span></div></td>
<td  class='ss-round-inputs' width="723"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="bankrtg" type="text" class="textbox" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
</tr>

<tr> 
<td width="737"> <div align="right"><span class="contact"> Account#</span></div></td>
<td  class='ss-round-inputs' width="723"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="bankact" type="text" class="textbox" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
</tr>

<tr> 
<td width="737"> <div align="right"><span class="contact"> ABA#</span></div></td>
<td  class='ss-round-inputs' width="723"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="bankaba" type="text" class="textbox" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
</tr>

<tr> 
<td width="737"> <div align="right"><span class="contact"> Check#</span></div></td>
<td  class='ss-round-inputs' width="723"><img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  name="checknum" type="text" class="textbox" size="25" maxlength="100"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
</tr>


<!---- CUSTOM HOT LINK SECTION --->
<tr> 
<td colspan="2">
<p align="center"><font color="#AD0948"><strong>Conversion Notes</strong></font>
</td>
</tr>


 <tr> 
 <td colspan="100%">
				  
				  
				  
				  
				  <table align="center" width="700" border="0" cellpadding="0" cellspacing="0" bordercolor="#000080" style="border-collapse: collapse" background="bluestripshort.gif">

<tr>
<td width="98" style="border-left-style: solid; border-left-width: 1">&nbsp;<font color="#FFFFFF"><b>Date</b></font></td>
<td class='ss-round-inputs' width="582" style="border-right-style: solid; border-right-width: 1">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input name="adddate" type="text" class="txtbox" size="40" value="<? print date("m-d-Y"); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="98" style="border-left-style: solid; border-left-width: 1"><font color="#FFFFFF"><b>&nbsp;Received</b></font></td>
<td class='ss-round-inputs' width="582" style="border-right-style: solid; border-right-width: 1">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input name="addreceived" type="text" class="txtbox" size="80"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
<input name="subject2" type="hidden" size="80">
</td>
</tr>

<tr>
<td width="98" style="border-left-style: solid; border-left-width: 1"><font color="#FFFFFF"><b>&nbsp;Action Taken</b></font></td>
<td class='ss-round-inputs' width="582" style="border-right-style: solid; border-right-width: 1">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input name="addaction" type="text" class="txtbox" size="80"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="98" style="border-left-style: solid; border-left-width: 1; border-bottom-style: solid; border-bottom-width: 1">&nbsp;<font color="#FFFFFF"><b>Sales Person</b></font></td>
<td class='ss-round-inputs' width="582" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input name="addcounselor" type="text" class="txtbox" size="80" value="<? print $_SESSION['usfname']; ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>


 <tr>
<td colspan="100%" style="border-style: solid; border-width: 1"><font color="#FFFFFF"><B>CUSTOM CANNED HOT LINKS</B>
<?php
if($_SESSION['usaccess']=="full")
{
?>
<a href="canned.php?type=hotlinks"><font color="#FFFFFF">(manage)</font></a>
<?php
}
?>

</font><BR>
 <?php
    $query = "SELECT id, cannedreceived, cannedaction, cannedsubject, cannedname FROM companyhotlinks where cannedsubject='LeadConversion' order by cannedname";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $cannedid= $row[0];
        $cannedreceived= $row[1];
        $cannedaction= $row[2];
        $cannedsubject= $row[3];
        $cannedname = $row[4];
  
?>
<SCRIPT LANGUAGE="javascript">
   function canned<?php print($cannedid);?>()
   {
document.formname.addreceived.value = '<?php print($cannedreceived);?>';
document.formname.addaction.value = '<?php print($cannedaction);?>';
}
</script>
<a href="javascript:canned<?php print($cannedid);?>()"><font color="#FFFFFF"><?php print($cannedname);?></font></a>
&nbsp;
 <?php
}
?>
</td>
</tr>
 
                             


 
                               
                            </table>
				  
				  
				  
				  
				  
</td>
                </tr>



              </table>
                            <br>
                            <input type="hidden" name="info" value="1">
                            <input type="hidden" name="affiliate_id" value="<?php print($affiliate_id); ?>">
                            <input type="hidden" name="broker_id" value="<?php print($broker_id); ?>">
<input type="hidden" name="sales_id" value="<?php print($SALES_DATA2[id]); ?>">

                            <p align="center">

                            <br>
                            <input type="hidden" name="updatecl" value="1">
                           

 
             
 <input type="submit" name="Update" value="Convert">
 
  
             

                            </p>

                        </form>

                     
</font>
                    
<?php
}}}
else
{
    header("Location: login.php");
    exit();
}

?>