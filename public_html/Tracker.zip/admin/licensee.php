<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";
$today = date("Y-m-d");
$ip=$_SERVER["REMOTE_ADDR"];


$nowday = date("d");
$nowmonthword = date("M");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
      include "700score_connection2.php"; 

include('template.php');

if ($note) {
$sql_note = "INSERT INTO settlement_notes

(id,contact_id,rep_id,note,user,ip,julian,tstamp)
               VALUES
(\"\",
\"$id\",
\"$rep_id\",
\"$note\",
\"$user\",
\"$ip\",
\"$julian\",
\"$tstamp\")";
$result_note = @mysql_query($sql_note,$conn2);
}



$sql = "UPDATE clients SET
dateresults = \"$today\"
WHERE id = \"$id\"";

$result = @mysql_query($sql,$conn);



if ($calhour !="") {
$webpage = $_SERVER["HTTP_REFERER"];
$webpage = "licensee.php?licid=$id";

 if (($calampm == "pm") && ($calhour < 12)){
$calhour += 12;
}
 if (($calampm == 'am') && ($calhour == 12)){
$calhour = 0;
}
$date = mktime ( 3, 0, 0, $calmonth, $calday, $calyear );
  $str_cal_date = date ( "Ymd", $date );
  $changefollowup = date ( "Y-m-d", $date );
  $str_cal_time = sprintf ( "%d%02d00", $calhour, $calminute );
  $modtime = date ( "Gis" );
$sqlcal1 = "INSERT INTO calendar (cal_contactid, cal_create_by, cal_date, cal_time, cal_mod_date, cal_mod_time, cal_name, cal_link, cal_description)
			VALUES(
	\"$id\",
	\"$username\",
	\"$str_cal_date\",
	\"$str_cal_time\",
	\"$julian\",
	\"$modtime\",
	\"Call $clientname $typeofreminder\",
	\"$webpage\",
	\"$note\")";
                $result = mysql_query($sqlcal1, $conn) or die("error:" . mysql_error());

}

if ($comments) {
$query = "UPDATE clients SET
                comments='$comments'
                WHERE id='$id'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

include('main.php');

$sql = "SELECT * FROM dealers WHERE dealer_id='" . $_SESSION['licid'] . "' and dedemail='" . $_SESSION['csotracker_id'] . "' ";
$result = mysql_query($sql, $conn2);
$line=mysql_fetch_array($result, MYSQL_ASSOC);
$number_results = mysql_num_rows($result);
$bgcolor = "FF9900";

$entered_year = substr("$line[createdate]", 0, 4);
$entered_month = substr("$line[createdate]", 5, 2);
$entered_day = substr("$line[createdate]", 8, 2);

if ($line[dedemail] == $_SESSION['csotracker_id']) {

?>

<style type="text/css">
table.bordered {border-left: 1px solid black;border-top: 1px solid black; }
table.bordered tr td, table.bordered tbody tr td {border-right: 1px solid black;border-bottom:1px solid black}
body, td {font-family:Verdana,Arial,sans-serif}
body {font-size:0.8em}
button, input[type="submit"] {font-weight:bold;border:1px solid black;cursor:hand;}
h1 {font-size:1.4em;border:1px solid black;text-align:center;padding:0;margin:0;}
.coloredbg, h1, th {background-color:lightgrey}
h2 {font-size:1.2em;text-align:center;padding:0;margin:0;}
.note {font-style:italic;}
.bl, .blr, .blt, .blb, .blrt, .blrb, .bltb, .blrtb {border-left: 1px solid black}
.br, .blr, .brt, .brb, .blrt, .blrb, .brtb, .blrtb {border-right: 1px solid black}
.bt, .blt, .brt, .btb, .blrt, .bltb, .brtb, .blrtb {border-top: 1px solid black}
.bb, .blb, .brb, .btb, .blrb, .bltb, .brtb, .blrtb {border-bottom: 1px solid black}
a.footnote {border-bottom: 1px dotted black; text-decoration: none}
tr.odd td{background-color:lightyellow}
tr.even td{background-color:lightgrey}
.graph1, .graph2 {background-color:lightyellow; border-left: 1px solid black;border-right: 1px solid black;border-top: 1px solid black; font-size:1px;border-bottom:1px solid black}
.graph1 {background-color:lightyellow}
.graph2 {background-color:darkgray}
</style>
<SCRIPT LANGUAGE="JavaScript" SRC="http://www.700score.com/CalendarPopup.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript">document.write(getCalendarStyles());</SCRIPT>
<SCRIPT LANGUAGE="JavaScript">
var cal = new CalendarPopup("testdiv1");
cal.setReturnFunction("setMultipleValues3"); 
function setMultipleValues3(y,m,d) { 
     document.forms[0].calyear.value=y; 
     document.forms[0].calmonth.selectedIndex=m; 
     document.forms[0].calday.selectedIndex=d; 
     }
     


function finalCheck(form) {
if(! document.Subscribe.note.value){
alert("You must enter a \"Note\"")
document.Subscribe.note.focus();return false}



	}

</SCRIPT>

                 <font color="red">  <B> <?php print($error); ?></B></font>
                  


   <center> 
   
   
<table cellpadding="0" cellspacing="0" class="blrtb" width="60%" style="border-collapse: collapse" bordercolor="#111111">
<tr><td colspan="5" class="bb">

<TABLE width="400" border="0" cellpadding="0" cellspacing="0">
<TR>
<td valign="top">
<table class="blrtb" width="400" border="0" cellpadding="0" cellspacing="0">
<form method="POST" action="" name="Subscribe" >
<input type="hidden" name="id" value="<? echo "$line[dealer_id]"; ?>">
<input type="hidden" name="addnote" value="yes">
<input type="hidden" name="user" value="<? print $_SESSION['usfname']; ?>">
<input type="hidden" name="username" value="<? print $_SESSION['usname']; ?>">

<TR><TD colspan="2" align="center"><h1><? echo "$line[dealership]"; ?></h1></TD></tr>

<tr class="odd"><td colspan="2" height="15" align="center">




<tr class="even"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Name</font>   </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><? echo "$line[firstname]"; ?> <? echo "$line[lastname]"; ?></font>
</td></tr>




<tr class="odd"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Create Date  </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><? echo "$entered_month/$entered_day/$entered_year"; ?></font>
</td></tr>

<tr class="even"><td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>> &nbsp; <font size="1">Domain</font>   </td><td width="<?php echo "$width_ctwo"; ?>">
&nbsp; <font size="1"><? echo "$line[trackersite]"; ?></font>
</td></tr>




<tr class="odd"><td width="100%" colspan="2" align="center">&nbsp; 
</td></tr>


<tr class="odd"><td width="100%" colspan="2" align="center"> 
<center>
<p>
<b><font size="1">NOTES</font></b><br>
<textarea name="note" rows="5" cols="45">
</textarea><br>
<font size="1">&nbsp;</font></p>
</center>
</td></tr>

<tr class="even"><td width="100%" colspan="2" align="center"> 
<center><font size="1"><b>SET FOLLOWUP</b><br>
			<select class="txtbox" name="calday">
<option value="<? echo "$nowday"; ?>" selected="selected"><? echo "$nowday"; ?></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22"">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<select class="txtbox" name="calmonth">
<option value="<? echo "$nowmonth"; ?>" selected="selected"><? echo "$nowmonthword"; ?></option>
<option value="1">Jan</option>
<option value="2">Feb</option>
<option value="3">Mar</option>
<option value="4">Apr</option>
<option value="5">May</option>
<option value="6">Jun</option>
<option value="7">Jul</option>
<option value="8">Aug</option>
<option value="9">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
<input maxlength="4" class="txtbox" type="text" name="calyear" size="4" value=<? echo "$nowyear"; ?> >

<A HREF="#" onClick="cal.showCalendar('anchor1'); return false;" NAME="anchor1" ID="anchor1">
<img border="0" src="http://www.700score.com/icon_light_green.gif" width="13" height="12"></A>




&nbsp;&nbsp;
			<input class="txtbox" type="text" name="calhour" size="2" value="" maxlength="2" />:<input class="txtbox" type="text" name="calminute" size="2" value="" maxlength="2" />
<label><input type="radio" name="calampm" value="am" checked="" />AM</label>
<label><input type="radio" name="calampm" value="pm"  />PM<br>
<input type="hidden" name="clientname" value="<? echo "$line[dealership]"; ?>">

</td></tr>
 
<tr class="odd"><td colspan="2" height="10"></td></tr>

<tr class="odd"><td align="center" colspan="2" width="100%">
<center><input type="submit" name="submit" value="Update">
<? if ($line[category] == "Prospect") { ?>
<input type="submit" name="delete" value="Delete"> 
<? } ?>
</td></tr>

<tr class="odd"><td colspan="2" height="15"></td></tr>



</table>
</form>
<DIV ID="testdiv1" STYLE="position:absolute;visibility:hidden;background-color:white;layer-background-color:white;"></DIV>
</TD><TD VALIGN="TOP">

</TD>

<TD>&nbsp;
</TD>






<td valign="top">
<table class="blrtb" width="500" border="0" cellpadding="0" cellspacing="0">
<?


echo "<center>";

$sql = "SELECT * FROM settlement_notes WHERE contact_id='" . $_SESSION['licid'] . "' ORDER BY julian, id";
$result = @mysql_query($sql,$conn2) or die("Couldn't execute");

$num_results = mysql_num_rows($result);

if (! $num_results || $num_results == "0") {
echo "<font color=red><b>$accesscomment</font></b><BR>";
echo "<b><font face=\"Verdana\" size=\"2\" color=\"#FF0000\">No notes added.</font></b>";
}else{

  $change_color = "1";
echo "<TABLE width=\"500\" BORDER=\"0\" bordercolor=\"#000000\" class=\"blrtb\" cellpadding=\"0\" cellspacing=\"0\">";
echo  "<TR>";
echo  "<TD colspan=\"3\" align=center><h1>Notes</h1></TD>";
echo  "</TR>";


  while ($row = mysql_fetch_array($result)) {	
    $NOTE_id = $row['id'];
    $NOTE_view = $row['note'];
    $NOTE_user = $row['user'];
    $NOTE_julian = $row['julian'];
    $NOTE_tstamp = $row['tstamp'];

$NOTE_year = substr("$NOTE_julian", 0, 4);
$NOTE_month = substr("$NOTE_julian", 4, 2);
$NOTE_day = substr("$NOTE_julian", 6, 2);

if ($change_color == "2") {
$bgcolor = "class=\"even\"";
$change_color = "1";
}else{
$bgcolor = "class=\"odd\"";
$change_color = "2";
}

echo "<TR $bgcolor>";
echo "<TD align=\"center\"><font size=\"1\">$NOTE_month/$NOTE_day/$NOTE_year at $NOTE_tstamp </font></TD>";
echo "<TD align=\"center\"><font face=\"Verdana\" ><font size=\"1\">$NOTE_view</font></TD>";
echo "<TD align=\"center\"><font face=\"Verdana\" ><font size=\"1\">$NOTE_user</font></TD>";
echo "</TR>";


} // end while loop //

} // end if results //
echo "</TABLE></div><p>";
?>
    </tr>

  </table>

<center><font size="1"><a href=licensee.php?f=1&Find=Find&showexpcanx=Yes>show all clients</a></center>
             



           </td></tr>
<tr class="coloredbg"><td class="bb">&nbsp;<font size="2">Date</font>&nbsp;</td><td class="bb">
  <font size="2">Name</font></td><td class="bb" align=\"left\"><font size="2">Client's Current Status&nbsp;</font></td><td class="bb" align=\"left\>&nbsp;<font size="2">Status</font>&nbsp;</td></tr>
     

<?
if ($showexpcanx == "Yes") {
$isfull = "";
}else{
$isfull = " AND status !='expired' AND status !='canceled' AND status !='inactive'";
}
$trackerconn  = @mysql_connect("$line[dbip]", "$line[dbuser]", "$line[dbpass]");
  @mysql_select_db("$line[dbname]", $trackerconn) or die ("error: No Database Setup" . mysql_error());
  $query = "SELECT id, name, status, createdate, showstatus FROM clients WHERE  prospectclient='Client' AND clientdelete != 'yes' $isfull order by createdate";
  $result = @mysql_query($query, $trackerconn) or die("error: No Database Setup" . mysql_error());
  while($row=mysql_fetch_row($result))
          {
              $clientid           = $row[0];
              $clientname   = $row[1];
              $status       = $row[2];
              $createdate  = $row[3];
              $showstatus  = $row[4];
              $cnt++;
			
			

			if ($status == "pending"){
	        $bgcolor = "FFFF00"; 
	        
  }else if ($status == "canceled"){
	        $bgcolor = "663300";
	}else if ($status == "NSF"){
	        $bgcolor = "FF00FF";
	}else if ($status == "contact1"){
	        $bgcolor = "FF4444";
	}else if ($status == "contact2"){
	        $bgcolor = "FF0000";
	}else if ($status == "contact3"){
	        $bgcolor = "888888";
	}else if ($status == "expired"){
	        $bgcolor = "888888";
	}else if ($status == "inactive"){
	        $bgcolor = "888888";
	}else if ($status == "complete"){
	        $bgcolor = "008000";
	}else if ($status == "scheduled"){
	        $bgcolor = "FFCCCC";
	}else if ($status == "Debtor"){
	        $bgcolor = "003399";
	}else if ($plan == "Budget"){
	        $bgcolor = "c0c0c0";
	}else{
$bgcolor = "FFFFFF";

}
?>
  


<tr>
<td bgcolor=<?php print($bgcolor); ?> align="left"><nobr><font size="1"><?php print($createdate); ?></font></td>
<td bgcolor=<?php print($bgcolor); ?> align="left"><font size="1"><a href="licenseeclient.php?licclientid=<?php print($clientid); ?>"><?php print($clientname); ?></a></font></td>
<td bgcolor=<?php print($bgcolor); ?> align="left"><font size="1"><?php print($showstatus); ?></font></td>
<td bgcolor=<?php print($bgcolor); ?> align="left"><font size="1"><?php print($status); ?></font></td></tr>
<?
} 
?>

 </form>
</table></center>

 <TD HEIGHT=24 width="500" colspan="2">
          <p align="center"><b>Payment History</TD>
        </TR>
        <TR>
          <TD WIDTH=500 HEIGHT=24 colspan="2">
          </b>
          <div align="center">
            <center>
          <table border="1" cellspacing="1" width="40%" id="AutoNumber1" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
            <tr>
              <td width="25%"><b><font size="1">Date</font></b></td>
              <td width="10%"><b><font size="1">Credits</font></b></td>
              <td width="49%"><b><font size="1">Details</font></b></td>
            </tr>
            <?php
            	
            	
    $query = "SELECT DATE_FORMAT(purchasedate, \"%m-%d-%Y\") as purchasedate2, amountpurchased, id, dealer_id, details FROM bulktracking WHERE dealer_id='" . $_SESSION['licid'] . "' ORDER BY purchasedate DESC";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $purchasedate = $row[0];
        $amountpurchased = $row[1];
        $purchaseid = $row[2];
        $dealer_id = $row[3];
        $details = $row[4];        
        
?>
             

            <tr>
            

              <td width="25%"><font size="1"><?php print($purchasedate); ?></font>&nbsp;</td>
              <td width="10%"><font size="1"><?php print($amountpurchased/100); ?></font>&nbsp;</td>
              <td width="49%"><font size="1"><?php print($details); ?>&nbsp;</font></td>

            </tr>
        <?php
       }
       
       
       $query = "SELECT SUM(amountpurchased) as amountpurchased FROM bulktracking WHERE dealer_id='" . $_SESSION['licid'] . "'";
$result = @mysql_query($query,$conn2);
while ($row = mysql_fetch_array($result)) {	
$totalamountpurchased = $row['amountpurchased'];
}


    
$query2 = "SELECT SUM(resellercredit) as resellercredit FROM clients";
$result2 = @mysql_query($query2,$trackerconn);
while ($row2 = mysql_fetch_array($result2)) {	
$totalresellercredit = $row2['resellercredit'];

}



       mysql_close($conn2);
?>              
   

          </table>
            </center>
</div>
          </TD>
           

                        
                        
                        <p align="center">
                        <font size="4" color="#008000"><?php print($totalamountpurchased - $totalresellercredit)/100 ;?> credits available
                        </font></p>
                         </font>
                         </font>




         
     </font>
                      
     <?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>