<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    
 include("connection.php");


///////STRIKING CALENDAR CHECK
if($strike  != ""){
$calendaruser =$_SESSION['usname'];
$gotopage = $_SERVER["HTTP_REFERER"];
$strikesql = "UPDATE calendar SET cal_mod_time = 0 where cal_id = '$strike' and cal_create_by ='$calendaruser' ";
$result = mysql_query($strikesql, $conn) or die("error:" . mysql_error());
header("Location: $gotopage");
}
///////////END STRIKING CALENDAR

if($_SESSION['usname']!="admin" && $_SESSION['usname']!="SPOC"){
$page="appts";
}

include('template.php');
include('main.php');
include "700score_connection2.php"; 
            	
$query = "SELECT dealer_id  FROM dealers WHERE dbname='$dbname' limit 1";
$result = mysql_query($query, $conn2);
$col_count = mysql_num_fields($result);
while($row=mysql_fetch_row($result))
{
$company_id = $row[0];
}

$query = "SELECT helpdeskaccess, contract FROM dealers WHERE dealer_id='$company_id'";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $helpdeskaccess = $row[0];
        $contract = $row[1];
        }

if($contract != "licensee"){
/////////////// REGULAR ACCOUNTS
?>
<script type="text/javascript">
function toggleMe(a){
var e=document.getElementById(a);
if(!e)return true;
if(e.style.display=="none"){
e.style.display="block"
}
else{
e.style.display="none"
}
return true;
}
</script>

  

  </tr>
</table>
<div id="para1" style="display:none">
<table border="0" cellpadding="2" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1" bgcolor="#FFFFFF" height="172">
  <tr>
    <td width="70" style="border-left-style: solid; border-left-width: 1; border-top-style: solid; border-top-width: 1" height="20" >Step 1</td>
    <td width="1171" colspan="2" style="border-right-style: solid; border-right-width: 1; border-top-style: solid; border-top-width: 1" height="20" >Download I.E. toolbar <a href="CreditRepair.exe">here</a></td>
  </tr>
  <tr>
    <td width="70" style="border-left-style: solid; border-left-width: 1" height="19" >
    Step 2</td>
    <td width="1171" colspan="2" height="19" style="border-right-style: solid; border-right-width: 1" >
    After install, open a new browser and the new toolbar will appear</td>
  </tr>
  <tr>
    <td width="70" style="border-left-style: solid; border-left-width: 1" height="19" >
    Step 3</td>
    <td width="1171" colspan="2" height="19" style="border-right-style: solid; border-right-width: 1" >
    Click Options and place the following inside:</td>
  </tr>
  <tr>
    <td width="70" style="border-left-style: solid; border-left-width: 1" height="19" >&nbsp;
    </td>
    <td width="77" height="19" >&nbsp;
    </td>
    <td width="1094" height="19" style="border-right-style: solid; border-right-width: 1" >&nbsp;
    </td>
  </tr>
  <tr>
    <td width="70" style="border-left-style: solid; border-left-width: 1" height="19" >&nbsp;
    </td>
    <td width="77" height="19" >
    URL</td>
    <td width="1094" height="19" style="border-right-style: solid; border-right-width: 1" >
    <?php print($companywebsite);?>/toolbar</td>
  </tr>
  <tr>
    <td width="70" style="border-left-style: solid; border-left-width: 1" height="19" >&nbsp;
    </td>
    <td width="77" height="19" >
    Login</td>
    <td width="1094" height="19" style="border-right-style: solid; border-right-width: 1" >
    Your username to this system</td>
  </tr>
  <tr>
    <td width="70" style="border-left-style: solid; border-left-width: 1" height="19" >&nbsp;
    </td>
    <td width="77" height="19" >
    Password</td>
    <td width="1094" height="19" style="border-right-style: solid; border-right-width: 1" >
    Your password to this system</td>
  </tr>
  <tr>
    <td width="70" style="border-left-style: solid; border-left-width: 1" height="19" >&nbsp;
    </td>
    <td width="77" height="19" >&nbsp;
    </td>
    <td width="1094" height="19" style="border-right-style: solid; border-right-width: 1" >&nbsp;
    </td>
  </tr>
  <tr>
    <td width="1241" colspan="3" height="19" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1" >
    If done correctly, you will now be able to easily access your clients, leads (including new leads), helpdesk tickets, etc.  Most of your menu is on the toolbar and will be available all the time!  </td>
  </tr>
</table></div>
    
<?php
}
/////////////APPOINTMENTS PAGE
if($page=="appts"){

if($calmonth2 != "")
{
$date2 = mktime ( 3, 0, 0, $calmonth2, $calday2, $calyear2);
  $calsearch2 = date ( "Ymd", $date2 );
    $calsearchword2 = date ( "Ymd", $date2 );

}else{
$calsearch2 = $julian;
$calsearchword2 = "today";
}

if($allusers=="Yes" && $_SESSION['usname']=="admin"){
$calendarsearching = "  ";
}else{
$calendarsearching = "and cal_create_by='$calendaruser' ";
}

?>

<table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="100%">
<tr>
<td width="50%" valign="top"  align="left">



<SCRIPT LANGUAGE="JavaScript" SRC="CalendarPopup.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript">document.write(getCalendarStyles());</SCRIPT>
<SCRIPT LANGUAGE="JavaScript">
var cal = new CalendarPopup("testdiv1");
cal.setReturnFunction("setMultipleValues3"); 
function setMultipleValues3(y,m,d) { 
     document.forms[0].calyear2.value=y; 
     document.forms[0].calmonth2.selectedIndex=m; 
     document.forms[0].calday2.selectedIndex=d; 
     }
     

function toggleMe(a){
var e=document.getElementById(a);
if(!e)return true;
if(e.style.display=="none"){
e.style.display="block"
}
else{
e.style.display="none"
}
return true;
}
</SCRIPT>    
<?php
if($_SESSION['usname']=="admin"){
echo "<a href=\"menu.php?page=appts&allusers=Yes\">Click for All Users</a>";
}
?>

<form action="" method="post">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="600">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Your calendar appointments for <? echo "$calsearchword2"; ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="600">
<tr>
<td width="600" align="center"> <pre style="
margin: 0px;
border: 1px inset;
width: 598px;
height: 100px;
text-align: left;
link: #FFFFFF;
overflow: auto">  
<?php

		$calsql2 = "SELECT * FROM calendar where cal_date='$calsearch2'  $calendarsearching ORDER BY cal_time";
		$calresult2 = @mysql_query($calsql2,$conn) or die("Couldn't execute");
		$number_appts = @mysql_num_rows($calresult2);
  while ($calrow2 = mysql_fetch_array($calresult2)) {	
		    $cal_id2 = $calrow2['cal_id'];
		    $cal_contactid2 = $calrow2['cal_contactid'];
		    $cal_create_by2 = $calrow2['cal_create_by'];
		    $cal_link2 = $calrow2['cal_link'];
		    $cal_name2 = $calrow2['cal_name'];
		    $cal_date2 = $calrow2['cal_date'];
		    $cal_time2 = $calrow2['cal_time'];
		    $active2 = $calrow2['cal_mod_time'];
		    
$cal_year2 = substr("$cal_date2", 0, 4);
$cal_month2 = substr("$cal_date2", 4, 2);
$cal_day2 = substr("$cal_date2", 6, 2);
$cal_time2 = substr("$cal_time2", 0, -2);
if (strlen($cal_time2) == 3){
$cal_time2 = "0$cal_time2";
}

		    
$caldateformat2 = $cal_year2/$cal_month2/$cal_day2;		    
//$cal_link2 = "prospectstatus.php?id=$cal_contactid2";
$strike_link2 = "menu.php?strike=$cal_id2";
$outlook_link = "outlook.php?page=outlook&cal_id=$cal_id2";

if ($active2 != 0){
echo "</center><font color=\"#FFFFFF\">$cal_month2/$cal_day2/$cal_year2 at $cal_time2 :: <a \"text-decoration: none;\" href=$cal_link2><strong><font color=\"#FFFFFF\">$cal_name2</font></strong></a>  <a \"text-decoration: none;\" href=$strike_link2><strong><font color=\"#FFFFFF\">STRIKE</font></strong></a>  <a \"text-decoration: none;\" href=$outlook_link><strong><font color=\"#00FF7F\">Add to Outlook</font></strong></a><br>";		    
}else{
echo "</center><font color=\"#FFFFFF\"><strike>$cal_month2/$cal_day2/$cal_year2 at $cal_time2 :: <a \"text-decoration: none;\" href=$cal_link2><strong><font color=\"#FFFFFF\">$cal_name2</font></strong></a></strike><br>";		    
}
	
		  }

?> </pre>
		   </td>
            </tr>
           
             <tr>
                <td width="600"> <input type="hidden" name="search" value="on">
                <p align="center">
                <select class="txtbox" name="calday2">
<option value="<? echo "$nowday"; ?>" selected="selected"><? echo "$nowday"; ?></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22"">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<select class="txtbox" name="calmonth2">
<option value="<? echo "$nowmonth"; ?>" selected="selected"><? echo "$nowmonthword"; ?></option>
<option value="1">Jan</option>
<option value="2">Feb</option>
<option value="3">Mar</option>
<option value="4">Apr</option>
<option value="5">May</option>
<option value="6">Jun</option>
<option value="7">Jul</option>
<option value="8">Aug</option>
<option value="9">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
<input maxlength="4" class="txtbox" type="text" name="calyear2" size="4" value=<? echo "$nowyear"; ?> >

<A HREF="#" onClick="cal.showCalendar('anchor1'); return false;" NAME="anchor1" ID="anchor1">
<img border="0" src="calendar.gif"></A>

        <input type="submit" name="search" value="search"></td>
            </tr>
            </table>
       
    </form>
    <DIV ID="testdiv1" STYLE="position:absolute;visibility:hidden;background-color:white;layer-background-color:white;"></DIV>
  
<BR>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="600">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">All UNSTRUCK calendar appointments</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="600">
<tr>
<td width="600" align="center"> <pre style="
margin: 0px;
border: 1px inset;
width: 598px;
height: 300px;
text-align: left;
link: #FFFFFF;
overflow: auto">  
<?php

$calsql2 = "SELECT * FROM calendar where cal_mod_time!=0  $calendarsearching  ORDER BY cal_date";
$calresult2 = @mysql_query($calsql2,$conn) or die("Couldn't execute");
$number_appts = @mysql_num_rows($calresult2);
while ($calrow2 = mysql_fetch_array($calresult2)) {	
$cal_id2 = $calrow2['cal_id'];
$cal_contactid2 = $calrow2['cal_contactid'];
$cal_create_by2 = $calrow2['cal_create_by'];
$cal_link2 = $calrow2['cal_link'];
$cal_name2 = $calrow2['cal_name'];
$cal_date2 = $calrow2['cal_date'];
$cal_time2 = $calrow2['cal_time'];
$active2 = $calrow2['cal_mod_time'];
		    
$cal_year2 = substr("$cal_date2", 0, 4);
$cal_month2 = substr("$cal_date2", 4, 2);
$cal_day2 = substr("$cal_date2", 6, 2);
$cal_time2 = substr("$cal_time2", 0, -2);
if (strlen($cal_time2) == 3){
$cal_time2 = "0$cal_time2";
}

		    
$caldateformat2 = $cal_year2/$cal_month2/$cal_day2;		    
//$cal_link2 = "prospectstatus.php?id=$cal_contactid2";
$strike_link2 = "menu.php?strike=$cal_id2";
$outlook_link = "outlook.php?page=outlook&cal_id=$cal_id2";

if ($active2 != 0){
echo "</center><font color=\"#FFFFFF\">$cal_month2/$cal_day2/$cal_year2 at $cal_time2 :: <a \"text-decoration: none;\" href=$cal_link2><strong><font color=\"#FFFFFF\">$cal_name2</font></strong></a>  <a \"text-decoration: none;\" href=$strike_link2><strong><font color=\"#FFFFFF\">STRIKE</font></strong></a>  <a \"text-decoration: none;\" href=$outlook_link><strong><font color=\"#00FF7F\">Add to Outlook</font></strong></a><br><br>";		    
}else{
echo "</center><font color=\"#FFFFFF\"><strike>$cal_month2/$cal_day2/$cal_year2 at $cal_time2 :: <a \"text-decoration: none;\" href=$cal_link2><strong><font color=\"#FFFFFF\">$cal_name2</font></strong></a></strike><br>";		    
}
	
		  }

?> </pre>
</td>
</tr>
</table>


</td>
<td width="50%" valign="top">
<?php

  $query = "SELECT id FROM sales_affiliates WHERE id='" . mysql_real_escape_string($_SESSION['usid']) . "' and type='Sales'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $affiliate_id = $row[0];
    }

if($affiliate_id !="" && $type!="Affiliate"){
$salesrecord = "yes";

$LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_sales WHERE rep_id = '$affiliate_id' GROUP BY rep_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];
}}
if($allcomms =="Yes"){
$titlecomm = "All Earned Commissions";
$titlemess = "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"menu.php\"><font size=1>Click to collapse</font></a>";
$commsearch = "";
}else{
$titlecomm = "Last Five Commissions Earned";
$titlemess = "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"menu.php?allcomms=Yes\"><font size=1>Click to see all</font></a>";

$commsearch = "LIMIT 5";
}
?>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="600">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%"><?php print($titlecomm); ?><?php print($titlemess); ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="600">
<tr>
<td width="600" align="center">
<table id="rounded-corner" width="100%">
<tr >
<th class="rounded-company">Earn Date</th>
<th class="rounded-company">Name</th>
<th class="rounded-company">Amount</th>

<?php
$query = "SELECT DATE_FORMAT(clients.createdate, \"%m-%d-%Y\") as createdate, clients.name, commission_sales.amount_paid, commission_sales.id FROM clients,commission_sales WHERE clients.prospectclient = 'Client' AND clients.dealer_id='$affiliate_id' AND clients.id = commission_sales.contact_id ORDER BY clients.createdate DESC $commsearch";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result)){

$createdate= $row[0];
$name = $row[1];
$amount_paid = $row[2];
$commission_id= $row[3];
$bgcolor = "#e8edff";

	?>	    
<tr bgcolor=<?php print($bgcolor); ?> onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
<td width="12%"><?php print($createdate); ?></td>
<td width="25%"><?php print($name); ?></td>
<td width="15%">$<?php print($amount_paid); ?></td>
</tr>		    
<?php } ?>

<tr bgcolor=<?php print($bgcolor); ?>>
<td width="12%">&nbsp;</td>
<td width="25%">&nbsp;</td>
<td width="15%"><b>Total - <font color="#008000">$<?php print($COM_total_comish); ?></font></b></td>
</table>


</td>
</tr>
</table><BR><BR>
<?php
if($allpaid =="Yes"){
$titlepaid = "All Paychecks";
$titlepmess = "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"menu.php\"><font size=1>Click to collapse</font></a>";
$paidsearch = "";
}else{
$titlepaid = "Last Five Paychecks";
$titlepmess = "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"menu.php?allpaid=Yes\"><font size=1>Click to see all</font></a>";

$paidsearch = "LIMIT 5";
}
?>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="600">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%"><?php print($titlepaid); ?><?php print($titlepmess); ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="600">
<tr>
<td width="600" align="center">
<table id="rounded-corner" width="100%">
<tr >
<th class="rounded-company">Pay Date</th>
<th class="rounded-company">Check #</th>
<th class="rounded-company">Notes</th>
<th class="rounded-company">Pay Amount</th>

<?php
$query = "SELECT payment_date, ck_number, notes, payment_amount, id FROM commission_sales WHERE rep_id='$affiliate_id' and payment_amount != '' ORDER BY payment_date DESC $paidsearch";

$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$col_count = mysql_num_fields($result);
while($row=mysql_fetch_row($result))
{
$check_date= $row[0];
$check_num = $row[1];
$notes = $row[2];
$amount_paid = $row[3];
$commission_id= $row[4];

$bgcolor = "#e8edff";

	?>	    
<tr bgcolor=<?php print($bgcolor); ?> onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
<td width="15%"><?php print($check_date); ?></td>
<td width="11%"><?php print($check_num); ?></td>
<td width="59%"><?php print($notes); ?></td>
<td width="15%">$<?php print($amount_paid); ?></td>
</tr>		    
<?php } 
	
	
       $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_sales WHERE rep_id='$affiliate_id' GROUP BY rep_id";
	$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}
	
	
	?>

<tr bgcolor=<?php print($bgcolor); ?>>
<td >&nbsp;</td>
<td >&nbsp;</td>
<td >&nbsp;</td>
<td ><b>Total - <font color="#008000">$<?php print($COM_total_pd); ?></font></b></td>

</table>


</td>
</tr>
</table>









</td>
</tr>
</table>

<?php
////////////END APPOINTMENTS SCREEN
}else{
if($_SESSION['usname']=="admin" or $_SESSION['usname']=="SPOC")
{
?>

  </tr>
      <div align="center">
      <center>

    <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="25%" id="AutoNumber1">

   <?php

if($reseller =="Yes")
{

$query = "SELECT SUM(amountpurchased) as amountpurchased FROM bulktracking WHERE dealer_id='$company_id'";
$result = @mysql_query($query,$conn2);
while ($row = mysql_fetch_array($result)) {	
$totalamountpurchased = $row['amountpurchased'];
}

$query2 = "SELECT SUM(resellercredit) as resellercredit FROM clients";
$result2 = @mysql_query($query2,$conn);
while ($row2 = mysql_fetch_array($result2)) {	
$totalresellercredit = $row2['resellercredit'];
}

$renewtoday=date("Y-m-d");
$expirewithin15 = date("Y-m-d", time()+15*24*3600);
$expirewithin30 = date("Y-m-d", time()+30*24*3600);
$expire30 = date("Y-m-d", time()-30*24*3600);

$query3 = "Select COUNT(enrolment.id) FROM clients,enrolment where clients.id=enrolment.clientid AND clients.status !='canceled' AND clients.reseller_id = 0 AND clients.prospectclient = 'Client'  AND clients.clientdelete != 'yes' and enrolment.dateexpire >= '$renewtoday' and enrolment.dateexpire <= '$expirewithin15'";
$result3 = @mysql_query($query3,$conn);
while ($row3 = mysql_fetch_array($result3)) 
{	
$totalexpirewithin15 = $row3[0];
}
$query3 = "Select COUNT(enrolment.id) FROM clients,enrolment where clients.id=enrolment.clientid AND clients.status !='canceled' AND clients.reseller_id = 0 AND clients.prospectclient = 'Client'  AND clients.clientdelete != 'yes' and enrolment.dateexpire >= '$renewtoday' and enrolment.dateexpire <= '$expirewithin30'";
$result3 = @mysql_query($query3,$conn);
while ($row3 = mysql_fetch_array($result3)) 
{	
$totalexpirewithin30 = $row3[0];
}
$query3 = "Select COUNT(enrolment.id) FROM clients,enrolment where clients.id=enrolment.clientid AND clients.status !='canceled' AND clients.reseller_id = 0 AND clients.prospectclient = 'Client'  AND clients.clientdelete != 'yes' and enrolment.dateexpire < '$renewtoday' and enrolment.dateexpire >= '$expire30'";
$result3 = @mysql_query($query3,$conn);
while ($row3 = mysql_fetch_array($result3)) 
{	
$totalexpire30 = $row3[0];
}


?>

    
    <?php

if($totalexpirewithin30 !="0")
{
  ?>


      <tr>
        <td width="70%" bgcolor="#f1f1f1"><b>Clients Expiring within 30 days</b></td>
        <td width="30%" bgcolor="#f1f1f1" align="center"><a href="search.php?expirecheck=30&f=1&Find=Find"><?php print($totalexpirewithin30);?></A>&nbsp;</td>
      </tr>
       <?php
}
if($totalexpirewithin15!="0")
{
  ?>

        <tr>
        <td width="70%" bgcolor="#FF9900"><b>Clients Expiring within 15 days</b></td>
        <td width="30%" bgcolor="#FF9900" align="center"><a href="search.php?expirecheck=15&f=1&Find=Find"><?php print($totalexpirewithin15);?></A>&nbsp;</td>
      </tr>
      <?php
}
if($totalexpire30!="0")
{
  ?>

        <tr>
        <td width="70%" bgcolor="#FF0000"><b>Clients Expired NLT 30 days ago</b></td>
        <td width="30%" bgcolor="#FF0000" align="center"><a href="search.php?expirecheck=-30&f=1&Find=Find"><?php print($totalexpire30);?></a>&nbsp;</td>
      </tr>
 <?php
}
  ?>




</table>

      </center>
</div>

    <p align="center"><b>Accounting</b>
    <BR>Your account has <?php print($totalamountpurchased - $totalresellercredit) / 100;?> available credits
    <BR><a href="clientaccounting.php">List Clients</a> ::
  <a href="depositaccounting.php">List Deposits</a></p>
   <?php
}
?>


</table>

   <?php

if($helpdeskaccess=="Yes" && $contract !="licensee")
{
?>
<link rel="stylesheet" type="text/css" href="../sbox/shadowbox.css"><script type="text/javascript" src="../sbox/shadowbox.js"></script><script type="text/javascript">Shadowbox.init();</script>
<p align="center">
<!--<a target="_blank" href="http://www.creditmasteryconference.com"><img border="0" src="http://www.creditrepairtracking.com/conferencebannerleft.png"></a><a target="_blank" href="http://www.youtube.com/v/xk5G2gbDxhs&#038;hl=en_US&#038;fs=1&#038;rel=0&#038;autoplay=1&#038;hd=1" rel="shadowbox;width=840;height=500"><img border="0" src="http://www.creditrepairtracking.com/conferencebannerright.png"></a>
-->
          <div align="center">
            <center><BR>
            </h2>
  <table width="80%" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
    <tr> 
      <td height="22"> 
      <?php
if($added=="yes"){
echo "<p align=center><font color=#008000 size=3><b>Ticket Logged!</b></font>";
}
if($emailadded=="yes"){
  echo "<p align=center><font color=#008000 size=3><b>Email ".$emailaccount." Created!</b></font>";
}
      if(!empty($errorpassword)){
          echo "<p align=center><font color=#008000 size=3><b>Password Error. Please try again.</b></font>";
      }
    ?>

</td>    </tr>
    <tr> 
      <td>
	  <script language="JavaScript" type="text/javascript">
function validate(formCheck)
{
 if (formCheck.emailfront.value =="")
    {
        alert("Please enter the user handle for this domain!"); 
        return false;
    }
 if (formCheck.emailpassword.value =="")
    {
        alert("Please enter a password you want associated with this email address!"); 
        return false;
    }


}
</script>
<?php
$domainextract=explode(".",$companywebsite); 
$maindomain="@$domainextract[1].$domainextract[2]";

if($_SESSION['isptcso']=="PTCSO"){
include "700score_connection2.php"; 

$query = "SELECT trackersite FROM dealers WHERE contract='licensee' and dedemail='" . $_SESSION['csotracker_id'] . "' ";
    $result = mysql_query($query, $conn2);
    while($row=mysql_fetch_row($result))
    {
        $trackersite = $row[0];
$trackerdomainextract=explode(".",$trackersite); 
$trackermaindomain="@$trackerdomainextract[1].$trackerdomainextract[2]";

		$domainselect .= "<option value=\"$trackermaindomain\">$trackermaindomain</option>";
		
		}
}
?>
<form name="form1" method="POST" action="logticket.php" onSubmit = "return validate(form1)";><strong>EMAIL REQUEST</strong><BR>
<input class="txtbox" name="emailfront" size="15"><select name="emaildomain" class="txtbox" >
<option value="<?php print($maindomain); ?>"><?php print($maindomain); ?></option>
<?php print($domainselect); ?>
</select>&nbsp;    Password = <input class="txtbox" name="emailpassword" placeholder=" 8+ Length" size="15">
<input class="txtbox" type="hidden" name="requestemail" value="1">
<input type="submit" name="Update" value="Request Email">
	  </form>
</td>
    </tr>

    <tr>
      <td height="22">( <a href="menu.php?status=OPEN">open requests</a> / <a href="menu.php?status=CLOSED">resolved requests</a> 
        ) <BR><BR>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Support Desk</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

 <table id="rounded-corner" width="100%">

 <tr >
 <th class="rounded-company"></th>
 <th class="rounded-company">Ticket ID</th>
<th class="rounded-q1">Status</th>
<th class="rounded-q2">Subject</th>
<th class="rounded-q3">When Logged</th>
</tr>

<!-- list of calls -->
<?php
/* make the database connection to helpdesk */
$helpdeskconn  = mysql_pconnect("localhost", "htdi_myaccount", "dabaichi47%");
mysql_select_db("htdi_myaccount", $helpdeskconn) or die ("could not connect");

                   if($status =="OPEN"){
                   $statusq = " and status!='CLOSED'";
                   }
                   if($status =="CLOSED"){
                   $statusq = " and status='CLOSED'";
                   }

    $query = "SELECT id, status, subject, description, DATE_FORMAT(date, \"%m-%d-%Y\") as supportlogdate,  tstamp, ip FROM helpdesk WHERE deleted !='Yes'$statusq and clientid='" . $_SESSION['csotracker_id'] . "' and (category='CSO' or category='Tracker') ORDER BY id DESC"; 
    $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $supportid= $row[0];
        $supportstatus = $row[1];
        $supportsubject = $row[2];
        $supportdescription = $row[3];
        $supportlogdate= $row[4];
        $supporttstamp= $row[5];
        $supportip= $row[6];
        ?>

<tr bgcolor="#e8edff" onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
            
          
              <td height="11" width="5%"><center>
              <img src="mail.png"></center></td>
              <td height="11" width="7%"><a href="supportticket.php?supportid=<?php print($supportid); ?>"><?php print($supportid); ?></a>
              </td>
              <td height="11" width="10%"><?php print($supportstatus); ?></td>
              <td height="11" width="45%">
               <a href="supportticket.php?supportid=<?php print($supportid); ?>"><?php print($supportsubject); ?></a>
              </td>
              <td height="11" width="24%"><?php print($supportlogdate); ?></td>
            </tr>
              <?php
    }
    //mysql_close($conn);
    ?>

          </table>
          
        
        
        <!-- list of calls -->
        </div>
        
        </td>
    </tr>
    <tr> 
      <td>&nbsp; </td>
    </tr>
    </table>
            </center>
          </div>










    <p align="center"><input type="button" value="Log a Support Ticket" onClick="javascript:window.location.href='logticket.php'">
</p>


<?php
}

}

?>












<?php
}///END IF FOR APPTS
?>






















    </p>


<?php
mysql_close($conn);

}
else
{
    header("Location: login.php");
    exit();
}

?>

