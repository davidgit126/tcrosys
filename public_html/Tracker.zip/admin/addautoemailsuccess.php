<?php

extract ($_GET );
extract ($_POST );
    include_once('common.inc.php');
    session_start();

    include("connection.php");
        $query = "INSERT INTO autoresponders(subject, message, type, days)
                VALUES(
                '" . mysql_real_escape_string($_POST['subject']) . "', 
                '" . mysql_real_escape_string($_POST['message']) . "',
                '" . mysql_real_escape_string($_POST['type']) . "',
                '" . mysql_real_escape_string($_POST['days']) . "')";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
//
        header("Location: menu.php");
        exit();
    
?>