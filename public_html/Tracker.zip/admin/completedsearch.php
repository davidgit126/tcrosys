<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
include('template.php');

    ?>
    <a href="search.php?cname=&zip=&email=&f=1&Find=Find">Pending Client Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="standardsearch.php?cname=&zip=&email=&f=1&Find=Find">Standard Client Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="completedsearch.php?cname=&zip=&email=&f=1&Find=Find">Completed Client Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="canceledsearch.php?cname=&zip=&email=&f=1&Find=Find">Canceled Client Search</a> <br>
    Please search for the Client  using one of the following criteria or Add a new Client to the database
    <form action="" method="get">
        <table>
            <tr>
                <td>Client Name: </td>
                <td>
                    <input type="text" name="cname" size="20">
                </td>
            </tr>
            <tr>
                <td colspan="2"><b>or</b></td>
            </tr>
            <tr>
                <td>ZIP: </td>
                <td>
                    <input type="text" name="zip" size="20">
                </td>
            </tr>
            <tr>
                <td colspan="2"><b>or</b></td>
            </tr>
            <tr>
                <td>Client E-mail: </td>
                <td>
                    <input type="text" name="email" size="20">
                </td>
            </tr>
        </table>
        <input type="hidden" name="f" value="1">
        <input type="submit" name="Find" value="Find">
    </form>
    
    <br>
    <a href="register.php">Add a new Client</a> <br>
<? print date("m-d-Y"); ?>    <br>
    <br>
    <a href="logout.php">Log out</a> <br>
    <br>
    <?php
    if($_SESSION['usname']=="admin")
    {
        ?>
        <a href="adduser.php">Add a new User to the admin section</a> <br>
        <br>
        <a href="deluser.php">Delete User from the admin section</a> <br>
        <br>
        <?php
    }

    include("connection.php");
    if($_GET['f']==1)
    {
        ?>
        <table border="1" cellspacing="1" width="31%" id="AutoNumber1">
          <tr>
            <td width="100%"><b>Legend</b></td>
          </tr>
          <tr>
            <td width="100%" bgcolor="#FFFFBB">Pending (Has not started credit 
            repair process)</td>
          </tr>
          <tr>
            <td width="100%" bgcolor="#FF6666">Results Overdue (It is past the 
            allotted time for results)</td>
          </tr>
          <tr>
            <td width="100%" bgcolor="#FFCCCC">Scheduled (A dispute round has been scheduled)</td>
          </tr>
          <tr>
            <td width="100%">Active Client</td>
          </tr>
</table>
<p>
        <br>
        List of Clients matching your search criteria </p>
        <table border="1">
        <tr>
            <td>Client Name</td>
            <td>Address</td>
            <td>E-mail</td>
            <td>Audit Date</td>
            <td>Audit Amt</td>
            <td>Monthly</td>
            <td>Due Date</td>
            <td>Method</td>
            <td>Status</td>
        </tr>
        <?php
          if(($_GET['cname'] != null) && ($_GET['cname'] != ''))
          {
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults FROM clients,billing WHERE clients.id=billing.clientid AND clients.reseller_id = 0 AND clients.status = 'complete' AND name LIKE('" . mysql_real_escape_string($_GET['cname']) . "%')";
          }
          else if($_GET['zip'] != '')
          {
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults FROM clients,billing WHERE clients.id=billing.clientid AND clients.reseller_id = 0 AND clients.status = 'complete' AND zip='" . mysql_real_escape_string($_GET['zip']) . "'";
          }
          else if(($_GET['email'] != null) && ($_GET['email'] != ''))
          {
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults FROM clients,billing WHERE clients.id=billing.clientid AND clients.reseller_id = 0 AND clients.status = 'complete' AND email LIKE('" . mysql_real_escape_string($_GET['email']) . "%')";
          }
          else
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults FROM clients,billing WHERE clients.id=billing.clientid AND clients.status = 'complete' AND clients.reseller_id = 0";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $address      = $row[2];
              $cemail       = $row[3];
              $paid         = $row[4];
              $auditfee       = $row[5];
              $monthlyfee	= $row[6];
              $monthlydue	= $row[7];
              $payment       = $row[8];
              $status       = $row[9];
              $dateresults  = $row[10];
              $cnt++;
              
          if ($status == "pending"){
	        $bgcolor = "FFFFBB"; 
	        
  }
    
else{

$bgcolor = "FFFFFF";
}
              ?>
              <tr>
              <td bgcolor=<?php print($bgcolor); ?>><a href="setclient.php?cid=<?php print($id); ?>&cname=<?php print($clientname); ?>"><?php print($clientname); ?></a>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($address); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><a href="mailto:<?php print($cemail); ?>"><?php print($cemail); ?></a>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($paid); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($auditfee); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($monthlyfee); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($monthlydue); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($payment); ?>&nbsp;</td>
              <td bgcolor=<?php print($bgcolor); ?>><?php print($status); ?>&nbsp;</td>
              <?php
    if($_SESSION['usaccess']=="full")
    {
        ?>

<td bgcolor=<?php print($bgcolor); ?>><a href="delete.php?cid=<?php print($id);?>&cname=<?php print($clientname);?>">Delete</a></td>
              <?php
  }
        ?>

</tr>
              <?php
          }
          mysql_close($conn);
          ?>
          </table>
          <?php
          if($cnt==0)
          {
              print("There are no matching records to your search criteria. Please try again.");
          }
    }
}
else
{
    header("Location: login.php");
    exit();
}

?>