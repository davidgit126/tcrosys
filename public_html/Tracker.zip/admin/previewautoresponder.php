<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   
    ?>
   
  <?php
    if($_SESSION['usname']=="admin")
    {
    
    
    include('template2.php');
     include("connection.php");
      $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload, autoresponder FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 
        $autoresponder = $row[14]; 

    }

     $query = "SELECT id, subject, message, type, days FROM autoresponders WHERE id='$autoid'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $autoid           = $row[0];
              $subject   = $row[1];
              $message   = $row[2];
              $type = $row[3];
              $days = $row[4];              
}

         include_once("companystrip.php");

        ?>
  
    
   
<? echo $subject2; ?>
<meta http-equiv="Content-Language" content="en-us">
<BR><BR><BR>
<? echo $message2; ?>

<BR><BR><BR><BR><BR><BR>

<a href="editautoemail.php?autoid=<?php print($autoid); ?>">Back</a><?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>