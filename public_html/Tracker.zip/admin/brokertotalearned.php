<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
include('template.php');

      

    if($salescheck == "yes"){

	  $query = "SELECT id, username, fname, access, affiliate, password, brokers, modletters, modemails, modleads, email, extension, lname, title FROM users WHERE id='$sales_id'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
 while($row=mysql_fetch_row($result))
    {
      $id = $row[0];
      $name = $row[1];
      $fname = $row[2];
      $access = $row[3];      
      $affiliate = $row[4];      
      $password = $row[5];      
      $brokers = $row[6];       
      $modletters = $row[7];       
      $modemails = $row[8];       
      $restrict = $row[9];       
      $email = $row[10];       
      $extension = $row[11];       
      $lname = $row[12];       
      $title = $row[13];       
    }
	$recordname = "$fname $lname";
	}

	  if($brokercheck=='yes'){
	$recordname = $_SESSION['clname'];
	  }else if($affiliatecheck=='yes'){
	$recordname = $_SESSION['clname'];
	  }

    if($_POST['editcomms'] == "yes")
      {
 

  if($brokercheck=='yes'){
          $query = "UPDATE commission_brokers SET
                amount_paid='" . mysql_real_escape_string($_POST['earned']) . "'    
                WHERE id='" . mysql_real_escape_string($_POST['commission_id']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Broker Commission',
                    '" . mysql_real_escape_string($_SESSION['dealer_id']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

}
   }
 include('main.php');

?>
         <STYLE>       
.numbers{
	background-color: #FFFFFF;


	font-family: Verdana, sans-serif; 
	font-size: 10px;

	color: #000000;
	background-image:   url('formshadow.gif');
}
</STYLE> <font color="red">  <B> <?php print($error); ?></B></font>
                 
              <BR><BR>   
                     
                        <div align="center">
                          <center>
                         <b><font color="#FF0000" face="Verdana" size="2"><?php print($message); ?>
                          </font></b>
                         

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="60%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Commission Table for <?php print($recordname); ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

 <table id="rounded-corner" width="60%">

<tr >
<th class="rounded-company">Earn Date</th>
 <th class="rounded-company">Name</th>
 <th class="rounded-company">Level</th>
 <th class="rounded-company">Amount</th>
 <th class="rounded-company">ID</th>
<th class="rounded-q3"></th></tr>


                         
                                
                                <?php
  if($brokercheck=='yes'){
      $gowhere = "brokerstatus.php";
      $updatedb = "commission_brokers";
                        
	$query = "SELECT pay_date, amount_paid, id, contact_id, level  FROM commission_brokers WHERE broker_id='" . $_SESSION['dealer_id'] . "' and contact_id !='' ORDER BY pay_date DESC ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result)) {
$createdate= $row[0];
$amount_paid = $row[1];
$commission_id= $row[2];
$contact_id= $row[3];
$level= $row[4];

$name="";
$c_sql = "SELECT name FROM clients WHERE id = '$contact_id'";
$c_result = @mysql_query($c_sql,$conn);
while ($row2 = mysql_fetch_array($c_result)) {
$name = $row2[0];
}

$pay_year = substr("$pay_date", 0, 4);
$pay_month = substr("$pay_date", 4, 2);
$pay_day = substr("$pay_date", 6, 2);
	
$bgcolor = "#e8edff";
	
?>
<form  action=""    method="post" >
<tr  bgcolor=<?php print($bgcolor); ?> onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
                            
<td width="12%"><?php print($createdate); ?></td>
<td width="25%"><?php print($name); ?></td>
<td width="25%">Tier <?php print($level); ?></td>
<td class='ss-round-inputs' width="15%">$<img border="0" src="input-left.gif" width="7" ><input class="numbers"  name="earned" value="<?php print($amount_paid); ?>" size="5"><img border="0" src="input-right.gif" width="7" ></td>
<td width="25%"><?php print($commission_id); ?></td>
<td width="15%"> <input class="numbers"  type="submit" name="Update" value="Edit">
<input type="hidden"  name="commission_id" value="<?php print($commission_id); ?>" size="3">                              
<input type="hidden"  name="updatedb" value="<?php print($updatedb); ?>" size="3">                              
<input type="hidden"  name="editcomms" value="yes" size="2">                              
                              
                              </td>
 </tr>
 </form>
                              <?php
       }}
      
        if($brokercheck=='yes'){
       $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_brokers WHERE broker_id='" . $_SESSION['dealer_id'] . "' GROUP BY broker_id";
}
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}

?>                

<tr  bgcolor=<?php print($bgcolor); ?> >
                                
                                  <td >&nbsp;</td>
                                  <td >&nbsp;</td>
                                  <td >&nbsp;</td>
                                  <td ><b>Total -
                                  <font color="#008000">$<?php print($COM_total_comish); ?></font></b></td>
                                  <td >&nbsp;</td><td width="25%">&nbsp;</td>

                              
 </tr>
                  
                                </table>
                              </td>
                            </tr>
                            </table>

                          </center>
</div>
                        <p align="left">
                        <a href="<?php print($gowhere); ?>">Back</a>
                        &nbsp;
                        </p>
                        
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>