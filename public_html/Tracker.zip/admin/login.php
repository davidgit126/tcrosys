<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


$year = date("Y"); 
$month = date("m");
$day = date("d");
$julian = "$year$month$day";


$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);
$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";

$ip=$_SERVER["REMOTE_ADDR"];
$site=$_SERVER["HTTP_REFERER"];

include("connection.php");

$query = "SELECT timezone FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $timezone = $row[0];
    }

if($timezone =="Hawaii"){
$timezoneoffset ="-3 hour";
}else if($timezone =="Alaska"){
$timezoneoffset ="-1 hour";
}else if($timezone =="Pacific"){
$timezoneoffset ="-0 hour";
}else if($timezone =="Mountain"){
$timezoneoffset ="+1 hour";
}else if($timezone =="Arizona"){
$timezoneoffset ="+0 hour";
}else if($timezone =="Central"){
$timezoneoffset ="+2 hour";
}else if($timezone =="Eastern"){
$timezoneoffset ="+3 hour";
}
$daythree = date("D",strtotime("$daythree $timezoneoffset"));
$military = date("Hi",strtotime("$military $timezoneoffset"));





$ipquery = "SELECT dbname FROM companyinfo WHERE companyid='1'";
    $ipresult = mysql_query($ipquery, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($ipresult))
    {
        $dbname = $row[0];          
    }
include "700score_connection2.php"; 
 $query = "SELECT mainstatus, dealer_id, fileloc FROM dealers WHERE dbname='$dbname' limit 1";
    $result = mysql_query($query, $conn2);
    while($row=mysql_fetch_row($result))
    {
        $mainstatus = $row[0];
          $dealer_id = $row[1];
          $isptcso = $row[2];
	  $csotracker_id=$dealer_id;
        $_SESSION['csotracker_id'] = $dealer_id; 
        $_SESSION['isptcso'] =  $row[2];

        }

 $query4 = "SELECT ipaddress FROM banned WHERE ipaddress='$ip'";
              $result4 = mysql_query($query4, $conn2) or die("error:" . mysql_error());
        if($row=mysql_fetch_assoc($result4))
              {
                   $isbanned = "banned";
}
 
 $query5 = "SELECT ipaddress FROM allowips WHERE ipaddress='$ip' and dealer_id='$dealer_id'";
              $result5 = mysql_query($query5, $conn2) or die("error:" . mysql_error());
        if($row=mysql_fetch_assoc($result5))
              {
                   $isallowed = "allowed";
}
 
    if ($isbanned != "banned" or $isallowed == "allowed")

	
if(($_POST['username']==null) && ($_POST['password']==null))
{
$query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, reseller, single, dbname, creditline, companyheader FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $reseller = $row[12];              
        $single = $row[13];              
        $dbname = $row[14];          
        $creditline = $row[15];          
        $companyheader = $row[16];          
    }
 if($companyheader !=""){
$insertheader = "<p align=center><img border=0 src=$companyheader></p>";
}else{
$insertheader = "";
}


 if ($mainstatus == "active"){
include('template.php');


    ?>
<br />

<?php print($insertheader); ?>

<br />

<br /><br />
    <div align="center">
<form  action="login.php" method="POST">
   

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="350">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Admin Entrance</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

 <table width=350  background="bluestrip.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
       
        <tr>
            <td colspan="2">
    <table width="350" background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
                    <tr>
                        <td width="123" height="11">&nbsp;
                            </td>
                        <td width="227" height="11">&nbsp;
                            </td>
                    </tr>
                    <tr>
                        <td width="123" height="11">&nbsp;
                            </td>
                        <td width="227" height="11">&nbsp;
                            </td>
                    </tr>
                    <tr>
                        <td width="123" height="11">
                            <div align="right">
                                <font face="Arial, Helvetica, sans-serif" size="2" color="#FFFFFF"><b>Login name:&nbsp;</b></font><font color="#FFFFFF">
                                </font>
                            </div>
                        </td>
                        <td width="227" height="11">
                            <input type="text" name="username" size="20">
                        </td>
                    </tr>
                    <tr>
                        <td width="123" height="17">&nbsp;
                            </td>
                        <td width="227" height="17">&nbsp;
                            </td>
                    </tr>
                    <tr>
                        <td width="123" height="17">
                            <div align="right">
                                <font face="Arial, Helvetica, sans-serif" size="2" color="#FFFFFF"><b>Password:&nbsp;</b></font><font color="#FFFFFF">
                                </font>
                            </div>
                        </td>
                        <td width="227" height="17">
                            <input type="password" name="password" size="20">
                        </td>
                    </tr>
                    <tr>
                        <td width="123">&nbsp;</td>

                        <td width="227">&nbsp;</td>
                    </tr>
                    <tr>
                        <td width="123">&nbsp;</td>

                        <td width="227">&nbsp;&nbsp;
                            <input type="submit" value="Submit" name="submit">
                            <input type="reset" value="Reset" name="reset">
                        </td>
                    </tr>
                    <tr>
                        <td width="350" colspan="2">&nbsp;</td>

                    </tr>
                    <tr>
                        <td width="350" colspan="2">
                        <img border="0" src="bottomlogin.gif" width="350" height="16"></td>

                    </tr>
                </table>
            </td>
        </tr>
    </table>
</form>
</div>
    <br /><br /><br /><br /><br />
<?php
 } }
  else
  {

    include("connection.php");

$daythree = strtolower($daythree);
$start = "$daythree"; 
$start .= "1";
$end = "$daythree"; 
$end .= "2";
$accessquery = "$start, $end ";


    $query = "SELECT $accessquery FROM users WHERE password='" . mysql_real_escape_string($_POST['password']) . "' and username='" . mysql_real_escape_string($_POST['username']) . "' LIMIT 1";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
 while ($row = mysql_fetch_array($result)) {

        $timestart   = $row[0];
        $timeend   = $row[1];
}
if($timestart == ""){
$timestart = "0000";
}if ($timeend ==""){
$timeend = "2400";
}


if($military >= $timestart && $military <= $timeend){
//echo "Time is $military <BR>";
//echo "Query is $accessquery <BR>";
//echo "Access hours are from $timestart to $timeend <BR>";
$allowedaccess = "Yes";
}else{
echo "Time is $military <BR>";
//echo "Query is $accessquery <BR>";
echo "Access hours are from $timestart to $timeend <BR>";
echo "Your access levels do not permit login during this hour";
exit();
}


    $query = "SELECT id, username, access, fname, extension, affiliate, brokers, modleads, modemails FROM users WHERE password='" . mysql_real_escape_string($_POST['password']) . "' and username='" . mysql_real_escape_string($_POST['username']) . "' LIMIT 1";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        if($row=mysql_fetch_assoc($result))
    {
        $usid   = $row['id'];
        $usname = $row['username'];
        $usaccess = $row['access'];
        $usfname = $row['fname'];
        $usext = $row['extension'];
        $affiliate = $row['affiliate'];
        $brokers = $row['brokers'];
        $restrict = $row['modleads'];
        $editleads = $row['modemails'];
        $is_admin = 1;
        $action = "Successful Login";

        session_register('usid');  
        session_register('usname'); 
        session_register('usaccess'); 
        session_register('usfname'); 
        session_register('usext'); 
        session_register('affiliate'); 
        session_register('brokers'); 
        session_register('restrict'); 
        session_register('editleads'); 

        session_register('is_admin'); 

$query = "INSERT INTO actionlog(username, action, julian, tstamp)
                    VALUES(
                    '$usfname',
                    'Admin Log In',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
mysql_close($conn);

include "700score_connection2.php"; 
$query = "INSERT INTO admintables(site, julian, tstamp, ipaddress, username, password, action)
                    VALUES(
                    '$site',
                    '$julian',
                    '$tstamp',
                    '$ip',
'" . mysql_real_escape_string($_POST['username']) . "',
'" . mysql_real_escape_string($_POST['password']) . "',
                    '$action')"; 
                $result = mysql_query($query, $conn2) or die("error:" . mysql_error());
mysql_close($conn2);

header("Location: menu.php");
exit();
    } 
    else
    {
include "700score_connection2.php"; 
$query = "INSERT INTO admintables(site, julian, tstamp, ipaddress, username, password, action)
                    VALUES(
                    '$site',
                    '$julian',
                    '$tstamp',
                    '$ip',
'" . mysql_real_escape_string($_POST['username']) . "',
'" . mysql_real_escape_string($_POST['password']) . "',
                    'Failed Login')"; 
                $result = mysql_query($query, $conn2) or die("error:" . mysql_error());

$query = "INSERT INTO failures(julian, tstamp, ipaddress)
                    VALUES(
                    '$julian',
                    '$tstamp',
                    '$ip')"; 
                $result = mysql_query($query, $conn2) or die("error:" . mysql_error());

 $query3 = "SELECT count(id) FROM failures WHERE ipaddress='$ip' and julian='$julian'";
              $result3 = mysql_query($query3, $conn2) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $numberfailures = $row3[0];

 if($numberfailures >= 30){
$query = "INSERT INTO banned(ipaddress)
                    VALUES(
                    '$ip')"; 
                $result = mysql_query($query, $conn2) or die("error:" . mysql_error());
}
}




mysql_close($conn2);

        print("<html><body><br>Sorry, wrong username or password! error: $numberfailures<br><a href=login.php>Try Again!</a>");
    }
  }

?>
