<?php
extract ($_GET );
extract ($_POST );

include("connection.php");



$sql = "UPDATE creditortype SET
type = \"$creditorname\",
address = \"$creditoraddress\",
citystatezip= \"$citystatezip\"
WHERE id = \"$creditorid\"";

$result = @mysql_query($sql,$conn);


header("Location: letters.php?creditorselected=$creditorid");  
exit;


?>