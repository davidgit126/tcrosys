 <style type="text/css">
/* This is where you can customize the appearance of the tooltip */
div#tipDiv {
  position:absolute; visibility:hidden; left:0; top:0; z-index:10000;
  background-color:#dee7f7; border:1px solid #336; 
  width:250px; padding:4px;
  color:#000; font-size:11px; line-height:1.2;
}
/* These are optional. They demonstrate how you can individually format tooltip content  */
div.tp1 { font-size:12px; color:#336; font-style:italic }
div.tp2 { font-weight:bolder; color:#337; padding-top:4px }
</style>
<script type="text/javascript">
function doTooltip(e, msg) {
  if ( typeof Tooltip == "undefined" || !Tooltip.ready ) return;
  Tooltip.show(e, msg);
}

function hideTip() {
  if ( typeof Tooltip == "undefined" || !Tooltip.ready ) return;
  Tooltip.hide();
}

var dw_event = {
  
  add: function(obj, etype, fp, cap) {
    cap = cap || false;
    if (obj.addEventListener) obj.addEventListener(etype, fp, cap);
    else if (obj.attachEvent) obj.attachEvent("on" + etype, fp);
  }, 

  remove: function(obj, etype, fp, cap) {
    cap = cap || false;
    if (obj.removeEventListener) obj.removeEventListener(etype, fp, cap);
    else if (obj.detachEvent) obj.detachEvent("on" + etype, fp);
  }, 

  DOMit: function(e) { 
    e = e? e: window.event;
    e.tgt = e.srcElement? e.srcElement: e.target;
    
    if (!e.preventDefault) e.preventDefault = function () { return false; }
    if (!e.stopPropagation) e.stopPropagation = function () { if (window.event) window.event.cancelBubble = true; }
        
    return e;
  }
  
}

 
var viewport = {
  getWinWidth: function () {
    this.width = 0;
    if (window.innerWidth) this.width = window.innerWidth - 18;
    else if (document.documentElement && document.documentElement.clientWidth) 
  		this.width = document.documentElement.clientWidth;
    else if (document.body && document.body.clientWidth) 
  		this.width = document.body.clientWidth;
  },
  
  getWinHeight: function () {
    this.height = 0;
    if (window.innerHeight) this.height = window.innerHeight - 18;
  	else if (document.documentElement && document.documentElement.clientHeight) 
  		this.height = document.documentElement.clientHeight;
  	else if (document.body && document.body.clientHeight) 
  		this.height = document.body.clientHeight;
  },
  
  getScrollX: function () {
    this.scrollX = 0;
  	if (typeof window.pageXOffset == "number") this.scrollX = window.pageXOffset;
  	else if (document.documentElement && document.documentElement.scrollLeft)
  		this.scrollX = document.documentElement.scrollLeft;
  	else if (document.body && document.body.scrollLeft) 
  		this.scrollX = document.body.scrollLeft; 
  	else if (window.scrollX) this.scrollX = window.scrollX;
  },
  
  getScrollY: function () {
    this.scrollY = 0;    
    if (typeof window.pageYOffset == "number") this.scrollY = window.pageYOffset;
    else if (document.documentElement && document.documentElement.scrollTop)
  		this.scrollY = document.documentElement.scrollTop;
  	else if (document.body && document.body.scrollTop) 
  		this.scrollY = document.body.scrollTop; 
  	else if (window.scrollY) this.scrollY = window.scrollY;
  },
  
  getAll: function () {
    this.getWinWidth(); this.getWinHeight();
    this.getScrollX();  this.getScrollY();
  }
  
}


var Tooltip = {
    followMouse: true,
    overlaySelects: true,  // iframe shim for select lists (ie win)
    offX: 8,
    offY: 12,
    tipID: "tipDiv",
    showDelay: 100,
    hideDelay: 200,
    
    ovTimer: 0, // for overlaySelects
    ready:false, timer:null, tip:null, shim:null, supportsOverlay:false,
  
    init: function() {
        if ( document.createElement && document.body && typeof document.body.appendChild != "undefined" ) {
            var el = document.createElement("DIV");
            el.id = this.tipID;
            document.body.appendChild(el);
            this.supportsOverlay = this.checkOverlaySupport();
            this.ready = true;
        }
    },
    
    show: function(e, msg) {
        if (this.timer) { clearTimeout(this.timer);	this.timer = 0; }
        this.tip = document.getElementById( this.tipID );
        if (this.followMouse) // set up mousemove 
            dw_event.add( document, "mousemove", this.trackMouse, true );
        this.writeTip("");  // for mac ie
        this.writeTip(msg);
        viewport.getAll();
        this.handleOverlay(1, this.showDelay);
        this.positionTip(e);
        this.timer = setTimeout("Tooltip.toggleVis('" + this.tipID + "', 'visible')", this.showDelay);
    },
    
    writeTip: function(msg) {
        if ( this.tip && typeof this.tip.innerHTML != "undefined" ) this.tip.innerHTML = msg;
    },
    
    positionTip: function(e) {
        if ( this.tip && this.tip.style ) {    
            // put e.pageX/Y first! (for Safari)
            var x = e.pageX? e.pageX: e.clientX + viewport.scrollX;
            var y = e.pageY? e.pageY: e.clientY + viewport.scrollY;
    
            if ( x + this.tip.offsetWidth + this.offX > viewport.width + viewport.scrollX ) {
                x = x - this.tip.offsetWidth - this.offX;
                if ( x < 0 ) x = 0;
            } else x = x + this.offX;
        
            if ( y + this.tip.offsetHeight + this.offY > viewport.height + viewport.scrollY ) {
                y = y - this.tip.offsetHeight - this.offY;
                if ( y < viewport.scrollY ) y = viewport.height + viewport.scrollY - this.tip.offsetHeight;
            } else y = y + this.offY;
            
            this.tip.style.left = x + "px"; this.tip.style.top = y + "px";
        }
            
        this.positionOverlay();
    },
    
    hide: function() {
        if (this.timer) { clearTimeout(this.timer);	this.timer = 0; }
        this.handleOverlay(0, this.hideDelay);
        this.timer = setTimeout("Tooltip.toggleVis('" + this.tipID + "', 'hidden')", this.hideDelay);
        if (this.followMouse) // release mousemove
            dw_event.remove( document, "mousemove", this.trackMouse, true );
        this.tip = null; 
    },
    
    toggleVis: function(id, vis) { // to check for el, prevent (rare) errors
        var el = document.getElementById(id);
        if (el) el.style.visibility = vis;
    },

    trackMouse: function(e) {
    	e = dw_event.DOMit(e);
     	Tooltip.positionTip(e);
    },
    
    // check need for and support of iframe shim
    checkOverlaySupport: function() {
        if ( navigator.userAgent.indexOf("Windows") != -1 && 
            typeof document.body != "undefined" && 
            typeof document.body.insertAdjacentHTML != "undefined" && 
            !window.opera && navigator.appVersion.indexOf("MSIE 5.0") == -1 
            ) return true;
        else return false;
    }, 
    
    handleOverlay: function(bVis, d) {
        if ( this.overlaySelects && this.supportsOverlay ) {
            if (this.ovTimer) { clearTimeout(this.ovTimer); this.ovTimer = 0; }
            switch (bVis) {
                case 1 :
                    if ( !document.getElementById('tipShim') ) 
                        document.body.insertAdjacentHTML("beforeEnd", '<iframe id="tipShim" src="2menu.php" style="position:absolute; left:0; top:0; z-index:500; visibility:hidden" scrolling="no" frameborder="0"></iframe>');
                    this.shim = document.getElementById('tipShim'); 
                    if (this.shim && this.tip) {
                        this.shim.style.width = this.tip.offsetWidth + "px";
                        this.shim.style.height = this.tip.offsetHeight + "px";
                    }
                    this.ovTimer = setTimeout("Tooltip.toggleVis('tipShim', 'visible')", d);
                break;
                case 0 :
                    this.ovTimer = setTimeout("Tooltip.toggleVis('tipShim', 'hidden')", d);
                    if (this.shim) this.shim = null;
                break;
             }
        }
    },    
    
    positionOverlay: function() {
        if ( this.overlaySelects && this.supportsOverlay && this.shim ) {
            this.shim.style.left = this.tip.style.left;
            this.shim.style.top = this.tip.style.top;
        }
    }
}
</script>