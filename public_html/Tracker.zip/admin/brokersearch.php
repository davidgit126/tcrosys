<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
include('template.php');
 include("connection.php");


    ?>
    
    
 <title>Broker Search</title> 
  <?php
    if($_SESSION['brokers']=="Yes")
    {
    $sql3 = "SELECT * FROM sales_affiliates WHERE type='Affiliate' ORDER BY lname";
  $result3 = @mysql_query($sql3,$conn);
  while ($row3 = mysql_fetch_array($result3)) {
  $AFFILIATE_username = $row3['user'];
  $AFFILIATE_id = $row3['id'];
  $AFFILIATE_fname = $row3['fname'];
    $AFFILIATE_lname = $row3['lname'];

  $AFFILIATE_select .= "<option value=\"$AFFILIATE_id\">$AFFILIATE_lname, $AFFILIATE_fname ($AFFILIATE_username)</option>";
  }
    ?>

 <script type="text/javascript">

	subject_id = '';
	function handleHttpResponse() {
		if (http.readyState == 4) {
			if (subject_id != '') {
				document.getElementById(subject_id).innerHTML = http.responseText;
			}
		}
	}
	function getHTTPObject() {
		var xmlhttp;
		/*@cc_on
		@if (@_jscript_version >= 5)
			try {
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (E) {
					xmlhttp = false;
				}
			}
		@else
		xmlhttp = false;
		@end @*/
		if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
			try {
				xmlhttp = new XMLHttpRequest();
			} catch (e) {
				xmlhttp = false;
			}
		}
		return xmlhttp;
	}
	var http = getHTTPObject(); // We create the HTTP Object

	function getScriptPage(div_id,content_id)
	{
		subject_id = div_id;
		content = document.getElementById(content_id).value;
		http.open("GET", "template.php?searchpage=broker&content=" + escape(content), true);
		http.onreadystatechange = handleHttpResponse;
		http.send(null);
		if(content.length>0)
			box('1');
		else
			box('0');

	}	

	function highlight(action,id)
	{
	  if(action)	
		document.getElementById('word'+id).bgColor = "#184EAE";
	  else
		document.getElementById('word'+id).bgColor = "#2E2E2E";
	}
	function display(word)
	{
		document.getElementById('text_content').value = word;
		document.getElementById('box').style.display = 'none';
		document.getElementById('text_content').focus();
	}
	function box(act)
	{
	  if(act=='0')	
	  {
		document.getElementById('box').style.display = 'none';

	  }
	  else
		document.getElementById('box').style.display = 'block';
		document.getElementById('topbox').style.display = 'block';
	}
</script> 
    <font color="red">  <B> <?php print($message); ?></B></font>
      <?php
    include('main.php');
    
    $longsearchstring = "firstname=$firstname&lastname=$lastname&searchaffiliate=$searchaffiliate&email=$email&dealership=$dealership";

   ?>     
<BR>
   <form action="" method="get">
      

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="600">
<tr><td width="1"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Broker Search</td>
<td width="1"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

  <table background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="600">
<tr>
<td>

<tr>
<td width="128">&nbsp;</td>
<td width="161">&nbsp;</td>
<td width="66">&nbsp;</td>
<td width="245">&nbsp;</td>
</tr>

<tr>
<td width="128" valign="top"><font color="#FFFFFF"><b>&nbsp;Record Search:</b></font></td>
<td class='ss-round-inputs' width="375" colspan="3">
<div class="ajax-div">
<div class="input-div">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  type="text" onKeyUp="getScriptPage('box','text_content')" id="text_content" size="40"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></div>
<div id="box"></div>
</div>
</td>
</tr>
<tr>
<td colspan = "4"><HR size=1></td>
</tr>



            <tr>
                <td><font color="#FFFFFF"><b>&nbsp;First Name: </b></font> </td>
                <td class='ss-round-inputs' >
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="firstname" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td><font color="#FFFFFF"><b>&nbsp;Last Name: </b></font> </td>
                <td class='ss-round-inputs' >
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="lastname" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td><b><font color="#FFFFFF">&nbsp;Affiliate</font></b><font color="#FFFFFF"><b>: </b></font> </td>
                <td>
                    <select class="txtbox"  name="searchaffiliate">
					    <option value="<? echo "$searchaffiliate"; ?>" selected><? echo "$searchaffiliate"; ?></option>
					    <? echo "$AFFILIATE_select"; ?>
					    <option value="">REMOVE</option>

					    </select>
                </td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td><font color="#FFFFFF"><b>&nbsp;E-mail: </b></font> </td>
                <td class='ss-round-inputs' >
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="email" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td><font color="#FFFFFF"><b>&nbsp;Company: </b></font> </td>
                <td class='ss-round-inputs' >
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="dealership" size="25"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>
       <tr>
                <td width="107"> <input type="hidden" name="f" value="1">
                <br>&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="submit" name="Find" value="Find"></td>
                <td width="185">&nbsp;
                    </td>
            </tr>
           
        </table>
       <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="600">
<tr><td width="1"><img border="0" src="bottomleftcorner.gif" ></td>
<td class="miniheaders" background="bottombackground.gif" width="99%"></td>
<td width="1"><img border="0" src="bottomrightcorner.gif"></td></tr>
</table>
    </form>
    
    <br>

    
        <?php
    

    include("connection.php");
    if($_GET['f']==1)
    {
if($_SESSION['usname']=="admin"){  ?>
<input type="button" style="position:relative;color: #07c;font-family: Georgia,serif;font-size: 12px;" name="OK" value="Export CSV" label="OK" onClick="javascript:window.location.href='brokerscsv.php';">
<?php  }  ?>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="80%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">List of brokers that match your criteria</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

 <table id="rounded-corner" width="80%">

<tr >
<th class="rounded-company">Name 
<a style="text-decoration: none" href="brokersearch.php?<?php print($longsearchstring);?>&sortby=name1&f=1">&darr;</a>
<a style="text-decoration: none" href="brokersearch.php?<?php print($longsearchstring);?>&sortby=name2&f=1">&uarr;</a>
</th>
 <th class="rounded-company">&nbsp;&nbsp;&nbsp;</th>
 <th class="rounded-company">Company</th>
 <th class="rounded-company">E-mail</th>
<th class="rounded-q1">Phone</th>
<th class="rounded-q2">Affiliate</th>

<th class="rounded-q3">Earned</th>
<th class="rounded-q3">Paid</th>
<th class="rounded-q3">Due</th>
<th class="rounded-company">Enter Date 
<a style="text-decoration: none" href="brokersearch.php?<?php print($longsearchstring);?>&sortby=date1&f=1">&darr;</a>
<a style="text-decoration: none" href="brokersearch.php?<?php print($longsearchstring);?>&sortby=date2&f=1">&uarr;</a>
</th>


<th class="rounded-q3"></th></tr>




        <?php
        
         if (! $searchbroker) {
$brokerquery = "";
}else{
$brokerquery = " AND broker_id='$searchbroker'";
}

if (! $searchaffiliate) {
$affquery = "";
}else{
$affquery = " AND affiliate_id='$searchaffiliate'";
}
if (! $dealership) {
$companyquery = "";
}else{
$companyquery = " AND dealership like '%$dealership%'";
}

if($sortby==""){
$sortstatement = "order by dealership";
}else if ($sortby =="name1") {       
$sortstatement = "order by lastname, dealer_id desc";
}else if ($sortby =="name2") {       
$sortstatement = "order by lastname desc, dealer_id desc";
}else if ($sortby =="date1") {       
$sortstatement = "order by createdate, dealer_id desc";
}else if ($sortby =="date2") {       
$sortstatement = "order by createdate desc, dealer_id desc";
}





          if(($_GET['firstname'] != null) && ($_GET['firstname'] != ''))
          {
             $query = "SELECT dealer_id, firstname, lastname, email, telephone, createdate, affiliate_id, dealership FROM dealers WHERE status != 9 $brokerquery $affquery $companyquery AND firstname LIKE('" . mysql_real_escape_string($_GET['firstname']) . "%')";
          }
          else if($_GET['lastname'] != '')
          {
              $query = "SELECT dealer_id, firstname, lastname, email, telephone, createdate, affiliate_id, dealership FROM dealers WHERE status != 9 $brokerquery $affquery $companyquery AND lastname LIKE('" . mysql_real_escape_string($_GET['lastname']) . "%')";
          }
          else if(($_GET['email'] != null) && ($_GET['email'] != ''))
          {
              $query = "SELECT dealer_id, firstname, lastname, email, telephone, createdate, affiliate_id, dealership FROM dealers WHERE status != 9 $brokerquery $affquery $companyquery AND email LIKE('" . mysql_real_escape_string($_GET['email']) . "%')";
          }
          else
              $query = "SELECT dealer_id, firstname, lastname, email, telephone, createdate, affiliate_id, dealership FROM dealers WHERE status != 9 $brokerquery $affquery $companyquery $sortstatement";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $firstname   = $row[1];
              $lastname      = $row[2];
              $cemail       = $row[3];
              $phone = $row[4];
              $createdate = $row[5];
              $affiliate_id  = $row[6];
              $dealership  = $row[7];
              $cnt++;
              
        

$bgcolor = "#e8edff";


$COM_total_comish = "";
$COM_total_pd = "";

$LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_brokers WHERE broker_id = '$id' GROUP BY broker_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];
}

$affiliatename = '';
$query3 = "SELECT user FROM sales_affiliates WHERE id = '$affiliate_id'";
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $affiliatename = $row3[0];
}

              ?>
<tr  bgcolor=<?php print($bgcolor); ?> onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
<td ><a href="setbroker.php?cid=<?php print($id); ?>&cname=<?php print($firstname); ?> <?php print($lastname); ?>"><?php print($lastname); ?>, <?php print($firstname); ?></a></td>
<td >
<a href="search.php?searchbroker=<?php print($id); ?>&f=1"><font style="font: 80.0% Calibri, Arial, sans-serif;">clients</font></a>&nbsp; 
<a href="prospectsearch.php?searchbroker=<?php print($id); ?>&f=1"><font style="font: 80.0% Calibri, Arial, sans-serif;">prospects</font></a>
</td>
              <td ><?php print($dealership); ?></td>
              <td ><a href="mailto:<?php print($cemail); ?>"><?php print($cemail); ?></a></td>
              <td ><?php print($phone); ?></td>
              <td ><?php print($affiliatename); ?></td>
              <td ><?php print($user); ?></td>
              <td >$<?php print($COM_total_pd); ?></td>
              <td >$<?php print($COM_total_comish - $COM_total_pd); ?></td>

              <td ><?php print($createdate); ?></td>
			  <td  >
              
              <?php
    if($_SESSION['usaccess']=="full")
    {
        ?>

            <a href="brokerdelete.php?cid=<?php print($id);?>&cname=<?php print($firstname); ?> <?php print($lastname); ?>"><img border="0" src="deletebutton.png"></a>
              
              <?php
          }
                    ?>
</td>
              </tr>
              <?php
          }
          mysql_close($conn);
          ?>
          </table>
          <?php
          if($cnt==0)
          {
              print("There are no matching records to your search criteria. Please try again.");
          }
    }
}}
else
{
    header("Location: login.php");
    exit();
}

?>