<?php
session_start();

extract ($_GET );
extract ($_POST );

$_SESSION['licid']     = $_GET['licid'];

header("Location: licensee.php");
exit();
?>
