<?php
extract ($_GET );
extract ($_POST );

include("connection.php");



$sql = "UPDATE credletters SET
lettername = \"$lettername\",
abovedisputes = \"$abovedisputes\",
belowdisputes = \"$belowdisputes\",
showdisputes = \"$showdisputes\",
letterorder = \"$letterorder\",
disputecolumn = \"$disputecolumn\",
showproof = \"$showproof\"
WHERE id = \"$credletterid\"";

$result = @mysql_query($sql,$conn);


header("Location: editcredletter.php?credletterid=$credletterid&success=Letter Updated!");  
exit;


?>