<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
include('template.php');
    include('main.php');


    if($_SESSION['usaccess']=="support" or $_SESSION['usaccess']=="full"){

if($_POST['updatecanned'] == 1)
    {
        $query = "UPDATE helpdeskcanned SET
                subject='" . mysql_real_escape_string($_POST['cannedsubject']) . "',
                content='" . mysql_real_escape_string($_POST['content']) . "'
                WHERE id='" . mysql_real_escape_string($_POST['cannedid']) . "' ";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        
$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Updated Canned Response',
                    '" . mysql_real_escape_string($_POST['cannedid']) . "',
                    '" . mysql_real_escape_string($_POST['cannedsubject']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

    }
    
    if($_POST['addcanned'] == 1)
    {
        $query = "INSERT INTO helpdeskcanned(subject, content)
                VALUES(
                '" . mysql_real_escape_string($_POST['subject']) . "',
                '" . mysql_real_escape_string($_POST['content']) . "'
                )";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

        
$query = "INSERT INTO actionlog(username, action, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Add Canned Response',
                    '" . mysql_real_escape_string($_POST['subject']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

    }
    
    
    
    
    
    if($_POST['updatehotlinks'] == 1)
    {
        $query = "UPDATE companyhotlinks SET
                cannedname='" . mysql_real_escape_string($_POST['cannedname']) . "',
                cannedreceived='" . mysql_real_escape_string($_POST['cannedreceived']) . "',
                cannedsubject='" . mysql_real_escape_string($_POST['cannedsubject']) . "',
				cannedaction='" . mysql_real_escape_string($_POST['cannedaction']) . "'
                WHERE id='" . mysql_real_escape_string($_POST['cannedid']) . "' ";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        
$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Updated Company Hotlinks',
                    '" . mysql_real_escape_string($_POST['cannedid']) . "',
                    '" . mysql_real_escape_string($_POST['cannedname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

    }
    
    if($_POST['addhotlink'] == 1)
    {
        $query = "INSERT INTO companyhotlinks(cannedname, cannedaction, cannedsubject, cannedreceived)
                VALUES(
                '" . mysql_real_escape_string($_POST['cannedname']) . "',
                '" . mysql_real_escape_string($_POST['cannedaction']) . "',
				'" . mysql_real_escape_string($_POST['cannedsubject']) . "',
                '" . mysql_real_escape_string($_POST['cannedreceived']) . "'
                )";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

        
$query = "INSERT INTO actionlog(username, action, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Add Company Hotlink',
                    '" . mysql_real_escape_string($_POST['cannedname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

    }


if($hotlinkdel == "yes" && $delhotlinkid !=""){
        $query = "DELETE FROM companyhotlinks WHERE id='$delhotlinkid'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Delete Custom Canned Hot Link',
                    '$delhotlinkid',
                    '$delhotlinkname',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}


     ?>
<STYLE type=text/css>
A:active  {	COLOR: #006699; TEXT-DECORATION: none      }
A:visited { COLOR: #334A9B; TEXT-DECORATION: none      }
A:hover   { COLOR: #334A9B; TEXT-DECORATION: underline }
A:link    { COLOR: #334A9B; TEXT-DECORATION: none      }
td { font-family:Tahoma;font-size:11px;color:#000000 }

 .title, h1	{ font-size: 23px; font-weight: bold; font-family: Trebuchet MS,Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000066; }
 .forminput     { font-size: 8pt; background-color: #CCCCCC; font-family: verdana, helvetica, sans-serif; vertical-align:middle }
 .tbox          { FONT-SIZE: 11px; FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif; COLOR: #000000; BACKGROUND-COLOR: #ffffff }
 .gbox          { FONT-SIZE: 11px; FONT-FAMILY: Verdana; COLOR: #000000; BACKGROUND-COLOR: #F7F7F7 }

</STYLE>

<style type="text/css">
 .tbox {
	FONT-SIZE: 11px;
	FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif;
	COLOR: #000000;
	BACKGROUND-COLOR: #ffffff
}
      </style> 
          <div align="center">
            <center><BR>
            
            
            
            
               <?php
            if ($type == "helpdesk" && $helpdesk =="Yes"){
            ?>

            
            
            
            
            
            
  <table width="75%" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
    <tr> 
      <td> 
       <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Canned Responses</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
<table width="100%" border="0" cellspacing="1" align="center" height="19">
          <tr bgcolor="#DEDEEB"> 
            <td width="34%" class="usertab"> 
            
            <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Description</font></td>
               
            <td width="66%"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                
                  <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
                  Response</font></td>
                </tr>
              
        </table></td>
                </tr>
        <div align="center">
        <!-- list of calls -->
        
        
          <table width="100%" border="0" cellspacing="1" cellpadding="4" align="center">
          
              <?php
              

    $query = "SELECT id, subject, content FROM helpdeskcanned ORDER BY subject"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $cannedid= $row[0];
        $cannedsubject = $row[1];
        $cannedcontent = $row[2];

  $textrows = strlen($cannedcontent);
  $textrows = $textrows / 81;
  $textrows = floor($textrows);
  $textrows = $textrows +1;

        ?>
 <form action="" method="post">

              <tr bgcolor="#f1f1f1">
            
          
              <td width="34" valign="top">
<input class="txtbox" name="cannedsubject" value="<?php print($cannedsubject); ?>" size="37">              </td>
              <td width="66%"><textarea class="txtbox" rows="<?php print($textrows); ?>" name="content" cols="70"><?php echo $cannedcontent; ?></textarea>
              
              <input type="hidden" name="updatecanned" value="1">
                                    <input type="hidden" name="cannedid" value="<?php print($cannedid);?>">

<input type="submit" name="Update" value="Update">

</td>
            </tr></form>
            
              <?php
    }
    ?>

          </table>
          
        <BR><BR>
        
          <table width="100%" border="0" cellspacing="1" cellpadding="4" align="center">
          
             
 <form action="" method="post">

              <tr bgcolor="#f1f1f1">
            
                 <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Add New Canned Response</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table width="100%" border="0" cellspacing="1" align="center" height="19">
          <tr bgcolor="#DEDEEB"> 
            <td width="34%" class="usertab"> 
            
            <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Description</font></td>
               
            <td width="66%"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                
                  <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
                  Response</font></td>
                </tr>
              
        </table>            </tr>
            
          
              <tr bgcolor="#f1f1f1">
            
          
              <td width="34" valign="top">
<input class="txtbox" name="subject" size="37">              </td>
              <td width="66%"><textarea class="txtbox" rows="7" name="content" cols="70"></textarea>
              
              <input type="hidden" name="addcanned" value="1">
                                    

<input type="submit" name="Update" value="Add">

</td>
            </tr>
            </form>
          
          </table>
        
        <!-- list of calls -->
        </div>
        
        </td>
    </tr>
    <tr> 
      <td>&nbsp; </td>
    </tr>
    </table>
       </center>
          </div>
          
          <p align="center"><input type="button" value="Back to HelpDesk" onClick="javascript:window.location.href='helpdesk.php'">
</p>
    
                   <?php
}
           else if ($type == "hotlinks"){
            ?>
    
    
    
    
    <table width="95%" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
    <tr> 
      <td> 
        
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td background="titlebackground.gif" width="1"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Current Custom Canned Hot Links</td>
<td background="titlebackground.gif" width="1"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table width="100%" border="0" cellspacing="1" cellpadding="4" align="center">
          
<?php
    $query = "SELECT id, cannedreceived, cannedaction, cannedsubject, cannedname FROM companyhotlinks order by cannedsubject,id";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $cannedid= $row[0];
        $cannedreceived= $row[1];
        $cannedaction= $row[2];
        $cannedsubject= $row[3];
        $cannedname = $row[4];
  
  $textrows = strlen($cannedreceived);
  $textrows = $textrows / 81;
  $textrows = floor($textrows);
  $textrows = $textrows +1;


if ($cannedsubject == ""){
$cannedsubject = "ClientStatusSheet";
}else{
$cannedsubject = $cannedsubject;
}
        ?>
<form action="" method="post">

<input type="hidden" name="cannedid" value="<?php print($cannedid);?>">

<input type="hidden" name="updatehotlinks" value="1">
                                    
<tr bgcolor="#DEDEEB">
<td width="10%" class="usertab"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Short Name</font></td>
<td width="10%" class="usertab"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Type</font></td>
<td width="40%" class="usertab"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Received</font></td>
<td width="40%" class="usertab"><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> Action Taken</font></td>
</tr>
            

<tr bgcolor="#f1f1f1">
<td width="10%" valign="top"><input class="txtbox" name="cannedname" value="<?php print($cannedname); ?>" size="14"><BR>
<input type="hidden" name="updatehotlinks" value="1">
<input type="hidden" name="cannedid" value="<?php print($cannedid);?>">                                    
<input type="submit" name="Update1" value="Update">
&nbsp;&nbsp;&nbsp;<a onclick="return confirm('Are you sure you want to delete <?php print($cannedname); ?> from Custom Hot Links?');" href="canned.php?type=hotlinks&hotlinkdel=yes&delhotlinkid=<?php print($cannedid); ?>&delhotlinkname=<?php print($cannedname); ?>"><img alt="Deleted from Custom Canned Hot Links" src="deletex.gif" border="0"></a>
</td>
<td width="10%" valign="top"><select name="cannedsubject" class="txtbox"><option value="<?php print($cannedsubject);?>" selected><?php print($cannedsubject);?></option>
<option value="ClientStatusSheet">ClientStatusSheet</option>
<option value="LeadConversion">LeadConversion</option>
<option value="Prospects">Prospects</option></select></td>
<td width="40%" valign="top"><textarea class="txtbox" rows="3" cols="65" name="cannedreceived"><?php print($cannedreceived); ?></textarea></td>
<td width="40%" valign="top"><textarea class="txtbox" rows="3" cols="65" name="cannedaction"><?php print($cannedaction); ?></textarea></td>
</tr>

              </form>
            
              <?php
    }
    ?>

          </table>
          
        <BR><BR>
        
<table width="99%" border="0" cellspacing="1" cellpadding="4" align="center">
          
             
 <form action="" method="post">

              <tr bgcolor="#f1f1f1">
            
<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Add New Custom Canned Hot Link</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

<table width="100%" border="0" cellspacing="1" cellpadding="4" align="center">
<tr bgcolor="#DEDEEB">
<td width="10%" class="usertab"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Short Name</font></td>
<td width="10%" class="usertab"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Type</font></td>
<td width="40%" class="usertab"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Received (skip if notes area is only one section)</font></td>
<td width="40%" class="usertab"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Action Taken</font></td>
</tr>          
               
<tr bgcolor="#f1f1f1">
<td width="10%" valign="top"><input class="txtbox" name="cannedname" size="13"></td>
<td width="10%" valign="top"><select name="cannedsubject" class="txtbox"   >
<option value="ClientStatusSheet">ClientStatusSheet</option>
<option value="LeadConversion">LeadConversion</option>
<option value="Prospects">Prospects</option></select></select></td>
<td width="40%" valign="top"><textarea class="txtbox" rows="4" name="cannedreceived" cols="65"></textarea></td>
<td width="40%"><textarea class="txtbox" rows="4" name="cannedaction" cols="65"></textarea>

</td>
</tr>

<tr bgcolor="#f1f1f1">
<td align="center" colspan=100%><input type="hidden" name="addhotlink" value="1">
<input type="submit" name="Update" value="Add">
</td>
</td>
</tr>

</form>
          
          </table>
        
        <!-- list of calls -->
        </div>
        
        </td>
    </tr>
    <tr> 
      <td>&nbsp; </td>
    </tr>
    </table>
    
      </center>
          </div>
          
      

    
    
    
                   <?php
/////////////END IF TYPE
}
                    ?>
    

         

    <?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>