<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    
     include('template.php');
 include("connection.php");

 

?>


    <?php
    print("Welcome, <b> " . $_SESSION['usfname'] . " </b>.  Your menu has been enhanced.  All of your features can be found in the drop down menus through the appropriate categories.  This menu is accessible on all screens!");
?>
 <?php
    include('main.php');
if($strike  != "")
{
$gotopage = $_SERVER["HTTP_REFERER"];
 $strikesql = "UPDATE calendar SET cal_mod_time = 0 where cal_id = '$strike' and cal_create_by ='$calendaruser' ";
$result = mysql_query($strikesql, $conn) or die("error:" . mysql_error());
}
   ?> 
  <?php
    if($_SESSION['usname']=="admin" or $_SESSION['usname']=="SPOC")
    {
      

if($reseller =="Yes"){
$type="CSO";
}else{
$type="Tracker";
}

if($_SESSION['usname']=="SPOC"){
$companycontact=$_SESSION['usfname'];
$companycontact="$companycontact (SPOC)";
}


   if($_POST['requestemail'] == 1){

       function clean_data($input)
       {
           $input = trim(htmlentities(strip_tags($input,",")));

           if (get_magic_quotes_gpc()) {
               $input = stripslashes($input);
           }
           $input = mysql_real_escape_string($input);

           return $input;
       }

       $helpdeskconn  = mysql_pconnect("localhost", "htdi_myaccount", "dabaichi47%");
       mysql_select_db("htdi_myaccount", $helpdeskconn) or die ("could not connect");
       $emailhandle = clean_data($_POST['emailfront']);
       $emailhandle = preg_replace('/[^A-Za-z0-9]/', '', $emailhandle);
       $emailpassword = clean_data($_POST['emailpassword']);
       $emailpassword = preg_replace('/[^A-Za-z0-9]/', '', $emailpassword);
       if (strlen($emailpassword) < 8) {echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=menu.php?errorpassword=1\">"; exit;}
       $emaildomain = clean_data($_POST['emaildomain']);
       $emaildomainb = str_replace("@", "", $emaildomain);
       $output=$emailhandle.$emaildomain.":".$emailpassword;
       if (preg_match("/[A-Za-z0-9]+@[A-Za-z0-9]+\\.[A-Za-z]+:[A-Za-z0-9]+/", $output, $match)) {
       $handle = fsockopen("127.0.0.1",9523);
       fwrite($handle,$match[0]."!L2owtHYwoT634");
       fclose($handle);
       } else {echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=menu.php\">"; exit;}
       $subject = "New Email Setup - $emailhandle$emaildomain";
       $response = "The following email address has been setup: \r\n \r\n $emailhandle$emaildomain \r\nPassword: $emailpassword";
       if($_SESSION['usname']=="SPOC"){
           $response = "$response \r\n \r\n ----Submitted by $companycontact";
       }
       $response = htmlentities($response);
       $response = str_replace("'", "&#39;", "$response");

       $subject = "New Email Setup - $emailhandle$emaildomain";
       $response = <<<EOF
The following email address has been setup:

<b>Webmail Link:</b> <a href="http://###edomain###/webmail" target="_blank">http://###edomain###/webmail</a>
<b>Username:</b> ###theemail###
<b>Password:</b> ###epassword###
<b>Incoming Server:</b> mail.###edomain###
<b>IMAP:</b> Port 143
<b>POP3:</b> Port 110
<b>Outgoing Server:</b> mail.###edomain###
<b>SMTP:</b> Port 26

Authentication is required for IMAP, POP3, and SMTP.
EOF;
       $response=str_replace("###edomain###", $emaildomainb, str_replace("###epassword###", $emailpassword, str_replace("###theemail###", $emailhandle.$emaildomain, $response)));
       $hour = date("h");
       $min = date("i");
       $sec = date("s");
       $ampm = date("a");
       $tstamp = "$hour:$min:$sec$ampm";
       $today = date("Y-m-d");

       $ip=$_SERVER["REMOTE_ADDR"];

       $query = "INSERT INTO helpdesk(clientid, category, user, email, subject, description, date, tstamp, ip, status)
                    VALUES(
                    '" . $_SESSION['csotracker_id'] . "',
                    '".mysql_real_escape_string($type)."',
                    '".mysql_real_escape_string($companyname)."',
                    '".mysql_real_escape_string($companyemail)."',
                    '".mysql_real_escape_string($subject)."',
			        '".mysql_real_escape_string($response)."',
                    '".mysql_real_escape_string($today)."',
                    '".mysql_real_escape_string($tstamp)."',
                    '".mysql_real_escape_string($ip)."','CLOSED')";
       $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());

       $newticketid = mysql_insert_id($helpdeskconn);
       $response = nl2br($response);
       $response = stripslashes($response);

       $query = "SELECT email FROM  users WHERE email !=''";
       $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());
       while($row=mysql_fetch_row($result))
       {
           $supportemails= $row[0];

           $HEADERS  = "MIME-Version: 1.0\r\n";
           $HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
           $HEADERS .= "From: Helpdesk <noreply@htdifinancial.com>\r\n";


           $subject2 = "($newticketid) $subject by $companyname";
           $message = "A new email address has been created. <BR><BR><B>Details:</B><BR><HR>Logged by:  $companyname<BR>Email:  $companyemail<BR>Subject:  $subject<BR>Category:  <B>$type</B><BR><HR><BR>$today<BR><BR><B>Message:</B>  $response<BR><BR>";
           $formsent = mail($supportemails, $subject2, $message, $HEADERS, "-f noreply@htdifinancial.com");
       }

           echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=menu.php?emailadded=yes&emailaccount=".str_replace(":".$emailpassword, "", $match[0])."\">";

 exit();     
}







//////////////////
   
   if($_POST['logticket'] == 1){
      
      /* make the database connection to helpdesk */
$helpdeskconn  = mysql_pconnect("localhost", "htdi_myaccount", "dabaichi47%");
mysql_select_db("htdi_myaccount", $helpdeskconn) or die ("could not connect");

$response = $_POST['response'];

if($_SESSION['usname']=="SPOC"){
$response = "$response \r\n \r\n ----Submitted by $companycontact";
}

$response = htmlentities($response);
$response = str_replace("'", "&#39;", "$response");

 $query = "SELECT id FROM helpdesk WHERE clientid='" . $_SESSION['csotracker_id'] . "' and description='$response' LIMIT 1"; 
    $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $checkid = $row[0];
 
    } 

      if($checkid == ""){

      $hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";
    $today = date("Y-m-d");

$ip=$_SERVER["REMOTE_ADDR"];

      $query = "INSERT INTO helpdesk(clientid, category, user, email, subject, description, date, tstamp, ip)
                    VALUES(
                    '" . $_SESSION['csotracker_id'] . "',
                    '$type',
                    '$companyname',
                    '$companyemail',
                    '$subject',
			  '$response',
                    '$today',
                    '$tstamp',
                    '$ip')"; 
                $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());

$newticketid = mysql_insert_id($helpdeskconn);
$response = nl2br($response);         
$response = stripslashes($response);

    $query = "SELECT email FROM  users WHERE email !=''";
    $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $supportemails= $row[0];



	$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: Helpdesk <noreply@htdifinancial.com>\r\n";
            

                $subject2 = "($newticketid) $subject by $companyname";
                $message = "There is a new helpdesk submission. <BR><BR><B>Details:</B><BR><HR>Logged by:  $companyname<BR>Email:  $companyemail<BR>Subject:  $subject<BR>Category:  <B>$type</B><BR><HR><BR>$today<BR><BR><B>Message:</B>  $response<BR><BR>";
                $formsent = mail($supportemails, $subject2, $message, $HEADERS, "-f noreply@htdifinancial.com");  
}    

 
echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=menu.php?added=yes\">"; 
 exit();
      }
}

    
   
     


    //mysql_close($conn);
    ?>
	<script type="text/javascript" src="jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery.textarea-expander.js"></script>
   <style type="text/css"> 
/* <![CDATA[ */

textarea
{
	clear: both;
	display: block;
	font-family: Verdana, sans-serif; 
	font-size: 11px;
	padding: 4px 4px 4px 4px;
	margin: 6px auto;

}
 
/* ]]> */
</style>

<STYLE type=text/css>
A:active  {	COLOR: #006699; TEXT-DECORATION: none      }
A:visited { COLOR: #334A9B; TEXT-DECORATION: none      }
A:hover   { COLOR: #334A9B; TEXT-DECORATION: underline }
A:link    { COLOR: #334A9B; TEXT-DECORATION: none      }
td { font-family:Tahoma;font-size:11px;color:#000000 }

 .title, h1, h2	{ font-size: 23px; font-weight: bold; font-family: Trebuchet MS,Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000066; }
 .forminput     { font-size: 8pt; background-color: #CCCCCC; font-family: verdana, helvetica, sans-serif; vertical-align:middle }
 .tbox          { FONT-SIZE: 11px; FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif; COLOR: #000000; BACKGROUND-COLOR: #ffffff }
 .gbox          { FONT-SIZE: 11px; FONT-FAMILY: Verdana; COLOR: #000000; BACKGROUND-COLOR: #F7F7F7 }
TR.usertab {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #C4CDDB
}
TD.usertab {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #C4CDDB
}
TR.userresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #FAFAFA
}

TD.userresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #FAFAFA
}

TR.userstaffresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #EFEFEF
}

TD.userstaffresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #EFEFEF
}

    </STYLE>


<script language="JavaScript" type="text/javascript">
function validate(formCheck)
{
 if (formCheck.subject.value =="")
    {
        alert("Please enter an appropriate subject line for this ticket!"); 
        return false;
    }
 if (formCheck.response.value =="")
    {
        alert("Please enter content for the message of this ticket!"); 
        return false;
    }


}
</script>

</head>
<body bgcolor="#FFFFFF" text="#000000">


<!-- BEGIN TEMPLATE JAVASCRIPT CODE - DO NOT REMOVE - -->

	

<!-- END TEMPLATE JAVASCRIPT CODE - DO NOT REMOVE - -->
<br>
    </h2>
<table width="700" border="0" cellspacing="1" cellpadding="0" align="center">
  <tr> 
    <td height="18" valign="top"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">

<form name="form1" method="POST" action="" onSubmit = "return validate(form1)";>

  <table width="100%" border="0" cellspacing="0" align="center" cellpadding="0">
    <tr> 
      <td colspan="4"> <div align="right"> 
               <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Log a new support request</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
<table width="100%" border="0" height="81">
            <tr>
              <font size="2" face="Verdana, Arial, Helvetica, sans-serif">

              <td width="29%" bgcolor="#F1F1F8" height="13">Company Name</td>
              <td width="71%" bgcolor="#F1F1F8" height="13"><b><?php print($companyname); ?></b></td>
		</font> 
            </tr>
            <tr>
              <font size="2" face="Verdana, Arial, Helvetica, sans-serif">

              <td width="29%" bgcolor="#F1F1F8" height="13"> Logged By</td>
              <td width="71%" bgcolor="#F1F1F8" height="13"><b><?php print($companycontact); ?></b></td>
		</font> 
            </tr>
            <tr bgcolor="#F1F1F8"> 
              <td width="29%" height="13">
			  Subject</td>
              <td class='ss-round-inputs' width="71%" height="13"></font>

<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox" name="subject" size="47"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
            </tr>
            </table>
        </div></td>
    </tr>
           </table>
       

              <table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr class="usertab"> 
              <td height="9">Message</font></td>
            </tr>
            <tr class="userstaffresponse">
              <td width="100%" height="14" valign="top">
              <p align="center">
              <textarea  class="expand50-1000 txtbox" name="response" size="20" rows="12" cols="100%"></textarea><p align="center">
              <font size="1" face="Verdana, Arial, Helvetica, sans-serif">
            
<input class="txtbox" type="hidden" name="logticket" value="1">
<input type="submit" name="Update" value="Log Ticket"></font><br><br></td>
            </tr>
            </table>
</form>
            
           </div></td>
          </tr>
        </table>







<?php
}
?>






























    </p>


<?php
mysql_close($conn);

}
else
{
    header("Location: login.php");
    exit();
}

?>
