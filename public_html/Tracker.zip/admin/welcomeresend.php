<?php
extract ($_GET );
extract ($_POST );

    include_once('common.inc.php');
    session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";
$today = date("Y-m-d");


$nowday = date("d");
$nowmonthword = date("M");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";
$user = $_SESSION['usfname'];

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
    include("connection.php");


$query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, reseller, single, dbname, creditline, passisssn, companyskin, privatelabel FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $reseller = $row[12];              
        $single = $row[13];              
        $dbname = $row[14];          
        $creditline = $row[15];    
        $passisssn = $row[16];       
        $companyskin = $row[17];       
        $privatelabel = $row[18];       
    }
	$poweredbymessage = "<BR><BR><p align=right><a href=\"http://www.creditrepairtracking.com\"><img border=0 src=http://www.creditrepairtracking.com/trackstarlogoforemail.png></a></p>";

$tail = "_Welcome";
$tail2 = "status.php";

 $query = "SELECT id, name, subject, message, type, activated, description FROM systememails WHERE name='$t$tail'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailid           = $row[0];
              $emailname   = $row[1];
              $subject   = $row[2];
              $message   = $row[3];
              $type = $row[4];
              $activated = $row[5];              
              $description = $row[6];    
}
    include_once("companystrip.php");





 if($activated =="Yes" && $t =="Client"){
    $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, comments, reseller_id, status, plan, DATE_FORMAT(dateresults, \"%m-%d-%Y\") as dateresults, singlecouple, showstatus, budgetday, avssnurl, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, altphone FROM clients WHERE id='" . $_SESSION['clientid'] . "' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password = $row[12];
        $broker_id = $row[13];
	  $dealer_id = $row[14];
	  $affiliate_id = $row[15];
	  $comments = $row[16];
	  $reseller_id = $row[17];
	  $status = $row[18];
	  $plan = $row[19];
	  $dateresults = $row[20];
	  $singlecouple = $row[21];
	  $status = $row[22];	  
	  $budgetday = $row[23];	  	  
	  $avssnurl = $row[24];	  	  	  
  	  $logins = $row[25];	  	 
	  $lastlogin = $row[26];	  	   	  
	  $altphone = $row[27];	  	   	  
    }
if ($passisssn == "Yes"){
$password = "********";
}
    include_once("clientstrip.php");
$EMAIL_Message = "$companyskin$message2";
if($privatelabel== "No"){
$EMAIL_Message .= $poweredbymessage;
}
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
        header("Location: $type$tail2?welcomeresend=$activated&data=$t$tail");
}


// BROKER EMAIL

 if($activated =="Yes" && $t =="Broker"){
     $query = "SELECT lastname, firstname, address, city, prov, zipcode, email, fax, telephone, dealership, username, password, comments, dealer_id, affiliate_id FROM dealers WHERE dealer_id='" . $_SESSION['dealer_id'] . "'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lastname = $row[0];
        $firstname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $prov = $row[4];
        $zipcode = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $telephone = $row[8];
        $dealership = $row[9];
        $username = $row[10];
        $password = $row[11];
	    $comments = $row[12];
		$dealer_id = $row[13];			
		$affiliate_id = $row[14];	
}

    include_once("brokerstrip.php");
$EMAIL_Message = "$companyskin$message2";
if($privatelabel== "No"){
$EMAIL_Message .= $poweredbymessage;
}
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
        header("Location: $type$tail2?welcomeresend=$activated&data=$t$tail");
}



// AFFILIATE EMAIL

 if($activated =="Yes" && $t =="Affiliate"){
     $query = "SELECT lname, fname, address, city, state, zip, email, fax, phone, ssn, user, password, comments, alt_phone, commission_rate, id FROM sales_affiliates WHERE id='" . $_SESSION['affiliateid'] . "'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lname = $row[0];
        $fname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $state = $row[4];
        $zip = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $phone = $row[8];
        $ssn = $row[9];
        $user = $row[10];
        $password = $row[11];
	    $comments = $row[12];
	    $altphone = $row[13];	  	   	  
		$commission_rate = $row[14];	 
		$affiliate_id = $row[15];			

    }


   include_once("affiliatestrip.php");
$EMAIL_Message = "$companyskin$message2";
if($privatelabel== "No"){
$EMAIL_Message .= $poweredbymessage;
}
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
        header("Location: $type$tail2?welcomeresend=$activated&data=$t$tail");
}


// PROSPECT EMAIL

 if($activated =="Yes" && $t =="Prospect"){
 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, comments, reseller_id, status, plan, DATE_FORMAT(dateresults, \"%m-%d-%Y\") as dateresults, singlecouple, showstatus, budgetday, avssnurl, logins, DATE_FORMAT(lastlogin, \"%m-%d-%Y\") as lastlogin, altphone, doubleopt, opttimesasked FROM clients WHERE id='$prospectid'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $username = $row[11];
        $password = $row[12];
        $broker_id = $row[13];
	  $dealer_id = $row[14];
	  $affiliate_id = $row[15];
	  $comments = $row[16];
	  $reseller_id = $row[17];
	  $status = $row[18];
	  $plan = $row[19];
	  $dateresults = $row[20];
	  $singlecouple = $row[21];
	  $status = $row[22];	  
	  $budgetday = $row[23];	  	  
	  $avssnurl = $row[24];	  	  	  
  	  $logins = $row[25];	  	 
	  $lastlogin = $row[26];	  	   	  
	  $altphone = $row[27];	  	   	  
	  $doubleopt = $row[28];	  	   	  
	  $opttimesasked = $row[29];	  	   	  
    }

$clientfirstname = explode(' ', $name); 
$clientfirstname = $clientfirstname[0];


if ($doubleopt == "Yes"){

   include_once("clientstrip.php");
$EMAIL_Message = "$companyskin$message2";
if($privatelabel== "No"){
$EMAIL_Message .= $poweredbymessage;
}
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  

}else{
$opttimesasked = $opttimesasked + 1;

if ($opttimesasked <= 5){
// create the MD5 hash 
$secret_code = 'htdiisawesome';
$formatted_email = preg_replace("/(-|\@|\.)/", "", $email);
$hashed = md5("$secret_code $formatted_email");

$mail_body = "$clientfirstname, to validate this email click the following link:\n";
$mail_body .= "$companywebsite/validate.php?m=$hashed&t=wc&w=p&id=$prospectid&eid=4\n";
$mail_body .= "By validating your email address you agree to receive emails from $companyname\n";
$mail_body .= "\n\n\n\n\n\n\n\n\n\n\n\n";
$mail_body .= "To remove yourself from future contact from $companyname, please click the following link instead:\n";
$mail_body .= "$companywebsite/remove.php?m=$hashed&w=p&id=$prospectid\n";

$mail_subject = "Please validate your email address with $companyname";
$mail_from = "From: $companyname <$companyreply>\r\n";
mail($email, $mail_subject, $mail_body, $mail_from);

$query = "UPDATE clients SET
opttimesasked='$opttimesasked'
WHERE id = \"$prospectid\"";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
}else{
$query = "UPDATE clients SET
                email='',
                optMD5hash='',
                doubleopt='',
                optdate='',
                opttstamp='',
                opttimesasked ='0',
                optipaddress=''
WHERE id = \"$prospectid\"";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());

$addtonote="Max number of validations reached.  Removed $email from record.";
$sql_note = "INSERT INTO salesnotes

(clientid,action,counselor,repairdate,filelocation)
               VALUES
(\"$prospectid\",
\"$addtonote\",
\"$user\",
\"$today\",
\"$tstamp\")";
$result_note = @mysql_query($sql_note,$conn);
}


}
       header("Location: $type$tail2?id=$prospectid&welcomeresend=$activated&data=$t$tail");
}



//        header("Location: $type$tail2?welcomeresend=$activated&data=$t$tail");
        exit();
    }
else
{
    header("Location: login.php");
    exit();
}

$page['content'] = ob_get_contents();
ob_end_clean();
include('template.php');
?>
