<?php

extract ($_GET );
extract ($_POST ); 
$message2 = str_replace("{USERNAME}", "$username", $message2);
$subject2 = str_replace("{USERNAME}", "$username", $subject2);
$message2 = str_replace("{PASSWORD}", "$password", $message2);
$subject2 = str_replace("{PASSWORD}", "$pasword", $subject2);
$message2 = str_replace("{F_NAME}", "$firstname", $message2);
$subject2 = str_replace("{F_NAME}", "$firstname", $subject2);
$message2 = str_replace("{L_NAME}", "$lastname", $message2);
$subject2 = str_replace("{L_NAME}", "$lastname", $subject2);
$message2 = str_replace("{BEMAIL}", "$email", $message2);
$subject2 = str_replace("{BEMAIL}", "$email", $subject2);
?>