<?php
extract ($_GET );
extract ($_POST );

$abovedisputes2=$abovedisputes;
$belowdisputes2=$belowdisputes;
$abovedisputes2 = str_replace("{BUREAU}", "$bureauname", $abovedisputes2);
$belowdisputes2 = str_replace("{BUREAU}", "$bureauname", $belowdisputes2);
$abovedisputes2 = str_replace("{BUREAUADDRESS}", "$bureauaddress", $abovedisputes2);
$belowdisputes2 = str_replace("{BUREAUADDRESS}", "$bureauaddress", $belowdisputes2);
$abovedisputes2 = str_replace("{BUREAUADDRESS2}", "$citystatezip", $abovedisputes2);
$belowdisputes2 = str_replace("{BUREAUADDRESS2}", "$citystatezip", $belowdisputes2);
?>