<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   include('template.php');
 include("connection.php");
    if($_REQUEST['del']==1)
    {
        $query = "DELETE FROM accounts WHERE id='" . mysql_real_escape_string($_REQUEST['accid']) . "' LIMIT 1"; 
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Delete Tradeline',
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

    }  
    if($_POST['u']==1)
    {
        $size = sizeof($_POST);
        $kcount =1;

        foreach ($_POST as $key => $value)
        {
            $check = strpos($key, '_');

            if(substr($key,$check)=="_$kcount")
            {
                //$pos = strpos($key, "acname");
                //echo "Key: $key value: $value display _$kcount<br> ";
                if(($pos = strpos($key, "acname")) !== false) {
                  $acname = $value;
                }
                if(($pos = strpos($key, "acnumber")) !== false) {
                  $acnumber = $value;
                }
                if(($pos = strpos($key, "bstatus")) !== false) {
                  $bstatus = $value;
                }
                if(($pos = strpos($key, "s1action")) !== false) {
                  $s1action = $value;
                }
                if(($pos = strpos($key, "s1result")) !== false) {
                  $s1result = $value;
                }
                if(($pos = strpos($key, "s2action")) !== false) {
                  $s2action = $value;
                }
                if(($pos = strpos($key, "s2result")) !== false) {
                  $s2result = $value;
                }
                if(($pos = strpos($key, "s3action")) !== false) {
                  $s3action = $value;
                }
                if(($pos = strpos($key, "s3result")) !== false) {
                  $s3result = $value;
                }
                if(($pos = strpos($key, "s4action")) !== false) {
                  $s4action = $value;
                }
                if(($pos = strpos($key, "s4result")) !== false) {
                  $s4result = $value;
                }
                if(($pos = strpos($key, "s5result")) !== false) {
                  $s5result = $value;
                }
                if(($pos = strpos($key, "s6result")) !== false) {
                  $s6result = $value;
                }
                if(($pos = strpos($key, "s7result")) !== false) {
                  $s7result = $value;
                }
                if(($pos = strpos($key, "s8result")) !== false) {
                  $s8result = $value;
                }
                if(($pos = strpos($key, "s9result")) !== false) {
                  $s9result = $value;
                }                                                                                
                if(($pos = strpos($key, "s1dispute")) !== false) {
                  $s1dispute = $value;
                }
                if(($pos = strpos($key, "deleted")) !== false) {
                  $deleted = $value;
                }
                if(($pos = strpos($key, "s2dispute")) !== false) {
                  $s2dispute = $value;
                }
                 if(($pos = strpos($key, "frivolousnum")) !== false) {
                  $frivolousnum = $value;
                }
                if(($pos = strpos($key, "frivolousdate")) !== false) {
                  $frivolousdate = $value;
                }
				if(($pos = strpos($key, "accid")) !== false) {
                  $accid = $value;
                }
            }
            else
            {
                $kcount = $kcount+1;
                $query = "UPDATE accounts SET name='$acname', number='$acnumber', beginstatus='$bstatus', s1action='$s1action', s1result='$s1result', s2action='$s2action', s2result='$s2result', s3action='$s3action', s3result='$s3result', s4action='$s4action', s4result='$s4result', s5result='$s5result', s6result='$s6result', s7result='$s7result', s8result='$s8result', s9result='$s9result', s1dispute='$s1dispute', deleted='$deleted', s2dispute='$s2dispute', frivolousnum='$frivolousnum', frivolousdate='$frivolousdate' WHERE id='$accid' ";
                //echo "$query <br>";
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
            }
        }
    }

   if($_POST['add']==1)
    {
    $actype2   = $_POST['actype'];
    session_register('actype2');  
    
           // ADDING NEW ACCOUNTS SECTION FOR CLIENT
          // ADDING NEW ACCOUNTS SECTION FOR CLIENT
		  // ADDING NEW ACCOUNTS SECTION FOR CLIENT

          
          
          if(($_POST['whoseaccount']=='client') || ($_POST['whoseaccount']=='bothaccounts'))
          {
          
            if(($_POST['actype']==1) || ($_POST['actype']==2) || ($_POST['actype']==3)) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_POST['actype']) . "',
                    '" . mysql_real_escape_string($_POST['acname']) . "',
                    '" . mysql_real_escape_string($_POST['acnumber']) . "',
                    '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
            }
            if($_POST['actype']==4) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        1,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                        '" . mysql_real_escape_string($_POST['s1dispute']) . "')";

                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        2,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
            }
            if($_POST['actype']==5) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        2,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        3,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
            }
            if($_POST['actype']==6) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        1, 
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        3,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
             }
            if($_POST['actype']==7) 
             {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        1, 
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                 $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        2, 
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                 $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        3, 
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                 $result = mysql_query($query, $conn) or die("error:" . mysql_error());
              }
			  			  ///////CANADA START
	 if(($_POST['actype']==8) || ($_POST['actype']==9)) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                    '" . mysql_real_escape_string($_POST['actype']) . "',
                    '" . mysql_real_escape_string($_POST['acname']) . "',
                    '" . mysql_real_escape_string($_POST['acnumber']) . "',
                    '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
            }
	if($_POST['actype']==10) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        8, 
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                        '" . mysql_real_escape_string($_SESSION['clientid']) . "',
                        9,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
             }
			 ///////CANADA END
              }
              
              
          // ADDING NEW ACCOUNTS SECTION FOR SPOUSE
          // ADDING NEW ACCOUNTS SECTION FOR SPOUSE
		  // ADDING NEW ACCOUNTS SECTION FOR SPOUSE

              
              
              if(($_POST['whoseaccount']=='spouse') || ($_POST['whoseaccount']=='bothaccounts'))
          {
          
            if(($_POST['actype']==1) || ($_POST['actype']==2) || ($_POST['actype']==3)) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                    VALUES(
                    '" . mysql_real_escape_string($_POST['jointwith']) . "',
                    '" . mysql_real_escape_string($_POST['actype']) . "',
                    '" . mysql_real_escape_string($_POST['acname']) . "',
                    '" . mysql_real_escape_string($_POST['acnumber']) . "',
                    '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
            }
            if($_POST['actype']==4) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        1,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        2,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
            }
            if($_POST['actype']==5) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        2,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        3,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
            }
            if($_POST['actype']==6) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        1, 
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        3,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
             }
            if($_POST['actype']==7) 
             {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        1, 
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                 $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        2, 
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                 $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        3, 
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                 $result = mysql_query($query, $conn) or die("error:" . mysql_error());
              }

			  			  			  ///////CANADA START
	 if(($_POST['actype']==8) || ($_POST['actype']==9)) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                    VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                    '" . mysql_real_escape_string($_POST['actype']) . "',
                    '" . mysql_real_escape_string($_POST['acname']) . "',
                    '" . mysql_real_escape_string($_POST['acnumber']) . "',
                    '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
            }
	if($_POST['actype']==10) 
            {
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        8, 
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    
                $query = "INSERT INTO accounts(clientid, accounttype, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s1action, s1dispute)
                        VALUES(
                    	'" . mysql_real_escape_string($_POST['jointwith']) . "',
                        9,
                        '" . mysql_real_escape_string($_POST['acname']) . "',
                        '" . mysql_real_escape_string($_POST['acnumber']) . "',
                        '" . mysql_real_escape_string($_POST['beginstatus']) . "',
                    '" . mysql_real_escape_string($_POST['s1result']) . "',
                    '" . mysql_real_escape_string($_POST['s2result']) . "',
                    '" . mysql_real_escape_string($_POST['s3result']) . "',
                    '" . mysql_real_escape_string($_POST['s4result']) . "',
                    '" . mysql_real_escape_string($_POST['s5result']) . "',
                    '" . mysql_real_escape_string($_POST['s6result']) . "',
                    '" . mysql_real_escape_string($_POST['s7result']) . "',
                    '" . mysql_real_escape_string($_POST['s1action']) . "', 
                    '" . mysql_real_escape_string($_POST['s1dispute']) . "')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
             }
			 ///////CANADA END

              }
              
              
              
              
       }
?>
<?php    
            $query5 = "SELECT plan,reseller_id,prospectclient,status,jointwith,sendtohtdi, country FROM clients WHERE id='" . mysql_real_escape_string($_SESSION['clientid']) . "'";
              $result5 = mysql_query($query5, $conn) or die("error:" . mysql_error());
              while($row5=mysql_fetch_row($result5))
              {
                   $plan = $row5[0];
                   $reseller_id = $row5[1];                   
                   $prospectclient = $row5[2];                     
                   $status = $row5[3];     
                   $jointwith = $row5[4];                   
                   $sendtohtdi = $row5[5];                   
                   $country = $row5[6];                   
                                   
                  }
                  
                  
                  if ($jointwith != ""){

                     $query6 = "SELECT name FROM clients WHERE id='$jointwith'";
              $result6 = mysql_query($query6, $conn) or die("error:" . mysql_error());
              while($row6=mysql_fetch_row($result6))
              {
                   $jointname = $row6[0];
                                   
                  }
                  
                  }

                   if ($reseller_id != ""){
$reseller = "reseller";  
                   }
                   
                   if ($plan == "Budget"){
                   $plan2 = "Budget Account - Draft one bureau at a time!";
                   }
                 elseif ($plan == "Standard"){
                  $plan2 = "";
                  
}
$SA_sql = "SELECT * FROM creditors ORDER BY name";
		$SA_result = @mysql_query($SA_sql,$conn);
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $creditor = $srow['name'];
		$creditor_select .= "<option value=\"$creditor\">$creditor</option>";
		}
			$SA_sql = "SELECT * FROM creditors ORDER BY name";
		$SA_result = @mysql_query($SA_sql,$conn);
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $removecreditorname = $srow['name'];
		    $removecreditorid = $srow['id'];
		$creditor_remove .= "<option value=\"$removecreditorid\">$removecreditorname</option>";
		
		}


	$SA_sql = "SELECT * FROM beginstatus ORDER BY negativetype";
		$SA_result = @mysql_query($SA_sql,$conn);
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $negativetype = $srow['negativetype'];
		$negativetype_select .= "<option value=\"$negativetype\">$negativetype</option>";
		}
		$SA_sql = "SELECT * FROM beginstatus ORDER BY negativetype";
		$SA_result = @mysql_query($SA_sql,$conn);
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $removebeginstatus = $srow['negativetype'];
		    $removebeginstatusid = $srow['id'];
		$beginstatus_remove .= "<option value=\"$removebeginstatusid\">$removebeginstatus</option>";
		
		}

	$SA_sql = "SELECT * FROM tailenddispute ORDER BY tailend";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $tailend= $srow['tailend'];
          
		$tailend_select .= "<option value=\"$tailend\">$tailend</option>";
		
		}
		$SA_sql = "SELECT * FROM tailenddispute ORDER BY tailend";
		$SA_result = @mysql_query($SA_sql,$conn);
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $removetailend = $srow['tailend'];
		    $removetailendid = $srow['id'];
		$tailend_remove .= "<option value=\"$removetailendid\">$removetailend</option>";
		
		}

   $query = "SELECT dropdowncreditors, dropdownbegin, dropdowntails FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dropdowncreditors = $row[0];    
        $dropdownbegin = $row[1];    
        $dropdowntails = $row[2];                            
    }

if ($prospectclient == "Prospect" or $_SESSION['usaccess']=="sales"){
?>
<font color="red"><B>You do not have access to this area </font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 }else {
 

  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")
    {
$menuwidth = 99;
}else{
$menuwidth = 118;
}
?>


   <title><?php print($_SESSION['clname']);?> Without Deleted Items</title>
<SCRIPT LANGUAGE="JavaScript">

function OpenWindow(url,winwidth,winheight) 
{
NewWindow=window.open(url,'descr','toolbar=no,location=0,directories=no,status=no,menubar=no,scrollbar=yes,scrollbars=yes,resizable=yes,copyhistory=no,width='+winwidth+',height='+winheight)
}
</script>

 <script type="text/javascript">

	subject_id = '';
	function handleHttpResponse() {
		if (http.readyState == 4) {
			if (subject_id != '') {
				document.getElementById(subject_id).innerHTML = http.responseText;
			}
		}
	}
	function getHTTPObject() {
		var xmlhttp;
		/*@cc_on
		@if (@_jscript_version >= 5)
			try {
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (E) {
					xmlhttp = false;
				}
			}
		@else
		xmlhttp = false;
		@end @*/
		if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
			try {
				xmlhttp = new XMLHttpRequest();
			} catch (e) {
				xmlhttp = false;
			}
		}
		return xmlhttp;
	}
	var http = getHTTPObject(); // We create the HTTP Object

	function getScriptPage(div_id,content_id)
	{
		subject_id = div_id;
		content = document.getElementById(content_id).value;
		http.open("GET", "template.php?searchpage=creditor&content=" + escape(content), true);
		http.onreadystatechange = handleHttpResponse;
		http.send(null);
		if(content.length>0)
			box('1');
		else
			box('0');

	}	

	function highlight(action,id)
	{
	  if(action)	
		document.getElementById('word'+id).bgColor = "#184EAE";
	  else
		document.getElementById('word'+id).bgColor = "#2E2E2E";
	}
	function display(word)
	{
		document.getElementById('text_content').value = word;
		document.getElementById('box').style.display = 'none';
		document.getElementById('text_content').focus();
	}
	function box(act)
	{
	  if(act=='0')	
	  {
		document.getElementById('box').style.display = 'none';

	  }
	  else
		document.getElementById('box').style.display = 'block';
		document.getElementById('topbox').style.display = 'block';
	}
</script> 

<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function ignoreQuote(string) {
var temp = "";
string = '' + string;
splitstring = string.split("'");
for(i = 0; i < splitstring.length; i++)
temp += splitstring[i];
return temp;

}
//  End -->
</script>
<title>Results Tracker</title>

               <?php
    include('main.php');
   ?>   
            
            


    <script language="JavaScript" fptype="dynamicanimation">
<!--
function dynAnimation() {}
function clickSwapImg() {}
//-->
</script>


<div align="center">
  <center>
      
<BR>
<!--

<STYLE>
#navigation {
	width: 500px;
	height: 10px;
	margin: 0;
	padding: 0;
	
} 
#navigation ul {
	list-style: none;
	margin: 0;
	padding: 0;
} 
#navigation ul li {
	display: inline;
	margin: 0px;
} 
#navigation ul li a {
	height:33px;
	display: block;
	float: left;
	padding: 4px 15px 4px 15px;
	font: bold 11px Arial;
	color: #FFF;
	text-decoration: none;
	background: url(http://www.tcrosystems.net/navigation-separator.png) no-repeat right center;
} 

#navigation ul li a:hover {
	color:#363636;
	background: url('http://www.tcrosystems.net/navigation-hover.png') repeat-x left top;
}

#navigation ul li#active a {
	color:#363636;
	background: url('http://www.tcrosystems.net/navigation-hover.png') repeat-x left top;
}
</STYLE>
    <div id="navigation">
			<ul>
            	<li>
                <p align="center"><a href="clientstatus.php">Client Status<BR>Sheet</a></li>
                <li><p align="center"><a href="creditreport.php">Results Tracker<BR>(all items)</a></li>
				<li><p align="center"><a href="creditreportnodelete.php">Results Tracker<BR>(open only)</a></li>
                 <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")
    {
        ?>
  <li><p align="center"><a href="javascript:OpenWindow2('letters.php','1024','768')">Letter<BR>Menu</a></li>
<?php
}
        ?>

				<li><p align="center"><a href="search.php?cname=&zip=&email=&f=1&Find=Find">Search<BR>Clients</a></li>
			</ul>
	</div>

-->

   <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="50" id="AutoNumber4" cellpadding="0" height="18">
                          <tr>
                            <td width="50%" height="33">
                            <a onmouseover="document['fpAnimswapImgFP1'].imgRolln=document['fpAnimswapImgFP1'].src;document['fpAnimswapImgFP1'].src=document['fpAnimswapImgFP1'].lowsrc;" onmouseout="document['fpAnimswapImgFP1'].src=document['fpAnimswapImgFP1'].imgRolln" href="clientstatus.php">
                            <img border="0" src="http://www.tcrosystems.net/cssoff.gif" id="fpAnimswapImgFP1" name="fpAnimswapImgFP1" dynamicanimation="fpAnimswapImgFP1" lowsrc="http://www.tcrosystems.net/csson.gif" width="97" height="31"></a></td>
                            <td width="25%" height="33">
                            <a href="creditreport.php" onmouseover="document['fpAnimswapImgFP2'].imgRolln=document['fpAnimswapImgFP2'].src;document['fpAnimswapImgFP2'].src=document['fpAnimswapImgFP2'].lowsrc;" onmouseout="document['fpAnimswapImgFP2'].src=document['fpAnimswapImgFP2'].imgRolln">
                            <img border="0" src="http://www.tcrosystems.net/rtoff.gif" id="fpAnimswapImgFP2" name="fpAnimswapImgFP2" dynamicanimation="fpAnimswapImgFP2" lowsrc="http://www.tcrosystems.net/rton.gif" width="97" height="31"></a></td>
                            <td width="25%" height="33">
                            <a href="creditreportnodelete.php" onmouseover="document['fpAnimswapImgFP4'].imgRolln=document['fpAnimswapImgFP4'].src;document['fpAnimswapImgFP4'].src=document['fpAnimswapImgFP4'].lowsrc;" onmouseout="document['fpAnimswapImgFP4'].src=document['fpAnimswapImgFP4'].imgRolln">
                            <img border="0" src="http://www.tcrosystems.net/rtoffoo.gif" id="fpAnimswapImgFP4" name="fpAnimswapImgFP4" dynamicanimation="fpAnimswapImgFP4" lowsrc="http://www.tcrosystems.net/rtonoo.gif" width="97" height="31"></a></td>
                            
                              <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")
    {
        ?>
                            <td width="25%" height="33">
                            <a href="javascript:OpenWindow2('letters.php','1024','768')" onmouseover="document['fpAnimswapImgFP5'].imgRolln=document['fpAnimswapImgFP5'].src;document['fpAnimswapImgFP5'].src=document['fpAnimswapImgFP5'].lowsrc;" onmouseout="document['fpAnimswapImgFP5'].src=document['fpAnimswapImgFP5'].imgRolln">
                            <img border="0" src="http://www.tcrosystems.net/lmoff.gif" id="fpAnimswapImgFP5" name="fpAnimswapImgFP5" dynamicanimation="fpAnimswapImgFP5" lowsrc="http://www.tcrosystems.net/lmon.gif" width="97" height="31"></a></td>
                            <?php
}
        ?>

                            
                            <td width="25%" height="33">
                            <a href="search.php?cname=&zip=&email=&f=1&Find=Find" onmouseover="document['fpAnimswapImgFP3'].imgRolln=document['fpAnimswapImgFP3'].src;document['fpAnimswapImgFP3'].src=document['fpAnimswapImgFP3'].lowsrc;" onmouseout="document['fpAnimswapImgFP3'].src=document['fpAnimswapImgFP3'].imgRolln">
                            <img border="0" src="http://www.tcrosystems.net/searchoff.gif" id="fpAnimswapImgFP3" name="fpAnimswapImgFP3" dynamicanimation="fpAnimswapImgFP3" lowsrc="http://www.tcrosystems.net/searchon.gif" width="97" height="31"></a></td>
                          </tr>
                   <!--       <tr>
                            <td width="50%" height="1">
                            </td>
                            <td width="25%" valign="top" height="1">
                            <p align="center">
                            <a href="creditreport.php?bureauid=1">
                            <img border="0" src="http://www.tcrosystems.net/efx.gif" width="32" height="10"></a><a href="creditreport.php?bureauid=2"><img border="0" src="http://www.tcrosystems.net/exp.gif" width="32" height="10"></a><a href="creditreport.php?bureauid=3"><img border="0" src="http://www.tcrosystems.net/tu.gif" width="32" height="10"></a></td>
                            <td width="25%" valign="top" height="1">
                            <p align="center">
                            <a href="creditreportnodelete.php?bureauid=1">
                            <img border="0" src="http://www.tcrosystems.net/efx.gif" width="32" height="10"></a><a href="creditreportnodelete.php?bureauid=2"><img border="0" src="http://www.tcrosystems.net/exp.gif" width="32" height="10"></a><a href="creditreportnodelete.php?bureauid=3"><img border="0" src="http://www.tcrosystems.net/tu.gif" width="32" height="10"></a></td>
                            
                            <td width="25%" height="1">
                            </td>

                            
                            <td width="25%" height="1">
                            </td>
                          </tr>
-->
</table>   
            

            


            
            
            </p></center> </div>





            <form action="" method="post" name=form>
            <?php
            
             if($bureauid !="")   {
 $bureauquery = " AND id = '$bureauid'";
 } 
             if($country =="" or $country=="United States")   {
 $countryquery = "WHERE country = 'United States'";
 $bureaudropdown ="<option value=\"1\">Equifax</option>";
 $bureaudropdown .="<option value=\"2\">Experian</option>";
 $bureaudropdown .="<option value=\"3\">TransUnion</option>";
 $bureaudropdown .="<option value=\"4\">Equifax &amp; Experian</option>";
 $bureaudropdown .="<option value=\"5\">Experian &amp; Trans Union</option>";
 $bureaudropdown .="<option value=\"6\">Equifax &amp; Trans Union</option>";
 $bureaudropdown .="<option value=\"7\">All Three</option>";

 } else if($country=="Canada")   {
 $countryquery = "WHERE country = '$country'";
 $bureaudropdown ="<option value=\"8\">Equifax</option>";
 $bureaudropdown .="<option value=\"9\">TransUnion</option>";
 $bureaudropdown .="<option value=\"10\">Both</option>";

 
 } else{
 $countryquery = "WHERE country = '$country'";
 }



                 $i = 1;
                 $query = "SELECT id, type FROM accounttype $countryquery $bureauquery";
                 $result = mysql_query($query, $conn) or die("error:" . mysql_error());
                 
                 while($row=mysql_fetch_row($result))
                 {
                     $actypeid = $row[0];
                     $actype = $row[1];
                     
                    if($actypeid ==1)   {
    $image = "<font color=#CB0101 size=4 face=Trebuchet MS><b>Equifax</b></font>&nbsp;&nbsp;<a href=creditreportnodelete.php?bureauid=$actypeid><img border=0 src=http://www.tcrosystems.net/magnglass.png></a>";
    }else if($actypeid ==2){
    $image = "<font color=#1F5394 size=4 face=Trebuchet MS><b>Experian</b></font>&nbsp;&nbsp;<a href=creditreportnodelete.php?bureauid=$actypeid><img border=0 src=http://www.tcrosystems.net/magnglass.png></a>";
        }else if($actypeid ==3){
    $image = "<font face=Trebuchet MS size=4 color=#9D9C9C><b>Trans</font></b><font face=Trebuchet MS size=4 color=#009966><b>Union</font></b>&nbsp;&nbsp;<a href=creditreportnodelete.php?bureauid=$actypeid><img border=0 src=http://www.tcrosystems.net/magnglass.png></a>";
            }else if($actypeid ==8){
    $image = "<font color=#CB0101 size=4 face=Trebuchet MS><b>Equifax</b></font>&nbsp;&nbsp;<a href=creditreportnodelete.php?bureauid=$actypeid><img border=0 src=http://www.tcrosystems.net/magnglass.png></a>";
            }else if($actypeid ==9){
    $image = "<font face=Trebuchet MS size=4 color=#009966><b>TransUnion</font></b>&nbsp;&nbsp;<a href=creditreportnodelete.php?bureauid=$actypeid><img border=0 src=http://www.tcrosystems.net/magnglass.png></a>";
            }
                     ?>
         <P align=left><?php print($image); ?>

         <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#000080
            cellSpacing=0 cellPadding=2 width="100%" border=0 background="bluestrip.gif">
              <TBODY>
              <TR>
                <TD style="border-right-style: solid; border-right-width: 1; border-top-style: solid; border-top-width: 1; border-bottom-style: solid; border-bottom-width: 1"></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Account Name</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Account Number</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Beginning Status</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Action</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Step 1 Results</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Step 2 Results</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Step 3 Results</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Step 4 Results</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Step 5 Results</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Step 6 Results</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Step 7 Results</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Step 8 Results</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Step 9 Results</b></font></TD>
                <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")
    {
        ?>         
        <TD style="border-style: solid; border-width: 1"><font color="#FFFFFF"><b>Step 1 Dispute</b></font></TD>
                <TD style="border-style: solid; border-width: 1">
                <font color="#FFFFFF"><b>Step 2 Dispute</b></font></TD>
                <?php
 }
        ?>         
                <TD style="border-left-style: solid; border-left-width: 1; border-bottom-style:solid; border-bottom-width:1"></TD>
            </TR>
<?php

              $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, comments, dispute, s1dispute, deleted, s2dispute, s5result, s6result, s7result, s8result, s9result, frivolousnum, frivolousdate  FROM accounts WHERE (deleted='open' or deleted='Olddate') and clientid='" . mysql_real_escape_string($_SESSION['clientid']) . "' and accounttype='$actypeid'";
              $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
              while($row2=mysql_fetch_row($result2))
              {
                   $accid = $row2[0];
                   $acname = $row2[1];
                   $acnumber = $row2[2];
                   $beginstatus = $row2[3];
                   $s1action = $row2[4];
                   $s1result = $row2[5];
                   $s2action = $row2[6];
                   $s2result = $row2[7];
                   $s3action = $row2[8];
                   $s3result = $row2[9];
                   $s4action = $row2[10];
                   $s4result = $row2[11];
                   $comments = $row2[12];
                   $dispute = $row2[13];
                   $s1dispute = $row2[14];
                   $deleted = $row2[15];
                   $s2dispute = $row2[16];
                   $s5result = $row2[17];
                   $s6result = $row2[18];
                   $s7result = $row2[19];
                   $s8result = $row2[20];
                   $s9result = $row2[21];    
				   $frivolousnum = $row2[22];                   
                   $frivolousdate = $row2[23];
                                                                                                              
                   $i = $i+1;
                     if($deleted=="Deleted" or $deleted=="Fixed"){
         $textcss = "txtboxdeleted";
}else{
                    $textcss = "txtbox";
}

?>

             <TR>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <input type="hidden" name="actypeid_<?php print($i);?>" value="<?php print($actypeid); ?>">
                 <input type="hidden" name="accid_<?php print($i);?>" value="<?php print($accid); ?>">
                 <select name="deleted_<?php print($i);?>" class="<?php print($textcss);?>" >
                 <option value selected="<?php print($deleted); ?>"><?php print($deleted); ?></option>
                <option value="Open">Open</option>
                <option value="Creditor">Creditor</option>                   
                <option value="Hold">Hold</option>                
                <option value="Inquiry">Inquiry</option>                      
                <option value="Fixed">Fixed</option>
                <option value="Deleted">Deleted</option>
                 </select>
                 
                </TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="acname_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($acname); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="acnumber_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($acnumber); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="bstatus_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($beginstatus); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s1action_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($s1action); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s1result_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($s1result); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s2result_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($s2result); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s3result_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($s3result); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s4result_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($s4result); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s5result_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($s5result); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s6result_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($s6result); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s7result_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($s7result); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s8result_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($s8result); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s9result_<?php print($i);?>" rows="2" cols="24" onChange="this.value=ignoreQuote(this.value)"><?php print($s9result); ?></textarea></TD>
             
 <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")

    {
        ?>
   <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s1dispute_<?php print($i);?>" rows="2" cols="85" onChange="this.value=ignoreQuote(this.value)"><?php print($s1dispute); ?></textarea></TD>
                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1">
                <textarea class="<?php print($textcss);?>" name="s2dispute_<?php print($i);?>" rows="2" cols="85" onChange="this.value=ignoreQuote(this.value)"><?php print($s2dispute); ?></textarea></TD>

                <TD class="<?php print($textcss);?>" style="border-top-style: solid; border-top-width: 1"> 
             


<a href="creditreportnodelete.php?del=1&accid=<?php print($accid);?>"><img border="0" src="http://www.tcrosystems.net/deletebutton.png"></a>

 
              <?php
}
        ?>
</TD>
             </TR>
<?php
    }
?>
                </TBODY>
              </TABLE>
<?php
  }
?>
 
              <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")
    {
        ?>
<BR>
<input type="hidden" name="u" value="1"> <input type="submit" name="Update" value="Update">
</form>

 
              <?php
}
        ?>

 
              <?php
  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")
    {
        ?>

              
                <form action="" method="post" name="formname">
                 <p>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="1021">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Add New Account for 
   
              <select class="txtbox" name="whoseaccount" >

              <option value="client" selected><? print $_SESSION['clname']; ?> - <? print $_SESSION['clientid']; ?></option>
              
               <?php
    if($jointwith != "")
    {
        ?>
                <option value="spouse"><? print $jointname; ?> - <? print $jointwith; ?></option>
                <option value="bothaccounts"><? print $_SESSION['clname']; ?> 
                and <? print $jointname; ?></option>          
                             <?php
}
        ?>     
              </select>

</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

                <table border="0" cellpadding="0" cellspacing="0" bordercolor="#000080" width="1021" style="border-collapse: collapse" background="bluestripshort.gif">
                  <tr>
                    <td width="103" style="border-left-style: solid; border-left-width: 1">
                    <font color="#FFFFFF">Account Type</font></td>
                    <td width="332">
                    
                    
                          <?php
if($_SESSION['actype2']==1){
	$actypename = "Equifax";
	}
else if($_SESSION['actype2']==2){
	$actypename = "Experian";
	}
 else if($_SESSION['actype2']==3){
	$actypename = "Trans Union";
	}
else if($_SESSION['actype2']==4){
	$actypename = "Equifax &amp; Experian";
	}
else if($_SESSION['actype2']==5){
	$actypename = "Experian &amp; Trans Union";
	}
else if($_SESSION['actype2']==6){
	$actypename = "Equifax &amp; Trans Union";
	}
else if($_SESSION['actype2']==7){
	$actypename = "All Three";
	}
else if($_SESSION['actype2']==8){
	$actypename = "Equifax";
	}
else if($_SESSION['actype2']==9){
	$actypename = "Transunion";
	}
else if($_SESSION['actype2']==10){
	$actypename = "Both";
	}


?>

       <select class="txtbox" name="actype" >
              
              <option value="<? print $_SESSION['actype2']; ?>"><? print $actypename; ?></option>
              <? print $bureaudropdown; ?>
              </select>

                 </td>
                    <td width="586" rowspan="12" style="border-right-style: solid; border-right-width: 1">
              &nbsp;<table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
                <tr>
                  <td width="25%">&nbsp;
</td>
                </tr>
              </table>
                 </td>
                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
  <font color="#FFFFFF">Account Name</font></td>



                  <td width="332">
                  
                  
                 
     
              <div class="ajax-div">
	<div class="input-div">
<input class="txtbox" name="acname" type="text" size="26" onChange="this.value=ignoreQuote(this.value)" onKeyUp="getScriptPage('box','text_content')" id="text_content">
</div>
<div id="box"></div>
</div>
             

                 


                 </td>
                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Account Number</font></td>
                  <td width="332">
                  <input class="txtbox" name="acnumber" type="text" id="acnumber" size="26" onChange="this.value=ignoreQuote(this.value)"></td>
                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Beginning Status</font></td>
                  <td width="332">
                  
                  
                    <?php
 
if ($dropdownbegin == "Yes"){
?>

                  
                  
                  <select class="txtbox" id="beginstatus"  name="beginstatus">

                  <option value="" selected></option>
					    <? echo "$negativetype_select"; ?>
						
					    </select>
					     <?php
}else{
?>
<input class="txtbox" name="beginstatus" type="text" id="beginstatus" size="26" onChange="this.value=ignoreQuote(this.value)">
      <?php
}
?>   
					    
					    
					    
					    
					    </td>
                 </tr>
              <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Action</font></td>
                  <td width="332">
                  <input class="txtbox" name="s1action" type="text" id="s1action" size="26" onChange="this.value=ignoreQuote(this.value)"></td>
                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Step 1 Result</font></td>
                  <td width="332">
                  <input class="txtbox" name="s1result" type="text" id="s1result" size="26" onChange="this.value=ignoreQuote(this.value)"></td>
                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Step 2 Result</font></td>
                  <td width="332">
                  <input class="txtbox" name="s2result" type="text" id="s2result" size="26" onChange="this.value=ignoreQuote(this.value)"></td>
                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Step 3 Result</font></td>
                  <td width="332">
                  <input class="txtbox" name="s3result" type="text" id="s3result" size="26" onChange="this.value=ignoreQuote(this.value)"></td>
                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Step 4 Result</font></td>
                  <td width="332">
                  <input class="txtbox" name="s4result" type="text" id="s4result" size="26" onChange="this.value=ignoreQuote(this.value)"></td>
                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Step 5 Result</font></td>
                  <td width="332">
                  <input class="txtbox" name="s5result" type="text" id="s5result" size="26" onChange="this.value=ignoreQuote(this.value)"></td>
                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Step 6 Result</font></td>
                  <td width="332">
                  <input class="txtbox" name="s6result" type="text" id="s6result" size="26" onChange="this.value=ignoreQuote(this.value)"></td>
                 </tr>
                  <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Step 7 Result</font></td>
                  <td width="332">
                  <input class="txtbox" name="s7result" type="text" id="s7result" size="26" onChange="this.value=ignoreQuote(this.value)"></td>
                  </tr>

                  <td width="103" style="border-left-style: solid; border-left-width: 1">
                  <font color="#FFFFFF">Tail End Dispute</font></td>
                  <td width="918" colspan="2" style="border-right-style: solid; border-right-width: 1">


<?php
 
if ($dropdowntails == "Yes"){
?>

                  <select class="txtbox" id="s1dispute"  name="s1dispute">

                  <option value="" selected></option>
					    <? echo "$tailend_select"; ?>
						
					    </select>
			  <?php
}else{
?>
<input class="txtbox" name="s1dispute" type="text" id="s1dispute" size="130" onChange="this.value=ignoreQuote(this.value)">
      <?php
}
?>   
		    
					    
					    
					    
					    </td>
                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1; border-bottom-style:solid; border-bottom-width:1"> <input type="hidden" name="add"  value="1">
                 <input type="hidden" name="jointwith"  value="<? print $jointwith; ?>">

                

                 <input type="submit" name="Add" value="Add">
                 <input type="reset" name="Reset" value="Clear"></td>
                  <td width="918" colspan="2" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                 
</td> 

                 </tr>  </table>
                 </form> 
                                 <table border="0" cellpadding="0" cellspacing="0" bordercolor="#000080" width="1021" style="border-collapse: collapse" background="bluestripshort.gif">
 <?php
 
if ($dropdowncreditors == "Yes"){
?>

                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1; border-bottom-style:solid; border-bottom-width:1"> 
                  <font color="#FFFFFF">Add Creditor </font></td>
                  <td width="366" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                  <form action="addtodb.php" method="post" name=form5>
                  <input class="txtbox" name="newcreditorname" type="text" id="newcreditorname" size="38" onChange="this.value=ignoreQuote(this.value)">
                  <input type="hidden" name="addnewcreditor"  value="1"><input type="submit" name="Add" value="Add"></form>

                  </td> 

                  <td width="552" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                  <form action="addtodb.php" method="post" name=form2>
                  <font color="#FFFFFF">Remove 
                  Creditor </font>
                  <select class="txtbox" id="removecreditorname"  name="removecreditorname">

                  <option value="" selected></option>
					    <? echo "$creditor_remove"; ?>
						</select>
                  <input type="hidden" name="removecreditor"  value="1"><input type="submit" name="Remove" value="Remove"></form>
</td> 

                 </tr>
                 <?php
 }
if ($dropdownbegin == "Yes"){
?>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1; border-bottom-style:solid; border-bottom-width:1"> 
                  <font color="#FFFFFF">Add Status </font></td>
                  <td width="366" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                                    <form action="addtodb.php" method="post" name=form3>
<input class="txtbox" name="newbeginstatus" type="text" id="newbeginstatus" size="38" onChange="this.value=ignoreQuote(this.value)">
                                    <input type="hidden" name="addnewbeginstatus"  value="1"><input type="submit" name="Add" value="Add"></form>

                  </td> 

                  <td width="459" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                                      <form action="addtodb.php" method="post" name=form6>
                  <font color="#FFFFFF">Remove Status </font>
                  <select class="txtbox" id="removenegativetype"  name="removenegativetype">

                  <option value="" selected></option>
					    <? echo "$beginstatus_remove"; ?>
						
					    </select>
                  <input type="hidden" name="removebeginstatus"  value="1"><input type="submit" name="Remove" value="Remove"></form>
</td> 

                 </tr>
                 
                 <?php
 }
if ($dropdowntails == "Yes"){
?>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1; border-bottom-style:solid; border-bottom-width:1"> 
                  <font color="#FFFFFF">Add Tail End </font></td>
                  <td width="918" colspan="2" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                 <form action="addtodb.php" method="post" name=form4>
 <p>
 <input class="txtbox" name="news1dispute" type="text" id="news1dispute" size="113" onChange="this.value=ignoreQuote(this.value)">
                                    <input type="hidden" name="addnews1dispute"  value="1"><input type="submit" name="Add" value="Add"></p>
                 </form>

                  </td> 

                 </tr>
                 <tr>
                  <td width="103" style="border-left-style: solid; border-left-width: 1; border-bottom-style:solid; border-bottom-width:1"> 
                  <font color="#FFFFFF">Remove Tail End </font></td>
                  <td width="918" colspan="2" style="border-right-style: solid; border-right-width: 1; border-bottom-style: solid; border-bottom-width: 1">
                 <form action="addtodb.php" method="post" name=form7>
                  <select class="txtbox" id="removetailid"  name="removetailid">

                  <option value="" selected></option>
					    <? echo "$tailend_remove"; ?>
						
					    </select>
                                    <input type="hidden" name="removetailend"  value="1"><input type="submit" name="Remove" value="Remove"></form>

                  </td> 

                 </tr>
                 <?php
 
}
?>
                </table>
                
               
                </form>
                
                 
              <?php
}
        ?>

             <p>&nbsp;</p>
             <P align=left><a href="clientstatus.php">Client Status Sheet</a></P>
              <p align="left"><a href="search.php?status=pending&zip=&email=&f=1&Find=Find">Search Another Client</a></p>

             <P align=left>&nbsp;</P>

    <?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>