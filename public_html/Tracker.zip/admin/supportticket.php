<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    
     include('template.php');
 include("connection.php");

 

?>


   
 <?php
    include('main.php');
if($strike  != "")
{
$gotopage = $_SERVER["HTTP_REFERER"];
 $strikesql = "UPDATE calendar SET cal_mod_time = 0 where cal_id = '$strike' and cal_create_by ='$calendaruser' ";
$result = mysql_query($strikesql, $conn) or die("error:" . mysql_error());
}
   ?> 
  <?php
    if($_SESSION['usname']=="admin" or $_SESSION['usname']=="SPOC")
    {
     
/* make the database connection to helpdesk */
$helpdeskconn  = mysql_pconnect("localhost", "htdi_myaccount", "dabaichi47%");
mysql_select_db("htdi_myaccount", $helpdeskconn) or die ("could not connect");



   if($_POST['addhdresponse'] == 1){
      
$response = $_POST['response'];

if($_SESSION['usname']=="SPOC"){
$companycontact=$_SESSION['usfname'];
$companycontact="$companycontact (SPOC)";
$response = "$response \r\n \r\n ----Submitted by $companycontact";
}

$response = htmlentities($response);
$response = str_replace("'", "&#39;", "$response");

 $query = "SELECT id FROM helpdeskresponses WHERE ticketid='$supportid' and response='$response' LIMIT 1"; 
    $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $checkid = $row[0];
 
    } 

      if($checkid == ""){

      $hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");
$tstamp = "$hour:$min:$sec$ampm";
$ip=$_SERVER["REMOTE_ADDR"];
    $today = date("Y-m-d");

      $query = "INSERT INTO helpdeskresponses(ticketid, byuser, response, date, tstamp, ip)
                    VALUES(
                    '$supportid',
                    '$companycontact',
			  '$response',
                    '$today',
                    '$tstamp',
                    '$ip')"; 
                $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());



        $query = "UPDATE helpdesk SET status='OPEN' WHERE id='$supportid'";
        $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());


    $query = "SELECT email FROM  users WHERE email !=''";
    $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $supportemails= $row[0];



	$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: TCRO Helpdesk <noreply@tcrosystems.com>\r\n";
            

                $subject2 = "RE: ($supportid) $supportsubject by $companyname";
                $message = "Logged by:  $companyname<BR>Email:  $companyemail<BR>Subject:  $supportsubject<BR><BR><HR><BR>$today<BR><BR><B>Message:</B>  $response<BR><BR>";
                $formsent = mail($supportemails, $subject2, $message, $HEADERS, "-f noreply@tcrosystems.com");  
}    





      }
}

    
       $query = "SELECT id, status, subject, description, DATE_FORMAT(date, \"%m-%d-%Y\") as supportlogdate,  tstamp, ip FROM helpdesk WHERE deleted !='Yes' and  (category='CSO' or category='Tracker') and clientid='" . $_SESSION['csotracker_id'] . "' and id=$supportid"; 
    $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $supportid= $row[0];
        $supportstatus = $row[1];
        $supportsubject = $row[2];
        $supportdescription = $row[3];
        $supportlogdate= $row[4];
        $supporttstamp= $row[5];
        $supportip= $row[6];
$supportdescription = nl2br($supportdescription);         

}
      if($supportstatus !=""){
     


    //mysql_close($conn);
    ?>

	<script type="text/javascript" src="jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery.textarea-expander.js"></script>
   <style type="text/css"> 
/* <![CDATA[ */

textarea
{
	clear: both;
	display: block;
	font-family: Verdana, sans-serif; 
	font-size: 11px;
	padding: 4px 4px 4px 4px;
	margin: 6px auto;

}
 
/* ]]> */
</style>

<STYLE type=text/css>
A:active  {	COLOR: #006699; TEXT-DECORATION: none      }
A:visited { COLOR: #334A9B; TEXT-DECORATION: none      }
A:hover   { COLOR: #334A9B; TEXT-DECORATION: underline }
A:link    { COLOR: #334A9B; TEXT-DECORATION: none      }
td { font-family:Tahoma;font-size:11px;color:#000000 }

 .title, h1, h2	{ font-size: 23px; font-weight: bold; font-family: Trebuchet MS,Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000066; }
 .forminput     { font-size: 8pt; background-color: #CCCCCC; font-family: verdana, helvetica, sans-serif; vertical-align:middle }
 .tbox          { FONT-SIZE: 11px; FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif; COLOR: #000000; BACKGROUND-COLOR: #ffffff }
 .gbox          { FONT-SIZE: 11px; FONT-FAMILY: Verdana; COLOR: #000000; BACKGROUND-COLOR: #F7F7F7 }
TR.usertab {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #C4CDDB
}
TD.usertab {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #C4CDDB
}
TR.userresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #FAFAFA
}

TD.userresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #FAFAFA
}

TR.userstaffresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #EFEFEF
}

TD.userstaffresponse {
	FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #EFEFEF
}

    </STYLE>
</head>
<body bgcolor="#FFFFFF" text="#000000">


<!-- BEGIN TEMPLATE JAVASCRIPT CODE - DO NOT REMOVE - -->

	<script language="javascript">
      function DisableForm (formname)  
	  	<!-- Prevent The Form being submitted twice -->
	      {
                browser = new String(navigator.userAgent);
			    if (browser.match(/IE/g))  { for (i=1; i<formname.elements.length; i++)   {   if (formname.elements[i].type == 'submit')  {  formname.elements[i].disabled = true;  } } }
		        formname.submit();
		  }
		  
      function Disable (formname)  
	      {
		      for (i=1; i<formname.elements.length; i++)   {   if (formname.elements[i].type == 'text')  {  formname.elements[i].onFocus = blur;  }  }
		  }
	</script>
<!-- END TEMPLATE JAVASCRIPT CODE - DO NOT REMOVE - -->
<br>
    </h2>
<table width="700" border="0" cellspacing="1" cellpadding="0" align="center">
  <tr> 
    <td height="18" valign="top"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">

  <table width="100%" border="0" cellspacing="0" align="center" cellpadding="0">
    <tr> 
      <td colspan="4"> <div align="right"> 
                 <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Support Ticket ID #<?php print($supportid); ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
<table width="100%" border="0" >



            <tr bgcolor="#F1F1F8"> 
              <td width="29%" height="13"> Status</td>
              <td width="71%" height="13"><b><?php print($supportstatus); ?></b></td>
            </tr>
            <tr bgcolor="#F1F1F8"> 
              <td width="29%" height="13"> Logged</td>
              <td width="71%" bgcolor="#F1F1F8" height="13"><?php print($supportlogdate); ?></td>
            </tr>
            <tr bgcolor="#F1F1F8"> 
              <td width="29%" height="13"> IP Address</td>
              <td width="71%" bgcolor="#F1F1F8" height="13"><?php print($supportip); ?></td>
            </tr>
          </table>
        </div></td>
    </tr>
    <tr> 
      <td colspan="4">&nbsp; </td>
    </tr>
    <tr> 
      <td colspan="4" valign="top"> <table width="99%" border="0" align="center" cellpadding="7">
          <tr> 
            <td class="usertab"><b><?php print($supportsubject); ?></b></td>
          </tr>
          <tr> 
            <td bgcolor="#F1F1F8"> <div align="left"><?php print($supportdescription); ?></div></td>
          </tr>
        </table>
        <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr> 
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td class="usertab"><b> User/Staff Follow-ups</b></td>
          </tr>
          <tr> 
            <td> <div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">
            
            
<?php

           $query = "SELECT id, byuser, response, DATE_FORMAT(date, \"%m-%d-%Y\") as supportresponsedate,  tstamp, ip FROM helpdeskresponses WHERE ticketid='$supportid' order by id"; 
    $result = mysql_query($query, $helpdeskconn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $supportid= $row[0];
        $byuser = $row[1];
        $response = $row[2];
        $supportresponsedate= $row[3];
        $supporttstamp= $row[4];
        $supportiptstamp= $row[5];

$response = nl2br($response);         

        ?>
          <table width="100%" border="0" cellspacing="1" cellpadding="3">
            <tr class="userstaffresponse">
              <td width="30%" height="14" valign="top"><b><?php print($byuser); ?><br></b><?php print($supportresponsedate); ?> at <?php print($supporttstamp); ?> <br><br></td>
              <td width="70%" height="14" valign="top"><?php print($response); ?></td>
            </tr>
            <tr class="userstaffresponse">
              <td colspan=2 valign="top" style="background-color: #FFFFFF">
              <hr color="#F1F1F8" width="50%"></td>
            </tr>
            </table>
              

<?php

 }

        ?>
  <form action="" method="post">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Add a Response?</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
              <table width="100%" border="0" cellspacing="1" cellpadding="3">

            <tr class="userstaffresponse">
              <td width="100%" height="14" valign="top">
              <p align="center">
              <textarea  class="expand50-1000 txtbox" name="response" size="20" rows="12" cols="100%"></textarea><p align="center">
              <font size="1" face="Verdana, Arial, Helvetica, sans-serif">
            
             <input class="txtbox" type="hidden" name="addhdresponse" value="1">
             <input class="txtbox" type="hidden" name="supportsubject" value="<?php print($supportsubject); ?>">

 <input type="submit" name="Update" value="Add Response"></font><br><br></td>
            </tr>
            </table>
</form>
            
           </div></td>
          </tr>
        </table></td>
    </tr>
   
  </table>
		</font> </div></td>
  </tr>
</table>
    







  <?php
}}
?>






























    </p>


<?php
mysql_close($conn);

}
else
{
    header("Location: login.php");
    exit();
}

?>