<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1 && $_SESSION['usname']=="admin"){

   include("connection.php");
   $i =1;

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);


$nowday = date("d");
$nowmonthword = date("M");
$nowmonthword2 = date("F");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

$thismonth = date("Y-m");


   $filename = "Broker Referral Report " . date("Y-m-d");
   $ext = 'csv';

   header("Content-type: text/plain");
   header('Content-Disposition: attachment; filename="' . $filename . '.' . $ext . '"');
   header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
   header('Pragma: no-cache');
   header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
   header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1

       echo("id,First Name,Last Name,Email,Phone,Company,Prospects,Clients,Closing Ratio\r\n");
	if ($startdate !="" and $enddate !="" and $startdate !="YYYY-MM-DD" and $enddate !="YYYY-MM-DD"){
$leadquery = "((clients.leadentered >= '$startdate' AND clients.leadentered <= '$enddate') or (clients.createdate >= '$startdate' AND clients.createdate <= '$enddate')) ";
$salesquery= "createdate >= '$startdate' AND createdate <= '$enddate' ";



	}else{
$leadquery = "((clients.leadentered like '$thismonth%') or (clients.createdate like '$thismonth%')) ";
$salesquery= "createdate like '$thismonth%' ";
$daterange = " - $nowmonthword2 $nowyear";
$startdate = "YYYY-MM-DD";
$enddate = "YYYY-MM-DD";
}


$query2 = "SELECT COUNT(clients.id), clients.broker_id, dealers.firstname, dealers.lastname, dealers.dealership, dealers.email, dealers.telephone, clients.singlecouple FROM clients,dealers WHERE clients.broker_id=dealers.dealer_id and clients.broker_id !='' and clients.clientdelete != 'yes' and clients.status != 'inactive' and $leadquery and dealers.status !='9' GROUP BY clients.broker_id ORDER BY 1 DESC" ;
$result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
$numberprospects = 0;
while($row2=mysql_fetch_row($result2))
{
              $numberprospects           = $row2[0];
              $broker_id           = $row2[1];
              $brokerfirstname           = $row2[2];
              $brokerlastname           = $row2[3];
              $brokercompany = $row2[4];
              $brokeremail = $row2[5];
              $brokerphone = $row2[6];



 $totalprospects = $totalprospects + $numberprospects;
       $cnt++;
$numberclients = '0';
$query3 = "SELECT COUNT(id) FROM clients WHERE broker_id ='$broker_id' and clientdelete != 'yes' and prospectclient='Client' and $salesquery GROUP BY broker_id";
$result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
while($row3=mysql_fetch_row($result3))
{
              $numberclients = $row3[0];

 $totalclients = $totalclients + $numberclients;

}
$closingratio =0;
if ($numberprospects !="0"){
$closingratio = $numberclients/$numberprospects*100;
  $closingratio = number_format($closingratio, 2, '.', '');

}
	   
	  
           echo("$broker_id,$brokerfirstname,$brokerlastname,$brokeremail,$brokerphone,$brokercompany,$numberprospects,$numberclients,$closingratio\r\n"); //--- without numbers
           $i = $i+1;
          // print("$row[0], $row[1], $row[2]");
          // print("\n");
      }

  
}
else
{
    header("Location: login.php");
    exit();
}

?>
