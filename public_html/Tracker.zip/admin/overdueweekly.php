List of clients<BR><BR>

       <table border="1">

<?php

extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
    include("connection.php");    
$todaydate = date("Y-m-d");
$todaydate2 = date("m-d-Y");

 $query2 = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, autoscheduler FROM companyinfo WHERE companyid='1'";
    $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result2);
    while($row2=mysql_fetch_row($result2))
    {
        $companyid = $row2[0];
        $companyname = $row2[1];
        $companycontact = $row2[2];
        $companyemail = $row2[3];
        $companyreply = $row2[4];
        $companyaddress = $row2[5];
        $companycity = $row2[6];
        $companystate = $row2[7];
        $companyzip = $row2[8];                        
        $companyphone = $row2[9];         
        $companyfax = $row2[10];         
        $companywebsite = $row2[11];              
        $companyskin = $row2[12]; 
        $autoscheduler = $row2[13]; 


    }

 if($autoscheduler == "ON"){

$query = "SELECT name, email, broker_id, dealer_id, affiliate_id, reseller_id, plan, dateresults, showstatus, status, id FROM clients where (status = 'active' or status = 'contact1' or status = 'contact2' or status = 'contact3') AND dateresults <= '$todaydate' and clientdelete != 'Yes'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $email = $row[1];
        $broker_id = $row[2];
	  $dealer_id = $row[3];
	  $affiliate_id = $row[4];
	  $reseller_id = $row[5];
	  $plan = $row[6];
	  $dateresults = $row[7];
	  $showstatus = $row[8];
	  $status = $row[9];
	  $usid = $row[10];


$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $companyname <$companyreply>\r\n";

    $subject = "**URGENT** Your account is overdue";
                $message = "$name, <BR><BR>  Our records show that it has been more than 45 days and you have not sent in all the responses for your last round or has been scheduled for the next step.  Your account is now overdue.  Please contact our offices immediately at $companyphone to let us know if you have responses you have not sent in. <BR><BR>  Current status on your account is: <BR><BR>     -$showstatus. <BR><BR>  Thank you for your assistance <BR><BR>$companyname <BR>$companyphone <BR><a href=$companywebsite>$companywebsite</a>";
 		    $formsent = mail($email, $subject, $message, $HEADERS);  


 if($status == "active"){

        $query2 = "UPDATE clients SET status='contact1' WHERE id=$usid";
  $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());

$query3 = "INSERT INTO repair(clientid, repairdate, action, counselor)
                VALUES(
                '$usid',
                '$todaydate',
                'Sent client email about overdue account.  Please contact us immediately at $companyphone',
                'System'
                )";
        $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
        


} 
else if($status == "contact1"){

        $query2 = "UPDATE clients SET status='contact2' WHERE id=$usid";
  $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
$query3 = "INSERT INTO repair(clientid, repairdate, action, counselor)
                VALUES(
                '$usid',
                '$todaydate',
                'Sent client email about overdue account.  Please contact us immediately at $companyphone',
                'System'
                )";
        $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());

}
 else if($status == "contact2"){

        $query2 = "UPDATE clients SET status='contact3' WHERE id=$usid";
  $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
$query3 = "INSERT INTO repair(clientid, repairdate, action, counselor)
                VALUES(
                '$usid',
                '$todaydate',
                'Sent client email about overdue account.  Please contact us immediately at $companyphone',
                'System'
                )";
        $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());

}
 else if($status == "contact3"){

        $query2 = "UPDATE clients SET status='scheduled', showstatus='SYSTEM GENERATION SCHEDULE - Next round scheduled on next dispute cycle' WHERE id=$usid";
  $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());

$query3 = "INSERT INTO repair(clientid, repairdate, action, counselor)
                VALUES(
                '$usid',
                '$todaydate',
                'Sent client email about overdue account.  System automatically scheduled next round due to no contact',
                'System'
                )";
        $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());

}





            



               
    ?>

<tr>

<td><?php print($name); ?></td>
<td><?php print($email); ?></td>
              <td>Email Sent</td>
<td><?php print($todaydate); ?></td>

<td><?php print($dateresults); ?></td>

</tr>


<?php


}
} if($autoscheduler == "OFF"){
?>
<BR> AUTOSCHEDULER IS TURNED OFF<BR>
<?php


}



    //mysql_close($conn);
?>
</table>
