<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1 && $_SESSION['usname']=="admin"){

   include("connection.php");
   $i =1;

   $filename = "List of Brokers " . date("Y-m-d");
   $ext = 'csv';

   header("Content-type: text/plain");
   header('Content-Disposition: attachment; filename="' . $filename . '.' . $ext . '"');
   header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
   header('Pragma: no-cache');
   header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
   header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1

       echo("id,Username,Password,Company,First Name,Last Name,Email,Phone,Fax,Address,City,State,Zip,Creation\r\n");
       $query = "SELECT dealer_id, username, password, firstname, lastname, email, telephone, fax, address, city, prov, zipcode, createdate, dealership FROM dealers WHERE
                status='0' ORDER BY dealer_id";
       $result = mysql_query($query, $conn) or die("error:" . mysql_error());
       $col_count = mysql_num_fields($result);
       while($row=mysql_fetch_row($result))
       {
           $dealer_id = '"'.$row[0].'"';
           $username = '"'.$row[1].'"';
           $password = '"'.$row[2].'"';
           $firstname = '"'.$row[3].'"';
           $lastname = '"'.$row[4].'"';
           $email = '"'.$row[5].'"';
           $telephone = '"'.$row[6].'"';
           $fax = '"'.$row[7].'"';
           $address = '"'.$row[8].'"';
           $city = '"'.$row[9].'"';
           $prov = '"'.$row[10].'"';
           $zipcode = '"'.$row[11].'"';
           $createdate = '"'.$row[12].'"';
           $dealership = '"'.$row[13].'"';
           echo("$dealer_id,$username,$password,$dealership,$firstname,$lastname,$email,$telephone,$fax,$address,$city,$prov,$zipcode,$createdate\r\n"); //--- without numbers
           $i = $i+1;
          // print("$row[0], $row[1], $row[2]");
          // print("\n");
      }

  
}
else
{
    header("Location: login.php");
    exit();
}

?>
