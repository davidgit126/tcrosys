<?php

extract ($_GET );
extract ($_POST );
extract ($_SERVER );
$message2 = str_replace("{AFFUSER}", "$user", $message2);
$subject2 = str_replace("{AFFUSER}", "$user", $subject2);
$message2 = str_replace("{AFFPASS}", "$password", $message2);
$subject2 = str_replace("{AFFPASS}", "$pasword", $subject2);
$message2 = str_replace("{A_FNAME}", "$fname", $message2);
$subject2 = str_replace("{A_FNAME}", "$fname", $subject2);
$message2 = str_replace("{A_LNAME}", "$lname", $message2);
$subject2 = str_replace("{A_LNAME}", "$lname", $subject2);
$message2 = str_replace("{AFFEMAIL}", "$email", $message2);
$subject2 = str_replace("{AFFEMAIL}", "$email", $subject2);
?>