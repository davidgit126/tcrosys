<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
include('template.php');

    if($salescheck == "yes"){

	  $query = "SELECT id, username, fname, access, affiliate, password, brokers, modletters, modemails, modleads, email, extension, lname, title FROM users WHERE id='$sales_id'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
 while($row=mysql_fetch_row($result))
    {
      $id = $row[0];
      $name = $row[1];
      $fname = $row[2];
      $access = $row[3];      
      $affiliate = $row[4];      
      $password = $row[5];      
      $brokers = $row[6];       
      $modletters = $row[7];       
      $modemails = $row[8];       
      $restrict = $row[9];       
      $email = $row[10];       
      $extension = $row[11];       
      $lname = $row[12];       
      $title = $row[13];       
    }
	$recordname = "$fname $lname";
	}

	  if($brokercheck=='yes'){
	$recordname = $_SESSION['clname'];
	  }else if($affiliatecheck=='yes'){
	$recordname = $_SESSION['clname'];
	  }
     

    if($_POST['editcomms'] == "yes")
      {
 

  if($brokercheck=='yes'){
          $query = "UPDATE commission_brokers SET
                payment_amount='" . mysql_real_escape_string($_POST['earned']) . "'    
                WHERE id='" . mysql_real_escape_string($_POST['commission_id']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Broker Paycheck',
                    '" . mysql_real_escape_string($_SESSION['dealer_id']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

}else if($affiliatecheck=='yes'){
          $query = "UPDATE commission_affiliate SET
                payment_amount='" . mysql_real_escape_string($_POST['earned']) . "'    
                WHERE id='" . mysql_real_escape_string($_POST['commission_id']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Affiliate Paycheck',
                    '" . mysql_real_escape_string($_SESSION['affiliateid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}else if($salescheck=='yes'){
          $query = "UPDATE commission_sales SET
                payment_amount='" . mysql_real_escape_string($_POST['earned']) . "'    
                WHERE id='" . mysql_real_escape_string($_POST['commission_id']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Sales Paycheck',
                    '$sales_id',
                    '$recordname',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}
   }

 include('main.php');
    
?>
       <STYLE>       
.numbers{
	background-color: #FFFFFF;


	font-family: Verdana, sans-serif; 
	font-size: 10px;

	color: #000000;
	background-image:   url('formshadow.gif');
}
</STYLE> <font color="red">  <B> <?php print($error); ?></B></font>
                 
                        <p align="center">
                     
                        <div align="center">
                          <center>
                         <b><font color="#FF0000" face="Verdana" size="2"><?php print($message); ?>
                          </font></b>
                         
                            
                            <BR>
                            
                           

                             <table border="1" cellspacing="1" bgcolor="#FFFFFF" width="75%" id="AutoNumber3" cellpadding="3">
 										
 <tr>
                              <td width="100%" valign="top">
                              <p align="center"><b>
                              <font face="Verdana" size="4">Total Paid to <?php print($recordname); ?></font></b></td>
                            </tr>
                            <tr>
                              <td width="100%" valign="top">
                              <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber5">
                                <tr>
                                  <td width="12%"><b>Pay Date</b></td>
                                  <td width="11%"><b>Check #</b></td>
                                  <td width="62%"> 
                                        <b>Notes</b></td>
                                  <td width="15%"> 
                                        <b>Pay Amount</b></td>
                                </tr>
                                
                                <?php
if($brokercheck=='yes'){
$gowhere = "brokerstatus.php";
$updatedb = "commission_brokers";

$query = "SELECT payment_date, ck_number, notes, payment_amount, id FROM commission_brokers WHERE broker_id='" . $_SESSION['dealer_id'] . "' and payment_amount != '' ORDER BY payment_date DESC";
}else if($affiliatecheck=='yes'){
$query = "SELECT payment_date, ck_number, notes, payment_amount, id FROM commission_affiliate WHERE affiliate_id='" . $_SESSION['affiliateid'] . "' and payment_amount != '' ORDER BY payment_date DESC";
$gowhere = "affiliatestatus.php";
$updatedb = "commission_affiliate";

}else if($salescheck=='yes'){
$query = "SELECT payment_date, ck_number, notes, payment_amount, id FROM commission_sales WHERE rep_id='$sales_id' and payment_amount != '' ORDER BY payment_date DESC";
$gowhere = "edituserb.php?uid=$sales_id";
$updatedb = "commission_sales";
}

$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$col_count = mysql_num_fields($result);
while($row=mysql_fetch_row($result))
{
$check_date= $row[0];
$check_num = $row[1];
$notes = $row[2];
$amount_paid = $row[3];
$commission_id= $row[4];

?>



<form action="" method="post">  
<tr>

<td width="12%"><?php print($check_date); ?></td>
<td width="11%"><?php print($check_num); ?></td>
<td width="62%"><?php print($notes); ?></td>

<td class='ss-round-inputs' width="15%">$<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7"><input class="numbers"  name="earned" value="<?php print($amount_paid); ?>" size="5"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7"></td>

<td width="15%"><input class="numbers" type="submit" name="Update" value="Edit">
<input type="hidden" name="commission_id" value="<?php print($commission_id); ?>" size="3"> 
<input type="hidden" name="updatedb" value="<?php print($updatedb); ?>" size="3">           
<input type="hidden" name="editcomms" value="yes" size="2">                              
</td></tr>
</form>                           

  <?php
       }
      
        if($brokercheck=='yes'){
       $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_brokers WHERE broker_id='" . $_SESSION['dealer_id'] . "' GROUP BY broker_id";
}else if($affiliatecheck=='yes'){
       $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_affiliate WHERE affiliate_id='" . $_SESSION['affiliateid'] . "' GROUP BY affiliate_id";
}else if($salescheck=='yes'){
       $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_sales WHERE rep_id='$sales_id' GROUP BY rep_id";
}
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}

?>                

  <tr>
                                
                                  <td >&nbsp;</td>
                                  <td >&nbsp;</td>
                                  <td >&nbsp;</td>
								  <td ><b>Total - <font color="#008000">$<?php print($COM_total_pd); ?></font></b></td>
                              
 </tr>           
                                <tr>
                                  <td width="100%" colspan="4">
                                  <p align="center">&nbsp;</td>
                                </tr>
                              </table>
                              </td>
                            </tr>
                            </table>

                          </center>
</div>
                        <p align="left">
                        <a href="<?php print($gowhere); ?>">Back</a>
                        &nbsp;
                        </p>
                        
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>