<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";
$today = date("Y-m-d");
$ip=$_SERVER["REMOTE_ADDR"];


$nowday = date("d");
$nowmonthword = date("M");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
      include "700score_connection2.php"; 

include('template.php');

include('main.php');

$sql = "SELECT * FROM dealers WHERE dealer_id='" . $_SESSION['licid'] . "' and dedemail='" . $_SESSION['csotracker_id'] . "' ";
$result = mysql_query($sql, $conn2);
$line=mysql_fetch_array($result, MYSQL_ASSOC);
$number_results = mysql_num_rows($result);

$entered_year = substr("$line[createdate]", 0, 4);
$entered_month = substr("$line[createdate]", 5, 2);
$entered_day = substr("$line[createdate]", 8, 2);

$trackerconn  = @mysql_connect("$line[dbip]", "$line[dbuser]", "$line[dbpass]");
  @mysql_select_db("$line[dbname]", $trackerconn) or die ("error: No Database Setup" . mysql_error());


 $query = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, status FROM clients WHERE id='$licclientid'"; 
    $result = mysql_query($query, $trackerconn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $address = $row[1];
        $city = $row[2];
        $state = $row[3];
        $zip = $row[4];
        $email = $row[5];
        $fax = $row[6];
        $phone = $row[7];
        $ssnum = $row[8];
        $birthdate = $row[9];
        $country = $row[10];
        $status = $row[11];
    } 
    
    	if ($status == "pending"){
	        $bgcolor = "FFFF00"; 
	        
  }else if ($status == "canceled"){
	        $bgcolor = "663300";
	}else if ($status == "NSF"){
	        $bgcolor = "FF00FF";
	}else if ($status == "contact1"){
	        $bgcolor = "FF4444";
	}else if ($status == "contact2"){
	        $bgcolor = "FF0000";
	}else if ($status == "contact3"){
	        $bgcolor = "888888";
	}else if ($status == "expired"){
	        $bgcolor = "888888";
	}else if ($status == "inactive"){
	        $bgcolor = "888888";
	}else if ($status == "complete"){
	        $bgcolor = "008000";
	}else if ($status == "scheduled"){
	        $bgcolor = "FFCCCC";
	}else if ($status == "Debtor"){
	        $bgcolor = "003399";
	}else if ($plan == "Budget"){
	        $bgcolor = "c0c0c0";
	}else{
$bgcolor = "FFFFFF";

}

//----------enrolment
    $query = "SELECT DATE_FORMAT(dateenrol, \"%m-%d-%Y\") as dateenrol,  DATE_FORMAT(reportreceived, \"%m-%d-%Y\") as repdate, DATE_FORMAT(addressreceived, \"%m-%d-%Y\") as adddate, DATE_FORMAT(ssdate, \"%m-%d-%Y\") as ssdate, DATE_FORMAT(welcomepacket, \"%m-%d-%Y\") as welcomedate, DATE_FORMAT(returndoc, \"%m-%d-%Y\") as returndoc FROM enrolment WHERE clientid='$licclientid'"; 
    $result = mysql_query($query, $trackerconn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dateenrol = $row[0];
        $reportreceived = $row[1];
        $addressreceived = $row[2];
        $ssdate = $row[3];
        $welcomepacket = $row[4];
        $returndoc = $row[5];
    } 
//---------billing
    $query = "SELECT auditfee, DATE_FORMAT(paid, \"%m-%d-%Y\") as paid, monthlyfee, monthlydue, payment FROM billing WHERE clientid='$licclientid'"; 
    $result = mysql_query($query, $trackerconn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $auditfee = $row[0];
        $paid = $row[1];
        $monthlyfee = $row[2];
        $monthlydue = $row[3];
        $payment = $row[4];
    } 

  $query3 = "SELECT count(deleted) FROM accounts WHERE (deleted='Deleted' OR deleted='Fixed') and clientid='$licclientid'"; 
              $result3 = mysql_query($query3, $trackerconn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $deleted2 = $row3[0];
                   $i = $i+1;
}
 $query4 = "SELECT count(id) FROM accounts WHERE clientid='$licclientid'"; 
              $result4 = mysql_query($query4, $trackerconn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result4))
              {
                   $totalaccounts = $row3[0];
                   $i = $i+1;
}

?>





  <p align="center">
                            
                             <?php

    if($totalaccounts !="0")
    {
       function encodeDataURL($strDataURL, $addNoCacheStr=false) {
    if ($addNoCacheStr==true) {
		if (strpos($strDataURL,"?")<>0)
			$strDataURL .= "&FCCurrTime=" . Date("H_i_s");
		else
			$strDataURL .= "?FCCurrTime=" . Date("H_i_s");
    }
	return urlencode($strDataURL);
}


function datePart($mask, $dateTimeStr) {
    @list($datePt, $timePt) = explode(" ", $dateTimeStr);
    $arDatePt = explode("-", $datePt);
    $dataStr = "";
    if (count($arDatePt) == 3) {
        list($year, $month, $day) = $arDatePt;
        // determine the request
        switch ($mask) {
        case "m": return $month;
        case "d": return $day;
        case "y": return $year;
        }
        return (trim($month . "/" . $day . "/" . $year));
    }
    return $dataStr;
}


function renderChart($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false, $registerWithJS=false, $setTransparent="") {
	if ($strXML=="")
        $tempData = "//Set the dataURL of the chart\n\t\tchart_$chartId.setDataURL(\"$strURL\")";
    else
        $tempData = "//Provide entire XML data using dataXML method\n\t\tchart_$chartId.setDataXML(\"$strXML\")";

    $chartIdDiv = $chartId . "Div";
    $ndebugMode = boolToNum($debugMode);
    $nregisterWithJS = boolToNum($registerWithJS);
	$nsetTransparent=($setTransparent?"true":"false");
$render_chart = <<<RENDERCHART

	<!-- START Script Block for Chart $chartId -->
	<div id="$chartIdDiv" align="center">
		Chart.
	</div>
	<script type="text/javascript">	
		var chart_$chartId = new FusionCharts("$chartSWF", "$chartId", "$chartWidth", "$chartHeight", "$ndebugMode", "$nregisterWithJS");
      chart_$chartId.setTransparent("$nsetTransparent");
    
		$tempData
		chart_$chartId.render("$chartIdDiv");
	                         </script>	
	<!-- END Script Block for Chart $chartId -->
RENDERCHART;

  return $render_chart;
}


function renderChartHTML($chartSWF, $strURL, $strXML, $chartId, $chartWidth, $chartHeight, $debugMode=false,$registerWithJS=false, $setTransparent="") {
    $strFlashVars = "&chartWidth=" . $chartWidth . "&chartHeight=" . $chartHeight . "&debugMode=" . boolToNum($debugMode);
    if ($strXML=="")
        $strFlashVars .= "&dataURL=" . $strURL;
    else
        $strFlashVars .= "&dataXML=" . $strXML;
    
    $nregisterWithJS = boolToNum($registerWithJS);
    if($setTransparent!=""){
      $nsetTransparent=($setTransparent==false?"opaque":"transparent");
    }else{
      $nsetTransparent="window";
    }
$HTML_chart = <<<HTMLCHART
	<!-- START Code Block for Chart $chartId -->
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="$chartWidth" height="$chartHeight" id="$chartId">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="$chartSWF"/>		
		<param name="FlashVars" value="$strFlashVars&registerWithJS=$nregisterWithJS" />
		<param name="quality" value="high" />
		<param name="wmode" value="$nsetTransparent" />
		<embed src="$chartSWF" FlashVars="$strFlashVars&registerWithJS=$nregisterWithJS" quality="high" width="$chartWidth" height="$chartHeight" name="$chartId" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="$nsetTransparent" /></object>
	<!-- END Code Block for Chart $chartId -->
HTMLCHART;

  return $HTML_chart;
}

function boolToNum($bVal) {
    return (($bVal==true) ? 1 : 0);
}





	$fixed = $deleted2/$totalaccounts*100;
	$open = ($totalaccounts-$deleted2)/($totalaccounts)*100;
		$strXML  = "<chart numberSuffix='%25' bgcolor='FFFFFF' caption='Items fixed/deleted: $deleted2 out of $totalaccounts'  showZeroPies='0' chartTopMargin='0' chartBottomMargin='0' showPercentValues='1' showAboutMenuItem='0' showPrintMenuItem='0' showValues='1' showYAxisValues ='0' formatNumberScale='0' showShadow='1' startingAngle='90' use3DLighting ='1' showBorder='0'>";
	$strXML .= "<set label='Open' value='$open'  isSliced='1'  />";
	$strXML .= "<set label='Improved' value='$fixed' color='008000'/>";
	$strXML .= "</chart>";
	
	echo renderChartHTML("http://www.tcrosystems.net/Pie2D.swf", "", $strXML, "myFirst", 500, 300, false, false);
 }
    ?>
                            
                            
                            

    <h2>Personal Information</h2>
    <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#C0C0C0 cellSpacing=0 cellPadding=3 width="98%" bgColor=#c0c0c0 border=2>
    <TBODY>
    <TR>
    <TD width="50%" bgcolor="#<?php print($bgcolor); ?>"><b>Name</b> - <?php print($name); ?>
    <p><b>Address</b><BR><?php print($address); ?><BR>
    <?php print($city); ?>, <?php print($state); ?> <?php print($zip); ?>
    
    
    
    </TD>
    <TD width="50%" bgcolor="#<?php print($bgcolor); ?>"><b>E-mail</b> - <?php print($email); ?><BR><b>Phone</b> - <?php print($phone); ?><BR><b>SSN</b> - <?php print($ssnum); ?><BR><b>DOB</b> - <?php print($birthdate); ?></TD></TR>
    </TBODY>
    <TBODY>
    <TR>
    <TD width="50%" bgcolor="#<?php print($bgcolor); ?>"><b>Date Of Enrollment</b> - <?php print($dateenrol); ?>    <b>Welcome Packet Mailed</b> - <?php print($welcomepacket); ?></TD>
    <TD width="50%" bgcolor="#<?php print($bgcolor); ?>"><b>Returned Documents Received</b> - <?php print($returndoc); ?></TD>
    </TR>
    </TBODY>
    </TABLE>

    <h2>Credit Repair Process</h2>

    <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#C0C0C0 cellSpacing=0 cellPadding=2 width="98%" border=3>
    <TBODY>
    <TR>
    <TD width="9%"><B>Date</B></TD>
    <TD width="42%"><B>Received</B> (e-mail, phone call, reports, letter, fax, etc.)</TD>
    <TD width="47%"><B>Action Taken</B></TD>
    </TR>
    <?php
    $query = "SELECT DATE_FORMAT(repairdate, \"%m-%d-%Y\") as repdate,  received, action,  filelocation, counselor FROM  repair WHERE clientid='$licclientid' ORDER BY repairdate DESC"; 
    $result = mysql_query($query, $trackerconn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $repairdate= $row[0];
        $received = $row[1];
        $action = $row[2];
        $filelocation = $row[3];
        $counselor= $row[4];
          if($filelocation !=""){
         $textcss = "FFCCCC";
}else {

                    $textcss = "FFFFFF";

                    }


        ?>
        <TR>
        <TD width="9%" bgcolor="#<?php print($textcss);?>"><?php print($repairdate); ?>&nbsp;</TD>
        <TD width="42%" bgcolor="#<?php print($textcss);?>"><?php print($received); ?>&nbsp;</TD>
        <TD width="47%" bgcolor="#<?php print($textcss);?>"><?php print($action); ?>&nbsp;</TD>        </TR>
        <?php
    }
    ?>
    </TBODY>
    </TABLE>
    
  <BR>
<HR><HR>






<?php


      $query = "SELECT id, type FROM accounttype"; 
      $result = mysql_query($query, $trackerconn) or die("error:" . mysql_error());
      $col_count = mysql_num_fields($result);
      while($row=mysql_fetch_row($result))
      {
        $actypeid = $row[0];
        $actype = $row[1];
    ?>

       <P align=left><FONT color=#000080><B><?php print($actype); ?> Credit 
    Report</B></FONT></P>
         <TABLE style="BORDER-COLLAPSE: collapse" borderColor=#000080 
    cellSpacing=0 cellPadding=2 width="90%" border=3>
      <TBODY>
      <TR>
         <TD width="11%" bgcolor="#FFFFFF"><b>Account Name</b></TD>
        <TD width="11%" bgcolor="#FFFFFF"><b>Account#</b></TD>
        <TD width="11%" bgcolor="#FFFFFF"><b>Status</b></TD>
        <TD width="11%" bgcolor="#FFFFFF"><b>Step 1</b></TD>
        <TD width="11%" bgcolor="#FFFFFF"><b>Step 2</b></TD>
        <TD width="11%" bgcolor="#FFFFFF"><b>Step 3</b></TD>
        <TD width="11%" bgcolor="#FFFFFF"><b>Step 4</b></TD>
        <TD width="11%" bgcolor="#FFFFFF"><b>Step 5</b></TD>
        <TD width="12%" bgcolor="#FFFFFF"><b>Step 6</b></TD>
    </TR>
    <?php 
         $query2 = "SELECT id, name, number, beginstatus, s1result, s2result, s3result, s4result, s5result, s6result, s7result, s8result, deleted  FROM accounts WHERE clientid='$licclientid' and accounttype='" . mysql_real_escape_string($actypeid) . "'";
         $result2 = mysql_query($query2, $trackerconn) or die("error:" . mysql_error());
         while($row2=mysql_fetch_row($result2))
         {
           $accid    = $row2[0];
           $acname   = $row2[1];                 
           $acnumber = $row2[2];                
           $acbeginstatus = $row2[3];               
           $s1result = $row2[4];                
           $s2result = $row2[5];
           $s3result = $row2[6];                
           $s4result = $row2[7];
           $s5result = $row2[8];                
           $s6result = $row2[9];
           $s7result = $row2[10];               
           $s8result = $row2[11];               
              $deleted = $row2[12];  
     
  if($deleted =="Deleted" or $deleted =="Fixed"){
         $textcss = "00CC99";
         $derogstatus = "FIXED/DELETED";
}else if($deleted =="Hold"){
                    $textcss = "FFFFFF";
                     $derogstatus = "On Hold";
}else if($status =="scheduled"){

                    $textcss = "FFCCCC";
                     $derogstatus = "Scheduled";

}else if($status =="pending"){

                    $textcss = "FFFF99";
                     $derogstatus = "prepared/pending";

}else {


                    $textcss = "FFFFFF";
                     $derogstatus = "In Dispute";

                    }
                    

             
    ?>

      <TR>
        <TD width="11%" bgcolor="#<?php print($textcss);?>"><?php print($acname); ?>&nbsp;</TD>
        <TD width="11%" bgcolor="#<?php print($textcss);?>"><?php print($acnumber); ?>&nbsp;</TD>
        <TD width="11%" bgcolor="#<?php print($textcss);?>"><?php print($acbeginstatus); ?>&nbsp;</TD>
        <TD width="11%" bgcolor="#<?php print($textcss);?>"><?php print($s1result); ?>&nbsp;</TD>
        <TD width="11%" bgcolor="#<?php print($textcss);?>"><?php print($s2result); ?>&nbsp;</TD>
        <TD width="11%" bgcolor="#<?php print($textcss);?>"><?php print($s3result); ?>&nbsp;</TD>
        <TD width="11%" bgcolor="#<?php print($textcss);?>"><?php print($s4result); ?>&nbsp;</TD>
        <TD width="11%" bgcolor="#<?php print($textcss);?>"><?php print($s5result); ?>&nbsp;</TD>
        <TD width="12%" bgcolor="#<?php print($textcss);?>"><?php print($s6result); ?>&nbsp;</TD>
      </TR>
     <?php
         }
     ?>
        </TBODY>
      </TABLE>
     <?php
       }
       mysql_close($conn);
    ?>







                  



           

                        
                        
                   
                      
     <?php
}
else
{
    header("Location: login.php");
    exit();
}

?>