<?php
    include_once('common.inc.php');
    session_start();

extract ($_GET );
extract ($_SESSION );
extract ($_POST );
extract ($_SERVER );

    include("connection.php");
        $query = "INSERT INTO creditortype(type, address, citystatezip)
                VALUES(
                '" . mysql_real_escape_string($_POST['creditorname']) . "', 
                '" . mysql_real_escape_string($_POST['creditoraddress']) . "',
                '" . mysql_real_escape_string($_POST['citystatezip']) . "')";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());


   $query = "SELECT id FROM creditortype WHERE address='$creditoraddress'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $creditorid   = $row[0];
}


//
        header("Location: letters.php?creditorselected=$creditorid");  
        exit();
    
?>
