<?php
extract ($_GET );
extract ($_POST );

require_once('../include/setclient_connection.php');
session_start();



$_SESSION['dealer_id']   = $_GET['cid'];
$_SESSION['clname']     = $_GET['cname'];

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Access Broker Record',
                    '" . mysql_real_escape_string($_SESSION['dealer_id']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());




header("Location: brokerstatus.php");
exit();
?>
