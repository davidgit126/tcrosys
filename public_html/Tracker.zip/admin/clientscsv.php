<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1 && $_SESSION['usname']=="admin"){
   include("connection.php");
   $i =1;

   $filename = "List of Clients " . date("Y-m-d");
   $ext = 'csv';

   header("Content-type: text/plain");
   header('Content-Disposition: attachment; filename="' . $filename . '.' . $ext . '"');
   header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
   header('Pragma: no-cache');
   header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
   header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1

       echo("id,Name,Address,City,State,Zip,Phone,Alt Phone,Email,Status,Creation,Sales Person,SingleCouple,SetupDate,SetupFee,MonthlyFee,DueDate,PaymentMethod\r\n");


	   if (! $cname) {
$namequery = "";
}else{
$namequery = " AND clients.name LIKE('%" . mysql_real_escape_string($_GET['cname']) . "%')";
}

if (! $zip) {
$zipquery = "";
}else{
$zipquery = " AND clients.zip ='$zip'";
}

if (! $email) {
$emailquery = "";
}else{
$emailquery = " AND clients.email LIKE('%" . mysql_real_escape_string($_GET['email']) . "%')";
}

if (! $status) {
$statusquery = "";
}else{
$statusquery = " AND clients.status LIKE('%" . mysql_real_escape_string($_GET['status']) . "%')";
}

if (! $billingcycle) {
$billingcyclequery = "";
}else{
$billingcyclequery = " AND billing.monthlydue LIKE('%" . mysql_real_escape_string($_GET['billingcycle']) . "%')";
}

if (! $searchbroker) {
$brokerquery = "";
}else{
$brokerquery = " AND clients.broker_id='$searchbroker'";
}

if (! $searchaffiliate) {
$affquery = "";
}else{
$affquery = " AND clients.affiliate_id='$searchaffiliate'";
}

if (! $searchsales) {
$salesquery = "";
}else{
$salesquery = " AND clients.dealer_id='$searchsales'";
}

if ($enrollfrom == "" or $enrollfrom =="YYYY-MM-DD" or $enrollto == "" or $enrollto =="YYYY-MM-DD") {
$enrollquery = "";
}else{
$enrollquery = " AND clients.createdate >= '$enrollfrom' AND clients.createdate <= '$enrollto'";
}

if ($cancelfrom == "" or $cancelfrom =="YYYY-MM-DD" or $cancelto == "" or $cancelto =="YYYY-MM-DD") {
$cancelquery = "";
}else{
$cancelquery = " AND clients.canceldate >= '$cancelfrom' AND clients.canceldate <= '$cancelto' AND clients.status ='canceled'";
}

if ($exclude == "yes" && $cancelquery =="") {
$excludequery = " AND clients.status != 'canceled' AND clients.status != 'complete' AND clients.status != 'inactive' AND clients.status != 'expired'";
}else{
$excludequery = " ";
}

       $query = "SELECT clients.id, clients.name, clients.address, clients.city, clients.state, clients.zip, clients.phone, clients.altphone, clients.email, clients.comments, clients.createdate, clients.status, clients.dealer_id, clients.singlecouple, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment FROM clients,billing WHERE clients.id=billing.clientid $namequery $zipquery $emailquery $statusquery $billingcyclequery $brokerquery $affquery $enrollquery $salesquery $excludequery $cancelquery AND clients.reseller_id = 0 AND clients.prospectclient = 'Client'  AND clients.clientdelete != 'yes' ORDER BY clients.id";
       $result = mysql_query($query, $conn) or die("error:" . mysql_error());
       $col_count = mysql_num_fields($result);
       while($row=mysql_fetch_row($result))
       {
           $id = '"'.$row[0].'"';
           $name = '"'.$row[1].'"';
           $address = '"'.$row[2].'"';
           $city = '"'.$row[3].'"';
           $state= '"'.$row[4].'"';
           $zip= '"'.$row[5].'"';
           $phone= '"'.$row[6].'"';
           $altphone= '"'.$row[7].'"';
           $email= '"'.$row[8].'"';
           $comments= '"'.$row[9].'"';
		   $createdate= '"'.$row[10].'"';
		   $status= '"'.$row[11].'"';
		   $dealer_id= '"'.$row[12].'"';
		   $singlecouple = '"'.$row[13].'"';
              $paid         = '"'.$row[14].'"';
              $auditfee       = '"'.$row[15].'"';
              $monthlyfee	= '"'.$row[16].'"';
              $monthlydue	= '"'.$row[17].'"';
              $payment       = '"'.$row[18].'"';

		   echo("$id,$name,$address,$city,$state,$zip,$phone,$altphone,$email,$status,$createdate,$dealer_id,$singlecouple,$paid,$auditfee,$monthlyfee,$monthlydue,$payment\r\n"); //--- without numbers
           $i = $i+1;
          // print("$row[0], $row[1], $row[2]");
          // print("\n");
      }

  
}
else
{
    header("Location: login.php");
    exit();
}

?>
