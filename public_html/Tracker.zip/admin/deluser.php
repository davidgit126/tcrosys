<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
include('template.php');

    include("connection.php");
    if($_REQUEST['del']==1)
    {
        $query = "DELETE FROM users WHERE id='" . mysql_real_escape_string($_REQUEST['uid']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    }
    
    $query = "SELECT id, username FROM users ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
 
    print("<table>");
    while($row=mysql_fetch_row($result))
    {
      $id = $row[0];
      $name = $row[1];
      print("<tr><td>$name</td><td><a href=deluser.php?del=1&uid=$id><img border=\"0\" src=\"http://www.tcrosystems.net/deletebutton.png\"></a></td></tr>");      
    } 
    print("</table>");
    
    mysql_close($conn);
    ?>
    <br><a href="search.php"> Back to Search Page</a>
    <?php
}
else
{
    header("Location: login.php");
    exit();
}


?>