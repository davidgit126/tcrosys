<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    include('template.php');
if($_SESSION['usaccess']=="sales")
{
   ?>
<font color="red"><B>You do not have access to this area </font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 }else{
  include("connection.php");

   $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload, passisssn, demanddraft FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 
        $passisssn = $row[14]; 
        $demanddraft = $row[15]; 
    }
     
$sql2 = "SELECT * FROM dealers where status !=9 ORDER BY lastname";
$result2 = @mysql_query($sql2,$conn);
while ($row2 = mysql_fetch_array($result2)) {
$ALLBROKER_username = $row2['username'];
$ALLBROKER_id = $row2['dealer_id'];
$ALLBROKER_fname = $row2['firstname'];
$ALLBROKER_lname = $row2['lastname'];

$BROKER_select .= "<option value=$ALLBROKER_id>$ALLBROKER_username</option> ";
//$BROKER_select .= "<option value=$ALLBROKER_id>$ALLBROKER_lname, $ALLBROKER_fname ($ALLBROKER_username)</option> ";
}

   $sql3 = "SELECT * FROM sales_affiliates WHERE type='Affiliate' and status !='del' ORDER BY lname";
  $result3 = @mysql_query($sql3,$conn);
  while ($row3 = mysql_fetch_array($result3)) {
  $AFFILIATE_username = $row3['user'];
  $AFFILIATE_id = $row3['id'];
  $AFFILIATE_fname = $row3['fname'];
    $AFFILIATE_lname = $row3['lname'];

$AFFILIATE_select .= "<option value=$AFFILIATE_id>$AFFILIATE_lname, $AFFILIATE_fname ($AFFILIATE_username)</option> ";
  }

  $sql3 = "SELECT * FROM sales_affiliates WHERE type='Sales' and status !='del' ORDER BY lname";
  $result3 = @mysql_query($sql3,$conn);
  while ($row3 = mysql_fetch_array($result3)) {
  $SALES_username = $row3['user'];
  $SALES_id = $row3['id'];
  $SALES_fname = $row3['fname'];
  $SALES_lname = $row3['lname'];

  $SALES_select .= "<option value=$SALES_id>$SALES_lname, $SALES_fname ($SALES_username)</option> ";
  }

$todaydate = date("Y-m-d");
$todaydate2 = date("m-d-Y");
function dateDiff($dformat, $endDate, $beginDate) 
{ 
$date_parts1=explode($dformat, $beginDate); 
$date_parts2=explode($dformat, $endDate); 
$start_date=gregoriantojd($date_parts1[0], $date_parts1[1], $date_parts1[2]); 
$end_date=gregoriantojd($date_parts2[0], $date_parts2[1], $date_parts2[2]); 
return $end_date - $start_date; 
} 

?>
    
   <script type="text/javascript">

	subject_id = '';
	function handleHttpResponse() {
		if (http.readyState == 4) {
			if (subject_id != '') {
				document.getElementById(subject_id).innerHTML = http.responseText;
			}
		}
	}
	function getHTTPObject() {
		var xmlhttp;
		/*@cc_on
		@if (@_jscript_version >= 5)
			try {
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (E) {
					xmlhttp = false;
				}
			}
		@else
		xmlhttp = false;
		@end @*/
		if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
			try {
				xmlhttp = new XMLHttpRequest();
			} catch (e) {
				xmlhttp = false;
			}
		}
		return xmlhttp;
	}
	var http = getHTTPObject(); // We create the HTTP Object

	function getScriptPage(div_id,content_id)
	{
		subject_id = div_id;
		content = document.getElementById(content_id).value;
		http.open("GET", "template.php?searchpage=client&content=" + escape(content), true);
		http.onreadystatechange = handleHttpResponse;
		http.send(null);
		if(content.length>0)
			box('1');
		else
			box('0');

	}	

	function highlight(action,id)
	{
	  if(action)	
		document.getElementById('word'+id).bgColor = "#184EAE";
	  else
		document.getElementById('word'+id).bgColor = "#2E2E2E";
	}
	function display(word)
	{
		document.getElementById('text_content').value = word;
		document.getElementById('box').style.display = 'none';
		document.getElementById('text_content').focus();
	}
	function box(act)
	{
	  if(act=='0')	
	  {
		document.getElementById('box').style.display = 'none';

	  }
	  else
		document.getElementById('box').style.display = 'block';
		document.getElementById('topbox').style.display = 'block';
	}
</script> 

<!--------BROKER ID ONLY SCRIPT ---->
 <script type="text/javascript">

	subject_id = '';
	function handleHttpResponse() {
		if (http.readyState == 4) {
			if (subject_id != '') {
				document.getElementById(subject_id).innerHTML = http.responseText;
			}
		}
	}
	function getHTTPObject() {
		var xmlhttp;
		/*@cc_on
		@if (@_jscript_version >= 5)
			try {
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (E) {
					xmlhttp = false;
				}
			}
		@else
		xmlhttp = false;
		@end @*/
		if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
			try {
				xmlhttp = new XMLHttpRequest();
			} catch (e) {
				xmlhttp = false;
			}
		}
		return xmlhttp;
	}
	var http = getHTTPObject(); // We create the HTTP Object

	function getBrokerIdScriptPage(div_id,content_id)
	{
		subject_id = div_id;
		content = document.getElementById(content_id).value;
		http.open("GET", "template.php?searchpage=brokeridonly&content=" + escape(content), true);
		http.onreadystatechange = handleHttpResponse;
		http.send(null);
		if(content.length>0)
			brokerid_box('1');
		else
			brokerid_box('0');

	}	

	function highlight(action,id)
	{
	  if(action)	
		document.getElementById('word'+id).bgColor = "#184EAE";
	  else
		document.getElementById('word'+id).bgColor = "#2E2E2E";
	}
	function display(word)
	{
		document.getElementById('brokerid_text_content').value = word;
		document.getElementById('brokerid_box').style.display = 'none';
		document.getElementById('brokerid_text_content').focus();
	}
	function brokerid_box(act)
	{
	  if(act=='0')	
	  {
		document.getElementById('brokerid_box').style.display = 'none';

	  }
	  else
		document.getElementById('brokerid_box').style.display = 'block';
		document.getElementById('topbox').style.display = 'block';
	}
</script> 





    <font color="red">  <B> <?php print($message); ?></B></font>
  <?php
    include('main.php');
   ?> <BR>
<script type="text/javascript">
function toggleMe(a){
var e=document.getElementById(a);
if(!e)return true;
if(e.style.display=="none"){
e.style.display="block"
}
else{
e.style.display="none"
}
return true;
}
</script>

<form action="" method="get">

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="600">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Client Search</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>


<table background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="600">
<tr>
<td>


<!------- INTERNAL TABLE #1 ----->
<table border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse" width="100%">
<tr>
<td>

<tr>
<td width="128">&nbsp;</td>
<td width="161">&nbsp;</td>
<td width="66">&nbsp;</td>
<td width="245">&nbsp;</td>
</tr>

<tr>
<td width="128" valign="top"><font color="#FFFFFF"><b>&nbsp;Record Search:</b></font></td>
<td class='ss-round-inputs' width="375" colspan="3">
<div class="ajax-div">
<div class="input-div">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox"  type="text" onKeyUp="getScriptPage('box','text_content')" id="text_content" size="40"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></div>
<div id="box"></div>
</div>
</td>
</tr>
<tr>
<td colspan = "4"><HR size=1></td>
</tr>




            <tr>
                <td width="128"><font color="#FFFFFF"><b>&nbsp;Client Name:</b></font> </td>
                <td class='ss-round-inputs' width="161">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox" type="text" name="cname" value="<?php print($cname);?>" size="20"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
                </td>
                <td width="66"><b><font color="#FFFFFF">&nbsp;</font></b><font color="#FFFFFF"><b>Status:</b></font></td>
                <td>
                    <select name="status" class="txtbox"   >
                    <option value="<?php print($status);?>" selected><?php print($status);?></option>
                <option value="pending">pending</option>
                <option value="active">active</option>
                <option value="scheduled">scheduled</option>
                <option value="complete">complete</option>
                <option value="canceled">canceled</option>
                <option value="expired">expired</option>
                <option value="contact1">contact1</option>
		    <option value="contact2">contact2</option>
                <option value="contact3">contact3</option>                
                <option value="NSF">NSF</option> 
                <option value="inactive">inactive</option> 
                
                                
              </select>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript: void(0)" style="color:#2B93DA" onclick="return toggleMe('para1')"><font color="#FFFFFF">Advanced Search</font></a>
                </td>
            </tr>
            <tr>
                <td width="128">&nbsp;</td>
                <td width="161">&nbsp;</td>
                <td width="66">&nbsp;</td>
                <td width="245">&nbsp;</td>
            </tr>

</td>
</tr>
</table>
<div id="para1" style="display:none">

<!------- INTERNAL TABLE #2 ----->
<table border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse" width="100%">
<tr>
<td>

            <tr>
                <td width="128"><font color="#FFFFFF"><b>&nbsp;Client E-mail:</b></font> </td>
                <td class='ss-round-inputs' width="161">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox" type="text" name="email" value="<?php print($email);?>" size="20"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
                </td>
                <td width="66"><b><font color="#FFFFFF">&nbsp;ZIP: </font></b> </td>
                <td class='ss-round-inputs' width="245">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="txtbox" type="text" name="zip" size="16"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
                </td>
            </tr>
            <tr>
                <td width="128">&nbsp;</td>
                <td width="161">
                    &nbsp;</td>
                <td width="66">&nbsp;</td>
                <td width="245">&nbsp;</td>
            </tr>

<!-- NEW BROKER SEARCH -->
                <tr>
                <td width="66"><b><font color="#FFFFFF">&nbsp;Broker</font></b><font color="#FFFFFF"><b>:</b></font></td>
                <td width="362" class='ss-round-inputs' colspan="3">
<div class="ajax-div">
<div class="input-div">
<img border="0" src="input-left.gif" width="7" ><input class="txtbox" name="searchbroker" type="text" onKeyUp="getBrokerIdScriptPage('brokerid_box','brokerid_text_content')" id="brokerid_text_content" size="40"><img border="0" src="input-right.gif" width="7" ></div>
<div id="brokerid_box"></div>
</div>

                  </td>
                </tr>



     
<tr>
                <td width="128">&nbsp;</td>
                <td width="161">
                    &nbsp;</td>
                <td width="66">&nbsp;</td>
                <td width="245">&nbsp;</td>
            </tr>

 <tr>
                <td width="66"><b><font color="#FFFFFF">&nbsp;Affiliate</font></b><font color="#FFFFFF"><b>:</b></font></td>
                <td width="362" colspan="3">
                    <select class="txtbox"  name="searchaffiliate">
					    <option value="<? echo "$searchaffiliate"; ?>" selected><? echo "$searchaffiliate"; ?></option>
					    <? echo "$AFFILIATE_select"; ?>
					    <option value="">REMOVE</option>

					    </select>
                </td>
            </tr>
<tr>
                <td width="128">&nbsp;</td>
                <td width="161">&nbsp;</td>
                <td width="66">&nbsp;</td>
                <td width="245">&nbsp;</td>
            </tr>




			 <tr>
                <td width="66"><b><font color="#FFFFFF">&nbsp;Sales</font></b><font color="#FFFFFF"><b>:</b></font></td>
                <td width="362" colspan="3">
                    <select class="txtbox"  name="searchsales">
					    <option value="<? echo "$searchsales"; ?>" selected><? echo "$searchsales"; ?></option>
					    <? echo "$SALES_select"; ?>
					    <option value="">REMOVE</option>

					    </select>
                </td>
            </tr>
<tr>
<td width="128">&nbsp;</td>
<td width="161">&nbsp;</td>
<td width="66">&nbsp;</td>
<td width="245">&nbsp;</td>
</tr>


<link href="calendar.css" type="text/css" rel="stylesheet" />
<script src="calendar.js" type="text/javascript"></script>
<script type="text/javascript"> 
function init() {
	calendar.set("enrollfrom");
	calendar.set("enrollto");
	calendar.set("cancelfrom");
	calendar.set("cancelto");
	calendar.set("expirefrom");
	calendar.set("expireto");
}
</script>


<tr>
<td width="128"><font color="#FFFFFF"><b>&nbsp;Enrolled From:</b></font> </td>
<td class='ss-round-inputs' colspan="3">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="enrollfrom" id="enrollfrom" size="11" value="YYYY-MM-DD"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" > <b><font color="#FFFFFF">&nbsp;to&nbsp; </font></b> 
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="enrollto" id="enrollto" size="11" value="YYYY-MM-DD"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="128">&nbsp;</td>
<td width="161">&nbsp;</td>
<td width="66">&nbsp;</td>
<td width="245">&nbsp;</td>
</tr>

<tr>
<td width="128"><font color="#FFFFFF"><b>&nbsp;Canceled From:</b></font> </td>
<td class='ss-round-inputs' colspan="3">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="cancelfrom" id="cancelfrom" size="11" value="YYYY-MM-DD"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" > <b><font color="#FFFFFF">&nbsp;to&nbsp; </font></b> 
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="cancelto" id="cancelto" size="11" value="YYYY-MM-DD"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="128">&nbsp;</td>
<td width="161">&nbsp;</td>
<td width="66">&nbsp;</td>
<td width="245">&nbsp;</td>
</tr>

<!--
<tr>
<td width="128"><font color="#FFFFFF"><b>&nbsp;Expired From:</b></font> </td>
<td class='ss-round-inputs' colspan="3">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="expirefrom" id="expirefrom" size="11" value="YYYY-MM-DD"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" > <b><font color="#FFFFFF">&nbsp;to&nbsp; </font></b> 
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="expireto" id="expireto" size="11" value="YYYY-MM-DD"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >
</td>
</tr>

<tr>
<td width="128">&nbsp;</td>
<td width="161">&nbsp;</td>
<td width="66">&nbsp;</td>
<td width="245">&nbsp;</td>
</tr>
-->

</td>
</tr>
</table>
</div>

<!------- INTERNAL TABLE #3 ----->
<table border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse" width="100%">
<tr>
<td>

            <tr>
                <td width="128"><font color="#FFFFFF"><b>&nbsp;Billing Cycle:</b></font></td>
                <td class='ss-round-inputs' width="161">
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input type="text" class="txtbox"  name="billingcycle" size="4" value="<?php print($billingcycle);?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" >&nbsp;&nbsp; 
                                     <?php
    if($billingcycle != "")
    {
        ?>
               
<a target="_blank" href="checkprintall.php?billingcycle=<?php print($billingcycle);?>&cname=<?php print($cname);?>" style="font-weight: 700">
                                    <font color="#FFFFFF">Draft Checks</font></a>


  <?php
}
        ?></td>
<td width="66">&nbsp;</td>
<td width="245"><input type="hidden" name="f" value="1"><input type="submit" name="Find" value="Search Clients"></td>
</tr>

<tr>
<td width="128">&nbsp;</td>
<td width="161">&nbsp;</td>
<td width="66">&nbsp;</td>
<td width="245"><input type="checkbox" name="exclude" value="yes" checked> Exclude Inactive Set</td>
</tr>
</table>


</td>
</tr>
</table>


<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="600">
<tr><td width="1"><img border="0" src="bottomleftcorner.gif" ></td>
<td class="miniheaders" background="bottombackground.gif" width="99%"></td>
<td width="1"><img border="0" src="bottomrightcorner.gif"></td></tr>
</table>

</form>

              <BR><BR><BR>
          <?php
    
    if($_GET['f']==1)
    {
if( $_GET['status']  =='scheduled'){
$numcols = 6;
}else{
$numcols = 10;
}

$longsearchstring = "cname=$cname&status=$status&email=$email&zip=$zip&searchbroker=$searchbroker&searchaffiliate=$searchaffiliate&searchsales=$searchsales&enrollfrom=$enrollfrom&enrollto=$enrollto&cancelfrom=$cancelfrom&cancelto=$cancelto&expirefrom=$expirefrom&expireto=$expireto&billingcycle=$billingcycle&exclude=$exclude&f=1&Find=Search+Clients";
        ?>

<?php  if($_SESSION['usname']=="admin"){  ?>
<input type="button" style="position:relative;color: #07c;font-family: Georgia,serif;font-size: 12px;" name="OK" value="Export CSV" label="OK" onClick="javascript:window.location.href='clientscsv.php?<?php print($longsearchstring);?>';">
<?php } ?>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="85%">
<tr>
<td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">List of clients that match your criteria</td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td>
</tr>
</table>



        <table width="85%" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
      
        <tr background="bluestrip.gif" >
       <td background="bluestrip.gif" ><font color="#FFFFFF"></font></td>

            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>Client Name 
			<a style="text-decoration: none" href="search.php?sortby=name1&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&darr;</font></a>
			<a style="text-decoration: none" href="search.php?sortby=name2&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&uarr;</font></b></td>
            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>Address 
			<a style="text-decoration: none" href="search.php?sortby=addr1&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&darr;</font></a>
			<a style="text-decoration: none" href="search.php?sortby=addr2&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&uarr;</font></b></td>
            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>E-mail 
			<a style="text-decoration: none" href="search.php?sortby=email1&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&darr;</font></a>
			<a style="text-decoration: none" href="search.php?sortby=email2&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&uarr;</font></b></td>
            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>Date 
			<a style="text-decoration: none" href="search.php?sortby=date1&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&darr;</font></a>
			<a style="text-decoration: none" href="search.php?sortby=date2&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&uarr;</font></b></td>

            <?php
            if( $_GET['status']  =='scheduled')
{
?>
            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>Notes</b></font></td>
 <?php
}else{
?>
            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>Setup 
			<a style="text-decoration: none" href="search.php?sortby=setup1&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&darr;</font></a>
			<a style="text-decoration: none" href="search.php?sortby=setup2&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&uarr;</font></b></td>

            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>Monthly 
			<a style="text-decoration: none" href="search.php?sortby=monthly1&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&darr;</font></a>
			<a style="text-decoration: none" href="search.php?sortby=monthly2&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&uarr;</font></b></td>

            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>Cycle 
			<a style="text-decoration: none" href="search.php?sortby=cycle1&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&darr;</font></a>
			<a style="text-decoration: none" href="search.php?sortby=cycle2&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&uarr;</font></b></td>

            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>Method 
			<a style="text-decoration: none" href="search.php?sortby=method1&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&darr;</font></a>
			<a style="text-decoration: none" href="search.php?sortby=method2&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&uarr;</font></b></td>

            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>Status 
			<a style="text-decoration: none" href="search.php?sortby=status1&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&darr;</font></a>
			<a style="text-decoration: none" href="search.php?sortby=status2&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&uarr;</font></b></td>

            <td background="bluestrip.gif" ><font color="#FFFFFF"><b>DFR 
			<a style="text-decoration: none" href="search.php?sortby=dfr1&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&darr;</font></a>
			<a style="text-decoration: none" href="search.php?sortby=dfr2&<?php print($longsearchstring);?>"><font size="2" color="#FFFFFF">&uarr;</font></b></td>

           <?php
}
?>
  <td background="bluestrip.gif" style="border-right-style: solid; border-right-width: 1"></td>

        </tr>
        <?php
        
if (! $cname) {
$namequery = "";
}else{
$namequery = " AND clients.name LIKE('%" . mysql_real_escape_string($_GET['cname']) . "%')";
}

if (! $zip) {
$zipquery = "";
}else{
$zipquery = " AND clients.zip ='$zip'";
}

if (! $email) {
$emailquery = "";
}else{
$emailquery = " AND clients.email LIKE('%" . mysql_real_escape_string($_GET['email']) . "%')";
}

if (! $status) {
$statusquery = "";
}else{
$statusquery = " AND clients.status LIKE('%" . mysql_real_escape_string($_GET['status']) . "%')";
}

if (! $billingcycle) {
$billingcyclequery = "";
}else{
$billingcyclequery = " AND billing.monthlydue LIKE('%" . mysql_real_escape_string($_GET['billingcycle']) . "%')";
}

if (! $searchbroker) {
$brokerquery = "";
}else{
$brokerquery = " AND clients.broker_id='$searchbroker'";
}

if (! $searchaffiliate) {
$affquery = "";
}else{
$affquery = " AND clients.affiliate_id='$searchaffiliate'";
}

if (! $searchsales) {
$salesquery = "";
}else{
$salesquery = " AND clients.dealer_id='$searchsales'";
}

if ($enrollfrom == "" or $enrollfrom =="YYYY-MM-DD" or $enrollto == "" or $enrollto =="YYYY-MM-DD") {
$enrollquery = "";
}else{
$enrollquery = " AND clients.createdate >= '$enrollfrom' AND clients.createdate <= '$enrollto'";
}

if ($cancelfrom == "" or $cancelfrom =="YYYY-MM-DD" or $cancelto == "" or $cancelto =="YYYY-MM-DD") {
$cancelquery = "";
}else{
$cancelquery = " AND clients.canceldate >= '$cancelfrom' AND clients.canceldate <= '$cancelto' AND clients.status ='canceled'";
}

if ($expirefrom == "" or $expirefrom =="YYYY-MM-DD" or $expireto == "" or $expireto =="YYYY-MM-DD") {
$expirequery = "";
}else{
$expirequery = " AND enrolment.dateexpire >= '$expirefrom' AND enrolment.dateexpire <= '$expireto'";
}


if ($exclude == "yes" && $cancelquery =="") {
$excludequery = " AND clients.status != 'canceled' AND clients.status != 'complete' AND clients.status != 'inactive' AND clients.status != 'expired'";
}else{
$excludequery = " ";
}


if ($sortby =="") {       
$sortstatement = "order by clients.createdate desc, clients.id desc";
}else if ($sortby =="name1") {       
$sortstatement = "order by clients.name, clients.id desc";
}else if ($sortby =="name2") {       
$sortstatement = "order by clients.name desc, clients.id desc";
}else if ($sortby =="addr1") {       
$sortstatement = "order by clients.address, clients.id desc";
}else if ($sortby =="addr2") {       
$sortstatement = "order by clients.address desc, clients.id desc";
}else if ($sortby =="email1") {       
$sortstatement = "order by clients.email, clients.id desc";
}else if ($sortby =="email2") {       
$sortstatement = "order by clients.email desc, clients.id desc";
}else if ($sortby =="date1") {       
$sortstatement = "order by billing.paid, clients.id desc";
}else if ($sortby =="date2") {       
$sortstatement = "order by billing.paid desc, clients.id desc";
}else if ($sortby =="setup1") {       
$sortstatement = "order by billing.auditfee, clients.id desc";
}else if ($sortby =="setup2") {       
$sortstatement = "order by billing.auditfee desc, clients.id desc";
}else if ($sortby =="monthly1") {       
$sortstatement = "order by billing.monthlyfee, clients.id desc";
}else if ($sortby =="monthly2") {       
$sortstatement = "order by billing.monthlyfee desc, clients.id desc";
}else if ($sortby =="cycle1") {       
$sortstatement = "order by billing.monthlydue, clients.id desc";
}else if ($sortby =="cycle2") {       
$sortstatement = "order by billing.monthlydue desc, clients.id desc";
}else if ($sortby =="method1") {       
$sortstatement = "order by billing.payment, clients.id desc";
}else if ($sortby =="method2") {       
$sortstatement = "order by billing.payment desc, clients.id desc";
}else if ($sortby =="status1") {       
$sortstatement = "order by clients.status, clients.id desc";
}else if ($sortby =="status2") {       
$sortstatement = "order by clients.status desc, clients.id desc";
}else if ($sortby =="dfr1") {       
$sortstatement = "order by clients.dateresults, clients.id desc";
}else if ($sortby =="dfr2") {       
$sortstatement = "order by clients.dateresults desc, clients.id desc";
}

 	
if(($_GET['expirecheck'] != null) && ($_GET['expirecheck'] != ''))
          {
          $expirecheck=$_GET['expirecheck'];
          $renewtoday=date("Y-m-d");
if($expirecheck > 0){
$expirewithin = date("Y-m-d", time()+$expirecheck*24*3600);
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults, clients.plan, clients.sendtohtdi, clients.showstatus, DATE_FORMAT(clients.dateresults, \"%m-%d-%Y\") as dateresults2    FROM clients,billing,enrolment WHERE clients.id=billing.clientid AND billing.clientid=enrolment.clientid $brokerquery $affquery $enrollquery $salesquery AND clients.clientdelete != 'yes' AND clients.prospectclient = 'Client'  AND dateexpire >= '$renewtoday' and dateexpire <= '$expirewithin' $sortstatement";

}else if($expirecheck < 0){
$expirecheck = trim($expirecheck, "-");
$expirewithin = date("Y-m-d", time()-$expirecheck*24*3600);
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults, clients.plan, clients.sendtohtdi, clients.showstatus, DATE_FORMAT(clients.dateresults, \"%m-%d-%Y\") as dateresults2  FROM clients,billing,enrolment WHERE clients.id=billing.clientid AND billing.clientid=enrolment.clientid $brokerquery $affquery $enrollquery $salesquery AND clients.clientdelete != 'yes' AND clients.prospectclient = 'Client'  AND dateexpire < '$renewtoday' and dateexpire >= '$expirewithin' $sortstatement";

}

 }


          else
              $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults, clients.plan, clients.sendtohtdi, clients.showstatus, DATE_FORMAT(clients.dateresults, \"%m-%d-%Y\") as dateresults2  FROM clients,billing WHERE clients.id=billing.clientid $namequery $zipquery $emailquery $statusquery $billingcyclequery $brokerquery $affquery $enrollquery $salesquery $excludequery $cancelquery AND clients.reseller_id = 0 AND clients.prospectclient = 'Client'  AND clients.clientdelete != 'yes' $sortstatement";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $address      = $row[2];
              $cemail       = $row[3];
              $paid         = $row[4];
              $auditfee       = $row[5];
              $monthlyfee	= $row[6];
              $monthlydue	= $row[7];
              $payment       = $row[8];
              $status       = $row[9];
              $dateresults  = $row[10];
              $plan  = $row[11];
              $sendtohtdi  = $row[12];
              $showstatus  = $row[13]; 
                $dateresults2  = $row[14]; 
                  
              $totalresids  = $totalresids + $monthlyfee;       
              $totalsetup = $totalsetup + $auditfee;       

             $cnt++;
if($dateresults !="0000-00-00"){
$sendday = dateDiff("-", $dateresults2, $todaydate2);
}else{
$sendday = "N/A";
}

			  
         if ($status == "pending"){
	        $bgcolor = "FFFFBB"; 
	        
  }
    else if ($status == "canceled"){
	        $bgcolor = "98877e";
	       
	}
    else if ($status == "NSF"){
	        $bgcolor = "FF00FF";
	       
	}
	  else if ($status == "contact1"){
	        $bgcolor = "FF4444";
	       
	}
  else if ($status == "contact2"){
	        $bgcolor = "FF0000";
	       
	}
  else if ($status == "inactive"){
	        $bgcolor = "888888";
	       
	}
  else if ($status == "contact3"){
	        $bgcolor = "888888";
	       
	}


else if ($status == "complete"){
	        $bgcolor = "008000";
	       
	}
else if ($status == "scheduled"){
	        $bgcolor = "FFCCCC";
	       
	}
else if ($status == "expired"){
	        $bgcolor = "888888";
	       
	}
else if ($plan == "budget"){
	        $bgcolor = "FFFFFF";
	       
	}
	else if ($dateresults <= date("Y-m-d")){
	        $bgcolor = "FF6666";
	       
	}

else{

$bgcolor = "FFFFFF";
}
              ?>
              <tr>
              
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($cnt); ?>&nbsp;&nbsp;</td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><a href="setclient.php?cid=<?php print($id); ?>&cname=<?php print($clientname); ?>"><?php print($clientname); ?></a></td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($address); ?></td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><a href="mailto:<?php print($cemail); ?>"><?php print($cemail); ?></a></td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($paid); ?></td>
 <?php
            if( $_GET['status']  =='scheduled')
{
?>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($showstatus); ?></td>
 <?php
}else{
?>

              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($auditfee); ?></td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($monthlyfee); ?></td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($monthlydue); ?></td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($payment); ?></td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($status); ?></td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($sendday); ?></td>
			  <?php
}
?>                         <td style="border-bottom-style: solid; border-bottom-width: 1; border-right-style:solid; border-right-width:1" bgcolor=<?php print($bgcolor); ?>>
              <?php
    if($_SESSION['usaccess']=="full" AND $sendtohtdi != "Yes")
    {
        ?>
<center>
<a href="delete.php?cid=<?php print($id);?>&cname=<?php print($clientname);?>"><img border="0" src="http://www.tcrosystems.net/deletebutton.png"></a>
</center>
              <?php
          }
                    ?>
                    </td>

              </tr>
              <?php
          }
          mysql_close($conn);
          ?>
          
          
          
          
          
          
          <tr>
              
<td ></td>
<td ></td>
<td ></td>
<td ></td>
<td ></td>
 <?php
            if( $_GET['status']  =='scheduled')
{
?>
<td ></td>
 <?php
}else{
?>

<td ><B>Setup<BR>$<?php echo number_format($totalsetup, 2, '.', ''); ?></b></td>
<td ><B>Residual<BR>$<?php echo number_format($totalresids, 2, '.', ''); ?></b></td>
<td ></td>
<td ></td>
<td ></td>
<?php
}
?>
<td >
              <?php
    if($_SESSION['usaccess']=="full" AND $sendtohtdi != "Yes")
    {
        ?>
              <?php
          }
                    ?>
                    </td>

              </tr>





          
          
          </table>

          <?php
          if($cnt==0)
          {
              print("There are no matching records to your search criteria. Please try again.");
          }
    }
}

?>
<script src="http://www.openjs.com/js/jsl.js" type="text/javascript"></script>
<script src="http://www.openjs.com/common.js" type="text/javascript"></script>
<?php
}

else
{
    header("Location: login.php");
    exit();
}

?>