<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);


$nowday = date("d");
$nowmonthword = date("M");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   include('template.php');
 include("connection.php");

 if($_SESSION['usname']=="admin" or ($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing")){

 if($del=="yes"){

 $query = "UPDATE letters SET
				letterorder='DEL'        
                WHERE id='$letterid'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Delete Letter',
                    '$letterid',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());


}}


         $query5 = "SELECT plan,reseller_id,prospectclient,status,jointwith,sendtohtdi, country FROM clients WHERE id='" . mysql_real_escape_string($_SESSION['clientid']) . "'";
              $result5 = mysql_query($query5, $conn) or die("error:" . mysql_error());
              while($row5=mysql_fetch_row($result5))
              {
                   $plan = $row5[0];
                   $reseller_id = $row5[1];                   
                   $prospectclient = $row5[2];                     
                   $status = $row5[3];     
                   $jointwith = $row5[4];                   
                   $sendtohtdi = $row5[5];                   
                   $country = $row5[6];                   
                                   
                  }

?>





            <font size=2 color=blue>
<table border="1" cellpadding="2" cellspacing="2" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="50%" valign="top">
    
    <?php
    if($_SESSION['usname']=="admin" or ($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing")){
        ?><p><a href="addletter.php">Add Letter to list</a></p>

           <?php
}
        ?>
    <p align="center"><b>Bureau Letters</b> </p>
            
            <table cellpadding="3" cellspacing="3" style="border-collapse: collapse" bordercolor="#111111" id="AutoNumber3">
              

            
         
           
            
             <?php
        include("connection.php");
        
     
              
     $query = "SELECT id, lettername FROM letters WHERE letterorder !='DEL' order by letterorder";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $letterid           = $row[0];
              $lettername   = $row[1];

    
        ?>
 
<tr>
       <td width="50%">
             <?php
             if($country =="" or $country=="United States")   {
        ?>
<a target="_blank" href="printletter.php?letterid=<?php print($letterid); ?>&bureauid=1">Equifax <?php print($lettername); ?></a><BR>
<a target="_blank" href="printletter.php?letterid=<?php print($letterid); ?>&bureauid=2">Experian <?php print($lettername); ?></a><BR>
<a target="_blank" href="printletter.php?letterid=<?php print($letterid); ?>&bureauid=3">Transunion <?php print($lettername); ?></a><BR>
<a target="_blank" href="printletter.php?letterid=<?php print($letterid); ?>">3x <?php print($lettername); ?></a>
             <?php
 } else if($country=="Canada")   {
        ?>
<a target="_blank" href="printletter.php?letterid=<?php print($letterid); ?>&bureauid=8">Equifax <?php print($lettername); ?></a><BR>
<a target="_blank" href="printletter.php?letterid=<?php print($letterid); ?>&bureauid=9">Transunion <?php print($lettername); ?></a><BR>
<a target="_blank" href="printletter.php?letterid=<?php print($letterid); ?>">2x <?php print($lettername); ?></a>
    <?php
		}
		?>


</td>

<td width="50%">
 <?php
    if($_SESSION['usname']=="admin" or ($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing"))
    {
        ?>

<a href="editletter.php?letterid=<?php print($letterid); ?>">edit</a>&nbsp;&nbsp;&nbsp;<a onclick="return confirm('Are you sure you want to delete <?php print($lettername); ?>?');" href=letters.php?letterid=<?php print($letterid); ?>&del=yes><img border="0" src="http://www.tcrosystems.net/deletebutton.png" width="13" height="15"></a>
  <?php
}
        ?>
        </td>

          </tr>


          
         
 <BR>
    <?php
}
?>
    </table>


</td>
    
    
    
    
    
    
    
    

    <td width="50%" valign="top">
    <form action="" method="post" name=form>

    <p align="center"><b>Creditors</b>
    <a href="addcreditor.php">
<img border="0" src="http://www.tcrosystems.net/addbutton.png" width="13" height="15"></a><br>
<a href="letters.php?begin=A">A</a>
<a href="letters.php?begin=B">B</a>
<a href="letters.php?begin=C">C</a>
<a href="letters.php?begin=D">D</a>
<a href="letters.php?begin=E">E</a>
<a href="letters.php?begin=F">F</a>
<a href="letters.php?begin=G">G</a>
<a href="letters.php?begin=H">H</a>
<a href="letters.php?begin=I">I</a>
<a href="letters.php?begin=J">J</a>
<a href="letters.php?begin=K">K</a>
<a href="letters.php?begin=L">L</a>
<a href="letters.php?begin=M">M</a>
<a href="letters.php?begin=N">N</a>
<a href="letters.php?begin=O">O</a>
<a href="letters.php?begin=P">P</a>
<a href="letters.php?begin=Q">Q</a>
<a href="letters.php?begin=R">R</a>
<a href="letters.php?begin=S">S</a>
<a href="letters.php?begin=T">T</a>
<a href="letters.php?begin=U">U</a>
<a href="letters.php?begin=V">V</a>
<a href="letters.php?begin=W">W</a>
<a href="letters.php?begin=X">X</a>
<a href="letters.php?begin=Y">Y</a>
<a href="letters.php?begin=Z">Z</a>
<BR><BR>
    <?php

 if($_SESSION['usname']=="admin" or ($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing")){
    
        ?>
        <p><a href="addcredletter.php">Add Letter to list</a></p>


 
           <?php
}
 if($begin !="")
    {

$SA_sql = "SELECT * FROM creditortype where type LIKE('" . mysql_real_escape_string($_GET['begin']) . "%') ORDER BY type";
		$SA_result = @mysql_query($SA_sql,$conn);
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $creditorid = $srow['id'];
		    $creditor = $srow['type'];
		    $credaddress = $srow['address'];
		    
		$creditor_select .= "<option value=\"$creditorid\">$creditor</option>";
		}


$query = "SELECT id, name, number, comments, dispute FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientid']) . "'  GROUP BY name, number"; 
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$col_count = mysql_num_fields($result);
$count=0;   
while($row=mysql_fetch_row($result))
{
    $accid= $row[0];
    $accname= $row[1];
    $accnumber = $row[2];
    $comments = $row[3];
    $dispute = $row[4];
    $count= $count+1;
		$tradeline_select .= "<option value=\"$accid\">$accname - $accnumber</option>";
		}

}
        ?>
       
    <select class="txtboxsmall" id="creditorselected"  name="creditorselected">
                  <option value="" selected></option>
					    <? echo "$creditor_select"; ?>
											    </select><BR>
											    <select class="txtboxsmall" id="tradeselected"  name="tradeselected">
                  <option value="" selected></option>
					    <? echo "$tradeline_select"; ?>
											    </select>
											  <input class="txtboxsmall" type="submit" name="Load" value="Load">  
											    </form>
							 <?php

$SA_sql = "SELECT * FROM creditortype where id = '$creditorselected'";
		$SA_result = @mysql_query($SA_sql,$conn);
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $creditorselected = $srow['id'];
		    $creditornameselected = $srow['type'];
		    $creditoraddressselected = $srow['address'];
		    $citystatezipselected = $srow['citystatezip'];
		    
		    }
		    
		     if($creditornameselected != '')
    {
    
    $SA_sql2 = "SELECT id, name, number FROM accounts where id = '$tradeselected'";
		$SA_result2 = @mysql_query($SA_sql2,$conn);
		  while ($srow2 = mysql_fetch_array($SA_result2)) {
		     $tradeid= $row2[0];
    $tradename= $srow2[1];
    $tradenumber = $srow2[2];

		    
		    }
    
        ?>
        
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber2">
      <tr>
        <td width="80%"><font color="#FF0000"><b>&nbsp;<? echo "$creditornameselected"; ?><BR>
				&nbsp;<? echo "$creditoraddressselected"; ?><BR>
				&nbsp;<? echo "$citystatezipselected"; ?></b></font><BR>
				&nbsp;<? echo "$tradename"; ?> - <? echo "$tradenumber"; ?>
</td>
        <td width="20%"><a href="editcreditor.php?creditorid=<?php print($creditorselected); ?>">edit</a></td>
      </tr>
    </table>
					 <?php
					}
        ?>
	    
											    
											    
 </p>
            <p align="center"><b>Creditor Letters<br></b>
            </p>
            <P align=left>
           
            
             <?php
        
     $query = "SELECT id, lettername FROM credletters WHERE letterorder !='DEL' order by letterorder";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $credletterid           = $row[0];
              $credlettername   = $row[1];
        ?>
 

<a target="_blank" href="printcredletter.php?letterid=<?php print($credletterid); ?>&creditorid=<?php print($creditorselected); ?>&tradenumber=<?php print($tradenumber); ?>"><?php print($credlettername); ?></a>
          

 <?php
 if($_SESSION['usname']=="admin" or ($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing")){
    
        ?>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="editcredletter.php?credletterid=<?php print($credletterid); ?>">edit</a>
           <?php
}
        ?>
<BR>
    <?php
}
?> </p>
</p>
</td>
  </tr>
  </table>
     
      







 </font>

            







 </font>

            







 <?php
}
else
{
    header("Location: login.php");
    exit();
}

?>