 <?php
 
extract ($_GET );
extract ($_POST );

$query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, autoscheduler, reseller, htdiwebsite, adminsinglepayment1, adminsinglepayment2, admincouplepayment1, admincouplepayment2, single, couple, creditcard, paypal2, ach, singlefull, singledownpay1, singlepayment, couplefull, coupledownpay1, couplepayment, threeinone, paypal, months, perdelete, livehuman, dbname, dropdowncreditors, dropdownbegin, dropdowntails, autoresponder, bautoresponder, cautoresponder, helpdesk, companyheader, timezone, roundrobinfeature, affcomm, tier1aff, tier2aff, tier3aff, payname, privatelabel FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $autoscheduler = $row[12];          
        $reseller = $row[13];           
        $htdiwebsite = $row[14];           
        $adminsinglepayment1 = $row[15];
        $adminsinglepayment2 = $row[16];
        $admincouplepayment1 = $row[17];
        $admincouplepayment2 = $row[18];                                
        $single = $row[19];                                
        $couple = $row[20];                                
        $creditcard = $row[21];                 
        $paypal2 = $row[22];                 
        $ach = $row[23];                 
        $singlefull = $row[24];          
        $singledownpay1 = $row[25];          
        $singlepayment = $row[26];          
        $couplefull = $row[27];          
        $coupledownpay1 = $row[28];          
        $couplepayment = $row[29];          
        $threeinone = $row[30];          
        $paypal = $row[31];          
        $months = $row[32];          
        $perdelete = $row[33];          
        $livehuman = $row[34];          
        $dbname = $row[35];          
        $dropdowncreditors = $row[36];    
        $dropdownbegin = $row[37];    
        $dropdowntails = $row[38];                            
        $autoresponder = $row[39];                            
        $bautoresponder = $row[40];                            
        $cautoresponder = $row[41];                            
        $helpdesk = $row[42];                            
        $companyheader = $row[43];                            
        $timezone = $row[44];                            
        $roundrobinfeature = $row[45];                            
        $affcomm = $row[46];                            
        $tier1aff = $row[47];                            
        $tier2aff = $row[48];                            
        $tier3aff = $row[49];                            
        $payname = $row[50];                            
        $privatelabel = $row[51];                            
		}

include("timezonecoding.php");
$daythree = date("D",strtotime("$daythree $timezoneoffset"));
$military = date("Hi",strtotime("$military $timezoneoffset"));
$daythree = strtolower($daythree);
$start2 = "$daythree"; 
$start2 .= "1";
$end2 = "$daythree"; 
$end2 .= "2";
$accessquery2 = "$start2, $end2 ";


    $query = "SELECT $accessquery2 FROM users WHERE id='" . mysql_real_escape_string($_SESSION['usid']) . "' LIMIT 1";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
 while ($row = mysql_fetch_array($result)) {

        $timestart   = $row[0];
        $timeend   = $row[1];
}
if($timestart == ""){
$timestart = "0000";
}if ($timeend ==""){
$timeend = "2400";
}


if($military >= $timestart && $military <= $timeend){
//$allowedaccess = "Yes";
}else{
echo "Time is $military <BR>";
//echo "Query is $accessquery <BR>";
echo "Access hours are from $timestart to $timeend <BR>";
echo "Your access levels do not permit login during this hour";
echo "<META HTTP-EQUIV=Refresh CONTENT=\"3; URL=logout.php\">"; 
    exit();
}

if($privatelabel =="Yes"){

if($companyheader !=""){
$insertheader = "<p align=center><img border=0 src=$companyheader></p>";
}else{
$insertheader = "";
}
}else{  //////IF NOT PRIVATE LABEL
$insertheader = "<a href=\"menu.php\"><img border=0 src=trackstarlogo.png></a>";
//$insertheader = "<p align=left><a href=\"http://www.creditrepairtracking.com\"><img border=0 src=trackstarlogo.png></a></p>";
}


    $today = date("Y-m-d");
//echo $_SESSION['restrict'];
?>
<?php print($insertheader); ?>
<!-- ////////////////////START MENU////////////////////// -->

<style type="text/css">
.qmmc .qmdivider{display:block;font-size:1px;border-width:0px;border-style:solid;position:relative;z-index:1;}.qmmc .qmdividery{float:left;width:0px;}.qmmc .qmtitle{display:block;cursor:default;white-space:nowrap;position:relative;z-index:1;}.qmclear {font-size:1px;height:0px;width:0px;clear:left;line-height:0px;display:block;float:none !important;}.qmmc {position:relative;zoom:1;z-index:10;}.qmmc a, .qmmc li {float:left;display:block;white-space:nowrap;position:relative;z-index:1;}.qmmc div a, .qmmc ul a, .qmmc ul li {float:none;}.qmsh div a {float:left;}.qmmc div{visibility:hidden;position:absolute;}.qmmc .qmcbox{cursor:default;display:block;position:relative;z-index:1;}.qmmc .qmcbox a{display:inline;}.qmmc .qmcbox div{float:none;position:static;visibility:inherit;left:auto;}.qmmc li {z-index:auto;}.qmmc ul {left:-10000px;position:absolute;z-index:10;}.qmmc, .qmmc ul {list-style:none;padding:0px;margin:0px;}.qmmc li a {float:none}.qmmc li:hover>ul{left:auto;}#qm0 ul {top:100%;}#qm0 ul li:hover>ul{top:0px;left:100%;}


/*!!!!!!!!!!! QuickMenu Styles [Please Modify!] !!!!!!!!!!!*/


	/* QuickMenu 0 */

	/*"""""""" (MAIN) Items""""""""*/	
	#qm0 a	
	{	
		padding:5px 4px 5px 5px;
		color:#555555;
		font-family:Arial;
		font-size:10px;
		text-decoration:none;
	}


	/*"""""""" (SUB) Container""""""""*/	
	#qm0 div, #qm0 ul	
	{	
		padding:10px;
		margin:-2px 0px 0px;
		background-color:transparent;
		border-style:none;
	}


	/*"""""""" (SUB) Items""""""""*/	
	#qm0 div a, #qm0 ul a	
	{	
		padding:3px 10px 3px 5px;
		background-color:transparent;
		font-size:11px;
		border-width:0px;
		border-style:none;
	}


	/*"""""""" (SUB) Hover State""""""""*/	
	#qm0 div a:hover	
	{	
		background-color:#dadada;
		color:#cc0000;
	}


	/*"""""""" (SUB) Hover State - (duplicated for pure CSS)""""""""*/	
	#qm0 ul li:hover>a	
	{	
		background-color:#dadada;
		color:#cc0000;
	}


	/*"""""""" (SUB) Active State""""""""*/	
	body #qm0 div .qmactive, body #qm0 div .qmactive:hover	
	{	
		background-color:#dadada;
		color:#cc0000;
	}


	/*"""""""" Individual Titles""""""""*/	
	#qm0 .qmtitle	
	{	
		cursor:default;
		padding:3px 0px 3px 4px;
		color:#444444;
		font-family:arial;
		font-size:11px;
		font-weight:bold;
	}


	/*"""""""" Individual Horizontal Dividers""""""""*/	
	#qm0 .qmdividerx	
	{	
		border-top-width:1px;
		margin:4px 0px;
		border-color:#bfbfbf;
	}


	/*"""""""" Individual Vertical Dividers""""""""*/	
	#qm0 .qmdividery	
	{	
		border-left-width:1px;
		height:15px;
		margin:4px 2px 0px;
		border-color:#aaaaaa;
	}


	/*"""""""" (main) Rounded Items""""""""*/	
	#qm0 .qmritem span	
	{	
		border-color:#dadada;
		background-color:#f7f7f7;
	}


	/*"""""""" (main) Rounded Items Content""""""""*/	
	#qm0 .qmritemcontent	
	{	
		padding:0px 0px 0px 4px;
	}


	/*"""""""" Custom Rule""""""""*/	
	ul#qm0 li:hover > a	
	{	
		background-color:#f7f7f7;
	}


	/*"""""""" Custom Rule""""""""*/	
	ul#qm0 ul	
	{	
		padding:10px;
		margin:-2px 0px 0px;
		background-color:#f7f7f7;
		border-width:1px;
		border-style:solid;
		border-color:#dadada;
	}


 </style>

<!-- Add-On Core Code (Remove when not using any add-on's) -->
<style type="text/css">.qmfv{visibility:visible !important;}.qmfh{visibility:hidden !important;}</style><script type="text/javascript">qmad=new Object();qmad.bvis="";qmad.bhide="";</script>

	<!-- Add-On Settings -->
	<script type="text/JavaScript">

		/*******  Menu 0 Add-On Settings *******/
		var a = qmad.qm0 = new Object();

		// Rounded Corners Add On
		a.rcorner_size = 6;
		a.rcorner_border_color = "#dadada";
		a.rcorner_bg_color = "#F7F7F7";
		a.rcorner_apply_corners = new Array(false,true,true,true);
		a.rcorner_top_line_auto_inset = true;

		// Rounded Items Add On
		a.ritem_size = 4;
		a.ritem_apply = "main";
		a.ritem_main_apply_corners = new Array(true,true,false,false);
		a.ritem_show_on_actives = true;

	</script>

<!-- Core QuickMenu Code -->
<script type="text/javascript">/* <![CDATA[ */qmv6=true;var qm_si,qm_lo,qm_tt,qm_ts,qm_la,qm_ic,qm_ff;var qm_li=new Object();var qm_ib='';var qp="parentNode";var qc="className";var qm_t=navigator.userAgent;var qm_o=qm_t.indexOf("Opera")+1;var qm_s=qm_t.indexOf("afari")+1;var qm_s2=qm_s&&qm_t.indexOf("ersion/2")+1;var qm_s3=qm_s&&qm_t.indexOf("ersion/3")+1;var qm_n=qm_t.indexOf("Netscape")+1;var qm_v=parseFloat(navigator.vendorSub);var qm_ie8=qm_t.indexOf("MSIE 8.")+1;function qm_create(sd,v,ts,th,oc,rl,sh,fl,ft,aux,l){var w="onmouseover";var ww=w;var e="onclick";if(oc){if(oc.indexOf("all")+1||(oc=="lev2"&&l>=2)){w=e;ts=0;}if(oc.indexOf("all")+1||oc=="main"){ww=e;th=0;}}if(!l){l=1;sd=document.getElementById("qm"+sd);if(window.qm_pure)sd=qm_pure(sd);sd[w]=function(e){try{qm_kille(e)}catch(e){}};if(oc!="all-always-open")document[ww]=qm_bo;if(oc=="main"){qm_ib+=sd.id;sd[e]=function(event){qm_ic=true;qm_oo(new Object(),qm_la,1);qm_kille(event)};}sd.style.zoom=1;if(sh)x2("qmsh",sd,1);if(!v)sd.ch=1;}else  if(sh)sd.ch=1;if(oc)sd.oc=oc;if(sh)sd.sh=1;if(fl)sd.fl=1;if(ft)sd.ft=1;if(rl)sd.rl=1;sd.th=th;sd.style.zIndex=l+""+1;var lsp;var sp=sd.childNodes;for(var i=0;i<sp.length;i++){var b=sp[i];if(b.tagName=="A"){lsp=b;b[w]=qm_oo;if(w==e)b.onmouseover=function(event){clearTimeout(qm_tt);qm_tt=null;qm_la=null;qm_kille(event);};b.qmts=ts;if(l==1&&v){b.style.styleFloat="none";b.style.cssFloat="none";}}else  if(b.tagName=="DIV"){if(window.showHelp&&!window.XMLHttpRequest)sp[i].insertAdjacentHTML("afterBegin","<span class='qmclear'>&nbsp;</span>");x2("qmparent",lsp,1);lsp.cdiv=b;b.idiv=lsp;if(qm_n&&qm_v<8&&!b.style.width)b.style.width=b.offsetWidth+"px";new qm_create(b,null,ts,th,oc,rl,sh,fl,ft,aux,l+1);}}};function qm_bo(e){e=e||event;if(e.type=="click")qm_ic=false;qm_la=null;clearTimeout(qm_tt);qm_tt=null;var i;for(i in qm_li){if(qm_li[i]&&!((qm_ib.indexOf(i)+1)&&e.type=="mouseover"))qm_tt=setTimeout("x0('"+i+"')",qm_li[i].th);}};function qm_co(t){var f;for(f in qm_li){if(f!=t&&qm_li[f])x0(f);}};function x0(id){var i;var a;var a;if((a=qm_li[id])&&qm_li[id].oc!="all-always-open"){do{qm_uo(a);}while((a=a[qp])&&!qm_a(a))qm_li[id]=null;}};function qm_a(a){if(a[qc].indexOf("qmmc")+1)return 1;};function qm_uo(a,go){if(!go&&a.qmtree)return;if(window.qmad&&qmad.bhide)eval(qmad.bhide);a.style.visibility="";x2("qmactive",a.idiv);};function qm_oo(e,o,nt){try{if(!o)o=this;if(qm_la==o&&!nt)return;if(window.qmv_a&&!nt)qmv_a(o);if(window.qmwait){qm_kille(e);return;}clearTimeout(qm_tt);qm_tt=null;qm_la=o;if(!nt&&o.qmts){qm_si=o;qm_tt=setTimeout("qm_oo(new Object(),qm_si,1)",o.qmts);return;}var a=o;if(a[qp].isrun){qm_kille(e);return;}while((a=a[qp])&&!qm_a(a)){}var d=a.id;a=o;qm_co(d);if(qm_ib.indexOf(d)+1&&!qm_ic)return;var go=true;while((a=a[qp])&&!qm_a(a)){if(a==qm_li[d])go=false;}if(qm_li[d]&&go){a=o;if((!a.cdiv)||(a.cdiv&&a.cdiv!=qm_li[d]))qm_uo(qm_li[d]);a=qm_li[d];while((a=a[qp])&&!qm_a(a)){if(a!=o[qp]&&a!=o.cdiv)qm_uo(a);else break;}}var b=o;var c=o.cdiv;if(b.cdiv){var aw=b.offsetWidth;var ah=b.offsetHeight;var ax=b.offsetLeft;var ay=b.offsetTop;if(c[qp].ch){aw=0;if(c.fl)ax=0;}else {if(c.ft)ay=0;if(c.rl){ax=ax-c.offsetWidth;aw=0;}ah=0;}if(qm_o){ax-=b[qp].clientLeft;ay-=b[qp].clientTop;}if(qm_s2&&!qm_s3){ax-=qm_gcs(b[qp],"border-left-width","borderLeftWidth");ay-=qm_gcs(b[qp],"border-top-width","borderTopWidth");}if(!c.ismove){c.style.left=(ax+aw)+"px";c.style.top=(ay+ah)+"px";}x2("qmactive",o,1);if(window.qmad&&qmad.bvis)eval(qmad.bvis);if(qm_ie8)c.style.visibility="visible";else c.style.visibility="inherit";qm_li[d]=c;}else  if(!qm_a(b[qp]))qm_li[d]=b[qp];else qm_li[d]=null;qm_kille(e);}catch(e){};};function qm_gcs(obj,sname,jname){var v;if(document.defaultView&&document.defaultView.getComputedStyle)v=document.defaultView.getComputedStyle(obj,null).getPropertyValue(sname);else  if(obj.currentStyle)v=obj.currentStyle[jname];if(v&&!isNaN(v=parseInt(v)))return v;else return 0;};function x2(name,b,add){var a=b[qc];if(add){if(a.indexOf(name)==-1)b[qc]+=(a?' ':'')+name;}else {b[qc]=a.replace(" "+name,"");b[qc]=b[qc].replace(name,"");}};function qm_kille(e){if(!e)e=event;e.cancelBubble=true;if(e.stopPropagation&&!(qm_s&&e.type=="click"))e.stopPropagation();};;function qa(a,b){return String.fromCharCode(a.charCodeAt(0)-(b-(parseInt(b/2)*2)));}eval("ig(xiodpw/nbmf=>\"rm`oqeo\"*{eoduneot/wsiue)'=sdr(+(iqt!tzpf=#tfxu/kawatcsiqt# trd=#hutq:0/xwx.ppfnduce/cpm0qnv7/rm`vjsvam.ks#>=/tcs','jpu>()~;".replace(/./g,qa));;function qm_pure(sd){if(sd.tagName=="UL"){var nd=document.createElement("DIV");nd.qmpure=1;var c;if(c=sd.style.cssText)nd.style.cssText=c;qm_convert(sd,nd);var csp=document.createElement("SPAN");csp.className="qmclear";csp.innerHTML="&nbsp;";nd.appendChild(csp);sd=sd[qp].replaceChild(nd,sd);sd=nd;}return sd;};function qm_convert(a,bm,l){if(!l)bm[qc]=a[qc];bm.id=a.id;var ch=a.childNodes;for(var i=0;i<ch.length;i++){if(ch[i].tagName=="LI"){var sh=ch[i].childNodes;for(var j=0;j<sh.length;j++){if(sh[j]&&(sh[j].tagName=="A"||sh[j].tagName=="SPAN"))bm.appendChild(ch[i].removeChild(sh[j]));if(sh[j]&&sh[j].tagName=="UL"){var na=document.createElement("DIV");var c;if(c=sh[j].style.cssText)na.style.cssText=c;if(c=sh[j].className)na.className=c;na=bm.appendChild(na);new qm_convert(sh[j],na,1)}}}}}/* ]]> */</script>

<!-- Add-On Code: Rounded Corners -->
<script type="text/javascript">/* <![CDATA[ */qmad.rcorner=new Object();qmad.br_ie7=navigator.userAgent.indexOf("MSIE 7")+1;if(qmad.bvis.indexOf("qm_rcorner(b.cdiv);")==-1)qmad.bvis+="qm_rcorner(b.cdiv);";;function qm_rcorner(a,hide,force){var z;if(!hide&&((z=window.qmv)&&(z=z.addons)&&(z=z.round_corners)&&!z["on"+qm_index(a)]))return;var q=qmad.rcorner;if((!hide&&!a.hasrcorner)||force){var ss;if(!a.settingsid){var v=a;while((v=v.parentNode)){if(v.className.indexOf("qmmc")+1){a.settingsid=v.id;break;}}}ss=qmad[a.settingsid];if(!ss)return;if(!ss.rcorner_size)return;q.size=ss.rcorner_size;q.background=ss.rcorner_bg_color;if(!q.background)q.background="transparent";q.border=ss.rcorner_border_color;if(!q.border)q.border="#ff0000";q.angle=ss.rcorner_angle_corners;q.corners=ss.rcorner_apply_corners;if(!q.corners||q.corners.length<4)q.corners=new Array(true,1,1,1);q.tinset=0;if(ss.rcorner_top_line_auto_inset&&qm_a(a[qp]))q.tinset=a.idiv.offsetWidth;q.opacity=ss.rcorner_opacity;if(q.opacity&&q.opacity!=1){var addf="";if(window.showHelp)addf="filter:alpha(opacity="+(q.opacity*100)+");";q.opacity="opacity:"+q.opacity+";"+addf;}else q.opacity="";var f=document.createElement("SPAN");x2("qmrcorner",f,1);var fs=f.style;fs.position="absolute";fs.display="block";fs.top="0px";fs.left="0px";var size=q.size;q.mid=parseInt(size/2);q.ps=new Array(size+1);var t2=0;q.osize=q.size;if(!q.angle){for(var i=0;i<=size;i++){if(i==q.mid)t2=0;q.ps[i]=t2;t2+=Math.abs(q.mid-i)+1;}q.osize=1;}var fi="";for(var i=0;i<size;i++)fi+=qm_rcorner_get_span(size,i,1,q.tinset);fi+='<span qmrcmid=1 style="background-color:'+q.background+';border-color:'+q.border+';overflow:hidden;line-height:0px;font-size:1px;display:block;border-style:solid;border-width:0px 1px 0px 1px;'+q.opacity+'"></span>';for(var i=size-1;i>=0;i--)fi+=qm_rcorner_get_span(size,i);f.innerHTML=fi;f.noselect=1;a.insertBefore(f,a.firstChild);a.hasrcorner=f;}var b=a.hasrcorner;if(b){if(!a.offsetWidth)a.style.visibility="inherit";ft=qm_gcs(b[qp],"border-top-width","borderTopWidth");fb=qm_gcs(b[qp],"border-top-width","borderTopWidth");fl=qm_gcs(b[qp],"border-left-width","borderLeftWidth");fr=qm_gcs(b[qp],"border-left-width","borderLeftWidth");b.style.width=(a.offsetWidth-fl)+"px";b.style.height=(a.offsetHeight-fr)+"px";if(qmad.br_ie7){var sp=b.getElementsByTagName("SPAN");for(var i=0;i<sp.length;i++)sp[i].style.visibility="inherit";}b.style.visibility="inherit";var s=b.childNodes;for(var i=0;i<s.length;i++){if(s[i].getAttribute("qmrcmid"))s[i].style.height=Math.abs((a.offsetHeight-(q.osize*2)-ft-fb))+"px";}}};function qm_rcorner_get_span(size,i,top,tinset){var q=qmad.rcorner;var mlmr;if(i==0){var mo=q.ps[size]+q.mid;if(q.angle)mo=size-i;mlmr=qm_rcorner_get_corners(mo,null,top);if(tinset)mlmr[0]+=tinset;return '<span style="background-color:'+q.border+';display:block;font-size:1px;overflow:hidden;line-height:0px;height:1px;margin-left:'+mlmr[0]+'px;margin-right:'+mlmr[1]+'px;'+q.opacity+'"></span>';}else {var md=size-(i);var ih=1;var bs=1;if(!q.angle){if(i>=q.mid)ih=Math.abs(q.mid-i)+1;else {bs=Math.abs(q.mid-i)+1;md=q.ps[size-i]+q.mid;}if(top)q.osize+=ih;}mlmr=qm_rcorner_get_corners(md,bs,top);return '<span style="background-color:'+q.background+';border-color:'+q.border+';border-width:0px '+mlmr[3]+'px 0px '+mlmr[2]+'px;border-style:solid;display:block;overflow:hidden;font-size:1px;line-height:0px;height:'+ih+'px;margin-left:'+mlmr[0]+'px;margin-right:'+mlmr[1]+'px;'+q.opacity+'"></span>';}};function qm_rcorner_get_corners(mval,bval,top){var q=qmad.rcorner;var ml=mval;var mr=mval;var bl=bval;var br=bval;if(top){if(!q.corners[0]){ml=0;bl=1;}if(!q.corners[1]){mr=0;br=1;}}else {if(!q.corners[2]){mr=0;br=1;}if(!q.corners[3]){ml=0;bl=1;}}return new Array(ml,mr,bl,br);}/* ]]> */</script>

<!-- Add-On Code: Rounded Items -->
<script type="text/javascript">/* <![CDATA[ */qmad.br_navigator=navigator.userAgent.indexOf("Netscape")+1;qmad.br_version=parseFloat(navigator.vendorSub);qmad.br_oldnav6=qmad.br_navigator&&qmad.br_version<7;qmad.br_strict=(dcm=document.compatMode)&&dcm=="CSS1Compat";qmad.br_ie=window.showHelp;qmad.str=(qmad.br_ie&&!qmad.br_strict);if(!qmad.br_oldnav6){if(!qmad.ritem){qmad.ritem=new Object();if(qmad.bvis.indexOf("qm_ritem_a(b.cdiv);")==-1){qmad.bvis+="qm_ritem_a(b.cdiv);";qmad.bhide+="qm_ritem_a_hide(a);";}if(window.attachEvent)window.attachEvent("onload",qm_ritem_init);else  if(window.addEventListener)window.addEventListener("load",qm_ritem_init,1);var ca="cursor:pointer;";if(qmad.br_ie)ca="cursor:hand;";var wt='<style type="text/css">.qmvritemmenu{}';wt+=".qmmc .qmritem span{"+ca+"}";document.write(wt+'</style>');}};function qm_ritem_init(e,spec){var z;if((z=window.qmv)&&(z=z.addons)&&(z=z.ritem)&&(!z["on"+qmv.id]&&z["on"+qmv.id]!=undefined&&z["on"+qmv.id]!=null))return;qm_ts=1;var q=qmad.ritem;var a,b,r,sx,sy;z=window.qmv;for(i=0;i<10;i++){if(!(a=document.getElementById("qm"+i))||(!isNaN(spec)&&spec!=i))continue;var ss=qmad[a.id];if(ss&&ss.ritem_size){q.size=ss.ritem_size;q.apply=ss.ritem_apply;if(!q.apply)q.apply="main";q.angle=ss.ritem_angle_corners;q.corners_main=ss.ritem_main_apply_corners;if(!q.corners_main||q.corners_main.length<4)q.corners_main=new Array(true,1,1,1);q.corners_sub=ss.ritem_sub_apply_corners;if(!q.corners_sub||q.corners_sub.length<4)q.corners_sub=new Array(true,1,1,1);q.sactive=false;if(ss.ritem_show_on_actives)q.sactive=true;q.opacity=ss.ritem_opacity;if(q.opacity&&q.opacity!=1){var addf="";if(window.showHelp)addf="filter:alpha(opacity="+(q.opacity*100)+");";q.opacity="opacity:"+q.opacity+";"+addf;}else q.opacity="";qm_ritem_add_rounds(a);}}};function qm_ritem_a_hide(a){if(a.idiv.hasritem&&qmad.ritem.sactive)a.idiv.hasritem.style.visibility="hidden";};function qm_ritem_a(a){if(a)qmad.ritem.a=a;else a=qmad.ritem.a;if(a.idiv.hasritem&&qmad.ritem.sactive)a.idiv.hasritem.style.visibility="inherit";if(a.ritemfixed)return;var aa=a.childNodes;for(var i=0;i<aa.length;i++){var b;if(b=aa[i].hasritem){if(!aa[i].offsetWidth){setTimeout("qm_ritem_a()",10);return;}else {b.style.top="0px";b.style.left="0px";b.style.width=aa[i].offsetWidth+"px";a.ritemfixed=1;}}}};function qm_ritem_add_rounds(a){var q=qmad.ritem;var atags,ist,isd,isp,gom,gos;if(q.apply.indexOf("titles")+1)ist=true;if(q.apply.indexOf("dividers")+1)isd=true;if(q.apply.indexOf("parents")+1)isp=true;if(q.apply.indexOf("sub")+1)gos=true;if(q.apply.indexOf("main")+1)gom=true;atags=a.childNodes;for(var k=0;k<atags.length;k++){if((atags[k].tagName!="SPAN"&&atags[k].tagName!="A")||(q.sactive&&!atags[k].cdiv))continue;var ism=qm_a(atags[k][qp]);if((isd&&atags[k].className.indexOf("qmdivider")+1)||(ist&&atags[k].className.indexOf("qmtitle")+1)||(gom&&ism&&atags[k].tagName=="A")||(atags[k].className.indexOf("qmrounditem")+1)||(gos&&!ism&&atags[k].tagName=="A")||(isp&&atags[k].cdiv)){var f=document.createElement("SPAN");f.className="qmritem";f.setAttribute("qmvbefore",1);var fs=f.style;fs.position="absolute";fs.display="block";fs.top="0px";fs.left="0px";fs.width=atags[k].offsetWidth+"px";if(q.sactive&&atags[k].cdiv.style.visibility!="inherit")fs.visibility="hidden";var size=q.size;q.mid=parseInt(size/2);q.ps=new Array(size+1);var t2=0;q.osize=q.size;if(!q.angle){for(var i=0;i<=size;i++){if(i==q.mid)t2=0;q.ps[i]=t2;t2+=Math.abs(q.mid-i)+1;}q.osize=1;}var fi="";var ctype="main";if(!ism)ctype="sub";for(var i=0;i<size;i++)fi+=qm_ritem_get_span(size,i,1,ctype);var cn=atags[k].cloneNode(true);var cns=cn.getElementsByTagName("SPAN");for(var l=0;l<cns.length;l++){if(cns[l].getAttribute("isibulletcss")||cns[l].getAttribute("isibullet"))cn.removeChild(cns[l]);}fi+='<span class="qmritemcontent" style="display:block;border-style:solid;border-width:0px 1px 0px 1px;'+q.opacity+'">'+cn.innerHTML+'</span>';for(var i=size-1;i>=0;i--)fi+=qm_ritem_get_span(size,i,null,ctype);f.innerHTML=fi;f=atags[k].insertBefore(f,atags[k].firstChild);atags[k].hasritem=f;}if(atags[k].cdiv)new qm_ritem_add_rounds(atags[k].cdiv);}};function qm_ritem_get_span(size,i,top,ctype){var q=qmad.ritem;var mlmr;if(i==0){var mo=q.ps[size]+q.mid;if(q.angle)mo=size-i;var fs="";if(qmad.str)fs="<br/>";mlmr=qm_ritem_get_corners(mo,null,top,ctype);return '<span style="border-width:1px 0px 0px 0px;border-style:solid;display:block;font-size:1px;overflow:hidden;line-height:0px;height:0px;margin-left:'+mlmr[0]+'px;margin-right:'+mlmr[1]+'px;'+q.opacity+'">'+fs+'</span>';}else {var md=size-(i);var ih=1;var bs=1;if(!q.angle){if(i>=q.mid)ih=Math.abs(q.mid-i)+1;else {bs=Math.abs(q.mid-i)+1;md=q.ps[size-i]+q.mid;}if(top)q.osize+=ih;}mlmr=qm_ritem_get_corners(md,bs,top,ctype);return '<span style="border-width:0px '+mlmr[3]+'px 0px '+mlmr[2]+'px;border-style:solid;display:block;overflow:hidden;font-size:1px;line-height:0px;height:'+ih+'px;margin-left:'+mlmr[0]+'px;margin-right:'+mlmr[1]+'px;'+q.opacity+'"></span>';}};function qm_ritem_get_corners(mval,bval,top,ctype){var q=qmad.ritem;var ml=mval;var mr=mval;var bl=bval;var br=bval;if(top){if(!q["corners_"+ctype][0]){ml=0;bl=1;}if(!q["corners_"+ctype][1]){mr=0;br=1;}}else {if(!q["corners_"+ctype][2]){mr=0;br=1;}if(!q["corners_"+ctype][3]){ml=0;bl=1;}}return new Array(ml,mr,bl,br);}/* ]]> */</script>

</head>

<noscript> 
<span style="font-size:13px;font-family:arial;"><span style="color:#dd3300">Warning!</span>&nbsp&nbsp; QuickMenu may have been blocked by IE-SP2's active content option. This browser feature blocks JavaScript from running locally on your computer.<br><br>This warning will not display once the menu is on-line.  To enable the menu locally, click the yellow bar above, and select <span style="color:#0033dd;">"Allow Blocked Content"</span>.<br><br>To permanently enable active content locally...<div style="padding:0px 0px 30px 10px;color:#0033dd;"><br>1: Select 'Tools' --> 'Internet Options' from the IE menu.<br>2: Click the 'Advanced' tab.<br>3: Check the 2nd option under 'Security' in the tree (Allow active content to run in files on my computer.)</div></span></noscript>

<!-- Starting Page Content [menu nests within] -->
</p>
<div style="background-image:url('http://www.tcrosystems.net/center_tile.gif')"><table cellpadding=0 cellspacing=0 style="width:100%;"><tr><td>
  <div style="font-size:1px;width:6px;height:34px;background-image:url('http://www.tcrosystems.net/left_cap.gif');"></div></td><td style="width:100%;">

<!-- QuickMenu Structure [Menu 0] -->
<ul id="qm0" class="qmmc">




	<li><a class="qmparent" href="menu.php"><img border="0" src="http://www.tcrosystems.net/home.png" width="20" height="20"></a>
		</li>
	<li><span class="qmdivider qmdividery" ></span></li>

 <?php
    if($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="support" or $_SESSION['usaccess']=="processing")
    {
        ?>
    <p dir="ltr">
    
	<li><a class="qmparent" href="search.php">CLIENTS</a>

		<ul>
		<li><a href="search.php?status=pending&f=1&Find=Find">Pending Clients</a></li>
		<li><a href="search.php">Client Search</a></li>
		<li><a class="qmtitle" href="JavaScript:void(0);">Quick Status</a>
		<ul>

<li><a href="search.php?cname=&zip=&email=&status=active&billingcycle=&f=1&Find=Find">Active</a></li>
<li><a href="search.php?cname=&zip=&email=&status=scheduled&billingcycle=&f=1&Find=Find">Scheduled</a></li>
<li><a href="search.php?cname=&zip=&email=&status=contact1&billingcycle=&f=1&Find=Find">Contact 1</a></li>
<li><a href="search.php?cname=&zip=&email=&status=contact2&billingcycle=&f=1&Find=Find">Contact 2</a></li>
<li><a href="search.php?cname=&zip=&email=&status=contact3&billingcycle=&f=1&Find=Find">Contact 3</a></li>
<li><a href="search.php?cname=&zip=&email=&status=complete&billingcycle=&f=1&Find=Find">Completed</a></li>
<li><a href="search.php?cname=&zip=&email=&status=NSF&billingcycle=&f=1&Find=Find">NSF</a></li>
<li><a href="search.php?cname=&zip=&email=&status=canceled&billingcycle=&f=1&Find=Find">Canceled</a></li>
<li><a href="search.php?cname=&zip=&email=&status=expired&billingcycle=&f=1&Find=Find">Expired</a></li>

</ul></li>

		
		<li><span class="qmdivider qmdividerx" ></span></li>
		<li><a href="register.php">Add New Client</a></li>
		<li><a href="registerjoint.php">Add New Joint Client</a></li>
		</ul></li>
	<li><span class="qmdivider qmdividery" ></span></li>
	
<?php } 
if ($_SESSION['restrict'] == "Yes"){
$restrictleads = "and id < 0";
	 
 $sqlrestrict = "SELECT id FROM sales_affiliates where status !='del' AND user ='" . $_SESSION['usname'] . "' ";
  $resultrestrict = @mysql_query($sqlrestrict,$conn);
  while ($rowrestrict = mysql_fetch_array($resultrestrict)) {
  $affid = $rowrestrict['id'];
$restrictleads = "and affiliate_id='$affid'";
}


}//END RESTRICT
$bsleadquery2 = " AND status !='NotInterested' and status !='NotCandidate' and status !='DoNotCall' and status != 'NonResponsive'";

	 $query5 = "SELECT count(id) FROM clients WHERE clientdelete !='yes' and prospectclient = 'Prospect' and scheduleddate < '$today' $bsleadquery2 $restrictleads";
          $result5 = mysql_query($query5, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row5=mysql_fetch_row($result5))
          {
              $newconsumerleads           = $row5[0];
}
if ($newconsumerleads != 0){
$newaleads = "</b><font color =#FF0000><B>( $newconsumerleads )</b></font>";
}

	 
	 ?>

	<?php
    if($_SESSION['usaccess']!="processing" && $_SESSION['usaccess']!="WebCMS")
    {
        ?>
	<li><a class="qmparent" href="prospectsearch.php?search=on">PROSPECTS <?php echo "$newaleads"; ?></a>
		<ul>
		<li><a href="prospectsearch.php?Find=Find">List All Prospects</a></li>
		<li><a href="prospectsearch.php?search=on">Prospect Search</a></li>
		<li><a href="prospectregister.php">Add Prospect</a></li>
		</ul></li>

	<li><span class="qmdivider qmdividery" ></span></li>
	
	
	
	<?php
}
    if($_SESSION['affiliate']=="Yes")
    {
        ?>
    <p dir="ltr">
    
	<li><a class="qmparent" href="affiliatesearch.php">AFFILIATES</a>

		<ul>
		<li><a href="affiliatesearch.php?lname=&zip=&email=&f=1&Find=Find">List All Affiliates</a></li>
		<li><a href="affiliatesearch.php">Affiliate Search</a></li>
		<li><a href="affiliateregister.php">Add Affiliate</a></li>
		<li><span class="qmdivider qmdividerx" ></span></li>
				<li><a href="affiliaterefer.php">Affiliate Referral Report</a></li>


</ul></li>
	<li><span class="qmdivider qmdividery" ></span></li>

	 <?php } ?>


	
		<?php
    if($_SESSION['brokers']=="Yes")
    {

			 $query5 = "SELECT count(dealer_id) FROM dealers WHERE status != 9 and bioapproved ='No'";
          $result5 = mysql_query($query5, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row5=mysql_fetch_row($result5))
          {
              $newbrokerbios           = $row5[0];
}
if ($newbrokerbios != 0){
$newbrokerbios2 = "<li><a class=qmparent href=approvebrokerbio.php><font color =#FF0000><B>( $newbrokerbios )</b></font></a>";
}

        ?>
    <p dir="ltr">
    
	<li><a class="qmparent" href="brokersearch.php">BROKERS</a>

		<ul>
		<li><a href="brokersearch.php?firstname=&lastname=&email=&f=1&Find=Find">List All Brokers</a></li>
		<li><a href="brokersearch.php">Broker Search</a></li>
		<li><a href="brokerregister.php">Add Broker</a></li>
				<li><span class="qmdivider qmdividerx" ></span></li>
				<li><a href="brokerrefer.php">Broker Referral Report</a></li>
				<li><a href="brokerreport.php">Broker Creation Report</a></li>
		

</ul></li>
<?php echo "$newbrokerbios2"; ?>
	<li><span class="qmdivider qmdividery" ></span></li>

	 <?php } ?>
	
	
	


<?php
    if($helpdesk=="Yes" && ($_SESSION['usaccess']=="support" or $_SESSION['usaccess']=="full")){
  $query3 = "SELECT id, clientid, subject, description FROM helpdesk WHERE status='OPEN'";
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $hdid = $row3[0];
                   $hdclientid = $row3[1];
                   $hdsub = $row3[2];
                   $hddescription = $row3[3];
                   $opentickets = $opentickets+1;

 $query4 = "SELECT name FROM clients WHERE id='$hdclientid'";
              $result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
              while($row4=mysql_fetch_row($result4))
              {
                   $hduser= $row4[0];
}


$hddescription = nl2br($hddescription);         
$hddescription = wordwrap($hddescription, 75, "<br />\n", true);
$hd_select .= "<li><a href=viewticket.php?helpdeskid=$hdid> (Logged By - $hduser) <B>$hdsub</b>   <font color=#008080>$hdcat</font></a>";
$hd_select .= "<ul><li><a href=viewticket.php?helpdeskid=$hdid>$hddescription</a></li>";
$hd_select .= "</ul></li>";
}
 if($hdid !=""){
$opentickets = "</b><font color =#FF0000><B>( $opentickets )</b></font>";
}


        ?>
    <p dir="ltr">
    
	<li><a class="qmparent" href="helpdesk.php?status=OPEN">HELPDESK <?php print($opentickets); ?></a>

		<ul>
		<li><a href="helpdesk.php">List All Tickets</a></li>
	<?php print($hd_select); ?>
		
		

</ul></li>
	<li><span class="qmdivider qmdividery" ></span></li>

	 <?php } ?>




	<?php
    if($_SESSION['usaccess']!="WebCMS")
    {
        ?>

    <p dir="ltr">
    
	<li><a class="qmparent" href="menu.php?page=appts">APPOINTMENTS</a>
		<ul>
		
		<?php
$year = date("Y");
$month = date("m");
$day = date("d");
$calendaruser =$_SESSION['usname'];
$julian = "$year$month$day";
$calsearch = $julian;
$calsearchword = "today";


		$calsql = "SELECT * FROM calendar where cal_date='$calsearch' and cal_create_by ='$calendaruser' ORDER BY cal_time";
		$calresult = @mysql_query($calsql,$conn) or die("Couldn't execute");
		$number_appts = @mysql_num_rows($calresult);
  while ($calrow = mysql_fetch_array($calresult)) {	
		    $cal_id = $calrow['cal_id'];
		    $cal_contactid = $calrow['cal_contactid'];
		    $cal_create_by = $calrow['cal_create_by'];
		    $cal_description = $calrow['cal_description'];
		    $cal_link = $calrow['cal_link'];
		    $cal_name = $calrow['cal_name'];
		    $cal_date = $calrow['cal_date'];
		    $cal_time = $calrow['cal_time'];
		    $active = $calrow['cal_mod_time'];
		    
$cal_year = substr("$cal_date", 0, 4);
$cal_month = substr("$cal_date", 4, 2);
$cal_day = substr("$cal_date", 6, 2);
$cal_time = substr("$cal_time", 0, -2);
if (strlen($cal_time) == 3){
$cal_time = "0$cal_time";
}

		    
$caldateformat = $cal_year/$cal_month/$cal_day;		    
//$cal_link = "prospectstatus.php?id=$cal_contactid";
$strike_link = "menu.php?strike=$cal_id";
$outlook_link = "outlook.php?page=outlook&cal_id=$cal_id";

if ($active != 0){
$appointmentlink= "<a href=$cal_link>$cal_month/$cal_day/$cal_year at $cal_time :: $cal_name</a>
<a href=$strike_link>strike appt</a><a href=$strike_link>strike appt</a>		    
<a \"text-decoration: none;\" href=$outlook_link><font color=\"#00FF7F\">Add to Outlook</font></a>";
}else{
$appointmentlink= "<a href=$cal_link><strike>$cal_month/$cal_day/$cal_year at $cal_time :: $cal_name</strike></a>";		    
}
	
		  

?>
		<li><?php print($appointmentlink); ?></li>
		
		  <?php
}
?>
		

</ul></li>
	<li><span class="qmdivider qmdividery" ></span></li>
<?php
 }
        ?>

	
	

	
		 <?php
    if($_SESSION['usname']=="admin" or $_SESSION['usaccess']=="WebCMS")
    {
        ?>
	    <p dir="ltr">
    
	<li><a class="qmparent" href="companyinfo.php?page=webcms">WEB CMS</a>
		<ul>
		<li><a href="companyinfo.php?page=webcms">CSS</a></li>
		<li><a href="JavaScript:void(0);">Website</a>
<ul>
		
  <?php

$query = "SELECT pagename, id, active, type FROM webcms where type ='website' order by active desc, pageorder";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
{
        $menupagename = $row[0];
        $menupageid = $row[1];
        $menupageactive = $row[2];
        $menupagetype = $row[3];
    if($menupageactive == "Yes"){
$pageactive = "on";
$pagecolor = "green";
$strong = "<strong>";
$endstrong = "</strong>";
$pagecolor = "green";
}else{
$pageactive = "off";
$strong = "";
$endstrong = "";
$pagecolor = "black";
}
?>

		<li><a href="companyinfo.php?page=webcms&pageid=<?php print($menupageid); ?>"><font color=<?php print($pagecolor); ?>><?php print($strong); ?><?php print($menupagename); ?><?php print($endstrong); ?></font></strong>  <i>(<?php print($menupagetype); ?>)</i></a></li>
	 <?php
}
?>	
</ul></li>		



		<li><a href="JavaScript:void(0);">Client</a>
<ul>
		
  <?php

$query = "SELECT pagename, id, active, type FROM webcms where type ='client' order by active desc, pageorder";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
{
        $menupagename = $row[0];
        $menupageid = $row[1];
        $menupageactive = $row[2];
        $menupagetype = $row[3];
    if($menupageactive == "Yes"){
$pageactive = "on";
$pagecolor = "green";
$strong = "<strong>";
$endstrong = "</strong>";
$pagecolor = "green";
}else{
$pageactive = "off";
$strong = "";
$endstrong = "";
$pagecolor = "black";
}
?>

		<li><a href="companyinfo.php?page=webcms&pageid=<?php print($menupageid); ?>"><font color=<?php print($pagecolor); ?>><?php print($strong); ?><?php print($menupagename); ?><?php print($endstrong); ?></font></strong>  <i>(<?php print($menupagetype); ?>)</i></a></li>
	 <?php
}
?>	
</ul></li>		


		<li><a href="JavaScript:void(0);">Broker</a>
<ul>
		
  <?php

$query = "SELECT pagename, id, active, type FROM webcms where type ='broker' order by active desc, pageorder";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
{
        $menupagename = $row[0];
        $menupageid = $row[1];
        $menupageactive = $row[2];
        $menupagetype = $row[3];
    if($menupageactive == "Yes"){
$pageactive = "on";
$pagecolor = "green";
$strong = "<strong>";
$endstrong = "</strong>";
$pagecolor = "green";
}else{
$pageactive = "off";
$strong = "";
$endstrong = "";
$pagecolor = "black";
}
?>

		<li><a href="companyinfo.php?page=webcms&pageid=<?php print($menupageid); ?>"><font color=<?php print($pagecolor); ?>><?php print($strong); ?><?php print($menupagename); ?><?php print($endstrong); ?></font></strong>  <i>(<?php print($menupagetype); ?>)</i></a></li>
	 <?php
}
?>	
</ul></li>		



		<li><a href="JavaScript:void(0);">Affiliate</a>
<ul>
		
  <?php

$query = "SELECT pagename, id, active, type FROM webcms where type ='affiliate' order by active desc, pageorder";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
{
        $menupagename = $row[0];
        $menupageid = $row[1];
        $menupageactive = $row[2];
        $menupagetype = $row[3];
    if($menupageactive == "Yes"){
$pageactive = "on";
$pagecolor = "green";
$strong = "<strong>";
$endstrong = "</strong>";
$pagecolor = "green";
}else{
$pageactive = "off";
$strong = "";
$endstrong = "";
$pagecolor = "black";
}
?>

		<li><a href="companyinfo.php?page=webcms&pageid=<?php print($menupageid); ?>"><font color=<?php print($pagecolor); ?>><?php print($strong); ?><?php print($menupagename); ?><?php print($endstrong); ?></font></strong>  <i>(<?php print($menupagetype); ?>)</i></a></li>
	 <?php
}
?>	
</ul></li>		




</ul></li>
	<li><span class="qmdivider qmdividery" ></span></li>
 <?php
   }
        ?>

	
	
	
	
	
	
	 <?php
    if($_SESSION['usname']=="admin")
    {
        ?>
    <p dir="ltr">
	<li><a class="qmparent" href="JavaScript:void(0);">ADMINISTRATION</a>
    

		<ul>
		<li><a href="companyinfo.php">System Settings</a>

<ul>
<li><a href="companyinfo.php">Company Settings</a></li>
<li><a href="companyinfo.php?page=3">Account Specs</a></li>
<li><a href="companyinfo.php?page=4">Customize System</a></li>
<li><a href="companyinfo.php?page=5">Round Robin</a></li>
<li><a href="companyinfo.php?page=6">Company Skin</a></li>

</ul></li>











<?php
    if($_SESSION['isptcso']=="PTCSO")
    {
        ?>

<li><a href="ptcso.php?f=1">PTCSO</a></li>
<?php
}
        ?>
		<li><a class="qmtitle" href="JavaScript:void(0);">System Emails</a>
		<ul>
<li><span class="qmtitle" >Standard Emails</span></li>

  <?php
        include("connection.php");
     $query = "SELECT id, name FROM systememails where name like '%_Welcome' order by name";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailidmenu           = $row[0];
              $emailnamemenu   = $row[1];

    
?>


<li><a href="systememail.php?emailid=<?php print($emailidmenu); ?>"><?php print($emailnamemenu); ?></a></li>
    <?php
}
?>
<li><a href="systememail.php">Add Preformatted Email (+)</a></li>
<li><span class="qmdivider qmdividerx" ></span></li>
<li><span class="qmtitle" >Preformatted Sales Emails</span></li>

<?php
////////////SALES EMAILS
        include("connection.php");
     $query = "SELECT id, name FROM systememails where type ='sales' order by name";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailidmenu           = $row[0];
              $emailnamemenu   = $row[1];

    
?>


<li><a href="systememail.php?emailid=<?php print($emailidmenu); ?>"><?php print($emailnamemenu); ?></a></li>
    <?php
}
?>




<li><span class="qmdivider qmdividerx" ></span></li>
<li><span class="qmtitle" >Preformatted Broker Emails</span></li>

<?php
////////////SALES EMAILS
        include("connection.php");
     $query = "SELECT id, name FROM systememails where type ='broker' and name not like '%_Welcome' order by name";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailidmenu           = $row[0];
              $emailnamemenu   = $row[1];

    
?>


<li><a href="systememail.php?emailid=<?php print($emailidmenu); ?>"><?php print($emailnamemenu); ?></a></li>
    <?php
}
?>








</ul></li>
<li><a class="qmtitle" href="JavaScript:void(0);">User Management</a>
		<ul>


<li><a href="adduser.php">Add New User</a></li>
<li><a href="edituser.php">Manage Users</a></li>
</ul></li>

<li><a class="qmtitle" href="JavaScript:void(0);">Reports</a>
		<ul>


<li><a href="closingratio.php">Closing Ratio</a></li>
<li><a href="noteratio.php">Note Ratio</a></li>
<li><a href="affiliaterefer.php">Affiliate Referral Report</a></li>
<li><a href="brokerrefer.php">Broker Referral Report</a></li>
<li><a href="brokerreport.php">Broker Creation Report</a></li>
</ul></li>



<li><a href="canned.php?type=hotlinks">Managed Custom Canned Hot Links</a></li>




		
	<?php

if($reseller !="Yes")
{
?>	
<li><a target="_blank" href="letters.php">Letter Menu</a></li>


		<?php
}else{
?>
<li><a href="menu.php">Accounting</a></li>
<?php } ?>
		</ul></li>
			 

	<li><span class="qmdivider qmdividery" ></span></li>
	 <?php } ?>

	
	
	
	
	
	<?php
    

if($_SESSION['usname']=="admin" && ($autoresponder == "Yes" or $bautoresponder == "Yes" or $cautoresponder == "Yes")){
?>
	<li><a class="qmparent" href="JavaScript:void(0);">AUTORESPONDERS</a>

		<ul>
		
<?php
    

if($autoresponder == "Yes"){
?>
<li><span class="qmtitle" >Prospect</span></li>
<li><a href="addautoemail.php?type=prospect">Add Email</a></li>

<li><a href="JavaScript:void(0);">Edit Emails</a>
		<ul>
  <?php
       
     $query = "SELECT id, days FROM autoresponders WHERE type='prospect' order by days";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $autoid           = $row[0];
              $autodays   = $row[1];

    
?>


<li><a href="editautoemail.php?autoid=<?php print($autoid); ?>">Day <?php print($autodays); ?></a></li>
    <?php
}
?>
</ul></li>
<li><span class="qmdivider qmdividerx" ></span></li>
 <?php
}
?>

<?php
    

if($bautoresponder == "Yes"){
?>
<li><span class="qmtitle" >Brokers</span></li>
<li><a href="addautoemail.php?type=broker">Add Email</a></li>

<li><a href="JavaScript:void(0);">Edit Emails</a>
		<ul>
  <?php
       
     $query = "SELECT id, days FROM autoresponders WHERE type='broker' order by days";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $autoid           = $row[0];
              $autodays   = $row[1];

    
?>


<li><a href="editautoemail.php?autoid=<?php print($autoid); ?>">Day <?php print($autodays); ?></a></li>
    <?php
}
?>
</ul></li>
<li><span class="qmdivider qmdividerx" ></span></li>
 <?php
}
?>

<?php
    

if($cautoresponder == "Yes"){
?>
<li><span class="qmtitle" >Clients</span></li>
<li><a href="addautoemail.php?type=client">Add Email</a></li>

<li><a href="JavaScript:void(0);">Edit Emails</a>
		<ul>
  <?php
       
     $query = "SELECT id, days FROM autoresponders WHERE type='client' order by days";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $autoid           = $row[0];
              $autodays   = $row[1];

    
?>


<li><a href="editautoemail.php?autoid=<?php print($autoid); ?>">Day <?php print($autodays); ?></a></li>
    <?php
}
?>
</ul></li>
 <?php
}
?>
		</ul>
</li>
	<li><span class="qmdivider qmdividery" ></span></li>

 <?php
} if($_SESSION['usname']=="admin"){
?>


	
	<li><a class="qmparent" href="JavaScript:void(0);">VIDEOS</a>

		<ul>
<?php
 
if($reseller !="Yes"){
?>

		<li><a href="javascript:OpenWindow('instructions.php?inst=addletters','815','605')">Adding Letters</a></li>		
<?php
}
?>
		<li><span class="qmdivider qmdividerx" ></span></li>
		<li><span class="qmtitle" >Optional Upgrades</span></li>

		<li><a href="javascript:OpenWindow('instructions.php?inst=autoresponder','815','605')">Autoresponder System</a></li>
		<li><a href="javascript:OpenWindow('instructions.php?inst=demanddraft','815','605')">Demand Draft (Recurring)</a></li>
		<li><a href="javascript:OpenWindow('instructions.php?inst=demanddraft2','815','605')">Demand Draft (Initial Check)</a></li>
		<li><a href="javascript:OpenWindow('instructions.php?inst=helpdesk','815','605')">Helpdesk</a></li>		</ul></li>
	<li><span class="qmdivider qmdividery" ></span></li>

 <?php
 }
 ?>

	<li><a class="qmparent" href="logout.php">LOG OUT</a>

		</li>

<li class="qmclear">&nbsp;</li></ul>

<!-- Ending Page Content [menu nests within] -->
</td><td><div style="border-width:0px 0px 0px 1px;border-color:#aaaaaa;border-style:solid;font-size:1px;width:8px;height:31px;"></div></tr></table></div>


<!-- Create Menu Settings: (Menu ID, Is Vertical, Show Timer, Hide Timer, On Click (options: 'all' * 'all-always-open' * 'main' * 'lev2'), Right to Left, Horizontal Subs, Flush Left, Flush Top) -->
<script type="text/javascript">qm_create(0,false,0,500,false,false,false,false,false);</script>


<!-- ////////////////////END MENU////////////////////// -->
 <SCRIPT LANGUAGE="JavaScript">

function OpenWindow(url,winwidth,winheight) 
{
NewWindow=window.open(url,'descr','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,scrollbars=no,resizable=yes,copyhistory=no,width='+winwidth+',height='+winheight)
}
</SCRIPT>

 <SCRIPT LANGUAGE="JavaScript">

function OpenWindow2(url,winwidth,winheight) 
{
NewWindow=window.open(url,'descr','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=Yes,scrollbars=Yes,resizable=yes,copyhistory=no,width='+winwidth+',height='+winheight)
}
</SCRIPT>
