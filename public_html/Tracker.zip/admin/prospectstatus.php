<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();
// need to make all globals into locals...




$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";
$today = date("Y-m-d");


$nowday = date("d");
$nowmonthword = date("M");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";
$poweredbymessage = "<BR><BR><p align=right><a href=\"http://www.creditrepairtracking.com\"><img border=0 src=http://www.creditrepairtracking.com/trackstarlogoforemail.png></a></p>";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {

include("connection.php");
include('template.php');
include('main.php');
include('rolloverhelp.php');
		echo "in admin <br/>";


		if ($editmode=="yes"  && ($_SESSION['usname']=="admin" or $_SESSION['editleads']=="Yes")) 
		{
		echo "in edit <br/>";

		$oldemail = $_POST['oldemail'];
		$currentemail = $_POST['email'];
		if($_POST['email'] != $oldemail){
		$addtonote=" and changed from $oldemail to $currentemail.  Validation sent.";
		 $query = "UPDATE clients SET
										optMD5hash='',
										doubleopt='',
										optdate='',
										opttstamp='',
										opttimesasked ='1',
										optipaddress=''
		WHERE id = \"$id\"";
		$result = mysql_query($query, $conn) or die("error:" . mysql_error());
		
			// create the MD5 hash 
		$secret_code = 'htdiisawesome';
		$formatted_email = preg_replace("/(-|\@|\.)/", "", $email);
		$hashed = md5("$secret_code $formatted_email");
		
		$mail_body = "$clientfirstname, to validate this email click the following link:\n";
		$mail_body .= "$companywebsite/validate.php?m=$hashed&w=p&id=$id\n";
		$mail_body .= "By validating your email address you agree to receive emails from $companyname\n";
		$mail_body .= "\n\n\n\n\n\n\n\n\n\n\n\n";
		$mail_body .= "To remove yourself from future contact from $companyname, please click the following link instead:\n";
		$mail_body .= "$companywebsite/remove.php?m=$hashed&w=p&id=$id\n";
		
		$mail_subject = "Please validate your email address";
		$mail_from = "From: $companyname <$companyreply>\r\n";
		mail($email, $mail_subject, $mail_body, $mail_from);
		
		}


$sql_note = "INSERT INTO salesnotes

(clientid,action,counselor,repairdate,filelocation)
               VALUES
(\"$id\",
\"Changed Prospect Info $addtonote\",
\"$user\",
\"$today\",
\"$tstamp\")";

echo "executing query: " . $sql_note  . "<br/>";
$result_note = @mysql_query($sql_note,$conn);


 $query = "UPDATE clients SET
                name='" . mysql_real_escape_string($_POST['name']) . "',
                address='" . mysql_real_escape_string($_POST['address']) . "',
                city='" . mysql_real_escape_string($_POST['city']) . "',
                state='" . mysql_real_escape_string($_POST['state']) . "',
                zip='" . mysql_real_escape_string($_POST['zip']) . "',
                email='" . mysql_real_escape_string($_POST['email']) . "',
                phone='" . mysql_real_escape_string($_POST['phone']) . "',
                broker_id='" . mysql_real_escape_string($_POST['broker_id']) . "',
                affiliate_id='" . mysql_real_escape_string($_POST['affiliate_id']) . "',
                altphone='" . mysql_real_escape_string($_POST['altphone']) . "'
WHERE id = \"$id\"";

echo "executing query: " . $query . "<br/>";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=prospectstatus.php?id=$id\">"; 

}




if ($note) {


$sql_note = "INSERT INTO salesnotes

(clientid,action,counselor,repairdate,filelocation)
               VALUES
(\"$id\",
\"$note\",
\"$user\",
\"$today\",
\"$tstamp\")";
$result_note = @mysql_query($sql_note,$conn);

$sql = "UPDATE clients SET
dateresults = \"$today\",
dealer_id = \"\"
WHERE id = \"$id\"";
$result = @mysql_query($sql,$conn);

if($brokeremail != "" && $brokeremailnotify >= 3){
$HEADERS  = "MIME-Version: 1.0\r\n";
$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
$HEADERS .= "From: $companyname <$companyreply>\r\n";

$subject3 = "$brokerfirstname, $clientinfoname 's lead record has been noted";
$message3 = "$companyskin$brokerfirstname, Here are the details of the note <BR><BR><b>Prospect Name:</b>  $clientinfoname <BR><B>Date:</B>  $today<BR><B>Note:</B>  $note<BR><BR><BR>Remember, you can log into your account at <a href=$companywebsite/brokers>$companywebsite/brokers</a> to check this prospect in detail at anytime.   <BR><BR>Username - $brokerusername <BR>Password - $brokerpassword";
if($privatelabel== "No"){
$message3 .= $poweredbymessage;
}

$formsent3 = mail($brokeremail, $subject3, $message3, $HEADERS, "-f $companyreply");  

}}





if ($calhour !="") {
$webpage = $_SERVER["HTTP_REFERER"];

 if (($calampm == "pm") && ($calhour < 12)){
$calhour += 12;
}
 if (($calampm == 'am') && ($calhour == 12)){
$calhour = 0;
}

 if ($priority == ""){
$priority = "";
}else  if ($priority == "Medium"){
$priority = "(Medium Priority)";
}else if ($priority == "High"){
$priority = "(HIGH Priority)";
}


$date = mktime ( 3, 0, 0, $calmonth, $calday, $calyear );
  $str_cal_date = date ( "Ymd", $date );
  $changefollowup = date ( "Y-m-d", $date );
  $str_cal_time = sprintf ( "%d%02d00", $calhour, $calminute );
  $modtime = date ( "Gis" );
$sqlcal1 = "INSERT INTO calendar (cal_contactid, cal_create_by, cal_date, cal_time, cal_mod_date, cal_mod_time, cal_name, cal_link, cal_description)
			VALUES(
	\"$id\",
	\"$username\",
	\"$str_cal_date\",
	\"$str_cal_time\",
	\"$julian\",
	\"$modtime\",
	\"Call $clientinfoname $typeofreminder $priority\",
	\"$webpage\",
	\"$note\")";
                $result = mysql_query($sqlcal1, $conn) or die("error:" . mysql_error());

$query = "UPDATE clients SET
                scheduleddate='$changefollowup'
                WHERE id='$id'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}

if ($comments) {
$query = "UPDATE clients SET
                comments='$comments'
                WHERE id='$id'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}




if ($changestatus=="yes") {

$sql_note = "INSERT INTO salesnotes

(clientid,action,counselor,repairdate,filelocation)
               VALUES
(\"$id\",
\"Change Status to $status\",
\"$user\",
\"$today\",
\"$tstamp\")";
$result_note = @mysql_query($sql_note,$conn);


$query = "UPDATE clients SET
                status='$status'
                WHERE id='$id'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

}





$GET_id=$_GET["id"];

 
       
$sql = "SELECT * FROM clients WHERE id = '$GET_id' AND prospectclient = 'Prospect' and clientdelete !='yes' $restrictleads";
$result = mysql_query($sql, $conn);
$line=mysql_fetch_array($result, MYSQL_ASSOC);
$number_results = mysql_num_rows($result);
$bgcolor = "FF9900";
$dealer_id = $line[dealer_id];
$salesid = $line[leadassigned];
$opttimesasked = $line[opttimesasked];

if ($opttimesasked == 1){
$attempts ="attempt";
}else{
$attempts ="attempts";
}


if ($line[doubleopt] == "Yes"){
$doubleoptmessage ="<font color='green'><b><i>validated</i></b></font>";
$welcomemessage = "Resend Welcome Email";
}else if ($line[doubleopt] != "Yes" && $line[email] !=""){
$doubleoptmessage ="<font color='red'><b><i>$opttimesasked $attempts to validate</i></b></font>";
$welcomemessage = "Resend Validation/Welcome Email";
}

$query = "SELECT fname, lname FROM users WHERE id='$dealer_id'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $accessfname = $row[0]; 
        $accesslname = $row[1]; 
		$accessname = "$accessfname $accesslname";
    }
if ($roundrobinfeature == "ON"){

	$query = "SELECT name FROM roundrobin WHERE salesid='$salesid'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
		$roundrobinname = $row[0]; 
    }
$roundrobincomment="<font color=green size=2><b>Round Robin goes to $roundrobinname</font></b><BR>";
}

$entered_year = substr("$line[createdate]", 0, 4);
$entered_month = substr("$line[createdate]", 5, 2);
$entered_day = substr("$line[createdate]", 8, 2);

if ($line[dealer_id] != ""){
$accesscomment = "<B><font color=blue size=2>$accessname has accessed this record and has not yet entered a note</font><B><BR><BR>";
}else if ($line[dealer_id] == "" AND $action !="update"){
$accesscomment = "<B><font color=blue size=2>Others will see that you are accessing this record until you note the account</font><B><BR><BR>";
$sql = "UPDATE clients SET
dealer_id = '" . $_SESSION['usid'] . "'
WHERE id = '$GET_id'";
$result = @mysql_query($sql,$conn);
}


$query3 = "SELECT user, fname, lname FROM sales_affiliates WHERE id = '$line[affiliate_id]'";
              $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
              while($row3=mysql_fetch_row($result3))
              {
                   $affiliatename = $row3[0];
                   $fname = $row3[1];
                   $lname = $row3[2];
}
$SA_sql = "SELECT firstname,lastname,username,dealership, email, emailnotify, password FROM dealers where dealer_id='$line[broker_id]'";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $brokerfirstname = $srow['firstname'];
		    $brokerlastname = $srow['lastname'];
		    $brokerusername = $srow['username'];		    
		    $brokercompany = $srow['dealership'];		    
		    $brokeremail = $srow['email'];		    
		    $brokeremailnotify = $srow['emailnotify'];		    
		    $brokerpassword = $srow['password'];		    
		}

if ($line[prospectclient] == "Client"){
?>
<font color="red"><B>This record is not a Prospect and cannot be accessed through here.</font><BR>
<BR>
Sending email to adminstrator.................DONE</b>
<?php
 }
if ($line[prospectclient] == "Prospect"){

if ($line[status] == "HotLead"){
echo "<STYLE>body { background-image:url('fire.jpg'); background-repeat:no-repeat; background-attachment:fixed } </STYLE>";
}else if ($line[status] == "DoNotCall"){
echo "<STYLE>body { background-image:url('DNC.png'); } </STYLE>";
}else if ($line[status] == "NonResponsive"){
echo "<STYLE>body { background-image:url('hourglass.png'); } </STYLE>";
}else if ($line[status] == "NotInterested"){
echo "<STYLE>body { background-image:url('notinterested.png'); } </STYLE>";
}else if ($line[status] == "NotCandidate"){
echo "<STYLE>body { background-image:url('hand.png'); } </STYLE>";
}else if ($line[status] == "CreditReview"){
echo "<STYLE>body { background-image:url('creditreview.png'); } </STYLE>";
}else if ($line[status] == "ContractOut"){
echo "<STYLE>body { background-image:url('contractout.png'); } </STYLE>";
}

?>
<body onLoad="Tooltip.init()">
<script type="text/javascript" src="jquery-1.3.2.min.js"></script> 
<script type="text/javascript" src="jquery.textarea-expander.js"></script>
<style type="text/css"> 
/* <![CDATA[ */

textarea
{
	clear: both;
	display: block;
	font-family: Verdana, sans-serif; 
	font-size: 11px;
	padding: 4px 4px 4px 4px;
	margin: 6px auto;

}
 
/* ]]> */
</style>
<script type="text/javascript">
function toggleMe(a){
var e=document.getElementById(a);
if(!e)return true;
if(e.style.display=="none"){
e.style.display="block"
}
else{
e.style.display="none"
}
return true;
}
</script>
<style type="text/css">
table.bordered {border-left: 1px solid black;border-top: 1px solid black; }
table.bordered tr td, table.bordered tbody tr td {border-right: 1px solid black;border-bottom:1px solid black}
body, td {font-family:Verdana,Arial,sans-serif}
body {font-size:0.8em}
button, input[type="submit"] {font-weight:bold;border:1px solid black;cursor:hand;}
h1 {font-size:1.4em;border:1px solid black;text-align:center;padding:0;margin:0;}
.coloredbg, h1, th {background-color:lightgrey}
h2 {font-size:1.2em;text-align:center;padding:0;margin:0;}
.note {font-style:italic;}
.bl, .blr, .blt, .blb, .blrt, .blrb, .bltb, .blrtb {border-left: 1px solid black}
.br, .blr, .brt, .brb, .blrt, .blrb, .brtb, .blrtb {border-right: 1px solid black}
.bt, .blt, .brt, .btb, .blrt, .bltb, .brtb, .blrtb {border-top: 1px solid black}
.bb, .blb, .brb, .btb, .blrb, .bltb, .brtb, .blrtb {border-bottom: 1px solid black}
a.footnote {border-bottom: 1px dotted black; text-decoration: none}
tr.odd td{background-color:lightyellow}
tr.even td{background-color:lightgrey}
tr.eopen td{background-color:lightgreen}
tr.preview td{background-color:white}

.graph1, .graph2 {background-color:lightyellow; border-left: 1px solid black;border-right: 1px solid black;border-top: 1px solid black; font-size:1px;border-bottom:1px solid black}
.graph1 {background-color:lightyellow}
.graph2 {background-color:darkgray}
</style>
<SCRIPT LANGUAGE="JavaScript" SRC="CalendarPopup.js"></SCRIPT> 
<SCRIPT LANGUAGE="JavaScript">document.write(getCalendarStyles());</SCRIPT> 
<SCRIPT LANGUAGE="JavaScript">
var cal = new CalendarPopup("testdiv1");
cal.setReturnFunction("setMultipleValues3"); 
function setMultipleValues3(y,m,d) { 
     document.forms[1].calyear.value=y; 
     document.forms[1].calmonth.selectedIndex=m; 
     document.forms[1].calday.selectedIndex=d; 
     }
     


function finalCheck(form) {
if(! document.Subscribe.note.value){
alert("You must enter a \"Note\"")
document.Subscribe.note.focus();return false}



	}

</SCRIPT> 
<font color="red"> <B> <?php print($error); ?></B></font>
<center>
<?php
if ($mode!="edit" && $mode !="email") {

?>
<BR>
<?
echo $roundrobincomment;
echo $accesscomment;

$GET_id=$_GET["id"];
$calendaruser =$_SESSION['usname'];
$calendarinput = "";
$outlooklink = "";

$idsearch = "id=$GET_id";
$CSOCALENDAR = "SELECT * FROM calendar WHERE cal_link LIKE '%/prospectstatus.php%' and cal_create_by ='$calendaruser' and cal_contactid = '$GET_id'   ORDER BY cal_date DESC";
$CSOCALENDAR_result = @mysql_query($CSOCALENDAR,$conn);
		
while ($csocalendarrow = mysql_fetch_array($CSOCALENDAR_result)) {
$csocalendar_name = $csocalendarrow['cal_name'];
$csocalendar_description = $csocalendarrow['cal_description'];
$csocalendar_time = $csocalendarrow['cal_time'];
$csocalendar_time = substr("$csocalendar_time", 0, -2);


$csocalendar_date = $csocalendarrow['cal_date'];
$csocalendar_createdby = $csocalendarrow['cal_create_by'];
$csocalendar_id = $csocalendarrow['cal_id'];

$calendar_year = substr("$csocalendar_date", 0, 4);
$calendar_month = substr("$csocalendar_date", 4, 2);
$calendar_day = substr("$csocalendar_date", 6, 2);
$apptdate = "($calendar_month/$calendar_day/$calendar_year at $csocalendar_time)";
$outlook_link = "<a \"text-decoration: none;\" href=outlook.php?page=outlook&cal_id=$csocalendar_id><strong><font color=\"#00FF7F\">Add to Outlook</font></strong></a>";
$calendarinput .= "$csocalendar_createdby - $csocalendar_name $apptdate $outlook_link<BR>" ;

}
?>
<script type="text/javascript">

	subject_id = '';
	function handleHttpResponse() {
		if (http.readyState == 4) {
			if (subject_id != '') {
				document.getElementById(subject_id).innerHTML = http.responseText;
			}
		}
	}
	function getHTTPObject() {
		var xmlhttp;
		/*@cc_on
		@if (@_jscript_version >= 5)
			try {
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (E) {
					xmlhttp = false;
				}
			}
		@else
		xmlhttp = false;
		@end @*/
		if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
			try {
				xmlhttp = new XMLHttpRequest();
			} catch (e) {
				xmlhttp = false;
			}
		}
		return xmlhttp;
	}
	var http = getHTTPObject(); // We create the HTTP Object

	function getScriptPage(div_id,content_id)
	{
		subject_id = div_id;
		content = document.getElementById(content_id).value;
		http.open("GET", "template.php?searchpage=prospect&content=" + escape(content), true);
		http.onreadystatechange = handleHttpResponse;
		http.send(null);
		if(content.length>0)
			box('1');
		else
			box('0');

	}	

	function highlight(action,id)
	{
	  if(action)	
		document.getElementById('word'+id).bgColor = "#184EAE";
	  else
		document.getElementById('word'+id).bgColor = "#2E2E2E";
	}
	function display(word)
	{
		document.getElementById('text_content').value = word;
		document.getElementById('box').style.display = 'none';
		document.getElementById('text_content').focus();
	}
	function box(act)
	{
	  if(act=='0')	
	  {
		document.getElementById('box').style.display = 'none';

	  }
	  else
		document.getElementById('box').style.display = 'block';
		document.getElementById('topbox').style.display = 'block';
	}
	</script>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber4">
<tr>
<td valign=top width="33%">
<table>
  <tr>
      <td class='ss-round-inputs' class="pointer" width="25%">
    <div class="ajax-div">
      <div class="input-div"> &nbsp; <img border="0" src="input-left.gif" width="7" >
        <input class="txtbox" type="text" Value="Quick Prospect Switch" onKeyUp="getScriptPage('box','text_content')" id="text_content" size="40" 
	onblur="if(this.value.length == 0) this.value='Quick Prospect Switch';" onClick="if(this.value == 'Quick Prospect Switch') this.value='';">
        <img border="0" src="input-right.gif" width="7" > </div>
      <div id="box"></div>
    </div>
    </td>
  
    </tr>
  
</table>
<?
echo "</td>";
echo "<td width=\"50%\">";

echo "<TABLE style=\"background-color:#dee7f7; border:1px solid #336;\">";
echo "<TR >";
echo "<TD><font face=\"Verdana\" ><font size=\"1\"><B>Appointment Details</B><BR><font style=font-size:9px><font  color=#0364C4><i>$calendarinput </i></font></TD>";
echo "</TR>";
echo "</TABLE>";

echo "</td>";
echo "<td width=\"25%\">&nbsp;";
echo "</td></tr>";
echo "</TABLE>";
?>
<form method="POST" action="" name="overallstatus" >
  <input type="hidden" name="changestatus" value="yes">
  <input type="hidden" name="id" value="<? echo "$line[id]"; ?>">
  <input type="hidden" name="user" value="<? print $_SESSION['usfname']; ?>">
  <input type="hidden" name="username" value="<? print $_SESSION['usname']; ?>">
  <BR>
  Overall Status =
  <select class="status" name="status">
    <option value="<? echo "$line[status]"; ?>" selected="selected"><? echo "$line[status]"; ?></option>
    <option value="Standard">Standard</option>
    <option value="DoNotCall">DoNotCall</option>
    <option value="NonResponsive">NonResponsive</option>
    <option value="NotInterested">NotInterested</option>
    <option value="NotCandidate">NotCandidate</option>
    <option value="HotLead">HotLead</option>
    <option value="CreditReview">CreditReview</option>
    <option value="ContractOut">ContractOut</option>
  </select>
  <input type="submit" name="submit" value="Change">
</form>
<TABLE width="1200" border="0" cellpadding="0" cellspacing="0">
<TR>
  <td valign="top"><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="500">
      <tr>
        <td width="1"><img border="0" src="leftupcorner.gif" width="31"></td>
        <td class="miniheaders" background="titlebackground.gif" width="99%">Prospect Record</td>
        <td width="1"><img border="0" src="rightupcorner.gif" width="10" height="29"></td>
      </tr>
    </table>
    <table class="blrtb" width="500" border="0" cellpadding="0" cellspacing="0">
        <form method="POST" action="" name="Subscribe" >
      
      <input type="hidden" name="id" value="<? echo "$line[id]"; ?>">
      <input type="hidden" name="addnote" value="yes">
      <input type="hidden" name="user" value="<? print $_SESSION['usfname']; ?>">
      <input type="hidden" name="username" value="<? print $_SESSION['usname']; ?>">
      <input name="brokerfirstname" value="<?php print($brokerfirstname); ?>" size="20" type="hidden">
      <input name="brokerlastname" value="<?php print($brokerlastname); ?>" size="20" type="hidden">
      <input name="brokeremail" value="<?php print($brokeremail); ?>" size="20" type="hidden">
      <input name="brokerusername" value="<?php print($brokerusername); ?>" size="20" type="hidden">
      <input name="brokerpassword" value="<?php print($brokerpassword); ?>" size="20" type="hidden">
      <input name="brokeremailnotify" value="<?php print($brokeremailnotify); ?>" size="20" type="hidden">
      <input name="clientinfoname" value="<? echo "$line[name]"; ?>" size="20" type="hidden">
      <tr class="odd">
        <td colspan="2" height="15" align="center"><?php
if ($_SESSION['usname']=="admin" or $_SESSION['editleads']=="Yes") {
?>
          <a href="prospectstatus.php?mode=edit&id=<? echo "$line[id]"; ?>">edit mode</a></td>
      </tr>
      <?php
}
?>
      <tr class="even">
        <td colspan="2" height="15"></td>
      </tr>
      <tr class="odd">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Name</font></td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp; <font size="1"><? echo "$line[name]"; ?></font></td>
      </tr>
      <tr class="even">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Address</font></td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp; <font size="1"><? echo "$line[address]"; ?></font></td>
      </tr>
      <tr class="even">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">City, State Zip</font></td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp; <font size="1"><? echo "$line[city]"; ?>, <? echo "$line[state]"; ?> <? echo "$line[zip]"; ?></font></td>
      </tr>
      <tr class="odd">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Phone</font></td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp; <font size="1"><? echo "$line[phone]"; ?></font></td>
      </tr>
      <tr class="odd">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Alt. Phone</font></td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp; <font size="1"><? echo "$line[altphone]"; ?></font></td>
      </tr>
      <tr class="even">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Email</font></td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp; <font size="1"> <a href="mailto:<? echo "$line[email]"; ?>"><? echo "$line[email]"; ?></a> </font></td>
      </tr>
      <tr class="even">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1"></font><BR>
          <BR></td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp; <font size="1"> <? echo "$doubleoptmessage"; ?><BR>
          <BR>
          </font></td>
      </tr>
      <tr class="even">
        <td colspan="2" ?><font size="1">
          <?php
$query = "SELECT id, name FROM systememails WHERE type='sales' and activated ='Yes' order by name";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$col_count = mysql_num_fields($result);
while($row=mysql_fetch_row($result))
{
$emailid = $row[0]; 
$emailname = $row[1]; 
?>
          <a href="prospectstatus.php?id=<? echo "$id"; ?>&mode=email&emailid=<? echo "$emailid"; ?>"><? echo $emailname; ?></a>&nbsp;
          <?php
}
?>
          </font></td>
      </tr>
      <tr class="even">
        <td width="100%" colspan="2" align="center"><font size="1">
          <?php
  if($welcomeresend == "Yes"){
        ?>
          Sent!
          <?php
  }else{
        ?>
          <BR>
          <input type="button" value="<? echo $welcomemessage; ?>" onClick="javascript:window.location.href='welcomeresend.php?t=Prospect&prospectid=<? echo "$id"; ?>'">
          <?php
 }
        ?>
          </font></td>
      </tr>
      <tr class="odd">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Entered Date </td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp; <font size="1"><? echo "$entered_month/$entered_day/$entered_year"; ?></font></td>
      </tr>
      <tr class="even">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Affiliate Name </td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp; <font size="1"><?php print($affiliatename); ?> (<?php print($lname); ?>, <?php print($fname); ?>)</font></td>
      </tr>
      <tr class="odd">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Broker Name </td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp;
          <?php
    if($_SESSION['brokers']=="Yes" && $line[broker_id] !=""){
	 ?>
          <a href="setbroker.php?cid=<?php print($line[broker_id]); ?>&cname=<?php print($brokerfirstname); ?> <?php print($brokerlastname); ?>"><font size="1"><?php print($brokercompany); ?> (<?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?>) <?php print($brokerusername); ?></font></a>
          <?php
   }else{
	 ?>
          <font size="1"><?php print($brokercompany); ?> (<?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?>) <?php print($brokerusername); ?></font>
          <?php
	 }
	 ?></td>
      </tr>
      <?php
  if($roundrobinfeature == "ON"){
        ?>
      <tr class="even">
        <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Round Robin</td>
        <td width="<?php echo "$width_ctwo"; ?>">&nbsp; <font size="1" color="green"><B><? echo "$roundrobinname"; ?></b></font></td>
      </tr>
      <?php
 }        ?>
      <tr class="even">
        <td width="100%" colspan="2" align="center">&nbsp; <font size="1">Internal Comments</font><BR>
          <textarea class="expand50-500 txtbox"  name="comments" rows="3" cols="60"><?php print($line[comments]); ?></textarea>
          </font></td>
      </tr>
      <tr class="odd">
        <td width="100%" colspan="2" align="center">&nbsp;</td>
      </tr>
      <tr class="odd">
        <td width="100%" colspan="2" align="center"><font size="1">
          <center>
          <a href="conversion.php?id=<? echo "$line[id]"; ?>"><img border=0 src="enrollsingle.png"><a>&nbsp;&nbsp;&nbsp; <a href="conversionjoint.php?id=<? echo "$line[id]"; ?>"><img border=0 src="enrolljoint.png"><a> </font></td>
      </tr>
      <tr class="odd">
        <td width="100%" colspan="2" align="center">&nbsp;</td>
      </tr>
      <tr class="odd">
        <td width="100%" colspan="2" align="center"><p align="center"> <b><font size="1">ENTER NOTES HERE</font></b><br>
            <textarea class="expand50-500" name="note" rows="5" cols="60">
</textarea>
          
          <p align="center"><font size="1"><b>CUSTOM HOT LINKS</b> <a href="canned.php?type=hotlinks">(manage)</a></font></p>
          <p align="left">
            <?php
    $query = "SELECT id, cannedreceived, cannedaction, cannedsubject, cannedname FROM companyhotlinks where cannedsubject='Prospects'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $cannedid= $row[0];
        $cannedreceived= $row[1];
        $cannedaction= $row[2];
        $cannedsubject= $row[3];
        $cannedname = $row[4];
  
?>
            <SCRIPT LANGUAGE="javascript">
   function canned<?php print($cannedid);?>()
   {
document.Subscribe.note.value = '<?php print($cannedaction);?>';
}
</script> 
            &nbsp;<a href="javascript:canned<?php print($cannedid);?>()"><?php print($cannedname);?></a>&nbsp;
            <?php
}
?>
        </td>
      </tr>
      <tr class="even">
        <td width="100%" colspan="2" align="center"><center>
          <font size="1"><b>SET FOLLOWUP</b><br>
          <select class="txtbox" name="calday">
            <option value="<? echo "$nowday"; ?>" selected="selected"><? echo "$nowday"; ?></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22"">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
          </select>
          <select class="txtbox" name="calmonth">
            <option value="<? echo "$nowmonth"; ?>" selected="selected"><? echo "$nowmonthword"; ?></option>
            <option value="1">Jan</option>
            <option value="2">Feb</option>
            <option value="3">Mar</option>
            <option value="4">Apr</option>
            <option value="5">May</option>
            <option value="6">Jun</option>
            <option value="7">Jul</option>
            <option value="8">Aug</option>
            <option value="9">Sep</option>
            <option value="10">Oct</option>
            <option value="11">Nov</option>
            <option value="12">Dec</option>
          </select>
          <input maxlength="4" class="txtbox" type="text" name="calyear" size="4" value=<? echo "$nowyear"; ?> >
          <A HREF="#" onClick="cal.showCalendar('anchor1'); return false;" NAME="anchor1" ID="anchor1"> <img border="0" src="calendar.gif"></A> &nbsp;&nbsp;
          <input class="txtbox" type="text" name="calhour" size="2" value="" maxlength="2" />
          :
          <input class="txtbox" type="text" name="calminute" size="2" value="" maxlength="2" />
          <label>
            <input type="radio" name="calampm" value="am" checked="" />
            AM</label>
          <label>
            <input type="radio" name="calampm" value="pm"  />
            PM<br>
            <input type="radio" name="typeofreminder" value="to FU"  checked="" />
            Follow up</label>
          <label>
            <input type="radio" name="typeofreminder" value="to Enroll"  />
            To Enroll</label>
          <BR>
          <strong>Priority</strong>
          <label>
            <input type="radio" name="priority" value=""  checked="" />
            Low</label>
          <label>
            <input type="radio" name="priority" value="Medium"  />
            Medium</label>
          <label>
            <input type="radio" name="priority" value="High"  />
            High</label>
          <input type="hidden" name="clientname" value="<? echo "$line[name]"; ?>"></td>
      </tr>
      <tr class="odd">
        <td colspan="2" height="10"></td>
      </tr>
      <tr class="odd">
        <td align="center" colspan="2" width="100%"><center>
          <input type="submit" name="submit" value="Update">
          <input type="hidden" name="action" value="update">
          <? if ($line[category] == "Prospect") { ?>
          <input type="submit" name="delete" value="Delete">
          <? } ?></td>
      </tr>
      <tr class="odd">
        <td colspan="2" height="15"></td>
      </tr>
    </table>
    </form>
    <DIV ID="testdiv1" STYLE="position:absolute;visibility:hidden;background-color:white;layer-background-color:white;"></DIV></TD>
  <TD VALIGN="TOP"></TD>
  <TD>&nbsp;</TD>
  <td valign="top"><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="700">
      <tr>
        <td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
        <td class="miniheaders" background="titlebackground.gif" width="99%">Notes</td>
        <td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td>
      </tr>
    </table>
    <div style="border:0px  solid; width:700; height:300px; overflow:auto;">
    <table class="blrtb" width="700" border="0" cellpadding="0" cellspacing="0">
    <?
echo "<center>";

$sql = "SELECT * FROM salesnotes WHERE clientid = '$GET_id' AND (received !='broker' or received IS NULL) ORDER BY repairdate desc, id desc";
$result = @mysql_query($sql,$conn) or die("Couldn't execute");

$num_results = mysql_num_rows($result);

if (! $num_results || $num_results == "0") {
echo "<b><font face=\"Verdana\" size=\"2\" color=\"#FF0000\">No notes added.</font></b>";
}else{

  $change_color = "1";
  
echo "<TABLE width=\"700\" BORDER=\"0\" bordercolor=\"#000000\" class=\"blrtb\" cellpadding=\"0\" cellspacing=\"0\">";



  while ($row = mysql_fetch_array($result)) {	
    $NOTE_id = $row['id'];
    $NOTE_contact_id = $row['clientid'];
    $NOTE_view = $row['action'];
    $NOTE_user = $row['counselor'];
    $NOTE_julian = $row['repairdate'];
    $NOTE_tstamp = $row['filelocation'];

$NOTE_year = substr("$NOTE_julian", 0, 4);
$NOTE_month = substr("$NOTE_julian", 5, 2);
$NOTE_day = substr("$NOTE_julian", 8, 2);

if ($change_color == "2") {
$bgcolor = "class=\"even\"";
$change_color = "1";
}else{
$bgcolor = "class=\"odd\"";
$change_color = "2";
}
///ADJUST FOR TIMEZONE
$notetime = date("m/d/Y h:i:sa",strtotime("$NOTE_julian $NOTE_tstamp $timezoneoffset"));

echo "<TR $bgcolor>";
echo "<TD align=\"center\"><font size=\"1\">$notetime</font></TD>";
echo "<TD align=\"center\"><font face=\"Verdana\" ><font size=\"1\">$NOTE_view</font></TD>";
echo "<TD align=\"center\"><font face=\"Verdana\" ><font size=\"1\">$NOTE_user</font></TD>";
echo "</TR>";


} // end while loop //
echo "</TABLE></div>
<p>";
	} // end if results //

echo "<br><br>";
///////TESTING EMAIL HISTORY SECTION

?>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="700">
      <tr>
        <td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
        <td class="miniheaders" background="titlebackground.gif" width="99%">Email History</td>
        <td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td>
      </tr>
    </table>
    <div style="border:0px  solid; width:700; height:275px; overflow:auto;">
    <table class="blrtb" width="700" border="0" cellpadding="0" cellspacing="0">
      <?


echo "<center>";

$sql = "SELECT * FROM emailhistory WHERE contact_id = '$GET_id' order by id desc";
$result = @mysql_query($sql,$conn) or die("Couldn't execute");

$num_results = mysql_num_rows($result);

if (! $num_results || $num_results == "0") {
echo "<b><font face=\"Verdana\" size=\"2\" color=\"#FF0000\">No Email History.</font></b>";
}else{

  $change_color = "1";
echo "<TABLE width=\"700\" BORDER=\"0\" bordercolor=\"#000000\" class=\"blrtb\" cellpadding=\"2\" cellspacing=\"0\">";

  while ($row = mysql_fetch_array($result)) {	
    $EMAIL_id = $row['id'];
    $EMAIL_contact_id = $row['contact_id'];
    $EMAIL_subject = $row['subject'];
    $EMAIL_preview = $row['preview'];
    $EMAIL_numopens = $row['numopens'];
    $EMAIL_lastopen = $row['lastopen'];
	$EMAIL_julian = $row['julian'];
    $EMAIL_tstamp = $row['tstamp'];

$EMAIL_year = substr("$EMAIL_julian", 0, 4);
$EMAIL_month = substr("$EMAIL_julian", 4, 2);
$EMAIL_day = substr("$EMAIL_julian", 6, 2);

$EMAIL_loyear = substr("$EMAIL_lastopen", 0, 4);
$EMAIL_lomonth = substr("$EMAIL_lastopen", 4, 2);
$EMAIL_loday = substr("$EMAIL_lastopen", 6, 2);

$EMAIL_preview2 = html_entity_decode($EMAIL_preview);

$bgcolor = "class=\"odd\"";
$bgcolorforpreview = "class=\"preview\"";
$emailstatus = "Unopened";
if ($EMAIL_lastopen != "") {
$bgcolor = "class=\"eopen\"";
$emailstatus = "Opened";
$bgcolorforpreview = "class=\"preview\"";
$change_color = "2";
}

echo "<TR $bgcolor>";
echo "<TD align=\"center\"><font size=\"1\">$EMAIL_month/$EMAIL_day/$EMAIL_year $EMAIL_tstamp </font></TD>";
echo "<TD align=\"center\"><font size=\"1\">$emailstatus</font></TD>";
if ($EMAIL_preview != "") {
echo "<TD align=\"center\"><font face=\"Verdana\" ><a href=\"javascript: void(0)\" onclick=\"return toggleMe('email$EMAIL_id')\"><font size=\"1\">$EMAIL_subject</font></a></TD>";
}else{
echo "<TD align=\"center\"><font face=\"Verdana\" ><font size=\"1\">$EMAIL_subject</font></TD>";
}
echo "<TD align=\"center\"><font face=\"Verdana\" ><font size=\"1\">LO: $EMAIL_lomonth/$EMAIL_loday/$EMAIL_loyear <BR>TO: $EMAIL_numopens</font></TD>";
echo "</TR>";
echo "<TR $bgcolorforpreview><TD colspan=4><font face=\"Verdana\" ><font size=\"1\"></font><div id=\"email$EMAIL_id\" style=\"display:none\">$EMAIL_preview2</div></TD></TR>";



} // end while loop //
echo "</TABLE></div>";
	} // end if results //

echo "<br><br>";
?>
    </table>
    <?php
      }
if ($mode=="edit" && ($_SESSION['usname']=="admin" or $_SESSION['editleads']=="Yes")) {

/* Connection to Affiliates People */

		$SA_sql = "SELECT * FROM sales_affiliates WHERE type='Affiliate' AND status !='suspend' AND status !='del' ORDER BY lname";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $affiliateid = $srow['id'];
		    $fname = $srow['fname'];
		    $lname = $srow['lname'];


                if ($username == "$user") {
		$user_select6 .= "<option value=\"$affiliateid\">$lname, $fname</option>";
		}else{
		$user_select6 .= "<option value=\"$affiliateid\">$lname, $fname</option>";
		}

		$ARUSERS{"$affiliateid"} = "$affiliateid";
		
		}

$SA_sql = "SELECT fname,lname FROM sales_affiliates where id= '$line[affiliate_id]'";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $affiliatefirstname = $srow['fname'];
		    $affiliatelastname = $srow['lname'];
		}


/* Connection to Brokers */

		$SA_sql = "SELECT * FROM dealers WHERE status !=9 ORDER BY lastname";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $dealerid = $srow['dealer_id'];
		    $firstname = $srow['firstname'];
		    $lastname = $srow['lastname'];


                if ($username == "$user") {
		$user_select5 .= "<option value=\"$dealerid\">$lastname, $firstname</option>";
		}else{
		$user_select5 .= "<option value=\"$dealerid\">$lastname, $firstname</option>";
		}

		$ARUSERS{"$dealerid"} = "$dealerid";
		
		}
$SA_sql = "SELECT firstname,lastname,email,username,password, emailnotify FROM dealers where dealer_id='$line[broker_id]' and status !=9";
		$SA_result2 = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result2)) {
		    $brokerfirstname = $srow['firstname'];
		    $brokerlastname = $srow['lastname'];
		    $brokeremail = $srow['email'];		    
		    $brokerusername = $srow['username'];		
		    $brokerpassword = $srow['password'];				    		    
		    $brokeremailnotify= $srow['emailnotify'];				    		    
		}

$clientfirstname = explode(' ', $line[name]); 
$clientfirstname = $clientfirstname[0];

?>
    <BR>
    <BR>
    <TABLE width="400" border="0" cellpadding="0" cellspacing="0">
      <TR>
        <td valign="top"><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="400">
            <tr>
              <td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
              <td class="miniheaders" background="titlebackground.gif" width="414">Edit Prospect Record</td>
              <td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td>
            </tr>
          </table>
          <table class="blrtb" width="400" border="0" cellpadding="0" cellspacing="0">
              <form method="POST" action="" name="EDIT" >
            
            <input type="hidden" name="id" value="<? echo "$line[id]"; ?>">
            <input type="hidden" name="editmode" value="yes">
            <input type="hidden" name="user" value="<? print $_SESSION['usfname']; ?>">
            <input type="hidden" name="username" value="<? print $_SESSION['usname']; ?>">
            <input type="hidden" name="oldemail" value="<? echo "$line[email]"; ?>">
            <input type="hidden" name="clientfirstname" value="<? echo "$clientfirstname"; ?>">
            <tr class="odd">
              <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Name</font></td>
              <td width="<?php echo "$width_ctwo"; ?>"><input class="txtbox" name="name" size="37" value="<? echo "$line[name]"; ?>" ></td>
            </tr>
            <tr class="even">
              <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Address</font></td>
              <td width="<?php echo "$width_ctwo"; ?>"><input class="txtbox" name="address" size="37" value="<? echo "$line[address]"; ?>" ></td>
            </tr>
            <tr class="even">
              <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">City, State Zip</font></td>
              <td width="<?php echo "$width_ctwo"; ?>"><input class="txtbox" name="city" size="15" value="<? echo "$line[city]"; ?>" >
                ,
                <input class="txtbox" name="state" size="4" value="<? echo "$line[state]"; ?>" >
                &nbsp;
                <input class="txtbox" name="zip" size="6" value="<? echo "$line[zip]"; ?>" ></td>
            </tr>
            <tr class="odd">
              <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Phone</font></td>
              <td width="<?php echo "$width_ctwo"; ?>"><input class="txtbox" name="phone" size="15" value="<? echo "$line[phone]"; ?>" ></td>
            </tr>
            <tr class="odd">
              <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Alt. Phone</font></td>
              <td width="<?php echo "$width_ctwo"; ?>"><input class="txtbox" name="altphone" size="15" value="<? echo "$line[altphone]"; ?>" ></td>
            </tr>
            <tr class="even">
              <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Email</font></td>
              <td width="<?php echo "$width_ctwo"; ?>"><input class="txtbox" name="email" size="37" value="<? echo "$line[email]"; ?>" ></td>
            </tr>
            <tr class="even">
              <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Affiliate Name </td>
              <td width="<?php echo "$width_ctwo"; ?>"><select name="affiliate_id"  class="txtbox" >
                  <option value="<? echo "$line[affiliate_id]"; ?>" selected><?php print($affiliatelastname); ?>, <?php print($affiliatefirstname); ?></option>
                  <? echo "$user_select6"; ?>
                  <option value="">----Remove Affiliate from this client----</option>
                </select></td>
            </tr>
            <tr class="odd">
              <td <? echo "width=\"$width_cone\" height=\"$height_sz\""; ?>>&nbsp; <font size="1">Broker Name </td>
              <td width="<?php echo "$width_ctwo"; ?>"><select name="broker_id" class="txtbox"  >
                  <option value="<? echo "$line[broker_id]"; ?>" selected><?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?></option>
                  <? echo "$user_select5"; ?>
                  <option value="">----Remove Brokers from this client----</option>
                </select></td>
            </tr>
            <tr class="odd">
              <td align="center" colspan="2" width="100%">&nbsp;</td>
            </tr>
            <tr class="odd">
              <td align="center" colspan="2" width="100%"><center>
                <input type="submit" name="submit" value="Update"></td>
            </tr>
            <tr class="odd">
              <td colspan="2" height="15"></td>
            </tr>
          </table>
          </form></TD>
    </table>
    <?php
} 
//END EDIT MODE

if ($mode=="email") {

$query = "SELECT id, subject, message, name FROM systememails WHERE id='$emailid'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
           
        $emailid = $row[0]; 
        $subject = $row[1]; 
        $message = $row[2]; 
        $emailname = $row[3]; 

    }
    $query = "SELECT fname, email, extension, lname FROM users WHERE id='" . $_SESSION['usid'] . "'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
           
        $salesfname = $row[0]; 
        $salesemail = $row[1]; 
        $salesextension = $row[2]; 
        $saleslname = $row[3]; 

    }
    $fname = explode(' ', $line[name]); 
if ($fname[2] != ""){
$lname = $fname[2];
}else{
$lname = $fname[1];
}
$fname = $fname[0];

$fname = ucwords(strtolower($fname)); 
$lname = ucwords(strtolower($lname)); 
$name=$line[name];
$email=$line[email];
$address=$line[address];
$city=$line[city];
$state=$line[state];
$zip=$line[zip];
$phone=$line[phone];
$fax=$line[fax];

    include_once("companystrip.php");
    include_once("clientstrip.php");

$message2 = str_replace("{SALESFNAME}", "$salesfname", $message2);
$subject2 = str_replace("{SALESFNAME}", "$salesfname", $subject2);

$message2 = str_replace("{SALESLNAME}", "$saleslname", $message2);
$subject2 = str_replace("{SALESLNAME}", "$saleslname", $subject2);

$message2 = str_replace("{SALESEMAIL}", "$salesemail", $message2);
$subject2 = str_replace("{SALESEMAIL}", "$salesemail", $subject2);

$message2 = str_replace("{SALESEXTENSION}", "$salesextension", $message2);
$subject2 = str_replace("{SALESEXTENSION}", "$salesextension", $subject2);

if($_POST['sendsalesmail'] == 'yes'){
$emailthatwassent = $_POST['email'];
$salesfname = $_POST['salesfname'];
$salesemail = $_POST['salesemail'];
$EMAIL_Message = "$message2";


///////FOR WRITING TO DATABASE
$message3 = htmlentities($message2);
$message3 = str_replace("'", "&#39;", "$message3");
$subject3 = htmlentities($subject2);
$subject3 = str_replace("'", "&#39;", "$subject3");
        $query = "INSERT INTO emailhistory(contact_id,preview,subject,julian,tstamp)
                VALUES(
                '$id',
                '$message3',
                '$subject3',
                '$julian',
                '$tstamp'
                )";
        $result = mysql_query($query, $conn) or die("could not add to email history:" . mysql_error());

$emailid = mysql_insert_id($conn);



$trackingcode="<BR><BR><BR><img src=\"$companywebsite/eopen.php?id=$emailid\" height=\"1\" width=\"1\">";
////////



if($privatelabel== "No"){
$EMAIL_Message .= $poweredbymessage;
}
$EMAIL_Message .= "$trackingcode";

$EMAIL_Subject = "$subject2";
$EMAIL_Reply = "$salesemail";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $salesfname ($companyname) <$salesemail>\r\n";
                  $formsent = mail($emailthatwassent, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $salesemail");  

    $note = "Sent $emailname email to $emailthatwassent";


$sql_note = "INSERT INTO salesnotes

(clientid,action,counselor,repairdate,filelocation)
               VALUES
(\"$id\",
\"$note\",
\"$salesfname\",
\"$today\",
\"$tstamp\")";
$result_note = @mysql_query($sql_note,$conn);

$sql = "UPDATE clients SET
dealer_id = \"\"
WHERE id = \"$id\"";
$result = @mysql_query($sql,$conn);

echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=prospectstatus.php?id=$id&action=update\">"; 


}

?>
    <BR>
    <BR>
    <TABLE width="60%" border="0" cellpadding="0" cellspacing="0">
      <TR>
        <td valign="top"><form method="POST" action="" name="EMAIL" >
            <input type="hidden" name="id" value="<? echo "$line[id]"; ?>">
            <input type="hidden" name="salesfname" value="<? echo $salesfname; ?>">
            <input type="hidden" name="salesemail" value="<? echo $salesemail; ?>">
            <input type="hidden" name="sendsalesmail" value="yes">
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
              <tr>
                <td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
                <td class="miniheaders" background="titlebackground.gif" width="99%"> Send
                  <input class="txtbox" name="fname" size="15" value="<? echo $fname; ?>">
                  <? echo "$emailname"; ?> email to
                  <input class="txtbox" name="email" size="35" value="<? echo $email; ?>"></td>
                <td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td>
              </tr>
            </table>
            <table class="blrtb" width="100%" border="0" cellpadding="3" cellspacing="3" style="border-width:0; border-collapse: collapse" bordercolor="#111111">
              <TR>
                <TD align="center"><h1>From <i><font color="#800000"><? echo $salesfname; ?> (<? echo $companyname; ?>) <? echo $salesemail; ?></font></i></h1></TD>
              </tr>
              <tr width="60%" bgcolor="#FFFFF">
                <td width="80%"><p><b>Subject:</b> <? echo "$subject2"; ?>
                  
                  <p><? echo "$message2"; ?></p></td>
              </tr>
              <tr >
                <td align="center" width="100%">&nbsp;</td>
              </tr>
              <tr >
                <td align="center" width="100%"><center>
                  <?php
if ($salesemail ==""){
echo "This feature not available because your profile does not contain a valid email address";
}else{
?>
                  <input type="submit" name="submit" value="SEND EMAIL">
                  <input type="hidden" name="action" value="update">
                  <?php
}
?></td>
              </tr>
              <tr >
                <td height="15"></td>
              </tr>
            </table>
          </form></TD>
    </table>
    <?php















} 
//END EMAIL MODE
?>
    <?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>
