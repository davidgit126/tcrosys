<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();

	

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   
    ?>
   
  <?php
    if($_SESSION['usname']=="admin")
    {
    
    
    include('template2.php');
     include("connection.php");
      $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 
        
       


    }

     $query = "SELECT id, name, subject, message, type, activated, description FROM systememails WHERE name='$emailname'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailid           = $row[0];
              $emailname   = $row[1];
              $subject   = $row[2];
              $message   = $row[3];
              $type = $row[4];
              $activated = $row[5];              
              $description = $row[6];     
              
          
}
    include_once("companystrip.php");

        ?>
  
    
   
<? echo $subject2; ?>
<meta http-equiv="Content-Language" content="en-us">
<BR><BR><BR>
<? echo $message2; ?>

<BR><BR><BR><BR><BR><BR>

<a href="systememail.php?emailname=<?php print($emailname); ?>">Back</a><?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>