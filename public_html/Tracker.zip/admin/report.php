<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    ?>
        
    

   
    <a href="search.php?cname=&zip=&email=&f=1&Find=Find">Pending Client Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="standardsearch.php?cname=&zip=&email=&f=1&Find=Find">Standard Client Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="completedsearch.php?cname=&zip=&email=&f=1&Find=Find">Completed Client Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="canceledsearch.php?cname=&zip=&email=&f=1&Find=Find">Canceled Client Search</a> <br>
   
    


 
        <?php
         include("connection.php");
include('template.php');


             $query = "SELECT count(id) as id, name, status, createdate FROM clients GROUP BY active";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $status       = $row[2];
              $createdate  = $row[3];
              $cnt++;
              
        

$bgcolor = "FFFFFF";
}
              ?>
              <tr>
              
              </tr>
              
          </table>
          <p>Total Active Accounts in the system (as of <? print date("m-d-Y"); ?>): <b><?php echo $id; ?></b></p>

                    
                    
                 <?php
       
$lastmonth = strftime ("%Y-%m", strtotime("-1 month"));
$twolastmonth = strftime ("%Y-%m", strtotime("-2 month"));
$lastmonth2 = strftime ("%m/%Y", strtotime("-1 month"));
$currentmonth = date("Y-m"); 
$lastday = "-31";
$firstday = "-01";

             $query2 = "SELECT count(id) FROM clients WHERE createdate >= '$lastmonth$firstday' and createdate <= '$lastmonth$lastday' GROUP BY active";

          $result = mysql_query($query2, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $newid           = $row[0];
              $cnt++;
              
        


}
$query3 = "SELECT count(id) FROM clients WHERE createdate <= '$twolastmonth$lastday' GROUP BY active";

          $result = mysql_query($query3, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $oldid           = $row[0];
              $cnt++;
              
        


}

$totalcommish = ($newid * 20) + ($oldid * 5);
              ?>
   
                              <p>Total Accounts this month: <b><?php echo $id - $oldid - $newid; ?></b></p>
                  <b>~~Accounting Info~~</b><BR><BR>
                     <p>Number of accounts from <?php echo $lastmonth2; ?>: <b><?php echo $newid; ?></b></p>

<p>Number of existing accounts before <?php echo $lastmonth2; ?>: <b><?php echo $oldid; ?></b></p>
~~~~~~~~~~~~~~~~~~~~~~<BR>
Amount owed for existing active accounts for <?php echo $lastmonth2; ?>: <font color="#008000"><b>$<?php echo $oldid * 5; ?></b></font><BR>
<p>Amount owed for new accounts for <?php echo $lastmonth2; ?>: <font color="#008000"><b>$<?php echo $newid * 20; ?></b></font><BR>
~~~~~~~~~~~~~~~~~~~~~<BR>
<b>Total = <font color="#008000">$<?php echo $totalcommish; ?></font>
</b>
<?php
         
}
else
{
    header("Location: login.php");
    exit();
}

?>