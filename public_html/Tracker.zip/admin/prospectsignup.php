<?php
extract ($_GET );
extract ($_POST );

    include_once('common.inc.php');
    session_start();



    include("connection.php");



$fontday = date("D");

        $query = "SELECT font FROM fonttypes WHERE fontday ='$fontday'"; 
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());
        $col_count = mysql_num_fields($result);

        while($row=mysql_fetch_row($result))
        {
          $fonttype = $row[0];

        } 
$query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, reseller, single, companyskin, roundrobinfeature, privatelabel FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $reseller = $row[12];              
        $single = $row[13];              
        $companyskin = $row[14];  
		$roundrobinfeature= $row[15];
        $privatelabel = $row[16];          
    }
$poweredbymessage = "<BR><BR><p align=right><a href=\"http://www.creditrepairtracking.com\"><img border=0 src=http://www.creditrepairtracking.com/trackstarlogoforemail.png></a></p>";

        $date_array = split("-", $birthdate);
        $birthdate = $date_array[2]."-".$date_array[0]."-".$date_array[1];
$createdate = date("Y-m-d");

$tier_id = $_POST['broker_id'];
if ($tier_id != "") {
    $query = "SELECT tier2aff, username, tier3aff, affiliate_id FROM dealers WHERE dealer_id='$tier_id'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $tier2aff = $row[0];
        $usernameu = $row[1];
        $tier3aff = $row[2];
        $affiliate_id = $row[3];
  }
}

 if($affiliate_id ==""){
$affiliate_id=$_POST['affiliate_id'];
}

//////////START ROUND ROBIN
 if($roundrobinfeature =="ON"){

//AFFILIATE CHECK
$query = "SELECT salesid, affid, id FROM roundrobin WHERE affid= '$affiliate_id' && affid !='' limit 1";
    $result = @mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result)) 
{
		    $roundrobinid = $row[0]; 
			$roundrobinaffid= $row[1]; 
			$roundrobincheck = $row[1]; 
			}
//SELF CHECK
if ($roundrobincheck ==""){  

$query = "SELECT id FROM sales_affiliates WHERE id='" . mysql_real_escape_string($_SESSION['usid']) . "' AND type='Sales' limit 1";
    $result = @mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result)) 
{
		    $roundrobinid = $row[0]; 
}

/////WHAT TO DO
if ($roundrobinid != $_SESSION['usid']){  

$query = "SELECT salesid, affid FROM roundrobin WHERE status= 'IN' ORDER BY Rand() limit 1";
    $result = @mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result)) 
{
		    $roundrobinid = $row[0]; 
			$roundrobinaffid = $row[1]; 

}
$sql = "UPDATE roundrobin
              SET
status = \"OUT\"
WHERE salesid = \"$roundrobinid\"";
$result = @mysql_query($sql,$conn);

if ($roundrobinid =="") {
$sql = "UPDATE roundrobin
              SET
status = \"IN\"
WHERE status = \"OUT\"";
$result = @mysql_query($sql,$conn);
	

$query = "SELECT salesid, affid FROM roundrobin WHERE status= 'IN' ORDER BY Rand() limit 1";
    $result = @mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result)) 
{
		    $roundrobinid = $row[0]; 
		    $roundrobinaffid = $row[1]; 
}
$sql = "UPDATE roundrobin
              SET
status = \"OUT\"
WHERE salesid = \"$roundrobinid\"";
$result = @mysql_query($sql,$conn);
}///END WHAT TO DO
}//END SELF CHECK
}//END AFFILIATE CHECK
 }//////////END ROUND ROBIN

        $query = "INSERT INTO clients(name, address, city, state, zip, email, fax, phone, altphone, ssnum, birthdate, createdate, leadentered, fonttype, username, password, country, prospectclient, broker_id, dealer_id, affiliate_id, tier2aff, tier3aff, leadassigned, reseller_id)
                VALUES(
                '" . mysql_real_escape_string($_POST['sname']) . "', 
                '" . mysql_real_escape_string($_POST['saddress']) . "', 
                '" . mysql_real_escape_string($_POST['city']) . "', 
                '" . mysql_real_escape_string($_POST['state']) . "',
                '" . mysql_real_escape_string($_POST['szip']) . "',
                '" . mysql_real_escape_string($_POST['semail']) . "',
                '" . mysql_real_escape_string($_POST['fax']) . "',
                '" . mysql_real_escape_string($_POST['phone']) . "',
                '" . mysql_real_escape_string($_POST['altphone']) . "',
                '" . mysql_real_escape_string($_POST['ssnum']) . "',
                '$birthdate',
                '$createdate',
                '$createdate',
				'$fonttype',
                '***********',
                '***********', 
                '" . mysql_real_escape_string($_POST['country']) . "',
                'Prospect',
                '$broker_id',
                '" . mysql_real_escape_string($_POST['dealer_id']) . "',
                '$affiliate_id',
                '$tier2aff',
                '$tier3aff',
				'$roundrobinid',
                '" . mysql_real_escape_string($_POST['reseller_id']) . "')";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$recordid = mysql_insert_id($conn);


$name=$_POST['sname'];
$address=$_POST['saddress'];
$city=$_POST['city'];
$state=$_POST['state'];
$zip=$_POST['szip'];
$email=$_POST['semail'];
$phone=$_POST['phone'];

$clientfirstname = explode(' ', $name); 
$clientfirstname = $clientfirstname[0];

 if($broker_id !=""){

    $query = "SELECT lastname, firstname, address, city, prov, zipcode, email, fax, telephone, dealership, username, password, comments, dealer_id, affiliate_id, commission, account_exec, emailnotify FROM dealers WHERE dealer_id='$broker_id' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lastname = $row[0];
        $firstname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $prov = $row[4];
        $zipcode = $row[5];
        $brokeremail = $row[6];
        $fax = $row[7];
        $telephone = $row[8];
        $dealership = $row[9];
        $username = $row[10];
        $password = $row[11];
	    $comments = $row[12];
		$dealer_id = $row[13];			
		$affiliate_id = $row[14];			
		$commission = $row[15];			
		$masterbroker = $row[16];			
		$emailnotify = $row[17];			
    }
 if($emailnotify >=2){
$message = "$firstname, <BR><BR>There has been a new lead submission from $name.<BR><BR>Remember, you can log into your account at anytime and track all sales notes on this prospect.";
$EMAIL_Message = "$companyskin$message";
if($privatelabel== "No"){
$EMAIL_Message .= $poweredbymessage;
}
$EMAIL_Subject = "New Lead Notification";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From>\r\n";
                $formsent = mail($brokeremail, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  

}}

    $query = "SELECT lname, fname, email FROM sales_affiliates WHERE id='$affiliate_id' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $afflname = $row[0];
        $afffname = $row[1];
        $affemail = $row[2];
    }




  // create the MD5 hash 
$secret_code = 'htdiisawesome';
$formatted_email = preg_replace("/(-|\@|\.)/", "", $email);
$hashed = md5("$secret_code $formatted_email");

$mail_body = "$clientfirstname, to validate this email click the following link:\n";
$mail_body .= "$companywebsite/validate.php?m=$hashed&t=wc&w=p&id=$recordid&eid=4\n";
$mail_body .= "By validating your email address you agree to receive emails from $companyname\n";
$mail_body .= "\n\n\n\n\n\n\n\n\n\n\n\n";
$mail_body .= "To remove yourself from future contact from $companyname, please click the following link instead:\n";
$mail_body .= "$companywebsite/remove.php?m=$hashed&w=p&id=$recordid\n";


$mail_subject = "Please validate your email address with $companyname";
$mail_from = "From: $companyname <$companyreply>\r\n";
mail($email, $mail_subject, $mail_body, $mail_from);

 $query = "UPDATE clients SET
                opttimesasked='1'
WHERE id = \"$recordid\"";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

/* if($email !="" ){

 $query = "SELECT id, name, subject, message, type, activated, description FROM systememails WHERE name='Prospect_Welcome'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailid           = $row[0];
              $emailname   = $row[1];
              $subject   = $row[2];
              $message   = $row[3];
              $type = $row[4];
              $activated = $row[5];              
              $description = $row[6];    
}

 if($activated =="Yes"){

   
    include_once("companystrip.php");
    include_once("clientstrip.php");

$message2 = str_replace("{A_FNAME}", "$afffname", $message2);
$subject2 = str_replace("{A_FNAME}", "$afffname", $subject2);
$message2 = str_replace("{A_LNAME}", "$afflname", $message2);
$subject2 = str_replace("{A_LNAME}", "$afflname", $subject2);
$message2 = str_replace("{AFFEMAIL}", "$affemail", $message2);
$subject2 = str_replace("{AFFEMAIL}", "$affemail", $subject2);


$EMAIL_Message = "$companyskin$message2";
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From>\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
}
}
*/




        mysql_close($conn);



        header("Location: prospectstatus.php?id=$recordid?message=Prospect Record Created!");
        exit();
    
?>