<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   include('template.php');

    ?>
   
  <?php
    if($_SESSION['usname']=="admin" or $_SESSION['usaccess']=="full")
    {
    
    
    
     include("connection.php");

     $query = "SELECT id, name, subject, message, type, activated, description FROM systememails WHERE name='$emailname'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailid           = $row[0];
              $emailname   = $row[1];
              $subject   = $row[2];
              $message   = $row[3];
              $type = $row[4];
              $activated = $row[5];              
              $description = $row[6];                
}

        ?>
  
    
   
<form method="POST" action="addlettersuccess.php">
                            <input type="hidden" name="emailname" value="<?php print($emailname); ?>">



<div align="center">
  <center>
<font color="#FF0000"><b><?php print($success); ?></b></font>


<table width="70%"><tr><td width="95%" align=center valign="top">


<table border=1 width="919" cellspacing="1" cellpadding="6">


<tr>
  <td BGCOLOR="#CCCCCC" align="right" width="229">
<b><font face="Verdana" size="2">Letter Name:</font></b> </td>
  <td BGCOLOR="#CCCCCC" colspan="3" width="672"> 
<input class="txtbox" type=text name=lettername size=85 value="">
</TD>
</tr>


<tr>
  <td BGCOLOR="#CCCCCC" align="right" width="229">


</td>
  <td BGCOLOR="#CCCCCC" width="229"> 
                                        &nbsp;<b><font face="Verdana" size="2">Display AV/SSN Proof?</font></b> 
                                        <br> 
                                        <select name="showproof" class="txtbox"  >
                
                 <option value="Yes">Yes</option>
 <option value="No">No</option>

              </select></TD>
  <td BGCOLOR="#CCCCCC" align="right" width="229">
<b><font face="Verdana" size="2">Order on letter menu&nbsp;&nbsp; </font></b><br>
<input class="txtbox" type=text name=letterorder size=6 value=""></td>
  <td BGCOLOR="#CCCCCC" width="229"> 
                                        &nbsp;<b><font face="Verdana" size="2">Dispute 
                                        Column?</font></b><br>
                                        <select name="disputecolumn" class="txtbox"  >
                                 

                 <option value="s1dispute">s1dispute</option>
                 <option value="s2dispute">s2dispute</option>
 

              </select></TD>
</tr>


<tr>
  <td colspan="4" BGCOLOR="#CCCCCC" align="center" width="901">
<textarea rows="20" name="abovedisputes"  id="abovedisputes" cols="110"></textarea>
<script language=JavaScript src='../include/gui/scripts/innovaeditor.js'></script>
   <script language=JavaScript src='http://www.tcrosystems.net/scripts/addbureau.js'></script>

</TD>
</tr>


</table><br>
<input type="submit" value="Add Letter">



</td></table>
</center>
</div>


</center>


  
</form>
<p>
<BR><BR><a href="letters.php">Letter Menu</a>
</p>



  
<?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>