<?php
extract ($_GET );
extract ($_POST );
include("connection.php");



$sql = "UPDATE letters SET
lettername = \"$lettername\",
abovedisputes = \"" . mysql_real_escape_string( $abovedisputes) . "\",
belowdisputes = \"" . mysql_real_escape_string( $belowdisputes) . "\",
showdisputes = \"$showdisputes\",
letterorder = \"$letterorder\",
disputecolumn = \"$disputecolumn\",
showproof = \"$showproof\"
WHERE id = \"$letterid\"";

$result = @mysql_query($sql,$conn);

$str = mysql_real_escape_string( print_r( $result, true ));
header("Location: editletter.php?letterid=$letterid&success=Letter Updated!&rsl=". $str);  
exit;

?>