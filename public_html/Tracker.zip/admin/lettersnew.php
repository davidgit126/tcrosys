<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    include("connection.php");
include('template.php');

?>


 <?php
    if($_SESSION['usname']=="admin")
    {
        ?>

            <font size=2 color=blue>
<p><a href="addletter.php">Add Letter to list</a></p>
</font>
           <?php
}
        ?>
  
            
            <P align=left>
            <font color="#C0C0C0" size="2">
            
             <?php
        include("connection.php");
        
     
              
     $query = "SELECT id, lettername FROM letters order by letterorder";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $letterid           = $row[0];
              $lettername   = $row[1];

    
        ?>
 

<a target="_blank" href="printletter.php?letterid=<?php print($letterid); ?>&bureauid=1">Equifax <?php print($lettername); ?></a><BR>
<a target="_blank" href="printletter.php?letterid=<?php print($letterid); ?>&bureauid=2">Experian <?php print($lettername); ?></a>              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          

 <?php
    if($_SESSION['usname']=="admin")
    {
        ?>
          <a href="editletter.php?letterid=<?php print($letterid); ?>">edit</a>
           <?php
}
        ?>
 <BR>
<a target="_blank" href="printletter.php?letterid=<?php print($letterid); ?>&bureauid=3">Transunion <?php print($lettername); ?></a><BR></p>
    <?php
}
?>
</p>
     
      







 </font>

            







 </font>

            







 <?php
}
else
{
    header("Location: login.php");
    exit();
}

?>