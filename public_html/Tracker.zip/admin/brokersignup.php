<?php
extract ($_GET );
extract ($_POST );
    include_once('common.inc.php');
    session_start();


    include("connection.php");
    $query = "SELECT dealer_id FROM dealers WHERE username='" . mysql_real_escape_string($_POST['username']) . "'"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
   // print($col_count);
   $reccount=0;
    while($row=mysql_fetch_row($result))
    {
         $reccount++;
    } 

    if($reccount>0)
    {

        print("<html><body>");
        print("The username <b>$username</b> already exist. Please choose another name. <br> Click on Back button of your browser");
    }  
    else
    {

$tier_id = $_POST['tier_id'];
if ($tier_id != "") {
    $query = "SELECT dealer_id, username, tier2aff, affiliate_id FROM dealers WHERE dealer_id='$tier_id'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $tier2aff = $row[0];
        $usernameu = $row[1];
        $tier3aff = $row[2];
        $affiliate_id = $row[3];
  }
}

if ($affiliate_id == "") {
$affiliate_id = $_POST['affiliate_id'];
}
       
$createdate = date("Y-m-d");
        $query = "INSERT INTO dealers(firstname, lastname, dealership, address, city, prov, zipcode, email, fax, telephone, createdate, username, password, affiliate_id, reseller_id, commission, tier2comm, tier3comm, tier2aff, tier3aff)
                VALUES(
                '" . mysql_real_escape_string($_POST['firstname']) . "', 
                '" . mysql_real_escape_string($_POST['lastname']) . "',
                '" . mysql_real_escape_string($_POST['dealership']) . "',
                '" . mysql_real_escape_string($_POST['saddress']) . "', 
                '" . mysql_real_escape_string($_POST['city']) . "', 
                '" . mysql_real_escape_string($_POST['state']) . "',
                '" . mysql_real_escape_string($_POST['szip']) . "',
                '" . mysql_real_escape_string($_POST['semail']) . "',
                '" . mysql_real_escape_string($_POST['fax']) . "',
                '" . mysql_real_escape_string($_POST['phone']) . "',
                '$createdate',
                '" . mysql_real_escape_string($_POST['username']) . "',
                '" . mysql_real_escape_string($_POST['password']) . "',
                '$affiliate_id',
                '" . mysql_real_escape_string($_POST['reseller_id']) . "',
                '" . mysql_real_escape_string($_POST['commission']) . "',
                '" . mysql_real_escape_string($_POST['tier2comm']) . "',
                '" . mysql_real_escape_string($_POST['tier3comm']) . "',
                '$tier2aff',
                '$tier3aff'
				)";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());



     $query = "SELECT id, name, subject, message, type, activated, description FROM systememails WHERE name='Broker_Welcome'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailid           = $row[0];
              $emailname   = $row[1];
              $subject   = $row[2];
              $message   = $row[3];
              $type = $row[4];
              $activated = $row[5];              
              $description = $row[6];    
}
 if($activated =="Yes"){

$poweredbymessage = "<BR><BR><p align=right><a href=\"http://www.creditrepairtracking.com\"><img border=0 src=http://www.creditrepairtracking.com/trackstarlogoforemail.png></a></p>";

 $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload, privatelabel FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 
        $privatelabel = $row[14]; 
    }
    $query = "SELECT lastname, firstname, address, city, prov, zipcode, email, fax, telephone, dealership, username, password, comments, dealer_id, affiliate_id FROM dealers WHERE username='" . mysql_real_escape_string($_POST['username']) . "'"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lastname = $row[0];
        $firstname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $prov = $row[4];
        $zipcode = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $telephone = $row[8];
        $dealership = $row[9];
        $username = $row[10];
        $password = $row[11];
	    $comments = $row[12];
		$dealer_id = $row[13];			
		$affiliate_id = $row[14];			

    }
    include_once("companystrip.php");
    include_once("brokerstrip.php");

$EMAIL_Message = "$companyskin$message2";
if($privatelabel== "No"){
$EMAIL_Message .= $poweredbymessage;
}
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From>\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
}



        header("Location: brokersearch.php?message=Broker Record Created!");
        exit();
    }
?>