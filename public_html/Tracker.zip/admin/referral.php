<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$ip=$_SERVER["REMOTE_ADDR"];

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    
include("connection.php");
include "700score_connection2.php"; 
            	
            	 

if($_POST['referral'] == "yes"){

$salesconn  = mysql_connect("localhost", "seth_htdipss", "!@#$4321qaz");
mysql_select_db("seth_mastercnt", $salesconn) or die ("could not connect");


$_POST = str_replace("'", "`", $_POST);
$_POST = str_replace('"', '�', $_POST);
extract($_POST);



$sql2 = "INSERT INTO `settlement_contacts`
(`affiliate_id`,`fname`,`lname`,`company`,`phone`,`email`,`address2`,`category`,`julian`,`tstamp`,`ip`,`user`,`import_from`,`referrer`)

 VALUES
(\"$affiliate_id\",
\"$fname\",
\"$lname\",
\"$company\",
\"$phone\",
\"$email\",
\"$address2\",
\"Prospect\",
\"$julian\",
\"$tstamp\",
\"$ip\",
\"$user\",
\"Existing Account\",
\"$affiliate_id\")";
$result2 = @mysql_query($sql2,$salesconn) or die ("could not add");

	  $id = mysql_insert_id($salesconn);


if ($note) {

$sql_note = "INSERT INTO `settlement_notes`

(id,contact_id,rep_id,note,user,ip,julian,tstamp)
               VALUES
(\"\",
\"$id\",
\"$rep_id\",
\"$note\",
\"System\",
\"$ip\",
\"$julian\",
\"$tstamp\")";

$result_note = @mysql_query($sql_note,$salesconn);

}

    header("Location: referral.php?message=Lead Added");

}


include('template.php');
include('main.php');

   $query = "SELECT dealer_id  FROM dealers WHERE dbname='$dbname' limit 1";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dealer_id = $row[0];
  
        }

$query = "SELECT helpdeskaccess, contract FROM dealers WHERE dealer_id='$dealer_id'";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $helpdeskaccess = $row[0];
        $contract = $row[1];
        }

if($contract != "licensee" && $_SESSION['usname']=="admin"){


if($reseller == "Yes"){      
$resellerlabel = "CSO$dealer_id";
}else{
$resellerlabel = "Tracker$dealer_id";
}
?><BR>
<table style="width: 100%;background-color: #FFFFFF;padding-left: 10px;padding-right: 10px;padding-top: 5px;padding-bottom: 5px;" >
				<tr>
								<td>
								
												<font style=" font: normal 14px/20px 'Helvetica Neue', Helvetica, Arial, sans-serif;">
												<span class="style1">Welcome to the DisputeAgent/TrackStar referral program</span>.  
												<br />
												<br />
												The concept is very easy.  You convince another credit repair company to use our systems and you get 
												your choice of:<br />
<ul><li>If DisputeAgent - waiving your next system fee, $400 worth of free processing, or a free Add On Module.</li>
<li>If TrackStar - waiving your next system fee or a free optional upgrade.</li>
								</ul>
<hr>																<p>Here are the 
																qualifications:</p>
<ul><li>We cannot already be actively working on this company or individual.&nbsp; If this was a lead that we have not been working on and it is in our system, then you will get credit for it.</li>
<BR><BR>
<li>They must know that we are calling and <u>they must know who you are</u>.&nbsp; You cannot simply provide us with a name, number and email and that&#39;s it.&nbsp; You must convince these people to look at our systems.</li>
</ul>

<p>This program only works if you put a bunch of effort into it.&nbsp; We already have a handful of Disputeagent and TrackStar users that are referring companies right now and are very successful.&nbsp; If you are happy with the service we provide, <u>then your recommendation will go a long way</u>.&nbsp; In our opinion, our system is the best and it is a no brainer for other companies to use us.&nbsp; However, some other companies think the system they are using is the best, simply because they do not know any better.&nbsp;</p>

<p>Our system is hands down, the best option available and that is from a feature by feature mathematical equation.&nbsp; This is not a biased statement; the companies that use us are the most profitable in the industry!  We hope that you agree and will share your excitement and knowledge of our system with others.&nbsp; We can continue to help each other grow with this unique DisputeAgent/TrackStar affiliate program.&nbsp; It&#39;s fun!</p>										

<p>For your convenience, we have a lead capture page below.&nbsp; Once submitted, this goes direct to our system under your name.&nbsp; If this is a clean lead, the information will stay and if we close it, with your help, you can choose from the options above.</p>



<FORM ACTION="" METHOD="POST" NAME="formname"> 
<input type="hidden" name="affiliate_id" value="<? print $resellerlabel; ?>">
<input type="hidden" name="referral" value="yes">
<table align="center" border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="30%" id="AutoNumber1">
   <tr>
     <td width="50%">*Company</td>
     <td width="50%"><input type="text" name="company" size="27"></td>
   </tr>

   <tr>
     <td width="50%">*First Name:</td>
     <td width="50%"><input type="text" name="fname" size="27"></b></font></td>
   </tr>

   <tr>
     <td width="50%">*Last Name:</td>
     <td width="50%"><input type="text" name="lname" size="27"></b></font></td>
   </tr>
   
   <tr>
     <td width="50%">*Email:</td>
     <td width="50%"><input type="text" name="email" size="27"></b></font></td>
   </tr>
   
   <tr>
     <td width="50%">*Phone:</td>
     <td width="50%"><input type="text" name="phone" size="27"></b></font></td>
   </tr>
  
    <tr>
     <td width="50%">*Credit Repair Website:</td>
     <td width="50%"><input type="text" name="address2" size="27"></b></font></td>
   </tr>
 
      <tr>
     <td width="100%" colspan="2"><center>Notes<BR><textarea name="note" cols=40 rows=8></textarea></td>
	 </tr>

   <tr>
     <td width="100%" colspan="2"><BR><p align="center"><input name="Submit" type="submit" value="Submit"><BR><BR></td>
	 </tr>
</table>
</form>



								</td>
				</tr>
</table>








<?php
}

}
else
{
    header("Location: login.php");
    exit();
}

?>

