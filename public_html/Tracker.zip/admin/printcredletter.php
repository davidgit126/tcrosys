<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();

	


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   
    ?>
   
  <?php
  if($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing")
    {
    
    
    
include('template2.php');
 include("connection.php");
   

      $query = "SELECT id, lettername, abovedisputes, belowdisputes, showdisputes, showproof, disputecolumn FROM credletters WHERE id='$letterid'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $letterid           = $row[0];
              $lettername   = $row[1];
              $abovedisputes   = $row[2];
              $belowdisputes   = $row[3];
              $showdisputes = $row[4];
              $showproof = $row[5];  
              $disputecolumn = $row[6];  
 
            
}

    $query = "SELECT id, type, address, citystatezip FROM creditortype WHERE id='$creditorid'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $credid           = $row[0];
              $credname   = $row[1];
              $credaddress   = $row[2];
              $citystatezip   = $row[3];

}



    $query3 = "SELECT name, address, city, state, zip, email, fax, phone, ssnum, DATE_FORMAT(birthdate, \"%m-%d-%Y\") as bdate, country, username, password, broker_id, dealer_id, affiliate_id, avssnurl, fonttype, status, sendtohtdi FROM clients WHERE id='" . $_SESSION['clientid'] . "' ";
    $result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
    while($row3=mysql_fetch_row($result3))
    {
        $name = $row3[0];
        $address = $row3[1];
        $city = $row3[2];
        $state = $row3[3];
        $zip = $row3[4];
        $email = $row3[5];
        $fax = $row3[6];
        $phone = $row3[7];
        $ssn = $row3[8];
        $dob = $row3[9];
        $country = $row3[10];
        $username = $row3[11];
        $password = $row3[12];
        $broker_id = $row3[13];
	  $dealer_id = $row3[14];
	  $affiliate_id = $row3[15];
	  $avssnurl = $row3[16];	  
	  $fonttype = $row3[17];	  	  
	  $status = $row3[18];	  	  
	  $sendtohtdi= $row3[19];	  	  
    }

  if(($_SESSION['usaccess']=="full" or $_SESSION['usaccess']=="processing") AND $status != "inactive" AND $status != "archived" AND $status != "canceled" AND $status != "complete" AND $sendtohtdi != "Yes")
    {

                 include_once("credstrip.php");
    include_once("clientletterstrip.php");
    $todaysdate =  date("F d, Y");
$abovedisputes2 = str_replace("{TODAYDATE}", "$todaysdate", $abovedisputes2);
        ?>
   <style>
<!--
P.breakhere {page-break-before: always}
-->
</style>

  

    
 <font size="2" face = "<?php print($fonttype); ?>">  
<? echo $abovedisputes2; ?><BR>
 <?   if($showdisputes=="Yes"){ ?>


              
<?php
			  $i = 0;
              $query2 = "SELECT id, name, number, beginstatus, s1action, s1result, s2action, s2result, s3action, s3result, s4action, s4result, comments, dispute, $disputecolumn  FROM accounts WHERE clientid='" . mysql_real_escape_string($_SESSION['clientid']) . "' and accounttype='$bureauid' and deleted='open'";
              $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
              while($row2=mysql_fetch_row($result2))
              {
                   $accid = $row2[0];
                   $acname = $row2[1];
                   $acnumber = $row2[2];
                   $beginstatus = $row2[3];
                   $s1action = $row2[4];
                   $s1result = $row2[5];
                   $s2action = $row2[6];
                   $s2result = $row2[7];
                   $s3action = $row2[8];
                   $s3result = $row2[9];
                   $s4action = $row2[10];
                   $s4result = $row2[11];
                   $comments = $row2[12];
                   $dispute = $row2[13];
                   $s1dispute = $row2[14];
                   $i = $i+1;
?>

    <BR>
<font size="2" face = "<?php print($fonttype); ?>"><?php print($i); ?>.&nbsp;
<?php print($acname); ?>,&nbsp;<?php print($acnumber); ?>,&nbsp;<?php print($s1dispute); ?></font>
<?php
    }
?>
              
             
<BR><BR><BR>

 <?  }?>
<? echo $belowdisputes2; ?>

 <?   if($showproof=="Yes"){ ?>

<P CLASS="breakhere">
<CENTER><IMG SRC="<?php print($avssnurl); ?>">








 <?  }}?>


<?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>