<?php
extract ($_GET );
extract ($_POST );
    include_once('common.inc.php');
    session_start();

    include("connection.php");
    $query = "SELECT id, name FROM clients WHERE username='" . mysql_real_escape_string($_POST['susername']) . "'"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
   // print($col_count);
   $reccount=0;
    while($row=mysql_fetch_row($result))
    {
         $reccount++;
    } 

    if($reccount>0)
    {

        print("<html><body>");
        print("The username <b>$username</b> already exist. Please choose another name. <br> Click on Back button of your browser");
    }  
    else
    {

       
$createdate = date("Y-m-d");
        $query = "INSERT INTO sales_affiliates(fname, lname, company, address, city, state, zip, email, fax, phone, ssn, user, password, country, type, commission_rate)
                VALUES(
                '" . mysql_real_escape_string($_POST['fname']) . "', 
                '" . mysql_real_escape_string($_POST['lname']) . "', 
                '" . mysql_real_escape_string($_POST['company']) . "', 
                '" . mysql_real_escape_string($_POST['saddress']) . "', 
                '" . mysql_real_escape_string($_POST['city']) . "', 
                '" . mysql_real_escape_string($_POST['state']) . "',
                '" . mysql_real_escape_string($_POST['szip']) . "',
                '" . mysql_real_escape_string($_POST['semail']) . "',
                '" . mysql_real_escape_string($_POST['fax']) . "',
                '" . mysql_real_escape_string($_POST['phone']) . "',
                '" . mysql_real_escape_string($_POST['ssnum']) . "',
                '" . mysql_real_escape_string($_POST['susername']) . "',
                '" . mysql_real_escape_string($_POST['spassword']) . "', 
                '" . mysql_real_escape_string($_POST['country']) . "',
                'Affiliate',
                '" . mysql_real_escape_string($_POST['commission_rate']) . "')";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

       
         $query = "SELECT id, name, subject, message, type, activated, description FROM systememails WHERE name='Affiliate_Welcome'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailid           = $row[0];
              $emailname   = $row[1];
              $subject   = $row[2];
              $message   = $row[3];
              $type = $row[4];
              $activated = $row[5];              
              $description = $row[6];    
}
 if($activated =="Yes"){
$poweredbymessage = "<BR><BR><p align=right><a href=\"http://www.creditrepairtracking.com\"><img border=0 src=http://www.creditrepairtracking.com/trackstarlogoforemail.png></a></p>";

 $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload, privatelabel FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 
        $privatelabel = $row[14]; 

    }
    $query = "SELECT lname, fname, address, city, state, zip, email, fax, phone, ssn, user, password, comments, alt_phone, commission_rate, id FROM sales_affiliates WHERE user='" . mysql_real_escape_string($_POST['susername']) . "'"; 
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $lname = $row[0];
        $fname = $row[1];
        $address = $row[2];
        $city = $row[3];
        $state = $row[4];
        $zip = $row[5];
        $email = $row[6];
        $fax = $row[7];
        $phone = $row[8];
        $ssn = $row[9];
        $user = $row[10];
        $password = $row[11];
	    $comments = $row[12];
	    $altphone = $row[13];	  	   	  
		$commission_rate = $row[14];	 
		$affiliate_id = $row[15];			

    }
    include_once("companystrip.php");
    include_once("affiliatestrip.php");

$EMAIL_Message = "$message2";
if($privatelabel== "No"){
$EMAIL_Message .= $poweredbymessage;
}
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From>\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
}

       

        mysql_close($conn);

        header("Location: affiliatesearch.php?cname=&zip=&email=&f=1&Find=Find&message=Affiliate Created!");
        exit();
    }
?>