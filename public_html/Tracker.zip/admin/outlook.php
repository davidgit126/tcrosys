<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1){

include("connection.php");


$query = "SELECT timezone FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $timezone= $row[0];
    }
$calsql2 = "SELECT * FROM calendar where cal_id='$cal_id'";
		$calresult2 = @mysql_query($calsql2,$conn) or die("Couldn't execute");
		$number_appts = @mysql_num_rows($calresult2);
  while ($calrow2 = mysql_fetch_array($calresult2)) {	
		    $cal_id2 = $calrow2['cal_id'];
		    $cal_contactid2 = $calrow2['cal_contactid'];
		    $cal_create_by2 = $calrow2['cal_create_by'];
		    $linktolead = $calrow2['cal_link'];
		    $cal_name2 = $calrow2['cal_name'];
		    $cal_date2 = $calrow2['cal_date'];
		    $cal_time2 = $calrow2['cal_time'];
		    $active2 = $calrow2['cal_mod_time'];
		    $cal_description2 = $calrow2['cal_description'];
		    
$cal_year2 = substr("$cal_date2", 0, 4);
$cal_month2 = substr("$cal_date2", 4, 2);
$cal_day2 = substr("$cal_date2", 6, 2);
$caldateformat2 = "$cal_year2-$cal_month2-$cal_day2";	

if (strlen($cal_time2) == 5){
$cal_time2 = "0$cal_time2";
}
$cal_hour = substr("$cal_time2", 0, 2);
$cal_minute = substr("$cal_time2", 2, 2);
$cal_second = substr("$cal_time2", 4, 2);
$caltimeformat2 = "$cal_hour:$cal_minute:$cal_second";	
}
$linktolead = str_replace("=", "=3D", $linktolead);

//include("timezonecoding.php");

///ADJUST FOR GREENWICH
$notedate = date("Ymd",strtotime("$caldateformat2 $caltimeformat2 + 7 hour $timezoneoffset"));
$notetime = date("His",strtotime("$caldateformat2 $caltimeformat2 + 7 hour $timezoneoffset"));

//$notedate = date("Ymd",strtotime("$caldateformat2 $caltimeformat2 + 7 hour +1 hour"));
//$notetime = date("His",strtotime("$caldateformat2 $caltimeformat2 + 7 hour +1 hour"));


header("Content-Type: text/x-vCalendar");
header("Content-Disposition: inline; filename=MyvCalFile.vcs");
?>
BEGIN:VCALENDAR
VERSION:1.0
BEGIN:VEVENT
SUMMARY:<? echo "$cal_name2"; ?> 
DESCRIPTION;ENCODING=QUOTED-PRINTABLE:<? echo "$cal_description2"; ?>=0D=0A=
<? echo "$linktolead"; ?> 
DTSTART:<? echo "$notedate"; ?>T<? echo "$notetime"; ?>Z
DTEND:<? echo "$notedate"; ?>T<? echo "$notetime"; ?>Z
END:VEVENT
END:VCALENDAR
<?php
exit();

}
else
{
    header("Location: login.php");
    exit();
}

?>

