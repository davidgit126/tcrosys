<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   include('template.php');
 include("connection.php");

?>


 

            <font size=2 color=blue>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="90%" id="AutoNumber1">
  <tr>
    <td>
    
    
    
    
    
    <b>Edit Creditor</b>
     <?php

$SA_sql = "SELECT * FROM creditortype where id = '$creditorid'";
		$SA_result = @mysql_query($SA_sql,$conn);
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $creditorid = $srow['id'];
		    $creditorname = $srow['type'];
		    $creditoraddress= $srow['address'];
		    $citystatezip= $srow['citystatezip'];
		    
		    }
		     		    
		     if($creditorid != '')
    {
        ?>
        <form action="editcreditorsuccess.php" method="post">
<input class="txtbox" name="creditorname" type="text" size="50" value ="<?php print($creditorname); ?>"><BR>
<input class="txtbox" name="creditoraddress" type="text" size="50" value ="<?php print($creditoraddress); ?>"><BR>
<input class="txtbox" name="citystatezip" type="text" size="50" value ="<?php print($citystatezip); ?>"><BR>
<input class="txtbox" name="creditorid" type="hidden" value ="<?php print($creditorid); ?>" >
	<input type="submit" name="Update" value="Update">	  
        <?php
  }
        ?>

    
</p>
</td>
  </tr>
  </table>
     
      







 </font>

            







 </font>

            







 <?php
}
else
{
    header("Location: login.php");
    exit();
}

?>