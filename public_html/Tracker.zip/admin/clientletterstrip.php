<?php

extract ($_GET );
extract ($_POST );
 
$abovedisputes2 = str_replace("{NAME}", "$name", $abovedisputes2);
$belowdisputes2 = str_replace("{NAME}", "$name", $belowdisputes2);
$abovedisputes2 = str_replace("{ADDRESS}", "$address", $abovedisputes2);
$belowdisputes2 = str_replace("{ADDRESS}", "$address", $belowdisputes2);
$abovedisputes2 = str_replace("{CITY}", "$city", $abovedisputes2);
$belowdisputes2 = str_replace("{CITY}", "$city", $belowdisputes2);
$abovedisputes2 = str_replace("{STATE}", "$state", $abovedisputes2);
$belowdisputes2 = str_replace("{STATE}", "$state", $belowdisputes2);
$abovedisputes2 = str_replace("{ZIP}", "$zip", $abovedisputes2);
$belowdisputes2 = str_replace("{ZIP}", "$zip", $belowdisputes2);
$abovedisputes2 = str_replace("{PHONE}", "$phone", $abovedisputes2);
$belowdisputes2 = str_replace("{PHONE}", "$phone", $belowdisputes2);
$abovedisputes2 = str_replace("{FAX}", "$fax", $abovedisputes2);
$belowdisputes2 = str_replace("{FAX}", "$fax", $belowdisputes2);
$abovedisputes2 = str_replace("{EMAIL}", "$email", $abovedisputes2);
$belowdisputes2 = str_replace("{EMAIL}", "$email", $belowdisputes2);
$abovedisputes2 = str_replace("{USERNAME}", "$username", $abovedisputes2);
$belowdisputes2 = str_replace("{USERNAME}", "$username", $belowdisputes2);
$abovedisputes2 = str_replace("{PASSWORD}", "$password", $abovedisputes2);
$belowdisputes2 = str_replace("{PASSWORD}", "$password", $belowdisputes2);
$abovedisputes2 = str_replace("{STATUS}", "$showstatus", $abovedisputes2);
$belowdisputes2 = str_replace("{STATUS}", "$showstatus", $belowdisputes2);
$abovedisputes2 = str_replace("{NUMLOGINS}", "$logins", $abovedisputes2);
$belowdisputes2 = str_replace("{NUMLOGINS}", "$logins", $belowdisputes2);
$abovedisputes2 = str_replace("{LASTLOGIN}", "$lastlogin", $abovedisputes2);
$belowdisputes2 = str_replace("{LASTLOGIN}", "$lastlogin", $belowdisputes2);
$abovedisputes2 = str_replace("{SSN}", "$ssn", $abovedisputes2);
$belowdisputes2 = str_replace("{SSN}", "$ssn", $belowdisputes2);
$abovedisputes2 = str_replace("{DOB}", "$dob", $abovedisputes2);
$belowdisputes2 = str_replace("{DOB}", "$dob", $belowdisputes2);

$firstname = explode(' ', $name); 
if ($firstname[2] != ""){
$lastname = $firstname[2];
}else{
$lastname = $firstname[1];
}
$firstname = $firstname[0];


$abovedisputes2 = str_replace("{FNAME}", "$firstname", $abovedisputes2);
$belowdisputes2 = str_replace("{FNAME}", "$firstname", $belowdisputes2);
$abovedisputes2 = str_replace("{LNAME}", "$lastname", $abovedisputes2);
$belowdisputes2 = str_replace("{LNAME}", "$lastname", $belowdisputes2);


?>