<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   
    ?>
   
<?php
if($_SESSION['usname']=="admin"){
include("connection.php");

if($addsales =="yes"){
$query = "INSERT INTO systememails(name, type)
VALUES('" . mysql_real_escape_string($_POST['emailname']) . "', '" . mysql_real_escape_string($_POST['emailtype']) . "')";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
$emailid = mysql_insert_id($conn);
echo "<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=systememail.php?emailid=$emailid\">"; 
      exit();
}




include('template.php');
        
      $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 

    }

     $query = "SELECT id, name, subject, message, type, activated, description FROM systememails WHERE id='$emailid'";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $emailid           = $row[0];
              $emailname   = $row[1];
              $subject   = $row[2];
              $message   = $row[3];
              $type = $row[4];
              $activated = $row[5];              
              $description = $row[6];                
}

        ?>

<title><? echo $emailname; ?> Email</title>
    
      <?php
    include('main.php');
    include('rolloverhelp.php');
	?>     

  <body onload="Tooltip.init()">

 <?php
    if($emailid == "")
    {
 ?>
<form method="POST" action="">

<p align="center"><b>Add New Preformatted Email</b> <BR>
Short Name:
<input class="txtbox" type=text name=emailname size=24> <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Short Name</B><BR>Enter the short name of the email.  For example, if your email was for a Left Message, then call it <B>LM</B>')" 
    onmouseout="hideTip()" width="19" height="19">
<BR>
Type: <select name="emailtype" class="txtbox"  >
                
                <option value="sales">sales</option>
                <option value="broker">broker</option>
                                
              </select>


<input type="hidden" name="addsales" value="yes">
<BR><input type="submit" value="Add"></p>
</form>

<?php
   }else{
     ?>
     
     
<form method="POST" action="update_system_email.php">
<input type="hidden" name="emailtype" value="<?php print($type); ?>">
<input type="hidden" name="emailid" value="<?php print($emailid); ?>">


<div align="center">
  <center>
<font color="#FF0000"><b><?php print($success); ?></b></font>


<table width="70%"><tr><td width="95%" align=center valign="top">


<table border=1 width="919" cellspacing="1" cellpadding="6">





<b>Description:</b> <? echo $description; ?>


<tr>
  <td BGCOLOR="#CCCCCC" align="right" width="102">
<b><font face="Verdana" size="2">Activated?</font></b> </td>
  <td BGCOLOR="#CCCCCC" width="103"> 
                                        <select name="activated" class="txtbox"  >
                <option value="<?php print($activated); ?>" selected><?php print($activated); ?></option>
                 <option value="Yes">Yes</option>
 <option value="No">No</option>

              </select>
</TD>
  <td BGCOLOR="#CCCCCC" width="49"> 
                                        <b><font face="Verdana" size="2">Name</font></b></TD>
  <td BGCOLOR="#CCCCCC" width="602"> 
<input class="txtbox" type=text name=emailname size=24 value="<? echo $emailname; ?>"></TD>
</tr>


<tr><td BGCOLOR="#CCCCCC" align="right" width="102">
<b><font face="Verdana" size=2>Subject:</font></b> </td>
  <td BGCOLOR="#CCCCCC" colspan="3" width="784"> 
<input class="txtbox" type=text name=subject size=88 value="<? echo $subject; ?>">
</TD></TR>
<tr><td colspan="4" BGCOLOR="#CCCCCC" align="center" width="901">
<textarea class="txtbox" rows="15" name="message"  id="message" cols="110"><? echo "$message" ?></textarea>
 <script language=JavaScript src='../include/gui/scripts/innovaeditor.js'></script>
   <script language=JavaScript src='http://www.tcrosystems.net/scripts/<? echo "$type" ?>welcome.js'></script>



</TD></TR>
</table><br>
<input type="submit" value="Update <? echo $emailname; ?> Email">



</td></table>
</center>
</div>


</center>


  
</form>



<?php
 }
     ?>



<?php

}}
else
{
    header("Location: login.php");
    exit();
}

?>