<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   include("connection.php");
   $i =1;

   $filename = "account_ " . str_replace(' ','-',$_SESSION['clname']) . '_' . date("Y-m-d");
   $ext = 'csv';

   header("Content-type: text/plain");
   header('Content-Disposition: attachment; filename="' . $filename . '.' . $ext . '"');
   header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
   header('Pragma: no-cache');
   header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
   header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1

  $query2 = "Select id, type From accounttype";
  $result2 = mysql_query($query2, $conn) or die("Error:" . mysql_error());
  while($row2=mysql_fetch_row($result2))
  {
       echo("$row2[1]\r\n");

       $query = "SELECT id, name, number, accounttype  FROM accounts WHERE
                clientid='" . $_SESSION['clientid'] . "' and accounttype='$row2[0]' ORDER BY ID";
       $result = mysql_query($query, $conn) or die("error:" . mysql_error());
       $col_count = mysql_num_fields($result);
       while($row=mysql_fetch_row($result))
       {
           $id = $row[0];
           $name = $row[1];
           $number = $row[2];
           $acctype = $row[3];

           //fwrite($fp,"$i. $row[1], $row[2] \r\n");  // --- with numbers
           echo(" $row[1], $row[2]\r\n"); //--- without numbers
           $i = $i+1;
          // print("$row[0], $row[1], $row[2]");
          // print("\n");
      }
  }
}
else
{
    header("Location: login.php");
    exit();
}

?>
