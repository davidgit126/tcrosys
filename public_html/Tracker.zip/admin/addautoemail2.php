<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
   
    ?>
   
  <?php
    if($_SESSION['usname']=="admin")
    {
    
    
    include('template.php');
     include("connection.php");
      $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload, autoresponder FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 
        $autoresponder = $row[14]; 

    }

   

        ?>
  
    <?php
    include('main.php');
   ?>    
   
<form method="POST" action="addautoemailsuccess.php">
          <input type="hidden" name="type" value="<?php print($type); ?>">
                  



<div align="center">
  <center>



<table width="70%"><tr><td width="95%" align=center valign="top">


<table border=1 width="600" cellspacing="1" cellpadding="6">


<tr>
  <td BGCOLOR="#CCCCCC" align="right">
<b><font face="Verdana" size="2">Days to send</font></b> </td><td BGCOLOR="#CCCCCC"> 
                                        <input class="txtbox" type=text name=days size=6 value="">
</TD>
</tr>


<tr><td BGCOLOR="#CCCCCC" align="right">
<b><font face="Verdana" size=2>Subject:</font></b> </td><td BGCOLOR="#CCCCCC"> 
<input class="txtbox" type=text name=subject size=88 value="">
</TD></TR>

<tr><td colspan="2" BGCOLOR="#CCCCCC" align="center">
<textarea class="txtbox" rows="15" name="message" cols="110"></textarea>
  <script language=JavaScript src='../include/gui/scripts/innovaeditor.js'></script>
   <script language=JavaScript src='http://www.tcrosystems.net/scripts/editautoresponder.js'></script>

</TD></TR>

</table>
<br>
<input type="submit" value="Add to <? echo $type; ?> autoresponder">


</td></tr></table>
</center>
</div>


</center>


  
</form>



  
<?php
}}
else
{
    header("Location: login.php");
    exit();
}

?>