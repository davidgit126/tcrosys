<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
          include("connection.php");

    if($_POST['updatecl'] == 1)
      {

          $query = "INSERT INTO users(username, password,fname,lname,title,email,extension,access,affiliate,brokers,modletters,modemails,modleads)
                    VALUES(
                    '" . mysql_real_escape_string($_POST['newusername']) . "',
                    '" . mysql_real_escape_string($_POST['newpassword']) . "',
                    '" . mysql_real_escape_string($_POST['newfname']) . "',
                    '" . mysql_real_escape_string($_POST['newlname']) . "',
                    '" . mysql_real_escape_string($_POST['title']) . "',
                    '" . mysql_real_escape_string($_POST['email']) . "',
                    '" . mysql_real_escape_string($_POST['newextension']) . "',
                    '" . mysql_real_escape_string($_POST['newaccess']) . "',                                        
                    '" . mysql_real_escape_string($_POST['affiliate']) . "',                        
                    '" . mysql_real_escape_string($_POST['brokers']) . "',                    
                    '" . mysql_real_escape_string($_POST['modletters']) . "',                    
                    '" . mysql_real_escape_string($_POST['modemails']) . "',                    
                    '" . mysql_real_escape_string($_POST['restrict']) . "'                    
                    )";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

      $newuserid = mysql_insert_id($conn);
          mysql_close($conn);

    header("Location: edituserb.php?uid=$newuserid");
	  }
	  
	  include('template.php');

include('main.php');
include('rolloverhelp.php');

   ?>     
<body onLoad="Tooltip.init()">


        <FORM  action="adduser.php" method="POST">
          <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="500">
<tr><td width="1"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Add User</td>
<td width="1"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="455">
       
        <tr> 
            <td> 
            <table border="0" cellspacing="4" cellpadding="2" bgcolor="#FFFFFF" style="border-collapse: collapse" bordercolor="#111111" width="500">
            <tr> 
                <td height="11"> 
                    <div align="right"><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>Username:</b></font></div>
                </td>
                <td class='ss-round-inputs' height="11"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newusername" type="text" id="newusername" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
            </tr>
            <tr>
                <td height="17"> 
                    <div align="right"><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>Password:</b></font></div>
                </td>
                <td class='ss-round-inputs' height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newpassword" type="password" id="newpassword" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
             </tr>
            <tr>
                <td height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      First Name</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newfname" type="text" id="newfname" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
             </tr>
            <tr>
                <td height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Last Name</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newlname" type="text" id="newlname" size="20"><img border="0" src="input-right.gif" width="7" >
                </td>
             </tr>
            <tr>
                <td height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Title</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="title" type="text" id="title" size="20"><img border="0" src="input-right.gif" width="7" >
<img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Title</B><BR>Enter the title of this employee if applicable.<font color=#0364C4 style=font-size:9px;><br><br>I.E. Glorified Janitor</font>')" 
    onmouseout="hideTip()" width="19" height="19">
                </td>
             </tr>
            <tr>
                <td height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Email</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td class='ss-round-inputs' height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="email" type="text" id="email" size="30"><img border="0" src="input-right.gif" width="7" >
<img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Email</B><BR>Please enter a valid email.  If this email field is blank, then this user will not be able to send any of the Preformatted Sales Emails that you have in the system.  Preformatted Sales Emails are created under Adminstration --> System Emails --> Sales Emails.  Once created, the sales user can click on them from any Prospect Record.<font color=#0364C4 style=font-size:9px;><br><br>I.E. user@domain.com.  We can setup emails for you free of charge.  Please contact your Account Executive if you need them.</font>')" 
    onmouseout="hideTip()" width="19" height="19">

                </td>
             </tr>

            <tr>
                <td height="17"> 
                    <div align="right"><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>
                      Extension:</b></font></div>
                </td>
                <td class='ss-round-inputs' height="17"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="newextension" type="text" id="newfname" size="20"><img border="0" src="input-right.gif" width="7" >
<img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Extension</B><BR>If this user has an extension that is dialed off of the main number to be reached, then enter it here.<font color=#0364C4 style=font-size:9px;><br><br>I.E. 7525</font>')" 
    onmouseout="hideTip()" width="19" height="19">

                </td>
             </tr>

            <tr>
                <td height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Access</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="336600"><b>:</b></font></div>
                </td>
                <td height="17"> 
                    <select name="newaccess" class="txtbox"  >
                <option value="full">full</option>
                <option value="processing">processing</option>
                <option value="support">support</option>
                <option value="sales">sales</option>                
                <option value="WebCMS">WebCMS</option>                
                
                
                                
              </select>
                </td>
             </tr>
            <tr>
                <td height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Manage Affiliate<br>
                      Program</font></b></div>
                </td>
                <td height="17"> 
                    <select name="affiliate" class="txtbox"  >

                <option value="No">No</option>
                <option value="Yes">Yes</option>                
                
                                
              </select>
			  			  <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Manage Affiliate Program</B><BR>If this is set to Yes, then this user has complete and full access to the Affiliate section of the system.<font color=#0364C4 style=font-size:9px;><br><br>Not recommended for anyone other than the ADMIN username.</font>')" 
    onmouseout="hideTip()" width="19" height="19">

                </td>
             </tr>
            <tr>
                <td height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Manage
                      Broker Program</font></b></div>
                </td>
                <td height="17"> 
                    <select name="brokers" class="txtbox"  >

                <option value="No">No</option>
                <option value="Yes">Yes</option>                
                
                                
              </select>
			  			  <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Manage Broker Program</B><BR>If this is set to Yes, then this user has complete and full access to the Broker section of the system.<font color=#0364C4 style=font-size:9px;><br><br>Not recommended for anyone other than the ADMIN username.</font>')" 
    onmouseout="hideTip()" width="19" height="19">

                </td>
             </tr>

            <tr> 
                <td height="9"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Modify Leads<br></font></b></div>
                </td>
                <td height="9"> 
                    <select name="modemails" class="txtbox"  >

                <option value="No">No</option>
                <option value="Yes">Yes</option>                
                </select>
				
				<img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Modify Leads</B><BR>If this is set to Yes, then this user can modify the data contained in a Prospect Record.')" 
    onmouseout="hideTip()" width="19" height="19">
                </td>
             </tr>
             <tr>
                <td height="17"> 
                    <div align="right"><b>
                      <font face="Arial, Helvetica, sans-serif" size="2" color="#336600">
                      Restrict Lead View?</font></b></div>
                </td>
                <td height="17"> 
                    <select name="restrict" class="txtbox"  >

                <option value="No">No</option>
                <option value="Yes">Yes</option>                
                
                                
              </select>

                 <img border="0" src="questionmark.png"
    onmouseover="doTooltip(event,'<B>Lead Restriction</B><BR>If this is set to No or Blank, then this user can see all leads without restriction.  If set to Yes, then this user can only see leads with the affiliate username of <b><i><?php print($name); ?></i></b> tied to it.<font color=#0364C4 style=font-size:9px;><br><br>Good for locking down to self generated leads.</font>')" 
    onmouseout="hideTip()" width="19" height="19">
                </td>
             </tr>

            <tr> 
                <td height="8">&nbsp; 
                    </td>
                <td height="8">&nbsp; 
                    </td>
             </tr>
             <tr> 
                <td width="209">&nbsp;</td>
                <td width="226"> &nbsp;&nbsp; 
				 <input type="hidden" name="updatecl" value="1">
                <INPUT type=submit value="Add" name="submit">
                <INPUT type=reset value="Clear" name="reset">
                </td>
             </tr>
             </table>
          </td>
        </tr>
        </table>
        </FORM>
        <?php
    
}
else
{
    header("Location: login.php");
    exit();
}

?>