<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);


$nowday = date("d");
$nowmonthword = date("M");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    include("connection.php");
    include('template.php');
    include('main.php');

 if($_REQUEST['del']==1)
    {
        $query = "DELETE FROM users WHERE id='" . mysql_real_escape_string($_REQUEST['uid']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

        $query = "DELETE FROM roundrobin WHERE salesid='" . mysql_real_escape_string($_REQUEST['uid']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Delete Admin User',
                    '" . mysql_real_escape_string($_REQUEST['uid']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    }
    
   
?>
<BR>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="900">
<tr><td width="1%"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Manage Your Users</td>
<td width="1%"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>
 <table id="rounded-corner" width="900">

 <tr >
 <th class="rounded-company">Username</th>
 <th class="rounded-company">Last Name</th>
<th class="rounded-q1">First Name</th>
<th class="rounded-q2">Email Address</th>
<th class="rounded-q3">Earned</th>
<th class="rounded-q3">Paid</th>
<th class="rounded-q3">Due</th>
<th class="rounded-q3" align="center">Round Robin</th>
<th class="rounded-q3"></th>
<th class="rounded-q3"></th>
</tr>

   
<?php

    $query = "SELECT id, username, fname, email, lname FROM users ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
      $id = $row[0];
      $name = $row[1];
      $fname = $row[2];
      $email = $row[3];
      $lname = $row[4];

		$salesid = "";

	  $query2 = "SELECT salesid FROM roundrobin WHERE salesid='$id'";
$result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
 while($row2=mysql_fetch_row($result2))
    {
      $salesid = $row2[0];
    } 

		if($salesid ==""){
		$roundrobin = "No";
	}else{
		$roundrobin = "Yes";
	}


$bgcolor = "#e8edff";

$COM_total_comish = "";
$COM_total_pd = "";


$LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_sales WHERE rep_id = '$id' GROUP BY rep_id";
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}
?>
<tr bgcolor=<?php print($bgcolor); ?> onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
<td ><a href=edituserb.php?uid=<?php print($id); ?>><?php print($name); ?></a></td>
<td ><?php print($lname); ?></td>
<td > <?php print($fname); ?></td>
<td ><?php print($email); ?></td>
              <td >$<?php print($COM_total_comish); ?></td>
              <td >$<?php print($COM_total_pd); ?></td>
              <td >$<?php print($COM_total_comish - $COM_total_pd); ?></td>
<td  align="center"><?php print($roundrobin); ?></td>
<td ></td>

<td style="border-bottom-style: solid; border-bottom-width: 1; border-right-style:solid; border-right-width:1" ><a onclick="return confirm('Are you sure you want to delete <?php print($fname); ?>?');" href=edituser.php?del=1&uid=<?php print($id); ?>><img border="0" src="http://www.tcrosystems.net/deletebutton.png"></a></td>
</tr>      


 <?php
   } 
    print("</table>");
    
    mysql_close($conn);
    ?><?php
}
else
{
    header("Location: login.php");
    exit();
}


?>