<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
      include("connection.php");
include('template.php');

      

    if($salescheck == "yes"){

	  $query = "SELECT id, username, fname, access, affiliate, password, brokers, modletters, modemails, modleads, email, extension, lname, title FROM users WHERE id='$sales_id'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
 while($row=mysql_fetch_row($result))
    {
      $id = $row[0];
      $name = $row[1];
      $fname = $row[2];
      $access = $row[3];      
      $affiliate = $row[4];      
      $password = $row[5];      
      $brokers = $row[6];       
      $modletters = $row[7];       
      $modemails = $row[8];       
      $restrict = $row[9];       
      $email = $row[10];       
      $extension = $row[11];       
      $lname = $row[12];       
      $title = $row[13];       
    }
	$recordname = "$fname $lname";
	}

	  if($brokercheck=='yes'){
	$recordname = $_SESSION['clname'];
	  }else if($affiliatecheck=='yes'){
	$recordname = $_SESSION['clname'];
	  }

    if($_POST['editcomms'] == "yes")
      {
 

  if($brokercheck=='yes'){
          $query = "UPDATE commission_brokers SET
                amount_paid='" . mysql_real_escape_string($_POST['earned']) . "'    
                WHERE id='" . mysql_real_escape_string($_POST['commission_id']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Broker Commission',
                    '" . mysql_real_escape_string($_SESSION['dealer_id']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());

}else if($affiliatecheck=='yes'){
          $query = "UPDATE commission_affiliate SET
                amount_paid='" . mysql_real_escape_string($_POST['earned']) . "'    
                WHERE id='" . mysql_real_escape_string($_POST['commission_id']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Affiliate Commission',
                    '" . mysql_real_escape_string($_SESSION['affiliateid']) . "',
                    '" . mysql_real_escape_string($_SESSION['clname']) . "',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}else if($salescheck=='yes'){
          $query = "UPDATE commission_sales SET
                amount_paid='" . mysql_real_escape_string($_POST['earned']) . "'    
                WHERE id='" . mysql_real_escape_string($_POST['commission_id']) . "'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Sales Commission',
                    '$sales_id',
                    '$recordname',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}
   }
 include('main.php');

?>
         <STYLE>       
.numbers{
	background-color: #FFFFFF;


	font-family: Verdana, sans-serif; 
	font-size: 10px;

	color: #000000;
	background-image:   url('formshadow.gif');
}
</STYLE> <font color="red">  <B> <?php print($error); ?></B></font>
                 
              <BR><BR>   
                     
                        <div align="center">
                          <center>
                         <b><font color="#FF0000" face="Verdana" size="2"><?php print($message); ?>
                          </font></b>
                         

                            
 <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="50%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Commission Table for <?php print($recordname); ?></td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>


 <table id="rounded-corner" width="50%">

<tr >
<th class="rounded-company">Earn Date</th>
 <th class="rounded-company">Name</th>
 <th class="rounded-company">Amount</th>
<th class="rounded-q3"></th></tr>



                                
                                <?php
if($affiliatecheck=='yes'){
$gowhere = "affiliatestatus.php";
      $updatedb = "commission_affiliate";

        $query = "SELECT DATE_FORMAT(clients.createdate, \"%m-%d-%Y\") as createdate, clients.name, commission_affiliate.amount_paid, commission_affiliate.id FROM clients,commission_affiliate WHERE clients.prospectclient = 'Client' AND clients.affiliate_id='" . $_SESSION['affiliateid'] . "' AND clients.id = commission_affiliate.contact_id ORDER BY clients.createdate DESC";
}else if($salescheck=='yes'){

	
$gowhere = "edituserb.php?uid=$sales_id";
      $updatedb = "commission_sales";

        $query = "SELECT DATE_FORMAT(clients.createdate, \"%m-%d-%Y\") as createdate, clients.name, commission_sales.amount_paid, commission_sales.id FROM clients,commission_sales WHERE clients.prospectclient = 'Client' AND clients.dealer_id='$sales_id' AND clients.id = commission_sales.contact_id ORDER BY clients.createdate DESC";
}
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $createdate= $row[0];
        $name = $row[1];
$amount_paid = $row[2];
$commission_id= $row[3];
$bgcolor = "#e8edff";

?>
                              <form  action=""    method="post" >
<tr  bgcolor=<?php print($bgcolor); ?> onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
                                
                                  <td width="12%"><?php print($createdate); ?></td>
                                  <td width="25%"><?php print($name); ?></td>

                                  <td class='ss-round-inputs' width="15%">$<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input class="numbers"  name="earned" value="<?php print($amount_paid); ?>" size="5"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
                              <td width="15%"> <input class="numbers"  type="submit" name="Update" value="Edit">
<input type="hidden"  name="commission_id" value="<?php print($commission_id); ?>" size="3">                              
<input type="hidden"  name="updatedb" value="<?php print($updatedb); ?>" size="3">                              
<input type="hidden"  name="editcomms" value="yes" size="2">                              
                              
                              </td>
 </tr>
 </form>
                              <?php
       }
      
       if($affiliatecheck=='yes'){
       $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_affiliate WHERE affiliate_id='" . $_SESSION['affiliateid'] . "' GROUP BY affiliate_id";
}else if($salescheck=='yes'){
       $LP_sql = "SELECT sum(amount_paid) as total_comish, sum(payment_amount) as total_pd FROM commission_sales WHERE rep_id='$sales_id' GROUP BY rep_id";
}
$LP_result = @mysql_query($LP_sql,$conn);
while ($lprow = mysql_fetch_array($LP_result)) {	
$COM_total_comish = $lprow['total_comish'];
$COM_total_pd = $lprow['total_pd'];

}

?>                

<tr  bgcolor=<?php print($bgcolor); ?>>
                                
                                  <td width="12%">&nbsp;</td>
                                  <td width="25%">&nbsp;</td>

                                  <td width="15%"><b>Total -
                                  <font color="#008000">$<?php print($COM_total_comish); ?></font></b></td>
                              
                                  <td>&nbsp;</td> </tr>
                  
                                </table>
                              </td>
                            </tr>
                            </table>

                          </center>
</div>
                        <p align="left">
                        <a href="<?php print($gowhere); ?>">Back</a>
                        &nbsp;
                        </p>
                        
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>