List of clients<BR><BR>

       <table border="1">

<?php


extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
    include("connection.php");    
$todaydate = date("Y-m-d");
$todaydate2 = date("m-d-Y");

function dateDiff($dformat, $endDate, $beginDate) 
{ 
$date_parts1=explode($dformat, $beginDate); 
$date_parts2=explode($dformat, $endDate); 
$start_date=gregoriantojd($date_parts1[0], $date_parts1[1], $date_parts1[2]); 
$end_date=gregoriantojd($date_parts2[0], $date_parts2[1], $date_parts2[2]); 
return $end_date - $start_date; 
} 

 $query2 = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, autoscheduler, autoresponder FROM companyinfo WHERE companyid='1'";
    $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result2);
    while($row2=mysql_fetch_row($result2))
    {
        $companyid = $row2[0];
        $companyname = $row2[1];
        $companycontact = $row2[2];
        $companyemail = $row2[3];
        $companyreply = $row2[4];
        $companyaddress = $row2[5];
        $companycity = $row2[6];
        $companystate = $row2[7];
        $companyzip = $row2[8];                        
        $companyphone = $row2[9];         
        $companyfax = $row2[10];         
        $companywebsite = $row2[11];              
        $companyskin = $row2[12]; 
        $autoscheduler = $row2[13]; 
        $autoresponder = $row2[14]; 


    }



 if($autoscheduler == "ON"){

$query = "SELECT name, email, broker_id, dealer_id, affiliate_id, reseller_id, plan, dateresults, showstatus FROM clients where status = 'active' AND dateresults = '$todaydate' and clientdelete != 'Yes'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $email = $row[1];
        $broker_id = $row[2];
	  $dealer_id = $row[3];
	  $affiliate_id = $row[4];
	  $reseller_id = $row[5];
	  $plan = $row[6];
	  $dateresults = $row[7];
	  $showstatus = $row[8];

        
                $HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $companyname <$companyreply>\r\n";

    $subject = "**URGENT** Your account is overdue";
                $message = "$name, <BR><BR>  Our records show that it has been more than 45 days and you have not sent in all the responses for your last round or has been scheduled for the next step.  Your account is now overdue.  Please contact our offices immediately at $companyphone to let us know if you have responses you have not sent in. <BR><BR>  Current status on your account is: <BR><BR>     -$showstatus. <BR><BR>  Thank you for your assistance <BR><BR>$companyname <BR>$companyphone <BR><a href=$companywebsite>$companywebsite</a>";
 		    $formsent = mail($email, $subject, $message, $HEADERS);  


                
    ?>

<tr>

<td><?php print($name); ?></td>
<td><?php print($email); ?></td>
              <td>Email Sent</td>
<td><?php print($todaydate); ?></td>

<td><?php print($dateresults); ?></td>

</tr>


<?php


}
} if($autoscheduler == "OFF"){
?>
<BR> AUTOSCHEDULER IS TURNED OFF<BR>
<?php


}if($autoresponder == "Yes"){

$query = "SELECT name, email, address, city, state, zip, phone, DATE_FORMAT(createdate, \"%m-%d-%Y\") as createdate FROM clients where prospectclient = 'prospect' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $email = $row[1];
        $address = $row[2];
	  $city = $row[3];
	  $state = $row[4];
	  $zip = $row[5];
	  $phone = $row[6];
	  $createdate = $row[7];

$sendday = dateDiff("-", $todaydate2, $createdate);
    $query2 = "SELECT id, subject, message, type, days FROM autoresponders WHERE days='$sendday'";
          $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row2=mysql_fetch_row($result2))
          {
              $autoid           = $row2[0];
              $subject   = $row2[1];
              $message   = $row2[2];
              $type = $row2[3];
              $days = $row2[4];              
}       
             include_once("companystrip.php");
   include_once("clientstrip.php");

$EMAIL_Message = "$message2";
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";
$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
     
    ?>

<tr>

<td><?php print($name); ?></td>
<td><?php print($email); ?></td>
              <td>Email Sent</td>
<td><?php print($createdate); ?></td>

<td><?php print($sendday); ?></td>

</tr>


<?php


}
} if($autoresponder == "No"){
?>
<BR> AUTORESPONDER IS TURNED OFF<BR>
<?php


}

    //mysql_close($conn);
?>
</table>
