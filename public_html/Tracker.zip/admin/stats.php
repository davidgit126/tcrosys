<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
include('template.php');

    ?>
    <title>Results Statistics</title>

    <a href="search.php?cname=&zip=&email=&f=1&Find=Find">Active Client Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="completedsearch.php?cname=&zip=&email=&f=1&Find=Find">Completed Client Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="canceledsearch.php?cname=&zip=&email=&f=1&Find=Find">Canceled Client Search</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="onetime/search.php?cname=&zip=&email=&f=1&Find=Find">One Time Search</a><br>
   
    


 
        <?php
         include("connection.php");


             $query = "SELECT count(id) as deleteditems1 FROM accounts WHERE (s1result LIKE 'FIXED%' or s1result LIKE 'LATES REMOVED%' or s1result LIKE 'DELETED%' or s1result LIKE 'NO LONGER REPORTING%' or s1result LIKE 'SHOWS POSITIVE%')";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $deleteditems1 = $row[0];
                           $cnt++;
              }
              
               $query = "SELECT count(id) as deleteditems2 FROM accounts WHERE (s2result LIKE 'FIXED%' or s2result LIKE 'LATES REMOVED%' or s2result LIKE 'DELETED%' or s2result LIKE 'NO LONGER REPORTING%' or s2result LIKE 'SHOWS POSITIVE%')";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $deleteditems2 = $row[0];
                           $cnt++;
              }

$query = "SELECT count(id) as deleteditems3 FROM accounts WHERE (s3result LIKE 'FIXED%' or s3result LIKE 'LATES REMOVED%' or s3result LIKE 'DELETED%' or s3result LIKE 'NO LONGER REPORTING%' or s3result LIKE 'SHOWS POSITIVE%')";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $deleteditems3 = $row[0];
                           $cnt++;
              }
$query = "SELECT count(id) as deleteditems4 FROM accounts WHERE (s4result LIKE 'FIXED%' or s4result LIKE 'LATES REMOVED%' or s4result LIKE 'DELETED%' or s4result LIKE 'NO LONGER REPORTING%' or s4result LIKE 'SHOWS POSITIVE%')";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $deleteditems4 = $row[0];
                           $cnt++;
              }

$query = "SELECT count(id) as deleteditems5 FROM accounts WHERE (s5result LIKE 'FIXED%' or s5result LIKE 'LATES REMOVED%' or s5result LIKE 'DELETED%' or s5result LIKE 'NO LONGER REPORTING%' or s5result LIKE 'SHOWS POSITIVE%')";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $deleteditems5 = $row[0];
                           $cnt++;
              }


              $query = "SELECT count(id) as totalresults1 FROM accounts WHERE (s1result != '')";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $totalresults1 = $row[0];
                           $cnt++;
              }

               $query = "SELECT count(id) as totalresults2 FROM accounts WHERE (s2result != '')";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $totalresults2 = $row[0];
                           $cnt++;
              }


                $query = "SELECT count(id) as totalresults3 FROM accounts WHERE (s3result != '')";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $totalresults3 = $row[0];
                           $cnt++;
              }
 $query = "SELECT count(id) as totalresults4 FROM accounts WHERE (s4result != '')";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $totalresults4 = $row[0];
                           $cnt++;
              }

 $query = "SELECT count(id) as totalresults5 FROM accounts WHERE (s5result != '')";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $totalresults5 = $row[0];
                           $cnt++;
              }
              
      
 $query = "SELECT count(id) as totalresults FROM accounts WHERE (deleted = 'Deleted' or deleted = 'Fixed') AND deleted != 'Hold'";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $totalresults = $row[0];
                           $cnt++;
              }
              
              $query = "SELECT count(id) as totalaccounts FROM accounts";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $totalaccounts = $row[0];
                           $cnt++;
              }         
              
              
     $equation1 = $deleteditems1 / $totalresults1 * 100;         
     $equation2 = $deleteditems2 / $totalresults2 * 100;         
     $equation3 = $deleteditems3 / $totalresults3 * 100;         
     $equation4 = $deleteditems4 / $totalresults4 * 100;         
     $equation5 = $deleteditems5 / $totalresults5 * 100;         
      
 $formattedequation1 = number_format($equation1, 2);        
  $formattedequation2 = number_format($equation2, 2);     
   $formattedequation3 = number_format($equation3, 2);     
    $formattedequation4 = number_format($equation4, 2);     
     $formattedequation5 = number_format($equation5, 2);     
              
              
              ?>
              <tr>
              
              </tr>
              
          </table>
          <p><b>Results on Accounts as of <? print date("m-d-Y"); ?> <BR>
          &nbsp;</b></p>

                                                             
<div align="center">
  <center>

                                                             
<table border="1" cellpadding="4" cellspacing="0" width="95%" id="AutoNumber1">
  <tr>
    <td width="606%" colspan="5">
    <p align="center"><b><font size="1" face="Lucida Sans" color="#0000FF">
    <br>
    </font><font size="6" face="Lucida Sans" color="#0000FF">
    Results Statistics<br>
&nbsp;</font></b></td>
  </tr>
  <tr>
    <td width="16%">&nbsp;</td>
    <td width="17%" align="center">
    <p align="center"><b><font size="5" face="Lucida Sans" color="#008000">Round 
    1</font></b></td>
    <td width="17%" align="center"><b>
    <p align="center"><font size="5" face="Lucida Sans" color="#008000">Round 2</font></b></td>
    <td width="17%" align="center"><b>
   <p align="center"> <font size="5" face="Lucida Sans" color="#008000">Round 3</font></b></td>
    <td width="17%" align="center"><b>
    <p align="center"><font size="5" face="Lucida Sans" color="#008000">Round 4</font></b></td>
  </tr>
  <tr>
    <td width="16%"><b>Number of Repairs</b></td>
    <td width="17%" align="center"><p align="center"><?php echo $deleteditems1; ?>&nbsp;</td>
    <td width="17%" align="center"><p align="center"><?php echo $deleteditems2; ?>&nbsp;</td>
    <td width="17%" align="center"><p align="center"><?php echo $deleteditems3; ?>&nbsp;</td>
    <td width="17%" align="center"><p align="center"><?php echo $deleteditems4; ?>&nbsp;</td>
  </tr>
  <tr>
    <td width="16%"><b>Number of Accounts</b></td>
    <td width="17%" align="center"><p align="center"><?php echo $totalresults1; ?>&nbsp;</td>
    <td width="17%" align="center"><p align="center"><?php echo $totalresults2; ?>&nbsp;</td>
    <td width="17%" align="center"><p align="center"><?php echo $totalresults3; ?>&nbsp;</td>
    <td width="17%" align="center"><p align="center"><?php echo $totalresults4; ?>&nbsp;</td>
  </tr>
  <tr>
    <td width="16%">&nbsp;</td>
    <td width="17%" align="center"><p align="center"><?php echo $formattedequation1; ?>%</td>
    <td width="17%" align="center"><p align="center"><?php echo $formattedequation2; ?>%</td>
    <td width="17%" align="center"><p align="center"><?php echo $formattedequation3; ?>%</td>
    <td width="17%" align="center"><p align="center"><?php echo $formattedequation4; ?>%</td>
  </tr>
  <tr>
    <td width="16%">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td width="16%">&nbsp;</td>
    <td width="17%" align="center">
    <p align="center"><b><font size="5" face="Lucida Sans" color="#008000">Round 
    5</font></b></td>
    <td width="17%" align="center"><b>
    <p align="center"><font size="5" face="Lucida Sans" color="#008000">Round 6</font></b></td>
    <td width="17%" align="center"><b>
   <p align="center"> <font size="5" face="Lucida Sans" color="#008000">Round 7</font></b></td>
    <td width="17%" align="center"><b>
    <p align="center"><font size="5" face="Lucida Sans" color="#008000">Round 8</font></b></td>
    </tr>
  <tr>
    <td width="16%"><b>Number of Repairs</b></td>
    <td width="17%" align="center"><p align="center"><?php echo $deleteditems5; ?>&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td width="16%"><b>Number of Accounts</b></td>
    <td width="17%" align="center"><p align="center"><?php echo $totalresults5; ?>&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td width="16%">&nbsp;</td>
    <td width="17%" align="center"><p align="center"><?php echo $formattedequation5; ?>%</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td width="16%">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td width="16%">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
    <td width="17%" align="center">&nbsp;</td>
  </tr>
</table>

                  
  </center>
</div>


                  
<?php
         
}
else
{
    header("Location: login.php");
    exit();
}

?>