<?php

extract ($_GET );
extract ($_POST );

$abovedisputes2=$abovedisputes;
$belowdisputes2=$belowdisputes;
$abovedisputes2 = str_replace("{CREDITOR}", "$credname", $abovedisputes2);
$belowdisputes2 = str_replace("{CREDITOR}", "$credname", $belowdisputes2);
$abovedisputes2 = str_replace("{CREDITORADDRESS}", "$credaddress", $abovedisputes2);
$belowdisputes2 = str_replace("{CREDITORADDRESS}", "$credaddress", $belowdisputes2);
$abovedisputes2 = str_replace("{CREDITORADDRESS2}", "$citystatezip", $abovedisputes2);
$belowdisputes2 = str_replace("{CREDITORADDRESS2}", "$citystatezip", $belowdisputes2);
$abovedisputes2 = str_replace("{ACCOUNTNUM}", "$tradenumber", $abovedisputes2);
$belowdisputes2 = str_replace("{ACCOUNTNUM}", "$tradenumber", $belowdisputes2);

?>