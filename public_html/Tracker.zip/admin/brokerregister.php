<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
include('template.php');
include("connection.php");
/* Connection to Affiliates People */

		$SA_sql = "SELECT * FROM sales_affiliates WHERE type='Affiliate' AND status !='del' ORDER BY lname";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $affiliateid = $srow['id'];
		    $fname = $srow['fname'];
		    $lname = $srow['lname'];


                if ($username == "$user") {
		$user_select6 .= "<option value=\"$affiliateid\">$lname, $fname</option>";
		}else{
		$user_select6 .= "<option value=\"$affiliateid\">$lname, $fname</option>";
		}

		$ARUSERS{"$affiliateid"} = "$affiliateid";
		
		}


/* Connection to Brokers */

		$SA_sql = "SELECT * FROM dealers WHERE status !=9 ORDER BY lastname limit 1000";
		$SA_result = @mysql_query($SA_sql,$conn);
		
		  while ($srow = mysql_fetch_array($SA_result)) {
		    $dealerid = $srow['dealer_id'];
		    $firstname = $srow['firstname'];
		    $lastname = $srow['lastname'];


		$user_select5 .= "<option value=\"$dealerid\">$lastname, $firstname</option>";
		}

?>
<script language="JavaScript" type="text/javascript">
var i=0;

 function isEmpty(inputStr)
 {
   if(inputStr == null || inputStr == "" || inputStr == " "){
    return true
   }
   return false
 }

 function Check()
  {
    var form = document.forms[0];
      if (isEmpty(form.firstname.value)) {
        alert("There is a problem with your form. Please enter your name.")
        form.name.focus()
        }
      else if (isEmpty(form.semail.value)) {
        alert("There is a problem with your form. Please enter your email address.")
        form.email.focus()
        }
      else
        form.submit()
  }
 
 function Phone(form)
  {
    
      if(i>=3) {
       i=0
       form.phone2.focus()
    }
      i++
  }
 
 function Phone2(form)
  {
    if(i>=3) {
      i=0
      form.phone3.focus()  
    }
    i++
  }

  function PhoneFocus(Object)
 {
   //if(i==0) {Object.select();}
   i=0
 }
</script>
 <title>Add Broker</title>
 <?php
    include('main.php');
   ?> 

<p>Please fill out the form:</p>
<form method=post action="brokersignup.php" name="form">
<table width="90%" border="0" cellspacing="0" cellpadding="1" align="center">
<tr>
<td bgcolor="ad0948">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td bgcolor="ffffff">
<table width="100%" border="0" cellspacing="5" cellpadding="0" bgcolor="ffffff">
                <tr>
                  <td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>First 
                    name</span></div></td>
                  <td class='ss-round-inputs' width="50%"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="firstname" size="25" maxlength="100" class="textbox"><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>
                <tr>
                  <td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Last 
                    name</span></div></td>
                  <td class='ss-round-inputs' width="50%"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="lastname" size="25" maxlength="100" class="textbox"><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>
                <tr>
                  <td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Company</span></div></td>
                  <td class='ss-round-inputs' width="50%"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="dealership" size="25" maxlength="100" class="textbox"><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>
                <tr> 
                  <td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Address</span></div></td>
                  <td class='ss-round-inputs' width="50%"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="saddress" size="25" maxlength="100" class="textbox"><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>
                <tr> 
                  <td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>City</span></div></td>
                  <td class='ss-round-inputs' width="50%"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="city" size="25" maxlength="100" class="textbox"><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>
                <tr> 
                  <td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>State/Province</span></div></td>
                  <td width="50%"> <select class="txtbox"  name="state" class="selectbox">
                      <option value=NA>Not Applicable</option>
                      <option value="AL">Alabama</option>
                      <option value="AK">Alaska</option>
                      <option value="AZ">Arizona</option>
                      <option value="AR">Arkansas</option>
                      <option value="CA">California</option>
                      <option value="CO">Colorado</option>
                      <option value="CT">Connecticut</option>
                      <option value="DE">Delaware</option>
                      <option value="DC">Dist. of Columbia</option>
                      <option value="FL">Florida</option>
                      <option value="GA">Georgia</option>
                      <option value="HI">Hawaii</option>
                      <option value="ID">Idaho</option>
                      <option value="IL">Illinois</option>
                      <option value="IN">Indiana</option>
                      <option value="IA">Iowa</option>
                      <option value="KS">Kansas</option>
                      <option value="KY">Kentucky</option>
                      <option value="LA">Louisiana</option>
                      <option value="ME">Maine</option>
                      <option value="MD">Maryland</option>
                      <option value="MA">Massachusetts</option>
                      <option value="MI">Michigan</option>
                      <option value="MN">Minnesota</option>
                      <option value="MS">Mississippi</option>
                      <option value="MO">Missouri</option>
                      <option value="MT">Montana</option>
                      <option value="NE">Nebraska</option>
                      <option value="NV">Nevada</option>
                      <option value="NH">New Hampshire</option>
                      <option value="NJ">New Jersey</option>
                      <option value="NM">New Mexico</option>
                      <option value="NY">New York </option>
                      <option value="NC">North Carolina</option>
                      <option value="ND">North Dakota</option>
                      <option value="OH">Ohio</option>
                      <option value="OK">Oklahoma</option>
                      <option value="OR">Oregon</option>
                      <option value="PA">Pennsylvania</option>
                      <option value="RI">Rhode Island</option>
                      <option value="SC">South Carolina</option>
                      <option value="SD">South Dakota</option>
                      <option value="TN">Tennessee</option>
                      <option value="TX">Texas</option>
                      <option value="UT">Utah</option>
                      <option value="VT">Vermont</option>
                      <option value="VA">Virginia</option>
                      <option value="WA">Washington</option>
                      <option value="WV">West Virginia</option>
                      <option value="WI">Wisconsin</option>
                      <option value="WY">Wyoming</option>
                      <option value="NA">---------------</option>
                      <option value=AB>Alberta</option>
                      <option value=BC>British Columbia</option>
                      <option value=MB>Manitoba</option>
                      <option value=NB>New Brunswick</option>
                      <option value=NF>Newfoundland</option>
                      <option value=NT>Northwest Territories</option>
                      <option value=NS>Nova Scotia</option>
                      <option value=NU>Nunavut</option>
                      <option value=ON>Ontario</option>
                      <option value=PE>Prince Edward Island</option>
                      <option value=QC>Quebec</option>
                      <option value=SK>Saskatchewan</option>
                      <option value=YT>Yukon Territory</option>
                      <option value="NA">---------------</option>
                      <option value="PR">Puerto Rico</option>
                    </select>
                   </td>
                </tr>
                <tr> 
                  <td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Zip/Postal Code</span></div></td>
                  <td class='ss-round-inputs' width="50%"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="szip" size="7" maxlength="7" class="textbox"><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>
<tr> 
<td width="50%"> 
<div align="right"><span class="contact"> <font color="ad0948">*</font> Country</span></div>
</td>
<td width="50%"> 
<select class="txtbox"  name="country" class="selectbox">
<option  selected>United States</option>
<option>Canada</option>
<option value=NA></option>
<option>Afghanistan</option>
<option>Albania</option>
<option>Algeria</option>
<option>Andorra</option>
<option>Angola</option>
<option>Anguilla</option>
<option>Antigua</option>
<option>Argentina</option>
<option>Armenia</option>
<option>Aruba</option>
<option>Ascension</option>
<option>Australia</option>
<option>Austria</option>
<option>Azerbaijan</option>
<option>Azores</option>
<option>Bahamas</option>
<option>Bahrain</option>
<option>Bangladesh</option>
<option>Barbados</option>
<option>Barbuda</option>
<option>Belgium</option>
<option>Belize</option>
<option>Benin</option>
<option>Bermuda</option>
<option>Bhutan</option>
<option>Bolivia</option>
<option>Bosnia-Herzegovina</option>
<option>Botswana</option>
<option>Brazil</option>
<option>British Virgin Islands</option>
<option>Brunei</option>
<option>Bulgaria</option>
<option>Burkina</option>
<option>Burma (Myanmar)</option>
<option>Burundi</option>
<option>Byelarus</option>
<option>Caicos Islands</option>
<option>Cambodia</option>
<option>Cameroon</option>
<option>Cape Verde</option>
<option>Cayman Islands</option>
<option>Central African Republic</option>
<option>Chad</option>
<option>Chile</option>
<option>China</option>
<option>Colombia</option>
<option>Comoros</option>
<option>Congo</option>
<option>Costa Rica</option>
<option>Croatia</option>
<option>Cuba</option>
<option>Cyprus</option>
<option>Czech Republic</option>
<option>Denmark</option>
<option>Djibouti</option>
<option>Dominica</option>
<option>Dominican Republic</option>
<option>East Timor</option>
<option>Ecuador</option>
<option>Egypt</option>
<option>El Salvador</option>
<option>Equatorial Guinea</option>
<option>Eritrea</option>
<option>Estonia</option>
<option>Ethiopia</option>
<option>Falkland Islands</option>
<option>Faroe Island</option>
<option>Fiji</option>
<option>Finland</option>
<option>Fortuna Islands</option>
<option>France</option>
<option>French Guiana</option>
<option>French Polynesia</option>
<option>Gabon</option>
<option>Gambia</option>
<option>Republic of Georgia</option>
<option>Germany</option>
<option>Ghana</option>
<option>Gibraltar</option>
<option>Greece</option>
<option>Greenland</option>
<option>Grenada</option>
<option>Grenadines</option>
<option>Guadeloupe</option>
<option>Guam</option>
<option>Guatemala</option>
<option>Guinea</option>
<option>Guinea-Bissau</option>
<option>Guyana</option>
<option>Haiti</option>
<option>Holland</option>
<option>Honduras</option>
<option>Hong Kong</option>
<option>Hungary</option>
<option>Iceland</option>
<option>India</option>
<option>Indonesia</option>
<option>Iran</option>
<option>Iraq</option>
<option>Ireland</option>
<option>Israel</option>
<option>Italy</option>
<option>Ivory Coast</option>
<option>Jamaica</option>
<option>Japan</option>
<option>Jordan</option>
<option>Kampuchea</option>
<option>Kazakhstan</option>
<option>Kenya</option>
<option>Kiribati</option>
<option>Korea, North</option>
<option>Korea, South</option>
<option>Kuwait</option>
<option>Kyrgyztan</option>
<option>Laos</option>
<option>Latvia</option>
<option>Lebanon</option>
<option>Lesotho</option>
<option>Liberia</option>
<option>Libya</option>
<option>Liechtenstein</option>
<option>Lithuania</option>
<option>Luxembourg</option>
<option>Macedonia</option>
<option>Madagascar</option>
<option>Madeira Islands</option>
<option>Malawi</option>
<option>Malaysia</option>
<option>Maldives</option>
<option>Mali</option>
<option>Malta</option>
<option>Martinique</option>
<option>Mauritania</option>
<option>Mauritius</option>
<option>Mexico</option>
<option>Miquelon</option>
<option>Moldova</option>
<option>Monaco</option>
<option>Mongolia</option>
<option>Montenegro</option>
<option>Montserrat</option>
<option>Morocco</option>
<option>Mozambique</option>
<option>Namibia</option>
<option>Nauru</option>
<option>Nepal</option>
<option>Netherlands</option>
<option>Netherlands Antilles</option>
<option>Nevis</option>
<option>New Caledonia</option>
<option>New Zealand</option>
<option>Nicaragua</option>
<option>Niger</option>
<option>Nigeria</option>
<option>Norway</option>
<option>Oman</option>
<option>Pakistan</option>
<option>Panama</option>
<option>Papua New Guinea</option>
<option>Paraguay</option>
<option>Peru</option>
<option>Philippines</option>
<option>Pitcairn Island</option>
<option>Poland</option>
<option>Portugal</option>
<option>Principe</option>
<option>Qatar</option>
<option>Reunion</option>
<option>Romania</option>
<option>Russia</option>
<option>Rwanda</option>
<option>Saipan</option>
<option>San Marino</option>
<option>Sao Tome</option>
<option>Saudi Arabia</option>
<option>Senegal</option>
<option>Serbia</option>
<option>Seychelles</option>
<option>Sierra leone</option>
<option>Singapore</option>
<option>Slovak Republic</option>
<option>Slovenia</option>
<option>Solomon Islands</option>
<option>Somalia</option>
<option>South Africa</option>
<option>Spain</option>
<option>Sri Lanka</option>
<option>St. Christopher</option>
<option>St. Helena</option>
<option>St. Lucia</option>
<option>St. Pierre</option>
<option>St. Vincent</option>
<option>Sudan</option>
<option>Surinam</option>
<option>Swaziland</option>
<option>Sweden</option>
<option>Switzerland</option>
<option>Syria</option>
<option>Taiwan R.O.C.</option>
<option>Tajikistan</option>
<option>Tanzania</option>
<option>Temen</option>
<option>Thailand</option>
<option>Tobago</option>
<option>Togo</option>
<option>Tonga</option>
<option>Trinidad</option>
<option>Tristan Da Cunha</option>
<option>Tunisia</option>
<option>Turkey</option>
<option>Turkmenistan</option>
<option>Turks</option>
<option>Tuvalu</option>
<option>Uganda</option>
<option>United Kingdom</option>
<option>Ukraine</option>
<option>United Arab Emirates</option>
<option>Uruguay</option>
<option>Uzbekistan</option>
<option>Vanuatu</option>
<option>Vatican City</option>
<option>Venezuela</option>
<option>Vietnam</option>
<option>Wallis</option>
<option>Western Samoa</option>
<option>Yemen</option>
<option>Yugoslavia</option>
<option>Zaire</option>
<option>Zambia</option>
<option>Zimbabwe</option>
</select>
</td>
</tr>
                <tr> 
                  <td width="50%" valign="middle"> <div align="right"><span class="contact"> 
                      <font color="ad0948">*</font>Phone#</span></div></td>
                  <td class='ss-round-inputs' width="50%"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="phone" type="text" class="textphone2" id="phone" onFocus="PhoneFocus(this.form.phone3)" size="15" ><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>
                <tr> 
                  <td width="50%"> <div align="right"><span class="contact"> Alternate#</span></div></td>
                  <td class='ss-round-inputs' > 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="fax" type="text" class="textbox" id="fax" size="15" ><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>
                <tr> 
                  <td width="50%"> <div align="right"><span class="contact"> <font color="ad0948">*</font>Email 
                      address</span></div></td>
                  <td class='ss-round-inputs' width="50%"> 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  type="text" name="semail" size="25" maxlength="100" class="textbox"><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>


                <tr> 
                  <td width="100%" colspan=2><HR></td>
                </tr>

            
<!-- COMMISSION AREA -->                <tr>
                  <td> <div align="right"><span class="contact"> Tier 1 Commission 
                    </span></div></td>
                  <td class='ss-round-inputs' > 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="commission" type="text" class="textbox" size="11" maxlength="100" value="<?php print($tier1aff); ?>"><img border="0" src="input-right.gif" width="7" >
                  <font size="1">(I.E. 40.00)</font></td>
                </tr>

				                <tr>
                  <td> <div align="right"><span class="contact"> Tier 2 Commission  
                    </span></div></td>
                  <td class='ss-round-inputs' > 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="tier2comm" type="text" class="textbox" size="11" maxlength="100" value="<?php print($tier2aff); ?>"><img border="0" src="input-right.gif" width="7" >
                  <font size="1">(I.E. 30.00)</font></td>
                </tr>

				                <tr>
                  <td> <div align="right"><span class="contact"> Tier 3 Commission  
                    </span></div></td>
                  <td class='ss-round-inputs' > 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="tier3comm" type="text" class="textbox" size="11" maxlength="100" value="<?php print($tier3aff); ?>"><img border="0" src="input-right.gif" width="7" >
                  <font size="1">(I.E. 10.00)</font></td>
                </tr>

				<!-- END COMMISSION AREA -->

				  <tr>
                  <td> <div align="right"><span class="contact"> Affiliate</span></div></td>
                  <td> <select class="txtbox"  name="affiliate_id">
					    <option value="" selected>Select if applicable</option>
					    <? echo "$user_select6"; ?>
						
					    </select> <font size="1">(ignored if Broker selected below is tied to an Affiliate)</font>
                  </td>
                </tr>

				  <tr>
                  <td> <div align="right"><span class="contact"> Tier 1 Broker</span></div></td>
                  <td> <select class="txtbox"  name="tier_id">
					    <option value="" selected>Select if applicable</option>
					    <? echo "$user_select5"; ?>
						
					    </select> <font size="1">(Affiliate will be looked up automatically, if applicable)</font>
                  </td>
                </tr>


                <tr> 
                  <td width="100%" colspan=2><HR></td>
                </tr>


                <tr>
                  <td> <div align="right"><span class="contact"> <font color="ad0948">*</font>Username</span></div></td>
                  <td class='ss-round-inputs' > 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="username" type="text" class="textbox" size="25" maxlength="100"><img border="0" src="input-right.gif" width="7" ></td>
                </tr>
                <tr>
                  <td> <div align="right"><span class="contact"> <font color="ad0948">*</font>Password</span></div></td>
                  <td class='ss-round-inputs' > 
<img border="0" src="input-left.gif" width="7" ><input class="txtbox"  name="password" type="text" class="textbox" id="password" size="25" maxlength="100"><img border="0" src="input-right.gif" width="7" > 
                  </td>
                </tr>
                <tr> 
                  <td width="50%">&nbsp; </td>
                  <td width="50%">&nbsp; </td>
                </tr>

  


                <tr> 
                  <td colspan="2"> <div align="left"><font color="ad0948" size="2">* 
                      required fields</font></div></td>
                </tr>
                <tr> 
                  <td width="50%"> <div align="right"> 
                      <input type="button" name="Button" value="Submit" class="button" onfocus="this.blur()"
onmouseover="this.className='buttonover';"
onmouseout="this.className='button';"
onmousedown="this.className='buttondown';"
onmouseup="this.className='buttonover';"
onClick="Check(this.form)">
                    </div></td>
                  <td width="50%"> <input type="reset" name="Submit2" value="Reset" class="button" onfocus="this.blur()"
onmouseover="this.className='buttonover';"
onmouseout="this.className='button';"
onmousedown="this.className='buttondown';"
onmouseup="this.className='buttonover';"> </td>
                </tr>
              </table>
</td>
</tr>
</table>
</td>
</tr>
</table>
</form>
<?
}else{
    header("Location: login.php");
    exit();
}

?>