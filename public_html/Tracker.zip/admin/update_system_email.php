<?php
extract ($_GET );
extract ($_POST );
include("connection.php");


if($_POST['emailtype'] !="sales"){
$sql = "UPDATE systememails SET
subject = \"$subject\",
name = \"$emailname\",
message = \"$message\",
activated = \"$activated\"
WHERE id = \"$emailid\"";

$result = @mysql_query($sql,$conn);
header("Location: systememail.php?emailid=$emailid&success=Email Updated!");  

}else if($_POST['emailtype'] =="sales"){
$sql = "UPDATE systememails SET
subject = \"$subject\",
message = \"$message\",
name = \"$emailname\",
activated = \"$activated\"
WHERE id = \"$emailid\"";

$result = mysql_query($sql,$conn);
header("Location: systememail.php?emailid=$emailid&success=Sales Email Updated!");  
}

exit;

?>