List of Prospects<BR><BR>

       <table border="1">

<?php

extract ($_GET );
extract ($_POST );
//require_once('../include/common.inc.php');
    include("connection.php");    
$todaydate = date("Y-m-d");
$todaydate2 = date("m-d-Y");

function dateDiff($dformat, $endDate, $beginDate) 
{ 
$date_parts1=explode($dformat, $beginDate); 
$date_parts2=explode($dformat, $endDate); 
$start_date=gregoriantojd($date_parts1[0], $date_parts1[1], $date_parts1[2]); 
$end_date=gregoriantojd($date_parts2[0], $date_parts2[1], $date_parts2[2]); 
return $end_date - $start_date; 
} 

 $query2 = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, autoscheduler, autoresponder, bautoresponder, cautoresponder FROM companyinfo WHERE companyid='1'";
    $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result2);
    while($row2=mysql_fetch_row($result2))
    {
        $companyid = $row2[0];
        $companyname = $row2[1];
        $companycontact = $row2[2];
        $companyemail = $row2[3];
        $companyreply = $row2[4];
        $companyaddress = $row2[5];
        $companycity = $row2[6];
        $companystate = $row2[7];
        $companyzip = $row2[8];                        
        $companyphone = $row2[9];         
        $companyfax = $row2[10];         
        $companywebsite = $row2[11];              
        $companyskin = $row2[12]; 
        $autoscheduler = $row2[13]; 
        $autoresponder = $row2[14]; 
        $bautoresponder = $row2[15]; 
        $cautoresponder = $row2[16]; 

    }
if($autoresponder == "Yes"){

$query = "SELECT name, email, address, city, state, zip, phone, DATE_FORMAT(createdate, \"%m-%d-%Y\") as createdate FROM clients where prospectclient = 'prospect' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $email = $row[1];
        $address = $row[2];
	  $city = $row[3];
	  $state = $row[4];
	  $zip = $row[5];
	  $phone = $row[6];
	  $createdate = $row[7];

$message ='';
$subject='';
$message2 ='';
$subject2='';

$sendday = dateDiff("-", $todaydate2, $createdate);
    $query2 = "SELECT id, subject, message, type, days FROM autoresponders WHERE type='prospect' and days='$sendday'";
          $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row2=mysql_fetch_row($result2))
          {
              $autoid           = $row2[0];
              $subject   = $row2[1];
              $message   = $row2[2];
              $type = $row2[3];
              $days = $row2[4];              
}  


if($message != ""){
             include("companystrip.php");
   include("clientstrip.php");
$EMAIL_Message = "$message2";
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";

$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
 ?>

<tr>

<td><?php print($name); ?></td>
<td><?php print($email); ?></td>
              <td>Email Sent</td>
<td><?php print($createdate); ?></td>

<td><?php print($sendday); ?></td>
<td><?php print($EMAIL_Subject); ?></td>

</tr>


<?php


}}}
 if($autoresponder == "No"){
?>
<BR> AUTORESPONDER IS TURNED OFF<BR>
<?php
}
    //mysql_close($conn);

?>

</table>







List of Clients<BR><BR>

 <table border="1">
<?php

if($cautoresponder == "Yes"){

$query = "SELECT name, email, address, city, state, zip, phone, DATE_FORMAT(createdate, \"%m-%d-%Y\") as createdate FROM clients where prospectclient = 'client' ";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $name = $row[0];
        $email = $row[1];
        $address = $row[2];
	  $city = $row[3];
	  $state = $row[4];
	  $zip = $row[5];
	  $phone = $row[6];
	  $createdate = $row[7];

$message ='';
$subject='';
$message2 ='';
$subject2='';

$sendday = dateDiff("-", $todaydate2, $createdate);
    $query2 = "SELECT id, subject, message, type, days FROM autoresponders WHERE type='client' and days='$sendday'";
          $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row2=mysql_fetch_row($result2))
          {
              $autoid           = $row2[0];
              $subject   = $row2[1];
              $message   = $row2[2];
              $type = $row2[3];
              $days = $row2[4];              
}  


if($message != ""){
             include("companystrip.php");
   include("clientstrip.php");
$EMAIL_Message = "$message2";
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";

$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
 ?>

<tr>

<td><?php print($name); ?></td>
<td><?php print($email); ?></td>
              <td>Email Sent</td>
<td><?php print($createdate); ?></td>

<td><?php print($sendday); ?></td>
<td><?php print($EMAIL_Subject); ?></td>

</tr>


<?php


}}}
 if($cautoresponder == "No"){
?>
<BR> CLIENT AUTORESPONDER IS TURNED OFF<BR>
<?php
}
    //mysql_close($conn);

?>

</table>





List of Brokers<BR><BR>

 <table border="1">
<?php

if($bautoresponder == "Yes"){

$query = "SELECT firstname, lastname, username, password, email, DATE_FORMAT(createdate, \"%m-%d-%Y\") as createdate FROM dealers";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    while($row=mysql_fetch_row($result))
    {
        $firstname = $row[0];
        $lastname = $row[1];
        $username = $row[2];
	  $password = $row[3];
	  $email = $row[4];
	  $createdate = $row[5];

$message ='';
$subject='';
$message2 ='';
$subject2='';

$sendday = dateDiff("-", $todaydate2, $createdate);
    $query2 = "SELECT id, subject, message, type, days FROM autoresponders WHERE type='broker' and days='$sendday'";
          $result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
          $cnt=0;
          while($row2=mysql_fetch_row($result2))
          {
              $autoid           = $row2[0];
              $subject   = $row2[1];
              $message   = $row2[2];
              $type = $row2[3];
              $days = $row2[4];              
}  


if($message != ""){
             include("companystrip.php");
   include("brokerstrip.php");
$EMAIL_Message = "$message2";
$EMAIL_Subject = "$subject2";
$EMAIL_From_Name = "$companyname";
$EMAIL_From = "$companyreply";

$HEADERS  = "MIME-Version: 1.0\r\n";
			$HEADERS .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$HEADERS .= "From: $EMAIL_From_Name <$EMAIL_From\r\n";
                $formsent = mail($email, $EMAIL_Subject, $EMAIL_Message, $HEADERS, "-f $companyreply");  
 ?>

<tr>

<td><?php print($firstname); ?> <?php print($lastname); ?></td>
<td><?php print($email); ?></td>
              <td>Email Sent</td>
<td><?php print($createdate); ?></td>

<td><?php print($sendday); ?></td>
<td><?php print($EMAIL_Subject); ?></td>

</tr>


<?php


}}
} if($bautoresponder == "No"){
?>
<BR> BROKER AUTORESPONDER IS TURNED OFF<BR>
<?php
}
?>
</table>