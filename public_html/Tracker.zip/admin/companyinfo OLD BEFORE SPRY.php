<?php
require_once('common.inc.php');
session_start();


extract ($_GET );
extract ($_SESSION );
extract ($_POST );
extract ($_SERVER );

$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
  include("connection.php");

      if($_POST['updatecl'] == 1)
      {
        
        $query = "UPDATE companyinfo SET
                companyname='" . mysql_real_escape_string($_POST['companyname']) . "',
                companyaddress='" . mysql_real_escape_string($_POST['companyaddress']) . "',
                companycity='" . mysql_real_escape_string($_POST['companycity']) . "',
                companystate='" . mysql_real_escape_string($_POST['companystate']) . "',
                companyzip='" . mysql_real_escape_string($_POST['companyzip']) . "',
                companyemail='" . mysql_real_escape_string($_POST['companyemail']) . "',
                companyfax='" . mysql_real_escape_string($_POST['companyfax']) . "',
                companyphone='" . mysql_real_escape_string($_POST['companyphone']) . "',
                companyreply='" . mysql_real_escape_string($_POST['companyreply']) . "',
                companywebsite='" . mysql_real_escape_string($_POST['companywebsite']) . "',
                autoscheduler='" . mysql_real_escape_string($_POST['autoscheduler']) . "',                
                dropdowncreditors='" . mysql_real_escape_string($_POST['dropdowncreditors']) . "',     
                dropdownbegin='" . mysql_real_escape_string($_POST['dropdownbegin']) . "',     
                dropdowntails='" . mysql_real_escape_string($_POST['dropdowntails']) . "',                                     
                paypal='" . mysql_real_escape_string($_POST['paypal']) . "',                
                paypal2='" . mysql_real_escape_string($_POST['paypal2']) . "',                
                ach='" . mysql_real_escape_string($_POST['ach']) . "',                
                creditcard='" . mysql_real_escape_string($_POST['creditcard']) . "',                
                singlefull='" . mysql_real_escape_string($_POST['singlefull']) . "',                
                singledownpay1='" . mysql_real_escape_string($_POST['singledownpay1']) . "',                
                singlepayment='" . mysql_real_escape_string($_POST['singlepayment']) . "',                
                coupledownpay1='" . mysql_real_escape_string($_POST['coupledownpay1']) . "',                
                couplefull='" . mysql_real_escape_string($_POST['couplefull']) . "',                
                couplepayment='" . mysql_real_escape_string($_POST['couplepayment']) . "',                
                threeinone='" . mysql_real_escape_string($_POST['threeinone']) . "',                
                months='" . mysql_real_escape_string($_POST['months']) . "',                
                perdelete='" . mysql_real_escape_string($_POST['perdelete']) . "',                
                passisssn='" . mysql_real_escape_string($_POST['passisssn']) . "',                
                livehuman='" . mysql_real_escape_string($_POST['livehuman']) . "',                
                companyskin='" . mysql_real_escape_string($_POST['companyskin']) . "',                

                companycontact='" . mysql_real_escape_string($_POST['companycontact']) . "'                
                WHERE companyid='1'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Company Info',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}
 
     $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, autoscheduler, reseller, htdiwebsite, adminsinglepayment1, adminsinglepayment2, admincouplepayment1, admincouplepayment2, single, couple, creditcard, paypal2, ach, singlefull, singledownpay1, singlepayment, couplefull, coupledownpay1, couplepayment, threeinone, paypal, months, perdelete, livehuman, dbname, dropdowncreditors, dropdownbegin, dropdowntails, passisssn, autoresponder, bautoresponder, cautoresponder, demanddraft, helpdesk, companyskin FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $autoscheduler = $row[12];          
        $reseller = $row[13];           
        $htdiwebsite = $row[14];           
        $adminsinglepayment1 = $row[15];
        $adminsinglepayment2 = $row[16];
        $admincouplepayment1 = $row[17];
        $admincouplepayment2 = $row[18];                                
        $single = $row[19];                                
        $couple = $row[20];                                
        $creditcard = $row[21];                 
        $paypal2 = $row[22];                 
        $ach = $row[23];                 
        $singlefull = $row[24];          
        $singledownpay1 = $row[25];          
        $singlepayment = $row[26];          
        $couplefull = $row[27];          
        $coupledownpay1 = $row[28];          
        $couplepayment = $row[29];          
        $threeinone = $row[30];          
        $paypal = $row[31];          
        $months = $row[32];          
        $perdelete = $row[33];          
        $livehuman = $row[34];          
        $dbname = $row[35];          
        $dropdowncreditors = $row[36];    
        $dropdownbegin = $row[37];    
        $dropdowntails = $row[38];                            
        $passisssn = $row[39];                            
        $autoresponder = $row[40];                            
        $bautoresponder = $row[41];                            
        $cautoresponder = $row[42];                            
        $demanddraft = $row[43];                            
        $helpdesk = $row[44];                            
        $companyskin = $row[45];                            
    }
$bgcolor = "c0c0c0";

      if($reseller == "Yes"){      
$resellerlabel = "CSO";
}else{
$resellerlabel = "Tracker";
}


$query = "SELECT message FROM systememails WHERE name='Client_Welcome'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $welcomeemail = $row[0];
    }

    //mysql_close($conn);

if ($preview!="yes"){

?>
         <title>System Settings</title>
                 <font color="red">  <B> <?php print($error); ?></B></font>
                        <?php
    include('main.php');
    include('template.php');

   ?>     
  





                        <form  action="companyinfo.php"    method="post" >
                            <input type="hidden" name="enrol" value="1">
                            <table
                            cellspacing="1" cellpadding="8" width="98%" bgcolor="#<?php print($bgcolor);?>" border="1">
                                <tbody>
                                <tr>
                                    <td width="34%" colspan="2">Company Name<br>

  
<B><?php print($companyname); ?></B>
<input type="hidden"  name="companyname" value="<?php print($companyname); ?>">



                                        
                                    </td>
                                    <td width="17%">Contact:<br>
 
<B><?php print($companycontact); ?></B>
<input type="hidden"  name="companycontact" value="<?php print($companycontact); ?>">




</td>
                                    <td width="51%" colspan="3">E-mail&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                        <input class="txtbox"  name="companyemail" value="<?php print($companyemail); ?>" size="40">
                                    <br>
                                    Reply E-mail&nbsp;&nbsp;&nbsp; 
                                        <input class="txtbox"  name="companyreply" value="<?php print($companyreply); ?>" size="40">
                                    </td>
                                </tr>
                                <tr>
                                    <td width="52%" colspan="3">Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                        <input class="txtbox"  size="53" name="companyaddress" value="<?php print($companyaddress); ?>">
                                    <br>
                                    City, State Zip&nbsp;&nbsp;&nbsp;&nbsp; 
                                        <input class="txtbox"  size="22" name="companycity" value="<?php print($companycity); ?>">,&nbsp; 
                                        <input class="txtbox" 
                                                         size="4" name="companystate" value="<?php print($companystate); ?>">&nbsp;&nbsp;&nbsp; 
                                        <input class="txtbox"  size="10" name="companyzip" value="<?php print($companyzip); ?>"></td>
                                    <td width="51%" colspan="3">
                                        <?php
                                if($reseller !="Yes")
                                 {
        ?>

                                        <b>Result Tracker Drop Down Lists</b><br>
                                        Creditors 
    
   

                                        <select  name="dropdowncreditors" >
                <option value="<?php echo $dropdowncreditors; ?>" selected><?php echo $dropdowncreditors; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select>&nbsp;&nbsp;Beginning Status 
    
   

                                        <select  name="dropdownbegin" >
                <option value="<?php echo $dropdownbegin; ?>" selected><?php echo $dropdownbegin; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select>&nbsp;&nbsp;Tail Ends 
    
   

                                        <select  name="dropdowntails" >
                <option value="<?php echo $dropdowntails; ?>" selected><?php echo $dropdowntails; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select>
              
            
<?php
                           }
        ?>

 


                                         </td>
                                </tr>
                                <tr>
                                    <td width="52%" colspan="3">Phone# 
                                        <input class="txtbox"  name="companyphone" value="<?php print($companyphone); ?>" size="29">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fax# 
                                        <input class="txtbox"  name="companyfax" value="<?php print($companyfax); ?>" size="28">
                                    </td>
                                    <td width="51%" colspan="3">AutoScheduler 
                                        <select name="autoscheduler" class="txtbox"  >
                <option value="<?php print($autoscheduler); ?>" selected><?php print($autoscheduler); ?></option>
                <?php
                                if($reseller !="Yes")
                                 {
        ?>
 <option value="OFF">OFF</option>
  <?php
                             }
        ?>

                <option value="ON">ON</option>
              </select>&nbsp;&nbsp;
              
              
              
              Hide Password in Emails? 
    
   

                                        <select  name="passisssn" >
                <option value="<?php echo $passisssn; ?>" selected><?php echo $passisssn; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>
                                </tr>
                                <tr>
                                    <td width="52%" bgcolor="#<?php print($bgcolor);?>" colspan="3">
                                    Tracker URL 
                                        <input class="txtbox"  name="companywebsite" value="<?php print($companywebsite); ?>" size="54">
                                    </td>
                                    <td width="51%" colspan="3">
                                    
                                    <p align="center">
                                    <b>Autoresponder Systems<br>
&nbsp;</b>Prospect -<?php print($autoresponder); ?>&nbsp;&nbsp;   Broker -<?php print($bautoresponder); ?>&nbsp;&nbsp;  Client -<?php print($cautoresponder); ?></td>
                                </tr>
                                <tr>
                                    <td width="16%" bgcolor="#<?php print($bgcolor);?>">
                                    <p align="center">
                                    <b>Account Type</b><BR><?php print($resellerlabel); ?> 
                                    </td>
                                    <td width="16%" bgcolor="#<?php print($bgcolor);?>">
                                    <p align="center"><b>Integrated Website</b><BR><?php print($htdiwebsite); ?></td>
                                    <td width="17%" bgcolor="#<?php print($bgcolor);?>">
                                    <p align="center"><b>Demand Draft</b><BR> 
<?php print($demanddraft); ?></td>
                                    <td width="17%">
                                    <p align="center"><b>Helpdesk</b><BR><?php print($helpdesk); ?></td>
                                    <td width="17%">&nbsp;
                                    </td>
                                    <td width="17%">&nbsp; </td>
                                </tr>
                               

                                
                                
                                
                                
                             
                             </table><tr>
                                    <td width="98%" colspan="6">&nbsp; 
</td>

                                </tr>
                                  <?php
                                if($htdiwebsite =="Yes")
                                 {
        ?>
<table cellspacing="1" cellpadding="8" width="98%" bgcolor="#<?php print($bgcolor);?>" border="1">
                                <tr>
                                
                                
                                
                                
                             
                             
                                    <td width="34%" colspan="2">
                                    <p align="right"><b><font color="#FFFFFF">
                                    Website Settings</font> </b></td>
                                    <td width="17%"> 
    
   

                                        Accept PayPal? 
    
   

                                        <select  name="paypal2" >
                <option value="<?php echo $paypal2; ?>" selected><?php echo $paypal2; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>
                                    
                                    <td width="34%" colspan="2">
                                    <p align="center">Accept ACH?
    
    

   

                                          <select name="ach" >
                <option value="<?php echo $ach; ?>" selected><?php echo $ach; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>
                                    <td width="17%"> 
    
   

                                    Accept Credit Card?
    
   
   

                                          <select name="creditcard" >
                <option value="<?php echo $creditcard; ?>" selected><?php echo $creditcard; ?></option>
                <option value="No">No</option>
                <option value="Yes">Yes</option>
                
              </select></td>

                                </tr>
                               

                                <tr>
                                
                                
                                
                                
                             
                             
                                    <td width="34%" colspan="2">
                                    <p align="right">PayPal email address:</td>
                                    
                                  
                                    <td width="17%"> 
                                        <input class="txtbox"  name="paypal" value="<?php print($paypal); ?>" size="28"></td>
                                    
                                    <td width="34%" align="right" colspan="2">
                                    How long will your monthly 
                                    payments last:<hl><hl><hl><font face="Arial,Helvetica,Geneva,Sans-serif,sans-serif" size="1"><br>
                                      (&quot;0&quot; means ongoing)</font><hl><FONT SIZE="1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">
                                          
                                          </FONT></td>
                                    <td width="17%"> 
    
   

                                        <input class="txtbox"  name="months" value="<?php print($months); ?>" size="28"></td>
             

                                </tr>
                               

                                <tr>
                                
                                
                                
                                
                             
                             
                                    <td width="34%" align="right" colspan="2">
                                    How much is an <b>Individual</b> Full Pay:</td>
                                    <td width="17%"> 
    
   

                                        <input class="txtbox"  name="singlefull" value="<?php print($singlefull); ?>" size="28"></td>
                                    
                                    <td width="34%" align="right" colspan="2">
                                    How much is an <b>Couple</b> 
                                    Full Pay:</td>
                                    <td width="17%"> 
    
   

                                        <input class="txtbox"  name="couplefull" value="<?php print($couplefull); ?>" size="28"></td>

                                </tr>
                               

                                <tr>
                                
                                
                                
                                
                             
                             
                                    <td width="34%" align="right" colspan="2">
                                    How much is setup:</td>
                                    <td width="17%"> 
    
   

                                        <input class="txtbox"  name="singledownpay1" value="<?php print($singledownpay1); ?>" size="28"></td>
                                    
                                    <td width="34%" align="right" colspan="2">
                                    How much is setup:</td>
                                    <td width="17%"> 
    
   

                                        <input class="txtbox"  name="coupledownpay1" value="<?php print($coupledownpay1); ?>" size="28"></td>

                                </tr>
                               

                                <tr>
                                
                                
                                
                                
                             
                             
                                    <td width="34%" align="right" colspan="2">
                                    How much are the monthly payments:</td>
                                    <td width="17%"> 
    
   

                                        <input class="txtbox"  name="singlepayment" value="<?php print($singlepayment); ?>" size="28"></td>
                                    
                                    <td width="34%" align="right" colspan="2">
                                    How much are monthly 
                                    payments:</td>
                                    <td width="17%"> 
    
   

                                        <input class="txtbox"  name="couplepayment" value="<?php print($couplepayment); ?>" size="28"></td>

                                </tr>
                               

                                <tr>
                                
                                
                                
                                
                             
                             
                                    <td width="34%" align="right" colspan="2">
                                    Website for 3in1 reports:</td>
                                    <td width="17%"> 
    
   

                                        <input class="txtbox"  name="threeinone" value="<?php print($threeinone); ?>" size="28"></td>
                                    
                                    <td width="34%" align="right" rowspan="2" colspan="2">
                                    LiveHuman Link:<br>
    
   

   

                                      <font face="Arial,Helvetica,Geneva,Sans-serif,sans-serif" size="1">
                                      <a target="_blank" href="http://www.livehuman.com">
                                      <font color="#008000">What is this?</font></a></font></td>
                                    <td width="17%" rowspan="2"> 
    
   

                                        <FONT SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">
    
    

   

                                          <textarea rows="5" name="livehuman" cols="32"><?php echo $livehuman; ?></textarea></FONT></td>

                                </tr>
                               

 
                                   
                                    
                                   

                               
                               
                                           <tr>
                                    <td width="34%" colspan="2">
                                    <p align="right">How much do you want to 
                                    charge per delete:<br>
    
   
    
   

   

                                      <font face="Arial,Helvetica,Geneva,Sans-serif,sans-serif" size="1">
                                      (Shown on warranty page)</font></td>
                                    <td width="17%"> 
                                        <input class="txtbox"  name="perdelete" value="<?php print($perdelete); ?>" size="28"></td>
                                </tr>
                               

 
                                   
                                    
                                   

                               
                               
                                        
                    
            
    </tbody>
                            </table>
     <?php
                                }else{
        ?>
<input type="hidden" name="paypal" value="<?php print($paypal); ?>" size="28">
<input type="hidden" name="paypal2" value="<?php print($paypal2); ?>" size="28">
<input type="hidden" name="ach" value="<?php print($ach); ?>" size="28">
<input type="hidden" name="creditcard" value="<?php print($creditcard); ?>" size="28">
<input type="hidden" name="singlefull" value="<?php print($singlefull); ?>" size="28">
<input type="hidden" name="singlepayment" value="<?php print($singlepayment); ?>" size="28">
<input type="hidden" name="singledownpay1" value="<?php print($singledownpay1); ?>" size="28">
<input type="hidden" name="couplefull" value="<?php print($couplefull); ?>" size="28">
<input type="hidden" name="coupledownpay1" value="<?php print($coupledownpay1); ?>" size="28">
<input type="hidden" name="couplepayment" value="<?php print($couplepayment); ?>" size="28">
<input type="hidden" name="months" value="<?php print($months); ?>" size="28">
<input type="hidden" name="perdelete" value="<?php print($perdelete); ?>" size="28">
<input type="hidden" name="threeinone" value="<?php print($threeinone); ?>" size="28">
<input type="hidden" name="livehuman" value="<?php print($livehuman); ?>" size="28">
<?php
  
                           }
        ?>
        
        
        <tr>
                                    <td width="98%" colspan="6">&nbsp; 
</td>

                                </tr>
                                 
                                 
                                 
<table cellspacing="1" cellpadding="8" width="98%" bgcolor="#<?php print($bgcolor);?>" border="1">
                                <tr>
                                
                                
                                
                                
                             
                             
                                    <td width="34%" valign="top">
                                    <p align="right"><b><font color="#FFFFFF">
                                    Company Skin</font> </b></td>
                                    <td width="68%" rowspan="2"> 
    
   

                                        <FONT SIZE="-1" FACE="Arial,Helvetica,Geneva,Sans-serif,sans-serif">
    
    

   

                                          <textarea rows="10" name="companyskin" cols="95"><?php echo $companyskin; ?></textarea></FONT></td>
                                    
                                </tr>
                               

                                <tr>
                                
                                
                                
                                
                             
                             
                                    <td width="34%">&nbsp;
                                    </td>
                                    
                                  
                                </tr>
                               

                                </table>



                            <input type="hidden" name="info" value="1">

                            <p>


                            <input type="hidden" name="updatecl" value="1">
                            <input type="submit" name="Update" value="Update">
                            </p>
                        </form>
                        
         
  
                        This is a preview of your 
skin using the Client Welcome email.<BR>
<center><iframe name="I1" src="companyinfo.php?preview=yes" width="850" height="500">
</center>
<?php 
}
?>



<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>