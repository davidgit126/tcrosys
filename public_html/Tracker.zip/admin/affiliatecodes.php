<center><b><u>Affiliate</u></b><br>
{AFFUSER}<BR>
{AFFPASS}<BR>
{A_FNAME}<BR>
{A_LNAME}<BR>
{AFFEMAIL}<BR>
