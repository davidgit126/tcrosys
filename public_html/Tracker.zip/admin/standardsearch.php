<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
    include('template.php');
if($_SESSION['usaccess']=="sales")
{
   ?>
<font color="red"><B>You do not have access to this area </font> <BR><BR>Sending email to adminstrator.................DONE</b>
 <?php
 }else{
 include("connection.php");

   $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, companyskin, upload, passisssn, demanddraft FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $companyskin = $row[12]; 
        $upload = $row[13]; 
        $passisssn = $row[14]; 
        $demanddraft = $row[15]; 
    }
     
   $sql2 = "SELECT * FROM dealers ORDER BY lastname";
  $result2 = @mysql_query($sql2,$conn);
  while ($row2 = mysql_fetch_array($result2)) {
  $ALLBROKER_username = $row2['username'];
  $ALLBROKER_id = $row2['dealer_id'];
  $ALLBROKER_fname = $row2['firstname'];
    $ALLBROKER_lname = $row2['lastname'];

  $BROKER_select .= "<option value=\"$ALLBROKER_id\">$ALLBROKER_lname, $ALLBROKER_fname ($ALLBROKER_username)</option>";
  }

?>

   <title>Search Clients</title>
   <?php
    include('main.php');
   ?> 

        <table background="bluestripshort.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0" width="503">
            <tr>
                <td background="titlebackground.gif" width="289" colspan="2"><form action="" method="get">
            <img border="0" src="leftupcorner.gif" width="32" height="29"><img border="0" src="search.gif" width="250" height="29"></td>
                <td background="titlebackground.gif" width="66">&nbsp;</td>
                <td background="titlebackground.gif">
            <img border="0" src="filler.gif" width="138" height="29"><img border="0" src="rightupcorner.gif" width="10" height="29"></td>

            </tr>
            <tr>
                <td width="128"><font color="#FFFFFF"><b>&nbsp;Client Name:</b></font> </td>
                <td width="161">
                    <input class="txtbox" type="text" name="cname" size="20">
                </td>
                <td width="66"><b><font color="#FFFFFF">&nbsp;</font></b><font color="#FFFFFF"><b>Status:</b></font></td>
                <td width="148">
                    <select name="status" class="txtbox"   >
                    <option value="" selected></option>
                <option value="pending">pending</option>
                <option value="active">active</option>
                <option value="scheduled">scheduled</option>
                <option value="complete">complete</option>
                <option value="canceled">canceled</option>
                <option value="contact1">contact1</option>
                <option value="contact2">contact2</option>
                <option value="contact3">contact3</option>                
                <option value="NSF">NSF</option> 
                
                                
              </select>
                </td>
            </tr>
            <tr>
                <td width="128">&nbsp;</td>
                <td width="161">&nbsp;</td>
                <td width="66">&nbsp;</td>
                <td width="148">&nbsp;</td>
            </tr>
            <tr>
                <td width="128"><font color="#FFFFFF"><b>&nbsp;Client E-mail:</b></font> </td>
                <td width="161">
                    <input class="txtbox" type="text" name="email" size="20">
                </td>
                <td width="66"><b><font color="#FFFFFF">&nbsp;ZIP: </font></b> </td>
                <td width="148">
                    <input class="txtbox" type="text" name="zip" size="20">
                </td>
            </tr>
            <tr>
                <td width="128">&nbsp;</td>
                <td width="161">
                    &nbsp;</td>
                <td width="66">&nbsp;</td>
                <td width="148">&nbsp;</td>
            </tr>
            <tr>
                <td width="128"><font color="#FFFFFF"><b>&nbsp;Billing Cycle:</b></font></td>
                <td width="161">
                    <input type="text" class="txtbox"  name="billingcycle" size="7">&nbsp;&nbsp; 
                                     <?php
    if($billingcycle != "")
    {
        ?>
               
<a target="_blank" href="checkprintall.php?billingcycle=<?php print($billingcycle);?>" style="font-weight: 700">
                                    <font color="#FFFFFF">Draft Checks</font></a>


  <?php
}
        ?></td>
                <td width="214" colspan="2">
                    &nbsp;</td>
            </tr>
            <tr>
                <td width="289" colspan="2"> <input type="hidden" name="f" value="1">
&nbsp;</td>
                <td width="214" colspan="2">
                    &nbsp;</td>
            </tr>
            <tr>
                <td width="66"><b><font color="#FFFFFF">&nbsp;Broker</font></b><font color="#FFFFFF"><b>:</b></font></td>
                <td width="148">
                    <select class="txtbox"  name="searchbroker">
					    <option value="<? echo "$searchbroker"; ?>" selected><? echo "$searchbroker"; ?></option>
					    <? echo "$BROKER_select"; ?>
					    <option value="">REMOVE</option>

					    </select>
                </td>
                <td width="214" colspan="2">
                    <p align="right">
                    <input type="submit" name="Find" value="Search Clients">&nbsp;&nbsp;&nbsp;</td>
            </tr>
            <tr>
                <td width="503" colspan="4"> 
                <img border="0" src="bottomsearch.gif" width="503" height="16"></td>
            </tr>
        </table>
       
    </form>

              <BR><BR><BR>
    
    
    
        <?php
    

    include("connection.php");
    if($_GET['f']==1)
    {


if( $_GET['status']  =='scheduled'){
$numcols = 5;
}else{
$numcols = 9;
}
        ?>
        
        <table background="bluestrip.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
        <tr>

            <td colspan="<?php print($numcols); ?>" background="titlebackground.gif">
            <img border="0" src="leftupcorner.gif" width="32" height="29"><img border="0" src="listofclients.gif" width="250" height="29"></td>

            <td background="titlebackground.gif">
            <img border="0" src="filler.gif" width="63" height="29"><img border="0" src="rightupcorner.gif" width="10" height="29"></td>


        </tr>
        <tr>
       
            <td style="border-left-style: solid; border-left-width: 1"><font color="#FFFFFF"><b>Client Name</b></font></td>
            <td><font color="#FFFFFF"><b>Address</b></font></td>
            <td><font color="#FFFFFF"><b>E-mail</b></font></td>
            <td><font color="#FFFFFF"><b>Setup&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
            Date</b></font></td>
  <?php
            if( $_GET['status']  =='scheduled')
{
?>
            <td><font color="#FFFFFF"><b>Notes</b></font></td>
 <?php
}else{
?>
            <td><font color="#FFFFFF"><b>Setup<br>
            Amount&nbsp;&nbsp;&nbsp; </b></font></td>
            <td><font color="#FFFFFF"><b>Monthly<br>
            Payment&nbsp;&nbsp;&nbsp;</b></font></td>
            <td><font color="#FFFFFF"><b>Due<br>
            Date&nbsp;&nbsp;&nbsp;</b></font></td>
            <td><font color="#FFFFFF"><b>Method&nbsp;&nbsp;&nbsp;</b></font></td>
            <td><font color="#FFFFFF"><b>Status</b></font></td>
           <?php
}
?>

           <td style="border-right-style: solid; border-right-width: 1"></td>
           
        </tr>
        <?php
        
        if (! $searchbroker) {
$brokerquery = "";
}else{
$brokerquery = " AND clients.broker_id='$searchbroker'";
}

          if(($_GET['cname'] != null) && ($_GET['cname'] != ''))
          {
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults, clients.showstatus, clients.plan, clients.sendtohtdi  FROM clients,billing WHERE clients.id=billing.clientid $brokerquery AND clients.prospectclient = 'Client' AND clients.clientdelete != 'yes' AND name LIKE('%" . mysql_real_escape_string($_GET['cname']) . "%')";
          }
          else if($_GET['zip'] != '')
          {
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults, clients.showstatus, clients.plan, clients.sendtohtdi  FROM clients,billing WHERE clients.id=billing.clientid $brokerquery AND clients.prospectclient = 'Client' AND clients.clientdelete != 'yes'  AND zip='" . mysql_real_escape_string($_GET['zip']) . "'";
          }
          else if(($_GET['email'] != null) && ($_GET['email'] != ''))
          {
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults, clients.showstatus, clients.plan, clients.sendtohtdi  FROM clients,billing WHERE clients.id=billing.clientid $brokerquery AND clients.prospectclient = 'Client' AND clients.clientdelete != 'yes'  AND email LIKE('" . mysql_real_escape_string($_GET['email']) . "%')";
          }
		 else if(($_GET['status'] != null) && ($_GET['status'] != ''))
          {
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults, clients.showstatus, clients.plan, clients.sendtohtdi  FROM clients,billing WHERE clients.id=billing.clientid $brokerquery AND clients.status LIKE('" . mysql_real_escape_string($_GET['status']) . "%')";
        

 }
 	 else if(($_GET['billingcycle'] != null) && ($_GET['billingcycle'] != ''))
          {
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults, clients.showstatus, clients.plan, clients.sendtohtdi  FROM clients,billing WHERE clients.id=billing.clientid $brokerquery AND billing.monthlydue LIKE('%" . mysql_real_escape_string($_GET['billingcycle']) . "%')";
        

 }

          
          else
             $query = "SELECT clients.id, clients.name, clients.address, clients.email, billing.paid, billing.auditfee, billing.monthlyfee, billing.monthlydue, billing.payment, clients.status, clients.dateresults, clients.showstatus, clients.plan, clients.sendtohtdi  FROM clients,billing WHERE clients.id=billing.clientid $brokerquery AND clients.status != 'canceled' AND clients.status != 'complete' AND clients.prospectclient = 'Client'  AND clients.clientdelete != 'yes' AND clients.reseller_id = 0";

          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          $cnt=0;
          while($row=mysql_fetch_row($result))
          {
              $id           = $row[0];
              $clientname   = $row[1];
              $address      = $row[2];
              $cemail       = $row[3];
              $paid         = $row[4];
              $auditfee       = $row[5];
              $monthlyfee	= $row[6];
              $monthlydue	= $row[7];
              $payment       = $row[8];
              $status       = $row[9];
              $dateresults  = $row[10];
              $showstatus  = $row[11];       
              $plan  = $row[12];  
              $sendtohtdi  = $row[13];     
              $cnt++;
              
          if ($status == "pending"){
	        $bgcolor = "FFFFBB"; 
	        
  }
    else if ($status == "canceled"){
	        $bgcolor = "663300";
	       
	}
    else if ($status == "NSF"){
	        $bgcolor = "FF00FF";
	       
	}
	  else if ($status == "contact1"){
	        $bgcolor = "FF4444";
	       
	}
  else if ($status == "contact2"){
	        $bgcolor = "FF0000";
	       
	}
  else if ($status == "inactive"){
	        $bgcolor = "888888";
	       
	}
  else if ($status == "contact3"){
	        $bgcolor = "888888";
	       
	}


else if ($status == "complete"){
	        $bgcolor = "008000";
	       
	}
else if ($status == "scheduled"){
	        $bgcolor = "FFCCCC";
	       
	}
else if ($plan == "Budget"){
	        $bgcolor = "FFFFFF";
	       
	}

	else if ($dateresults <= date("Y-m-d")){
	        $bgcolor = "FF6666";
	       
	}
else{

$bgcolor = "FFFFFF";
}
              ?>
              <tr>
              <td style="border-bottom-style: solid; border-bottom-width: 1; border-left-style:solid; border-left-width:1" bgcolor=<?php print($bgcolor); ?>><a href="setclient.php?cid=<?php print($id); ?>&cname=<?php print($clientname); ?>"><?php print($clientname); ?></a>&nbsp;</td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($address); ?>&nbsp;</td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><a href="mailto:<?php print($cemail); ?>"><?php print($cemail); ?></a>&nbsp;</td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($paid); ?>&nbsp;</td>
   <?php
            if( $_GET['status']  =='scheduled')
{
?>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($showstatus); ?>&nbsp;</td>
 <?php
}else{
?>

              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($auditfee); ?>&nbsp;</td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($monthlyfee); ?>&nbsp;</td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($monthlydue); ?>&nbsp;</td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($payment); ?>&nbsp;</td>
              <td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($status); ?>&nbsp;</td>
<?php
}
?>           
  <td style="border-bottom-style: solid; border-bottom-width: 1; border-right-style:solid; border-right-width:1" bgcolor=<?php print($bgcolor); ?>>
         
      
              
              
              <?php
    if($_SESSION['usaccess']=="full" AND $sendtohtdi != "Yes")

    {
        ?>
        <center>
<a href="delete.php?cid=<?php print($id);?>&cname=<?php print($clientname);?>">Delete</a>
                      </center>
              <?php
    }
        ?>
</td>
              
              
              
              </tr>
              <?php
          }
          mysql_close($conn);
          ?>
          </table>
          <?php
          if($cnt==0)
          {
              print("There are no matching records to your search criteria. Please try again.");
          }
    }
}

}
else
{
    header("Location: login.php");
    exit();
}

?>