<?php
require_once('common.inc.php');
session_start();

extract ($_GET );
extract ($_SESSION );
extract ($_POST );
extract ($_SERVER );
$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);


$nowday = date("d");
$nowmonthword = date("M");
$nowmonthword2 = date("F");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

$thismonth = date("Y-m");


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
include('template.php');
 include("connection.php");


    ?>
    
    
 <title>Broker Referral</title> 
  <?php
    if($_SESSION['brokers']=="Yes")
    {
    ?>

    <font color="red">  <B> <?php print($message); ?></B></font>
      <?php
    include('main.php');
    


	if ($startdate !="" and $enddate !="" and $startdate !="YYYY-MM-DD" and $enddate !="YYYY-MM-DD"){
$leadquery = "and ((clients.leadentered >= '$startdate' AND clients.leadentered <= '$enddate') or (clients.createdate >= '$startdate' AND clients.createdate <= '$enddate')) and clients.status != 'inactive' and clients.clientdelete != 'yes' ";
$salesquery= "createdate >= '$startdate' AND createdate <= '$enddate' and status != 'inactive' and clientdelete != 'yes' ";



	}else{
$leadquery = "and ((clients.leadentered like '$thismonth%') or (clients.createdate like '$thismonth%')) and clients.status != 'inactive' and clients.clientdelete != 'yes' ";
$salesquery= "createdate like '$thismonth%' and status != 'inactive' and clientdelete != 'yes' ";
$daterange = " - $nowmonthword2 $nowyear";
$startdate = "YYYY-MM-DD";
$enddate = "YYYY-MM-DD";
}


    $beginvar = "firstname=$firstname&lastname=$lastname&searchaffiliate=$searchaffiliate&email=$email&dealership=$dealership";

   ?>     

    
        <?php
    

    include("connection.php");
?>

<link href="calendar.css" type="text/css" rel="stylesheet" />
<script src="calendar.js" type="text/javascript"></script>
<script type="text/javascript"> 
function init() {
	calendar.set("startdate");
	calendar.set("enddate");
}
</script>
<h3 class="elegantLG" align="center">Detailed Broker Referral Report <?php print($daterange); ?></h3>
<form action="" method="get">
<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="350">
<tr><td class='ss-round-inputs' align="center"><b>&nbsp;Date Range:</b>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="startdate" id="startdate" size="11" value="<?php print($startdate); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" > <b>&nbsp;to&nbsp; </b> 
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="enddate" id="enddate" size="11" value="<?php print($enddate); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
<td><INPUT TYPE="image" SRC="go.png"></td>
</tr></table></form>

Disclaimer on numbers:  This report contains number of prospects and sales per broker.  If a joint sale has been made, this report, to accurately calculate a closing ratio, adds two prospects to the prospect list, even though only one prospect may have originally been submitted by said broker.  The number of prospects listed may not be the same as the data shown under Referral Statistics the Broker Status Sheet for the corresponding broker.
<?php  if($_SESSION['usname']=="admin"){  ?>
<BR><input type="button" style="position:relative;color: #07c;font-family: Georgia,serif;font-size: 12px;" name="OK" value="Export CSV" label="OK" onClick="javascript:window.location.href='brokersrefercsv.php?startdate=<?php print($startdate);?>&enddate=<?php print($enddate);?>';">
<?php } ?>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="90%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Detailed Broker Referral Report </td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

 <table id="rounded-corner" width="90%">

 <tr >
 <th class="rounded-company"></th>
 <th class="rounded-company">Name</th>
<th class="rounded-q1">Email</th>
<th class="rounded-q2">Phone</th>
<th class="rounded-q3">Company</th>
<th class="rounded-q3">Prospects</th>
<th class="rounded-q3">Sales</th>
<th class="rounded-q3">Closing Ratio</th>
</tr>


<?php
$bgcolor = "#e8edff";

       
$query2 = "SELECT COUNT(clients.id), clients.broker_id, dealers.firstname, dealers.lastname, dealers.dealership, dealers.email, dealers.telephone, clients.singlecouple FROM clients,dealers WHERE clients.broker_id=dealers.dealer_id and clients.broker_id !='' $leadquery and dealers.status !='9' GROUP BY clients.broker_id ORDER BY 1 DESC" ;
$result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
$numberprospects = 0;
while($row2=mysql_fetch_row($result2))
{
              $numberprospects           = $row2[0];
              $broker_id           = $row2[1];
              $brokerfirstname           = $row2[2];
              $brokerlastname           = $row2[3];
              $brokercompany = $row2[4];
              $brokeremail = $row2[5];
              $brokerphone = $row2[6];



 $totalprospects = $totalprospects + $numberprospects;
       $cnt++;
$numberclients = '0';
$query3 = "SELECT COUNT(id) FROM clients WHERE broker_id ='$broker_id' and clientdelete != 'yes' and prospectclient='Client' and $salesquery GROUP BY broker_id";
$result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
while($row3=mysql_fetch_row($result3))
{
              $numberclients = $row3[0];

 $totalclients = $totalclients + $numberclients;

}
$closingratio =0;
if ($numberprospects !="0"){
$closingratio = $numberclients/$numberprospects*100;
  $closingratio = number_format($closingratio, 2, '.', '');

}
              ?>
<tr bgcolor="#e8edff" onMouseOver="this.bgColor='#d0dafd';" onMouseOut="this.bgColor='#e8edff';">
<td ><?php print($cnt); ?></td>
<td ><a href="setbroker.php?cid=<?php print($broker_id); ?>&cname=<?php print($brokerfirstname); ?> <?php print($brokerlastname); ?>"><?php print($brokerlastname); ?>, <?php print($brokerfirstname); ?></a></td>
<td ><?php print($brokeremail); ?></td>
<td ><?php print($brokerphone); ?></td>

<td ><?php print($brokercompany); ?></td>
<td ><a href="prospectsearch.php?searchbroker=<?php print($broker_id); ?>&f=1"><?php print($numberprospects); ?></a></td>
<td ><a href="search.php?searchbroker=<?php print($broker_id); ?>&f=1"><?php print($numberclients); ?></a></td>
<td ><?php print($closingratio); ?>%</td>
</tr>
              <?php
          }
  $totalclosingratio = $totalclients/$totalprospects*100;
  $totalclosingratio = number_format($totalclosingratio, 2, '.', '');

  $tablerowdataend .="<tr bgcolor=$bgcolor><td>&nbsp;</td><td>&nbsp;</td></td><td></td><td><td>&nbsp;</td><td><b>$totalprospects</b></td><td><b>$totalclients</b></td><td><b>$totalclosingratio %</b></td></tr> ";     

		  		echo $tablerowdataend;	

          mysql_close($conn);
          ?>
          </table>
		  <script src="http://www.openjs.com/js/jsl.js" type="text/javascript"></script>
<script src="http://www.openjs.com/common.js" type="text/javascript"></script>

          <?php

}}
else
{
    header("Location: login.php");
    exit();
}

?>