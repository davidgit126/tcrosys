<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
 include("connection.php");
include('template.php');
    include('main.php');

      if($_POST['updatecl'] == 1)
      {
        
        $query = "UPDATE companyinfo SET
                companyname='" . mysql_real_escape_string($_POST['companyname']) . "',
                companyaddress='" . mysql_real_escape_string($_POST['companyaddress']) . "',
                companycity='" . mysql_real_escape_string($_POST['companycity']) . "',
                companystate='" . mysql_real_escape_string($_POST['companystate']) . "',
                companyzip='" . mysql_real_escape_string($_POST['companyzip']) . "',
                companyemail='" . mysql_real_escape_string($_POST['companyemail']) . "',
                companyfax='" . mysql_real_escape_string($_POST['companyfax']) . "',
                companyphone='" . mysql_real_escape_string($_POST['companyphone']) . "',
                companyreply='" . mysql_real_escape_string($_POST['companyreply']) . "',
                companywebsite='" . mysql_real_escape_string($_POST['companywebsite']) . "',
                autoscheduler='" . mysql_real_escape_string($_POST['autoscheduler']) . "',                
                dropdowncreditors='" . mysql_real_escape_string($_POST['dropdowncreditors']) . "',     
                dropdownbegin='" . mysql_real_escape_string($_POST['dropdownbegin']) . "',     
                dropdowntails='" . mysql_real_escape_string($_POST['dropdowntails']) . "',                                     
                paypal='" . mysql_real_escape_string($_POST['paypal']) . "',                
                paypal2='" . mysql_real_escape_string($_POST['paypal2']) . "',                
                ach='" . mysql_real_escape_string($_POST['ach']) . "',                
                creditcard='" . mysql_real_escape_string($_POST['creditcard']) . "',                
                singlefull='" . mysql_real_escape_string($_POST['singlefull']) . "',                
                singledownpay1='" . mysql_real_escape_string($_POST['singledownpay1']) . "',                
                singlepayment='" . mysql_real_escape_string($_POST['singlepayment']) . "',                
                coupledownpay1='" . mysql_real_escape_string($_POST['coupledownpay1']) . "',                
                couplefull='" . mysql_real_escape_string($_POST['couplefull']) . "',                
                couplepayment='" . mysql_real_escape_string($_POST['couplepayment']) . "',                
                threeinone='" . mysql_real_escape_string($_POST['threeinone']) . "',                
                months='" . mysql_real_escape_string($_POST['months']) . "',                
                perdelete='" . mysql_real_escape_string($_POST['perdelete']) . "',                
                livehuman='" . mysql_real_escape_string($_POST['livehuman']) . "',                

                companycontact='" . mysql_real_escape_string($_POST['companycontact']) . "'                
                WHERE companyid='1'";
        $result = mysql_query($query, $conn) or die("error:" . mysql_error());

$query = "INSERT INTO actionlog(username, action, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Update Company Info',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());
}
 
     $query = "SELECT companyid, companyname, companycontact, companyemail, companyreply, companyaddress, companycity, companystate, companyzip, companyphone, companyfax, companywebsite, autoscheduler, reseller, htdiwebsite, adminsinglepayment1, adminsinglepayment2, admincouplepayment1, admincouplepayment2, single, couple, creditcard, paypal2, ach, singlefull, singledownpay1, singlepayment, couplefull, coupledownpay1, couplepayment, threeinone, paypal, months, perdelete, livehuman, dbname, dropdowncreditors, dropdownbegin, dropdowntails FROM companyinfo WHERE companyid='1'";
    $result = mysql_query($query, $conn) or die("error:" . mysql_error());
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $companyid = $row[0];
        $companyname = $row[1];
        $companycontact = $row[2];
        $companyemail = $row[3];
        $companyreply = $row[4];
        $companyaddress = $row[5];
        $companycity = $row[6];
        $companystate = $row[7];
        $companyzip = $row[8];                        
        $companyphone = $row[9];         
        $companyfax = $row[10];         
        $companywebsite = $row[11];              
        $autoscheduler = $row[12];          
        $reseller = $row[13];           
        $htdiwebsite = $row[14];           
        $adminsinglepayment1 = $row[15];
        $adminsinglepayment2 = $row[16];
        $admincouplepayment1 = $row[17];
        $admincouplepayment2 = $row[18];                                
        $single = $row[19];                                
        $couple = $row[20];                                
        $creditcard = $row[21];                 
        $paypal2 = $row[22];                 
        $ach = $row[23];                 
        $singlefull = $row[24];          
        $singledownpay1 = $row[25];          
        $singlepayment = $row[26];          
        $couplefull = $row[27];          
        $coupledownpay1 = $row[28];          
        $couplepayment = $row[29];          
        $threeinone = $row[30];          
        $paypal = $row[31];          
        $months = $row[32];          
        $perdelete = $row[33];          
        $livehuman = $row[34];          
        $dbname = $row[35];          
        $dropdowncreditors = $row[36];    
        $dropdownbegin = $row[37];    
        $dropdowntails = $row[38];                            
    }
$bgcolor = "c0c0c0";


    //mysql_close($conn);
?>

                 <font color="red">  <B> <?php print($error); ?></B></font>
                    
     
  
  
       


<SCRIPT LANGUAGE="JavaScript">

function OpenWindow(url,winwidth,winheight) 
{
NewWindow=window.open(url,'descr','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=yes,scrollbars=yes,resizable=yes,copyhistory=no,width='+winwidth+',height='+winheight)
}
</SCRIPT>




                  
                        
                        
                        
                        
                          <?php
                                if($reseller =="Yes")
                                 {
            include "700score_connection2.php"; 
      

      ?>              
            
        
                        
                        
            <BR>               
            <center>
       <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="40%">
<tr><td background="titlebackground.gif" width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="100%">Credit History</td>
<td background="titlebackground.gif" width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>

          <table border="1" cellspacing="1" width="40%" id="AutoNumber1">
            <tr>
              <td width="20%">Date</td>
              <td width="20%">Credits Earned</td>
              <td width="60%">Details</td>
            </tr>
            <?php
            	
            	
            	    $query = "SELECT dealer_id  FROM dealers WHERE dbname='$dbname' limit 1";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $dealer_id = $row[0];
  
        }
            	
    $query = "SELECT DATE_FORMAT(purchasedate, \"%m-%d-%Y\") as purchasedate2, amountpurchased, id, dealer_id, details FROM bulktracking WHERE dealer_id='$dealer_id' ORDER BY purchasedate DESC";
    $result = mysql_query($query, $conn2);
    $col_count = mysql_num_fields($result);
    while($row=mysql_fetch_row($result))
    {
        $purchasedate = $row[0];
        $amountpurchased = $row[1];
        $purchaseid = $row[2];
        $dealer_id = $row[3];
        $details = $row[4];        
        
?>

            <tr>
            

              <td width="20%"><?php print($purchasedate); ?>
&nbsp;</td>
              <td width="20%"><?php print($amountpurchased/100); ?>&nbsp;</td>
              <td width="60%"><?php print($details); ?>&nbsp;</td>
              
            </tr>
        <?php
       }
       
      
 
       $query = "SELECT SUM(amountpurchased) as amountpurchased FROM bulktracking WHERE dealer_id='$dealer_id'";
$result = @mysql_query($query,$conn2);
while ($row = mysql_fetch_array($result)) {	
$totalamountpurchased = $row['amountpurchased'];
}


    
$query2 = "SELECT SUM(resellercredit) as resellercredit FROM clients";
$result2 = @mysql_query($query2,$conn);
while ($row2 = mysql_fetch_array($result2)) {	
$totalresellercredit = $row2['resellercredit'];

}



       mysql_close($conn);
?>              
   

          </table>
            </center>
</div>
          </TD>

                        
              
          
                        
                      <p align="center">
                        <font size="4" color="#008000"><u>Current Balance</u><BR><BR><?php print(($totalamountpurchased - $totalresellercredit)/100);?> credits
                        </font></p>                        
                        
                          <?php
                            }
        ?>
                             

                        <p align="left">
                        <a href="menu.php">Main Menu</a>
                        </p>
                        <p align="left">&nbsp;
                        </p>
                        <p align="left">&nbsp;
                        
                        </p>
                    
<?php
}
else
{
    header("Location: login.php");
    exit();
}

?>