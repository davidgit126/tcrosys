<?php
extract ($_GET );
extract ($_POST );
require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);


$nowday = date("d");
$nowmonthword = date("M");
$nowmonthword2 = date("F");
$nowmonth = date("m");
$nowyear = date("Y");

$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

$thismonth = date("Y-m");


if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
{
include('template.php');
 include("connection.php");


    ?>
    
    
 <title>Affiliate Creation Report</title> 
  <?php
    if($_SESSION['affiliate']=="Yes")
    {
    ?>

    <font color="red">  <B> <?php print($message); ?></B></font>
      <?php
    include('main.php');
    

	if ($startdate !="" and $enddate !=""){
$leadquery = "((leadentered >= '$startdate' AND leadentered <= '$enddate') or (createdate >= '$startdate' AND createdate <= '$enddate')) ";
$salesquery= "(createdate >= '$startdate' AND createdate <= '$enddate') ";
$affiliatecreatequery= "createdate >= '$startdate' AND createdate <= '$enddate' ";


	}else{
$leadquery = "((leadentered like '$thismonth%') or (createdate like '$thismonth%')) ";
$salesquery= "createdate like '$thismonth%' ";
$affiliatecreatequery= "createdate like '$thismonth%' ";
$daterange = " - $nowmonthword2 $nowyear";
$startdate = "YYYY-MM-DD";
$enddate = "YYYY-MM-DD";
}


    $beginvar = "firstname=$firstname&lastname=$lastname&searchaffiliate=$searchaffiliate&email=$email&dealership=$dealership";

   ?>     

    
        <?php
    

    include("connection.php");
?>

<link href="calendar.css" type="text/css" rel="stylesheet" />
<script src="calendar.js" type="text/javascript"></script>
<script type="text/javascript"> 
function init() {
	calendar.set("startdate");
	calendar.set("enddate");
}
</script>
<h3 class="elegantLG" align="center">affiliate Creation Report <?php print($daterange); ?></h3>
<form action="" method="get">
<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="350">
<tr><td class='ss-round-inputs' align="center"><b>&nbsp;Date Range:</b>
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="startdate" id="startdate" size="11" value="<?php print($startdate); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" > <b>&nbsp;to&nbsp; </b> 
<img border="0" src="http://www.tcrosystems.net/input-left.gif" width="7" ><input onclick="if(this.value == 'YYYY-MM-DD') this.value='';" class="txtbox" type="text" name="enddate" id="enddate" size="11" value="<?php print($enddate); ?>"><img border="0" src="http://www.tcrosystems.net/input-right.gif" width="7" ></td>
<td><INPUT TYPE="image" SRC="go.png"></td>
</tr></table></form>


<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="90%">
<tr><td width="31"><img border="0" src="leftupcorner.gif" width="31"></td>
<td class="miniheaders" background="titlebackground.gif" width="99%">Detailed affiliate Referral Report </td>
<td width="10"><img border="0" src="rightupcorner.gif" width="10" height="29"></td></tr>
</table>


<table width="90%" background="bluestrip.gif" border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" cellpadding="0">
<tr>
<td><font color="#FFFFFF"></font></td>
<td><font color="#FFFFFF"><b>Name</b></font></td>
<td><font color="#FFFFFF"><b>Email</b></font></td>
<td><font color="#FFFFFF"><b>Phone</b></font></td>
<td><font color="#FFFFFF"><b>Company</b></font></td>
<td><font color="#FFFFFF"><b>Prospects</b></font></td>
<td><font color="#FFFFFF"><b>Sales</b></font></td>
<td><font color="#FFFFFF"><b>Closing Ratio</b></font></td>

<td><font color="#FFFFFF"><b>Total Prospects</b></font></td>
<td><font color="#FFFFFF"><b>Total Sales</b></font></td>
<td><font color="#FFFFFF"><b>Total Closing Ratio</b></font></td>

</tr>
<?php
$bgcolor = "FFFFFF";

       
$query2 = "SELECT fname, lname, company, email, phone, id FROM sales_affiliates WHERE $affiliatecreatequery and sales_affiliates.status !='del' ORDER BY createdate DESC" ;
$result2 = mysql_query($query2, $conn) or die("error:" . mysql_error());
while($row2=mysql_fetch_row($result2))
{
              $affiliatefirstname           = $row2[0];
              $affiliatelastname           = $row2[1];
              $affiliatecompany           = $row2[2];
              $affiliateemail           = $row2[3];
              $affiliatephone = $row2[4];
              $affiliate_id = $row2[5];

       $cnt++;



$numberclients = '0';
$query = "SELECT COUNT(id) FROM clients WHERE affiliate_id ='$affiliate_id' and clientdelete != 'yes' and prospectclient='Client' and $salesquery GROUP BY affiliate_id";
$result = mysql_query($query, $conn) or die("error:" . mysql_error());
while($row=mysql_fetch_row($result))
{
 $numberclients = $row[0];
 $totalclients = $totalclients + $numberclients;
}


$numberprospects = '0';
$query3 = "SELECT COUNT(id) FROM clients WHERE affiliate_id ='$affiliate_id' and clientdelete != 'yes' and prospectclient='Prospect' and $leadquery GROUP BY affiliate_id";
$result3 = mysql_query($query3, $conn) or die("error:" . mysql_error());
while($row3=mysql_fetch_row($result3))
{
 $numberprospects = $row3[0];
 $totalprospects = $totalprospects + $numberprospects;
}


$closingratio =0;
if ($numberprospects !="0"){
$closingratio = $numberclients/$numberprospects*100;
  $closingratio = number_format($closingratio, 2, '.', '');
}





/////////TOTAL SALES QUERY
$totalnumberclients = '0';
$query4 = "SELECT COUNT(id) FROM clients WHERE affiliate_id ='$affiliate_id' and clientdelete != 'yes' and prospectclient='Client' GROUP BY affiliate_id";
$result4 = mysql_query($query4, $conn) or die("error:" . mysql_error());
while($row4=mysql_fetch_row($result4))
{
              $totalnumberclients = $row4[0];
			   $totalclients2 = $totalclients2 + $totalnumberclients;
}
/////////TOTAL LEAD QUERY
$totalnumberprospects = '0';
$query5 = "SELECT COUNT(id) FROM clients WHERE affiliate_id ='$affiliate_id' and clientdelete != 'yes' and prospectclient='Prospect'  GROUP BY affiliate_id";
$result5 = mysql_query($query5, $conn) or die("error:" . mysql_error());
while($row5=mysql_fetch_row($result5))
{
              $totalnumberprospects = $row5[0];
			  			   $totalprospects2 = $totalprospects2 + $totalnumberprospects;
}

$totalclosingratio =0;
if ($totalnumberprospects !="0"){
$totalclosingratio = $totalnumberclients/$totalnumberprospects*100;
  $totalclosingratio = number_format($totalclosingratio, 2, '.', '');
}


              ?>
<tr>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($cnt); ?></td>
<td style="border-bottom-style: solid; border-bottom-width: 1; border-left-style:solid; border-left-width:1" bgcolor=<?php print($bgcolor); ?>><a href="setaffiliate.php?cid=<?php print($affiliate_id); ?>&cname=<?php print($affiliatefirstname); ?> <?php print($affiliatelastname); ?>"><?php print($affiliatelastname); ?>, <?php print($affiliatefirstname); ?></a></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($affiliateemail); ?></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($affiliatephone); ?></td>

<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($affiliatecompany); ?></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><a href="prospectsearch.php?searchaffiliate=<?php print($affiliate_id); ?>&f=1"><?php print($numberprospects); ?></a></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><a href="search.php?searchaffiliate=<?php print($affiliate_id); ?>&f=1"><?php print($numberclients); ?></a></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($closingratio); ?>%</td>

<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><a href="prospectsearch.php?searchaffiliate=<?php print($affiliate_id); ?>&f=1"><?php print($totalnumberprospects); ?></a></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><a href="search.php?searchaffiliate=<?php print($affiliate_id); ?>&f=1"><?php print($totalnumberclients); ?></a></td>
<td style="border-bottom-style: solid; border-bottom-width: 1" bgcolor=<?php print($bgcolor); ?>><?php print($totalclosingratio); ?>%</td>
</tr>
              <?php
          }
  $totalclosingratio2 = $totalclients/$totalprospects*100;
  $totalclosingratio2 = number_format($totalclosingratio2, 2, '.', '');

  $totalclosingratio3 = $totalclients2/$totalprospects2*100;
  $totalclosingratio3 = number_format($totalclosingratio3, 2, '.', '');

  $tablerowdataend .="<tr bgcolor=$bgcolor><td>&nbsp;</td><td>&nbsp;</td></td><td></td><td><td>&nbsp;</td><td><b>$totalprospects</b></td><td><b>$totalclients</b></td><td><b>$totalclosingratio2 %</b></td> ";     
  $tablerowdataend .="<td><b>$totalprospects2</b></td><td><b>$totalclients2</b></td><td><b>$totalclosingratio3 %</b></td></tr> ";     

		  		echo $tablerowdataend;	

          mysql_close($conn);
          ?>
          </table>
		  <script src="http://www.openjs.com/js/jsl.js" type="text/javascript"></script>
<script src="http://www.openjs.com/common.js" type="text/javascript"></script>

          <?php

}}
else
{
    header("Location: login.php");
    exit();
}

?>