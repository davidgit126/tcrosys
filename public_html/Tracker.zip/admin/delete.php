<?php
extract ($_GET );
extract ($_POST );

require_once('common.inc.php');
session_start();



$year = date("Y");
$month = date("m");
$day = date("d");

$julian = "$year$month$day";

$entered_year = substr("$julian", 0, 4);
$entered_month = substr("$julian", 4, 2);
$entered_day = substr("$julian", 6, 2);



$hour = date("h");
$min = date("i");
$sec = date("s");
$ampm = date("a");

$tstamp = "$hour:$min:$sec$ampm";

if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1)
  {
include('template.php');

      if($_REQUEST['del'] == 1)
      {
          include("connection.php");

          $query = "UPDATE clients set clientdelete = 'yes' WHERE id='" . mysql_real_escape_string($_REQUEST['cid']) . "' ";
          $result = mysql_query($query, $conn) or die("error:" . mysql_error());

          
$query = "INSERT INTO actionlog(username, action, clientid, clientname, julian, tstamp)
                    VALUES(
                    '" . mysql_real_escape_string($_SESSION['usfname']) . "',
                    'Delete Client',
                    '$cid',
                    '$cname',
                    '$julian',
                    '$tstamp')"; 
                $result = mysql_query($query, $conn) or die("error:" . mysql_error());


          mysql_close($conn);

          print('<br>The Client has been Removed from the Database.  <a href="search.php">Click here</a> to go back to the Search Page.');
      }
      else
      {
          ?>
           <br> Are you sure you want to Delete the Client <b>"<?php print($_REQUEST['cname']); ?>"</b>  ?
           <br><br>
           <a href="delete.php?cid=<?php print($_REQUEST['cid']); ?>&del=1&cname=<?php print($_REQUEST['cname']); ?>">Yes</a>
            &nbsp; &nbsp; &nbsp; <a href="javascript:history.back()">No</a><?php
      }
}
else
{
    header("Location: login.php");
    exit();
}

?>